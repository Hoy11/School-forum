# Token 管理

## POST /api/user/current/create_session_token

创建会话 Token。

**Request (JSON Body):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| password | string | 是 | 当前用户密码 |
| duration | Duration | 是 | Token 有效期 |

**Response:**

| 字段 | 类型 | 说明 |
|---|---|---|
| token | string | 生成的 Session Token |

---

## GET /api/user/session_token_expire

获取当前会话 Token 过期信息。

**Request:** 无（从上下文读取）

**Response:**

| 字段 | 类型 | 说明 |
|---|---|---|
| valid | bool | 是否有效 |
| expire_time | *Time | 过期时间 |

---

## POST /api/user/api_token

创建 API Token。

**Request (JSON Body):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| name | string | 是 | Token 名称 |
| remark | string | 否 | 备注 |
| expire_time | Time | 是 | 过期时间 |
| ip_policy | CIDRArray | 否 | IP 策略 |

**Response:**

| 字段 | 类型 | 说明 |
|---|---|---|
| token | string | 生成的 API Token |

---

## GET /api/user/api_token

获取 API Token 列表。

**Request (Query Params):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | *int64 | 否 | 每页数量 |
| offset | *int64 | 否 | 偏移量 |

**Response:**

| 字段 | 类型 | 说明 |
|---|---|---|
| total | uint | 总数 |
| token | []singleTokenReply | Token 列表 |

**singleTokenReply:**

| 字段 | 类型 | 说明 |
|---|---|---|
| id | uint | Token ID |
| name | string | Token 名称 |
| remark | string | 备注 |
| prefix | string | Token 前缀 |
| expire_time | string | 过期时间 |
| is_enabled | bool | 是否启用 |
| ip_policy | CIDRArray | IP 策略 |

---

## DELETE /api/user/api_token

删除 API Token。

**Request (JSON Body):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ids | []uint | 是 | 要删除的 Token ID 列表 |

**Response:** `data: null`
