# 日志查询 - Bot 日志

## POST /api/bot_log/record/list

查询 Bot 记录日志列表。

**Request (JSON Body):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | int | 否 | 每页数量 |
| offset | int | 否 | 偏移量 |
| **BasicFilter 筛选字段:** | | | |
| log_id | *StringArrayQuery | 否 | WAF 日志 ID |
| site_uuid | *IntQuery | 否 | 站点 UUID |
| bot_config_id | *IntQuery | 否 | Bot 配置 ID |
| country | *StringArrayQuery | 否 | 国家 |
| province | *StringArrayQuery | 否 | 省份 |
| host | *CIDRQuery | 否 | 主机 |
| src_ip | *CIDRQuery | 否 | 源 IP |
| protocol | *StringArrayQuery | 否 | 协议 |
| http_body_is_abandoned | *StringArrayQuery | 否 | HTTP 体是否丢弃 |
| req_http_body_is_truncate | *StringArrayQuery | 否 | 请求体是否截断 |
| rsp_http_body_is_truncate | *StringArrayQuery | 否 | 响应体是否截断 |
| dest_ip | *CIDRQuery | 否 | 目标 IP |
| dest_port | *StringQuery | 否 | 目标端口 |
| src_port | *StringQuery | 否 | 源端口 |
| url_path | *StringQuery | 否 | URL 路径 |
| verify_mode | *StringArrayQuery | 否 | 验证模式 |
| timestamp | *TimestampIntQuery | 否 | 时间戳 |
| timestamp_tsrange | *TimestampStringQuery | 否 | 时间戳范围 |

**Response:**

| 字段 | 类型 | 说明 |
|---|---|---|
| total | int64 | 总数 |
| items | []*BotLog | 日志列表 |

**BotLog:**

| 字段 | 类型 | 说明 |
|---|---|---|
| id | string | 日志 ID |
| bot_config_id | string | Bot 配置 ID |
| bot_config_name | string | Bot 配置名称 |
| site_uuid | string | 站点 UUID |
| website_name | string | 站点名称 |
| src_ip | string | 源 IP |
| verify_mode | object | 验证模式 `{value: int8, translation: string}` |
| challenge_id | string | Challenge ID |
| event_id | string | 事件 ID |
| log_id | string | WAF 日志 ID |
| waf_id | uint | WAF ID |
| waf_name | string | WAF 名称 |
| waf_deleted | bool | WAF 是否已删除 |
| timestamp | string | 时间戳 |
| is_bot | int | 是否 Bot |
| country | string | 国家 |
| province | string | 省份 |
| detector | string | 检测器 |
| dest_ip | string | 目标 IP |
| dest_port | int | 目标端口 |
| src_port | int | 源端口 |

---

## GET /api/bot_log/record/detail

获取 Bot 记录日志详情。

**Request:** Query 参数 `challenge_id`（string）

**Response:**

| 字段 | 类型 | 说明 |
|---|---|---|
| data | []*BotLogDetail | 日志详情列表 |

**BotLogDetail:** 在 BotLog 基础上扩展：

| 扩展字段 | 类型 | 说明 |
|---|---|---|
| req_header | string | 请求头 |
| req_body | string | 请求体 |
| website | string | 站点 |

---

## DELETE /api/bot_log/record/delete

删除 Bot 记录日志。

**Request (JSON Body):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ids | []string | 否 | 日志 ID 列表 |
| all | bool | 否 | 是否删除全部 |
| （支持同 record/list 的 BasicFilter 筛选字段） | | 否 | 按条件批量删除 |

**Response:** `data: null`

---

## POST /api/bot_log/result/list

查询 Bot 结果日志列表。请求与响应结构同 `POST /api/bot_log/record/list`。

---

## GET /api/bot_log/result/detail

获取 Bot 结果日志详情。

**Request:** Query 参数 `id`（string）

**Response:** 同 `GET /api/bot_log/record/detail`

---

## DELETE /api/bot_log/result/delete

删除 Bot 结果日志。请求结构同 `DELETE /api/bot_log/record/delete`。
