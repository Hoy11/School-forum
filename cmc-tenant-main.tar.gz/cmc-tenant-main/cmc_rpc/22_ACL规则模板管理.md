# ACL规则模板管理（WAF 代理 API）

> 以下 API 均为 WAF 实例侧的接口，纵横通过反向代理访问。
> 代理请求需在 Header 中携带 `Proxy: <instance_id>` 和 `ProxyPage: off`。

## GET /api/ACLRuleTemplateAPI

获取 ACL 规则模板列表。

**请求（Query Params）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| offset | int | 否 | 偏移量 |
| count | int | 否 | 每页数量 |

**响应：** `PaginationResponse<ACLRuleTemplate>` 或 `ACLRuleTemplate[]`

**ACLRuleTemplate：**

| 字段 | 类型 | 说明 |
|---|---|---|
| id | uint64 | 模板 ID |
| name | string | 模板名称 |
| action | object | 动作配置 |
| match_method | object | 匹配方式 |
| is_enabled | bool | 是否启用 |
| dry_run | *bool | 试运行模式 |
| version | int | 版本 |

---

## POST /api/ACLRuleTemplateAPI

创建 ACL 规则模板。

**请求（JSON Body）：** 同 ACLRuleTemplate 结构（不含 id）

**响应：** 创建后的 ACLRuleTemplate 对象

---

## PUT /api/ACLRuleTemplateAPI

更新 ACL 规则模板。

**请求（JSON Body）：** 同 ACLRuleTemplate 结构（需含 id）

**响应：** 更新后的 ACLRuleTemplate 对象

---

## DELETE /api/ACLRuleTemplateAPI

删除 ACL 规则模板。

**请求（JSON Body）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id__in | uint[] | 否 | 要删除的模板 ID 列表 |
| ids | uint[] | 否 | 同 id__in |

**响应：** `data: null`

---

## PUT /api/EnableDisableACLRuleTemplateAPI

启用/禁用 ACL 规则模板。

**请求（JSON Body）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id__in | uint[] | 否 | 模板 ID 列表 |
| ids | uint[] | 否 | 同 id__in |
| action | string | 是 | `enable` / `disable` |

**响应：** `data: null`

---

## GET /api/ACLRuleAPI

获取 ACL 规则列表。

**请求（Query Params）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| acl_rule_template_id | uint | 是 | ACL 规则模板 ID |
| server_ts | bool | 否 | 是否使用服务器时间 |

**响应：** `SimpleAclTemplateRuleModel[]`

---

## POST /api/ACLRuleAPI

创建 ACL 规则。

**请求（JSON Body）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| acl_rule_template_id | uint | 是 | 模板 ID |
| targets | string[] | 是 | 目标列表 |

**响应：** `SimpleAclTemplateRuleModel[]`

---

## DELETE /api/ACLRuleAPI

删除 ACL 规则。

**请求（JSON Body）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id | uint | 是 | 规则 ID |
| add_to_white_list | bool | 否 | 是否加入白名单 |

**响应：** `data: null`
