# SSL证书管理（WAF 代理 API）

> 以下 API 均为 WAF 实例侧的接口，纵横通过反向代理访问。
> 代理请求需在 Header 中携带 `Proxy: <instance_id>` 和 `ProxyPage: off`。

## GET /api/CertAPI

获取 SSL 证书列表或单个证书。

**请求（Query Params）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id | uint | 否 | 证书 ID（传则返回单个） |
| offset | int | 否 | 偏移量 |
| count | int | 否 | 每页数量 |

**响应：**

不传 id 返回 `SSLCertModel[]`（或 `PaginationResponse<SSLCertModel>`），传 id 返回单个 `SSLCertModel`。

**SSLCertModel：**

| 字段 | 类型 | 说明 |
|---|---|---|
| id | uint | 证书 ID |
| name | string | 名称 |
| password | string | 密码 |
| info | CertInfo | 证书信息 |
| websites | SimpleWebsite[] | 关联站点列表 |
| is_mgt_api_cert | bool | 是否管理接口证书 |
| create_time | int | 创建时间 |
| type | int | 1=普通证书, 2=国密证书 |
| file_names | string[] | 文件名列表 |

**CertInfo：**

| 字段 | 类型 | 说明 |
|---|---|---|
| serial | string | 序列号 |
| issuer | string | 颁发者 |
| domains | string[] | 域名列表 |
| not_before | string | 生效时间 |
| not_after | string | 过期时间 |

**SimpleWebsite：**

| 字段 | 类型 | 说明 |
|---|---|---|
| id | uint | 站点 ID |
| name | string | 站点名称 |
| server_names | string[] | 域名列表 |

---

## POST /api/UploadSSLCertAPI

上传 SSL 证书（multipart/form-data）。

**请求（Form Data）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| crt_file | File | 是 | 证书文件 |
| key_file | File | 否 | 私钥文件 |
| password | string | 是 | 密码 |
| name | string | 否 | 名称 |
| type | string | 否 | 1=普通证书, 2=国密证书 |
| enc_crt_file | File | 否 | 国密证书文件 |
| enc_key_file | File | 否 | 国密私钥文件 |

**响应：** 创建后的 SSLCertModel 对象

---

## POST /api/EditSSLCertAPI

编辑 SSL 证书（multipart/form-data，支持重新上传证书文件）。

**请求（Form Data）：** 同 UploadSSLCertAPI，额外：

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id | string | 是 | 证书 ID |

**响应：** 更新后的 SSLCertModel 对象

---

## PUT /api/CertAPI

更新 SSL 证书信息（非文件字段）。

**请求（JSON Body）：** 同 SSLCertModel 结构（需含 id）

**响应：** 更新后的 SSLCertModel 对象

---

## DELETE /api/CertAPI

删除 SSL 证书。

**请求（JSON Body）：**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| id__in | uint[] | 否 | 要删除的证书 ID 列表 |
| ids | uint[] | 否 | 同 id__in |
| delete_all_resources | bool | 否 | 删除全部 |

**响应：** `data: null`
