# 日志查询 - ACL 日志

## POST /api/acl_log/list

查询 ACL 日志列表。

**Request (JSON Body):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| count | int | 否 | 每页数量 |
| offset | int | 否 | 偏移量 |
| **BasicFilter 筛选字段:** | | | |
| log_id | *StringArrayQuery | 否 | WAF 日志 ID |
| acl_rule_template_id__in | *IntQuery | 否 | ACL 规则模板 ID |
| timestamp | *TimestampIntQuery | 否 | 时间戳 |
| target | *StringQuery | 否 | 目标 |
| timestamp_tsrange | *TimestampStringQuery | 否 | 时间戳范围 |

**Response:**

| 字段 | 类型 | 说明 |
|---|---|---|
| total | int64 | 总数 |
| items | []*AclLog | 日志列表 |

**AclLog:**

| 字段 | 类型 | 说明 |
|---|---|---|
| id | string | 日志 ID |
| origin_id | int | 原始 ID |
| waf_id | uint | WAF ID |
| waf_name | string | WAF 名称 |
| timestamp | string | 时间戳 |
| acl_rule_target | string | ACL 规则目标 |
| acl_rule_template | ACLRuleTemplate | ACL 规则模板 |
| acl_rule_template_id | string | ACL 规则模板 ID |
| count | string | 计数 |
| waf_deleted | bool | WAF 是否已删除 |

**ACLRuleTemplate:**

| 字段 | 类型 | 说明 |
|---|---|---|
| id | uint64 | 模板 ID |
| name | string | 模板名称 |
| action | map[string]interface{} | 动作 |
| dry_run | *bool | 试运行模式 |
| match_method | map[string]interface{} | 匹配方式 |
| status | string | 状态 |

---

## DELETE /api/acl_log/delete

删除 ACL 日志。

**Request (JSON Body):**

| 字段 | 类型 | 必填 | 说明 |
|---|---|---|---|
| ids | []string | 是 | 日志 ID 列表 |
| all | bool | 否 | 是否删除全部 |
| （支持同 list 的 BasicFilter 筛选字段） | | 否 | 按条件批量删除 |

**Response:** `data: null`
