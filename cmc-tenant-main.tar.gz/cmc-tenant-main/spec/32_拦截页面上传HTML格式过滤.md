---
issue_key: 拦截页面上传HTML格式过滤
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: shicheng
merge_to: main
estimated_loc: 18
priority: medium
---

# DESCRIPTION

原始需求: 防护管理拦截页面增加 HTML 格式过滤功能，确保上传内容有效可用，上传成功及失败均有有效提示。
背景: 拦截页面上传功能当前未在 CMC 侧对齐雷池 SafeLine `23.01.014_r6` 的处置逻辑。雷池后端仅接受 `.html` 后缀，前端限制自定义拦截页面大小：普通模式 128KB，硬件透明桥模式 10KB。
目标: CMC 前端体验与后端兜底均对齐雷池：仅允许小写 `.html`，拒绝 `.htm` / `.HTML` / 无后缀等文件；限制上传大小；上传失败显示 CMC 后端归一化后的中文提示。

# DESIGN

### 现状问题

| 层 | 问题 | 对比 SSL 证书上传 |
|---|---|---|
| 层 | 问题 | 雷池 `23.01.014_r6` 行为 |
|---|---|---|
| 前端 onChange | 未限制上传大小 | `handleLazyUpload`：透明桥 10KB，其它 128KB |
| 前端 catch | 只显示"上传失败"，不展示 CMC 后端归一化错误 | 上传失败应能显示后端统一后的中文提示 |
| 后端 BlockPageUpload | 透传 multipart 到 Captain，不做 CMC 侧兜底 | `UploadForbiddenPageAPI` 仅接受 `.html` 后缀 |

### 修复：前端大小限制 + 后端 `.html`/大小兜底 + 错误提示完善

#### 1. 前端 `BlockPage.tsx` — 对齐雷池大小限制

前端不做后缀拦截，格式由后端与 Captain 统一兜底；前端仅做雷池同款大小限制：
```tsx
get uploadMaxSizeKB(): number {
  const selected = this.wafOptions.find(w => w.captain_instance_id === this.wafId)
  return selected?.operation_mode === WorkGroupOperationMode.HardwareTransparentBridging ? 10 : 128
}

onChange: (f: any) => {
  if (f.raw && f.raw.size > this.uploadMaxSizeKB * 1024) {
    this.$message.error(`自定义拦截页面最大为 ${this.uploadMaxSizeKB} KB`)
    this.uploadFile = null
    ;(this.$refs.bpUpload as any)?.clearFiles()
    return
  }
  this.uploadFile = f.raw
}
```

**完善 catch 错误提示**：
```tsx
catch (e: any) {
  this.$message.error(e?.response?.data?.msg || '上传失败')
}
```
只展示 CMC 后端统一后的 `msg`，不直接透传 Captain 原始 `e.message`。

#### 2. 后端 `block_page.go` — BlockPageUpload 加 `.html` 与大小校验

在 `c.MultipartForm()` 之后、构建 `formUnits` 之前加校验：
```go
maxSizeKB := blockPageUploadMaxSizeKB(instanceID, form.Value)
for _, files := range form.File {
    for _, f := range files {
        if filepath.Ext(f.Filename) != ".html" {
            c.JSON(http.StatusBadRequest, gin.H{"err": "invalid_format", "msg": "仅支持 .html 格式文件", "data": ""})
            return
        }
        if f.Size > int64(maxSizeKB*1024) {
            c.JSON(http.StatusBadRequest, gin.H{"err": "file_too_large", "msg": fmt.Sprintf("自定义拦截页面最大为 %d KB", maxSizeKB), "data": ""})
            return
        }
    }
}
```

- 与雷池后端 `endswith(".html")` 行为一致：只允许小写 `.html`
- `.htm`、`.HTML`、无后缀均拒绝
- 大小限制与雷池前端一致：透明桥 10KB，其它 128KB
- 后端优先从 Captain `/api/group/detail` 获取 WAF 模式；失败时按默认 128KB 兜底
- `filepath.Ext("page")` 返回空字符串 → 无扩展名文件被拒绝（预期行为，拦截页面必须是 HTML）
- 校验在构建 `formUnits` 之前，不会执行后续 Captain 请求和映射写入
- `comment` 与 `operation_mode` 字段在 `form.Value` 中，不受文件校验影响，转发 Captain 时会过滤 `captain_instance_id`

#### 3. 不做的事

- ❌ 不做 HTML 内容解析/校验（检查 `<html>` 标签、XSS 过滤等）——过度设计，Captain 自身负责内容安全
- ❌ 不改 Captain API 端点或响应格式——差异在 handler 层消化原则不变

### 影响评估

| 功能 | 是否受影响 | 原因 |
|---|---|---|
| 拦截页面列表 | ❌ 不影响 | 只改了 BlockPageUpload handler |
| 拦截页面删除 | ❌ 不影响 | 删除走 BlockPageDelete，不涉及上传 |
| 拦截页面下载 | ❌ 不影响 | 下载走 BlockPageDownload |
| 防护策略引用拦截页面 | ❌ 不影响 | `forbidden_page_config` 引用 name hash，不受影响 |
| 映射表同步 | ❌ 不影响 | 上传成功后 `writeMapping` 逻辑不变，上传失败不会到达该步 |
| admin/tenant 权限 | ❌ 不影响 | 校验在 `requireInstanceID` 之后，不影响权限流程 |

# STEPS

## 1. 修改前端 BlockPage.tsx

文件: `frontend/packages/skyview-web/src/views/Network/Management/BlockPage.tsx`

### 1.1 onChange 加大小限制

```diff
- <el-upload {...{ props: { onChange: (f: any) => { this.uploadFile = f.raw }, onRemove: () => { this.uploadFile = null } } }} drag action="" auto-upload={false} limit={1} ref="bpUpload">
+ <el-upload {...{ props: { onChange: (f: any) => {
+   if (f.raw && f.raw.size > this.uploadMaxSizeKB * 1024) {
+     this.$message.error(`自定义拦截页面最大为 ${this.uploadMaxSizeKB} KB`)
+     this.uploadFile = null
+     ;(this.$refs.bpUpload as any)?.clearFiles()
+     return
+   }
+   this.uploadFile = f.raw
+ }, onRemove: () => { this.uploadFile = null } } }} drag action="" auto-upload={false} limit={1} ref="bpUpload">
```

### 1.2 补充上传大小与错误提示

```diff
 const fd = new FormData()
 fd.append('file', this.uploadFile)
+const selected = this.wafOptions.find(w => w.captain_instance_id === this.wafId)
+if (selected?.operation_mode) {
+  fd.append('operation_mode', selected.operation_mode)
+}

  } catch {
-   this.$message.error('上传失败')
+ } catch (e: any) {
+   this.$message.error(e?.response?.data?.msg || '上传失败')
  }
```

## 2. 修改后端 block_page.go

文件: `gateway/server/apis/captain/handler/block_page.go`

### 2.1 新增 import

```diff
  import (
+   "path/filepath"
      ...
  )
```

### 2.2 BlockPageUpload 加格式和大小校验

在 `c.MultipartForm()` 之后、`var formUnits` 之前插入：

```go
maxSizeKB := blockPageUploadMaxSizeKB(instanceID, form.Value)
for _, files := range form.File {
    for _, f := range files {
        if filepath.Ext(f.Filename) != ".html" {
            c.JSON(http.StatusBadRequest, gin.H{"err": "invalid_format", "msg": "仅支持 .html 格式文件", "data": ""})
            return
        }
        if f.Size > int64(maxSizeKB*1024) {
            c.JSON(http.StatusBadRequest, gin.H{"err": "file_too_large", "msg": fmt.Sprintf("自定义拦截页面最大为 %d KB", maxSizeKB), "data": ""})
            return
        }
    }
}
```

## 3. 验证

### 3.1 前端校验

- 上传小于等于限制的 `.html` 文件 → 成功，提示"上传成功"
- 上传超过限制的 `.html` 文件 → onChange 拦截，提示"自定义拦截页面最大为 128 KB/10 KB"
- 上传 `.txt` / `.jpg` / `.exe` / `.htm` / `.HTML` 文件 → 提交后后端返回格式错误，前端展示"仅支持 .html 格式文件"

### 3.2 后端校验

- 绕过前端（curl 直接 POST API）上传非 `.html` 文件 → 返回 `400 {"err":"invalid_format","msg":"仅支持 .html 格式文件"}`
- 绕过前端上传超大 `.html` 文件 → 返回 `400 {"err":"file_too_large","msg":"自定义拦截页面最大为 N KB"}`
- 绕过前端上传 `.html` 文件 → 正常通过

### 3.3 错误提示

- 上传失败 → 前端显示 CMC 后端统一后的 `msg`，不再只显示"上传失败"

# RULES

- 前端仅做大小限制，格式由后端兜底，避免前端与 Captain 契约分裂
- 后端校验用 `filepath.Ext`，严格只允许 `.html`，与雷池 `endswith(".html")` 保持一致
- 后端保留 CMC 侧兜底，即使 Captain 已有校验，也要避免大文件进入转发流程并统一错误契约
- 遵循设计原则"差异在 handler 层消化，前端无需适配"
- 不做 HTML 内容校验/XSS 过滤——Captain 自身负责内容安全
- 错误提示从 CMC 后端 `msg` 字段提取，不直接透传 Captain 原始错误
