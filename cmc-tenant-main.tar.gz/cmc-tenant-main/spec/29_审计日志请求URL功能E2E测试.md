---
issue_key: 审计日志请求URL功能E2E测试
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: shicheng
dev_env: local
start_from: shicheng
merge_to: main
estimated_loc: 100
priority: medium
---

# DESCRIPTION

原始需求: 为审计日志请求URL记录功能编写E2E测试，验证功能正确性。
背景: 审计日志已实现 request_url 字段记录和前端展示，需要自动化测试覆盖。
目标: 编写Integration E2E测试，验证：
1. 审计日志列表正确展示「请求路径」列
2. 操作产生的审计日志包含正确的请求URL
3. 详情弹窗正确展示请求路径

# DESIGN

方案设计: 新建独立E2E测试文件 `integ-audit-log.spec.js`，使用Playwright + 真实后端API验证。

详细设计:

## 1. 测试文件

新建：`frontend/packages/skyview-web/e2e/integ-audit-log.spec.js`

## 2. 测试用例

### 用例1: 审计日志页面渲染
- 登录admin账号
- 导航至「系统管理-审计日志」页面
- 验证表格存在且包含「请求路径」列
- 验证列数据正常加载

### 用例2: 操作产生审计日志记录
- 导航至「系统管理-高亮IP」页面
- 创建一条高亮IP（IP: 192.168.100.200）
- 等待审计日志异步写入（1秒）
- 返回审计日志页面
- 验证最新一条日志的 request_url 不为空
- 验证请求路径格式正确（以/api/开头）

### 用例3: 详情弹窗展示请求路径
- 在审计日志页面点击第一条数据的「查看」链接
- 验证详情弹窗打开
- 验证弹窗内包含「请求路径」字段
- 验证请求路径值不为空

### 用例4: 数据清理
- 删除测试创建的高亮IP
- 验证删除成功

## 3. 测试数据

- 测试IP: `192.168.100.200`（唯一标识，避免冲突）
- 测试备注: `e2e-test-audit-url`

## 4. 断言标准

| 检查项 | 期望结果 |
|--------|----------|
| 「请求路径」列存在 | 列头文本包含「请求路径」 |
| 列数据格式 | 以 `/api/` 开头的路径 |
| 详情弹窗展示 | 包含「请求路径」标签且值不为空 |
| 异步写入延迟 | 创建操作后等待1秒 |

## 5. 错误处理

- 网络超时: 等待元素时使用 { timeout: 5000 }
- 数据不存在: 使用可选链操作符，空值显示为 "—"
- 清理失败: 使用 try/catch 包裹，不影响测试结果

# STEPS

## 1. 创建E2E测试文件
新建 `e2e/integ-audit-log.spec.js`

## 2. 实现测试代码
按照「详细设计」中的4个用例实现测试逻辑。

## 3. 更新 run-integration.js
将 `integ-audit-log.spec.js` 加入 GROUPS 第1组。

## 4. 运行单文件测试
```bash
node e2e/integ-audit-log.spec.js
```

## 5. 运行全量测试
```bash
node e2e/run-integration.js
```

## 6. 提交代码
包含E2E测试文件和 run-integration.js 更新。

# RULES

遵循现有Integration E2E测试风格（使用 integ-helpers 中的 loginAs, navTo, launchOptions）。
使用真实API调用，不使用Mock。
测试数据使用唯一标识，避免与其他测试冲突。
测试结束后清理数据。
