---
issue_key: MR55 IP组 comment/original 字段缺失
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: codex
dev_env: local
start_from: current branch
merge_to: current branch
estimated_loc: 200
priority: medium
---

# DESCRIPTION

原始问题: CMC 的 IP 组列表原先代理 Captain `/api/IPGroupAPI`，该接口在雷池侧只返回精简 serializer，缺少页面需要展示和编辑的 `comment`、`original` 字段。

目标:
- IP 组列表返回完整字段，包括 `comment`、`original`、`cidrs`。
- 前端仍调用 CMC 本地接口 `/api/captain/ip-group/list`，不感知 Captain/WAF API 差异。
- 保持 CMC 多租户隔离、共享保护字段和分页 `total` 正确。
- 移除为补字段引入的 `captain_ip_group_cache` 本地缓存路径。

# BACKGROUND

## 雷池 23.01.014_r6 行为

雷池 IP 组存在两条读取路径:

1. `/api/IPGroupAPI`

   该接口列表使用 `IPGroupIDNameSerializer`，显式排除了 `comment` 和 `original`。

2. `/api/FilterV2API?scope=detect:asset:ip_group`

   该接口使用 `IPGroupScope.serializer = IPGroupSerializer`，`IPGroupSerializer` 为 `fields = "__all__"`，会返回完整字段。

雷池前端资产 IP 组页面原生使用 FilterV2:

```ts
getFilterPaginationData<IPGroupModel>({
  ...paginationOptions,
  ...getFilterData(route.query),
  scope: route.name
})
```

其中路由名为 `detect:asset:ip_group`。

## FilterV2 分页方式

雷池 FilterV2 对 IP 组这种普通 DB scope 走:

```text
FilterV2API -> QuerySetProvider -> SubFrameAdaptor
```

分页由数据库 QuerySet 切片完成:

```python
query_set[offset : offset + limit]
```

`total` 来自原始 QuerySet 的 `count()`。

# DESIGN

## CMC 对外接口保持不变

前端仍调用:

```text
GET /api/captain/ip-group/list?captain_instance_id=<id>&offset=<n>&count=<n>
```

handler 内部把上游读取路径切换为:

```text
GET /api/FilterV2API?scope=detect:asset:ip_group
```

Captain 请求仍通过 `captain_instance_id` 转换为 CaptainClient 的 `InstanceID`，由 CaptainClient 注入 `Proxy` / `ProxyPage: off` 请求头。

## Admin 路径

Admin 拥有全量资源视角，不需要 CMC 侧租户映射过滤。

实现逻辑:

1. 读取前端 `offset/count`。
2. 直接请求 WAF FilterV2 当前页:

   ```text
   /api/FilterV2API?count=<count>&offset=<offset>&scope=detect:asset:ip_group
   ```

3. 保留雷池原生分页语义。
4. 注入 CMC 侧 `binding_count`。
5. 返回前端。

这样与雷池原生页面一致，不做全量拉取。

## Tenant 路径

Tenant 只能看到本租户组绑定的 IP 组。由于 CMC 的绑定关系存在本地表 `captain_ip_group_bindings`，雷池 FilterV2 本身不知道 CMC 租户组，因此不能直接透传分页。

如果直接把前端 `offset/count` 传给 WAF，再在 CMC 本地过滤，会出现:

- 当前页被过滤后为空，但后续页有本租户数据。
- `total` 是 WAF 全量 total，不是租户可见 total。
- 翻页结果不稳定。

最终实现:

1. 先查本地 `captain_ip_group_bindings`。
2. 如果该租户组在当前 WAF 下没有绑定 IP 组，直接返回空页:

   ```json
   {
     "err": null,
     "msg": "success",
     "data": { "total": 0, "items": [] }
   }
   ```

3. 如果存在绑定，则分批请求 WAF FilterV2 全量 IP 组:

   ```text
   /api/FilterV2API?count=500&offset=0&scope=detect:asset:ip_group
   /api/FilterV2API?count=500&offset=500&scope=detect:asset:ip_group
   ...
   ```

4. 根据 FilterV2 返回的 `total` 和每批 `items` 判断是否继续拉取。
5. 在 CMC 本地按 `captain_ip_group_bindings` 过滤。
6. 注入 `binding_count`、`used_count`、`source`、`has_external_ref` 等保护字段。
7. 最后执行本地分页 `applyLocalPagination(offset, count)`，保证租户视角 `total` 正确。

## 为什么 tenant 不按绑定 ID 下推查询

理论上最优查询是:

```text
/api/FilterV2API?scope=detect:asset:ip_group&id__in=1,2,3
```

但雷池 `23.01.014_r6` 中 `IPGroupScope` 的 `id` 字段使用的是 `NumericField("id")`，只支持:

```text
exact / not_exact / lt / gt
```

不支持 `in`。FilterV2 会校验 filter key，`id__in` 会被拒绝。

可行但不推荐的替代方案是对每个绑定 ID 调一次:

```text
/api/FilterV2API?scope=detect:asset:ip_group&id__exact=<id>
```

该方案会产生 N 次 Captain/WAF 请求，绑定 IP 组多时性能更差，因此当前不采用。

# CLEANUP

删除了旧的 IP 组本地缓存路径:

- `CaptainIPGroupCache` 模型
- AutoMigrate 中的 `CaptainIPGroupCache` 注册
- `writeIPGroupCacheFromResp`
- `writeIPGroupCache`
- `deleteIPGroupCache`
- `fetchAndCacheIPGroup`
- `enrichIPGroupList`
- 写接口成功后的 cache 写入/刷新逻辑

旧数据库中已经存在的 `captain_ip_group_cache` 表不会被 GORM AutoMigrate 删除，但新部署不会再创建该表，业务代码也不再读写它。

# PERFORMANCE

Admin:
- 与雷池原生页面一致，只查询当前页。
- 性能由 WAF DB 分页决定。

Tenant:
- 无绑定时不请求 WAF。
- 有绑定时按 500 条/批拉取 WAF IP 组，再本地过滤。
- 批大小 500 不是总量上限，只是单次请求大小，用于避免一次响应过大。
- 性能成本主要取决于单 WAF 上 IP 组总量，而不是当前租户绑定数量。

后续优化方向:
- 如果目标 WAF/雷池版本支持 `id__in`，CMC 可改为根据本地绑定 ID 下推查询，只拉取租户绑定 IP 组。
- 对雷池 `23.01.014_r6`，需要先将 `IPGroupScope.id` 从 `NumericField` 改为支持 `in` 的字段，或新增等价过滤能力。

# VERIFICATION

已验证:

```bash
GOCACHE=/private/tmp/cmc-tenant-go-build go test ./server/apis/captain/handler ./server ./domain/binding/model
```

预期行为:

- Admin IP 组列表返回雷池 FilterV2 当前页数据，并包含完整字段。
- Tenant 无绑定时返回空页，不请求 WAF。
- Tenant 有绑定时返回本租户组可见 IP 组，`total` 为租户可见数量。
- 列表项包含 `comment`、`original`、`cidrs`。
- 共享保护和运行时引用保护字段继续生效。
