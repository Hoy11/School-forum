---
issue_key: requirements/SSL证书功能完善
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: tian.zq
dev_env: container://devbox:ubuntu
start_from: tzq
merge_to: main
estimated_loc: 400
priority: medium
---

# DESCRIPTION

原始需求: 重构 CMC 的 SSL 证书页面，仿照雷池（SafeLine）"资产管理 > 共享文件 > SSL证书"界面实现，并增加多租户组绑定时的操作限制。
背景: 当前 SSL 证书页面列表展示 ID、名称、创建时间，详情页信息不完整，上传对话框使用按钮模式非拖拽模式，且缺乏共享资源保护。与雷池 UI 差距较大，用户体验不一致。
目标:
1. 列表页对齐雷池：列名、使用情况展示、操作图标按钮
2. 详情页对齐雷池：K/V 分行展示、名称和证书文件可编辑、关联站点可跳转
3. 添加证书对话框对齐雷池：拖拽上传、"是否含私钥"默认不勾选
4. 共享资源（binding_count > 1）禁止编辑和删除

# DESIGN

方案设计:
- 后端列表响应注入 `binding_count` 字段，标识绑定租户组数量
- 后端编辑/更新/删除接口增加共享检查，`binding_count > 1` 时返回 403
- 前端列表、详情、对话框全面对齐雷池 UI
- 前端 `el-upload` 的 `on-change` 使用内联箭头函数，避免 Vue 2 TSX 方法引用 `this` 上下文丢失

思路:
- 复用 IP 组已验证的 `injectBindingCounts` + `checkXxxShared` 模式（spec 16）
- 前端类型 `CertInfo` 对齐 Captain `SSLCertModel` 嵌套结构（`info`、`websites`）
- 详情页使用自定义 div K/V 布局替代 `el-descriptions`（后者在当前 Element UI 版本渲染异常）

详细设计:

## 后端

### 1. 列表注入 binding_count

`GET /api/captain/cert/list` 响应中每个证书增加 `binding_count` 字段（int），表示该证书被多少个租户组绑定。

在 `CertList` handler 中，`wrapListAsPage` 后追加 `injectBindingCounts(body, mappingCert, instanceID)`。

复用 `mapping.go` 中已有的 `getBindingCounts(table, instanceID, ids)` 批量查询函数和 `injectBindingCounts` 注入函数。

### 2. 编辑/更新/删除增加共享检查

以下接口增加共享检查（`binding_count > 1` 时返回 403）：

| 接口 | Captain API | 共享检查 | 错误响应 |
|------|-------------|----------|----------|
| `POST /api/captain/cert/edit` | `POST /api/EditSSLCertAPI` | `checkCertShared` | `{"err": "shared", "msg": "该资源被多个租户组绑定，不可编辑"}` |
| `PUT /api/captain/cert/update` | `PUT /api/CertAPI` | `checkCertShared` | `{"err": "shared", "msg": "该资源被多个租户组绑定，不可编辑"}` |
| `DELETE /api/captain/cert/delete` | `DELETE /api/CertAPI` | `checkCertShared` | `{"err": "shared", "msg": "该资源被多个租户组绑定，不可删除"}` |

新增 `checkCertShared(instanceID int, resourceID int) bool` 函数，查询 `captain_cert_bindings` 表计数。

`CertEdit`、`CertUpdate`、`CertDelete` handler 从通用 `proxyMappingWrite`/`proxyMappingDelete` 改为显式逻辑：所有权检查 → 共享检查 → 转发 Captain 请求。

### 3. 删除时清理 mapping

`CertDelete` 成功后（`resp.StatusCode < 300`），非 admin 用户需调用 `deleteMapping(mappingCert, instanceID, resourceID, getTenantGroupID(c))` 清理绑定记录。

### 4. 详情页注入 binding_count

`GET /api/captain/cert/detail` 响应中注入 `binding_count` 字段，供前端判断共享状态。

在 `CertDetail` handler 中，调用 Captain API 获取响应后，对单条数据调用 `injectDetailBindingCount(body, mappingCert, instanceID, certID)` 注入 `binding_count`。

新增 `injectDetailBindingCount` 函数（区别于列表页的 `injectBindingCounts`，后者处理分页格式，详情页为单条对象格式）：解析响应 → 提取 data 对象 → 调用 `getBindingCounts` → 注入字段 → 重新序列化。

### 5. 详情页过滤关联站点

非 admin 用户查看证书详情时，`websites` 数组需按租户组过滤，只显示当前租户组在 `site_bindings` 中有绑定记录的站点。

在 `CertDetail` handler 中，非 admin 时调用 `filterCertWebsites(body, instanceID, getTenantGroupID(c))`：
- 查询 `site_bindings` 表获取该租户组在此 WAF 实例上绑定的 `site_id` 集合
- 过滤 `websites` 数组，只保留 `id` 在集合中的站点
- admin 不过滤，显示全部关联站点

## 前端

### 1. CertInfo 类型对齐 Captain SSLCertModel

```ts
export interface CertWebsite {
  id: number
  name: string
  server_names?: string[]
  create_time?: string
}

export interface CertDetailInfo {
  serial: string
  issuer: string
  domains: string[]
  not_valid_before: number
  not_valid_after: number
}

export interface CertInfo {
  id: number
  name: string
  captain_instance_id: number
  binding_count: number
  info: CertDetailInfo
  websites: CertWebsite[]
  is_mgt_api_cert: boolean
  create_time: number
  type: number
  file_names: string[]
  signature: string
  password: string
}
```

新增 `certEdit` API 函数，对应 `EditSSLCertAPI`：
```ts
export function certEdit(captainInstanceId: number, formData: FormData) {
  formData.append('captain_instance_id', String(captainInstanceId))
  return upload<CertInfo>('/api/captain/cert/edit', formData)
}
```

### 2. 列表页改造

**列定义**：

| 列 | 字段 | 说明 |
|---|---|---|
| 证书名称 | `name` | minWidth:200, nowrap + ellipsis |
| 使用情况 | 自定义 render | 叠加逻辑：`is_mgt_api_cert` → "系统使用中"，`websites.length > 0` → "有 N 个站点正在使用"，逗号连接，否则 "未使用" |
| 创建时间 | `create_time` | unix 时间戳格式化为 `yyyy-MM-dd HH:mm:ss` |
| 操作 | 图标按钮 | `el-icon-view`（查看）+ `el-icon-delete`（删除），样式与 IP 组一致 |

**共享资源保护**：`binding_count > 1` 时点击删除弹 `$message.warning` 提示"该资源被多个租户组绑定，不可删除"。

**按钮文字**："添加SSL证书"（非"上传证书"）。

### 3. 添加证书对话框对齐雷池

字段及顺序：证书名称 → 是否含私钥（checkbox，默认不勾选）→ 证书文件（drag 拖拽上传）→ 私钥文件（不含私钥时显示，drag 拖拽上传）→ 证书密码

对话框标题："添加 SSL 证书"。

**el-upload on-change 使用内联箭头函数**，避免方法引用在 Vue 2 TSX drag 模式下 `this` 上下文丢失导致文件对象未设置：

```tsx
<el-upload drag action="" auto-upload={false} accept=".pem,.crt,.pfx,.p7b" limit={1}
  on-change={(f: any) => { this.certFile = f.raw }}
  on-remove={() => { this.certFile = null }}>
```

### 4. 详情页改造

使用自定义 div K/V 布局（`el-descriptions` 在当前 Element UI 版本渲染异常）：

| 字段 | 值 | 可编辑 |
|------|-----|--------|
| 名称 | `name` | 是（铅笔图标 → 弹对话框修改名称，调用 `certUpdate`）|
| 证书文件 | `file_names.join(', ')` | 是（铅笔图标 → 弹对话框上传新文件，调用 `certEdit`）|

**共享资源保护**：`binding_count > 1` 时隐藏名称和证书文件的编辑图标（`el-icon-edit`），防止用户打开编辑对话框后才发现无法操作。
| 证书签名 | `signature` | 否 |
| 上传时间 | `create_time` 格式化 | 否 |
| 颁发者 | `info.issuer` | 否 |
| 序列号 | `info.serial` | 否 |
| 有效期 | `info.not_valid_before` - `info.not_valid_after` | 否 |
| 域名 | `info.domains.join(', ')` | 否 |
| 关联站点 | `websites[].name`（router-link 跳转站点详情）| 否 |

**编辑名称对话框**：输入新名称，调用 `certUpdate({ id, captain_instance_id, name })`。

**编辑证书文件对话框**：是否含私钥（默认不勾选）→ 证书文件 drag 上传 → 私钥文件 drag 上传 → 证书密码，提交调用 `certEdit(wafId, formData)`。

### 5. el-upload on-change 修复

`SslCert.tsx` 和 `SslCertDetail.tsx` 中所有 `el-upload` 的 `on-change` 从方法引用改为内联箭头函数：

```tsx
// 修复前（方法引用，this 可能丢失）
on-change={this.handleCertFileChange}

// 修复后（内联箭头函数，this 确保正确）
on-change={(f: any) => { this.certFile = f.raw }}
```

删除不再需要的 `handleCertFileChange`、`handleKeyFileChange`、`handleEditCertFileChange`、`handleEditKeyFileChange` 方法。

约束条件和限制:
- 共享资源（binding_count > 1）禁止编辑和删除，防止影响其他租户组
- SSL 证书操作不触发频率检查（与站点管理不同，不涉及 nginx 重启）
- 编辑证书文件使用 `EditSSLCertAPI`（POST multipart），更新名称使用 `CertAPI`（PUT JSON），两个不同的 Captain API
- 详情页使用自定义 div 布局而非 `el-descriptions`，因后者在当前 Element UI 2.x + Vue 2 TSX 下渲染异常

# STEPS

## 1. 生成 spec 文档
新建 `spec/22_SSL证书功能完善.md`。

## 2. 后端列表注入 binding_count
修改 `gateway/server/apis/captain/handler/cert.go` 的 `CertList` handler，在 `wrapListAsPage` 后追加 `injectBindingCounts(body, mappingCert, instanceID)`。

## 3. 后端新增 checkCertShared 函数
在 `cert.go` 中添加 `checkCertShared(instanceID int, resourceID int) bool`，查询 `captain_cert_bindings` 表计数。

## 4. 后端 CertEdit/CertUpdate/CertDelete 增加共享检查
将三个 handler 从通用 `proxyMappingWrite`/`proxyMappingDelete` 改为显式逻辑：所有权检查 → 共享检查 → 转发 Captain 请求。

## 5. 前端 CertInfo 类型对齐
修改 `frontend/packages/skyview-web/src/api/captain-cert.ts`，更新 `CertInfo` 类型，新增 `CertWebsite`、`CertDetailInfo` 接口，新增 `certEdit` 函数。

## 6. 前端列表页改造
修改 `frontend/packages/skyview-web/src/views/Network/Management/SslCert.tsx`：列定义、使用情况 render、操作图标按钮、共享资源提示、添加证书对话框 drag 布局、按钮文字。

## 7. 前端详情页改造
修改 `frontend/packages/skyview-web/src/views/Network/Management/SslCertDetail.tsx`：K/V 分行布局、名称/证书文件可编辑、关联站点 router-link、编辑对话框。

## 8. 前端 el-upload on-change 修复
`SslCert.tsx` 和 `SslCertDetail.tsx` 中所有 `el-upload` 的 `on-change` 改为内联箭头函数，删除多余的 handleXxxChange 方法。

## 9. 编译验证
后端 `go build`，前端页面功能验证（列表、详情、添加、编辑名称、编辑文件、删除、共享资源提示）。

# RULES
确保所有新增代码遵循项目编码规范。
后端差异在 handler 层消化，前端不感知 Captain API 特殊性。
共享检查逻辑与 IP 组保持一致（spec 16），复用 `injectBindingCounts` 和 `getBindingCounts`。
`el-upload` 的 `on-change` 在 Vue 2 TSX 中必须使用内联箭头函数，禁止使用方法引用。
