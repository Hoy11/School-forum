---
issue_key: requirements/WAF绑定增强
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: tian.zq
dev_env: container://devbox:ubuntu
start_from: tzq
merge_to: main
estimated_loc: 150
priority: medium
---

# DESCRIPTION

原始需求: 增强 CMC 租户管理中 WAF 绑定功能，支持多选绑定和级联解绑检查。
背景: 当前 WAF 绑定对话框只支持单选 WAF 实例，且前端-后端契约不匹配（前端发送 `captain_instance_id` 单数，后端期望 `captain_instance_ids` 数组），导致创建功能失效。此外，解绑 WAF 时不检查关联的站点绑定，可能产生孤立数据。
目标:
1. WAF 实例下拉框改为多选，一次可绑定多个 WAF
2. 解绑 [租户组, WAF] 时，若该组合下仍有站点绑定，阻止解绑并提示"有站点还在使用此绑定关系"

# DESIGN

方案设计:
- 前端 WAF 实例下拉框添加 `multiple` 属性，form 状态从 `captain_instance_id: number` 改为 `captain_instance_ids: number[]`
- 前端 API 调用 `wafBindingCreate` 参数对齐后端，发送 `captain_instance_ids` 数组
- 后端 `DeleteWafBindings` 增加级联检查：删除前查询 `site_bindings` 表，若待删除的 [tenant_group_id, captain_instance_id] 对下存在站点绑定，返回 `ErrWafHasSiteBindings`
- 后端 Handler 层区分错误类型：级联检查失败返回 400，其余仍返回 500
- 前端 `handleDelete` 使用 try/catch 捕获异常：后端返回非 2xx 时 axios 抛异常（`request` 函数 `throw new Error(networkError(err))`），需 catch 后用 `this.$alert()` 弹窗显示，而非仅出现在浏览器 console

思路:
- 级联检查是"全有或全无"策略：批次中任一绑定存在站点关联则拒绝整个操作，避免部分删除导致数据不一致
- 多选模式与 `SiteBinding.tsx` 中站点多选一致，保持 UI 风格统一

# RULES

- WAF 实例共享：一个 WAF 可绑定到多个租户组（同一租户组不可重复绑定同一 WAF）
- 站点绑定的前提条件：租户组必须先绑定 WAF，才能绑定该 WAF 下的站点（已有约束，不变）
- 级联解绑检查范围：仅检查同一 [tenant_group_id, captain_instance_id] 下的站点绑定，不跨租户组检查
