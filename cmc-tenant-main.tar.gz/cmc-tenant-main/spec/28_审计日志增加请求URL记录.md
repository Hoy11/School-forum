---
issue_key: 系统管理-审计日志增加请求URL记录和展示
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: shicheng
dev_env: local
start_from: shicheng
merge_to: main
estimated_loc: 50
priority: medium
---

# DESCRIPTION

原始需求: 系统管理-审计日志需要增加请求URL记录和展示。
背景: 当前审计日志仅记录操作类型和资源，未记录具体的请求URL路径。在排查问题和审计追溯时，无法直观了解用户访问了哪个具体接口。
目标: 在审计日志中记录完整的请求路径（包含Query String），并在前端列表和详情中展示。

# DESIGN

方案设计: 在 AuditLog 数据模型中新增 `RequestURL` 字段，在中间件中从 Gin Context 提取请求路径，前端表格和详情弹窗展示该字段。

详细设计:

## 1. 数据库模型变更
- 在 `audit_logs` 表新增 `request_url` 字段，类型 VARCHAR(500)
- 不加索引（暂不需要按URL过滤）
- 历史数据该字段为空

## 2. 后端模型变更
- `domain/audit_log/model/audit_log.go` 新增 `RequestURL string` 字段
- 使用 `gorm:"size:500"` 标签

## 3. 中间件记录逻辑
- 修改 `server/midware/audit.go`
- 提取 `c.Request.URL.Path` 和 `c.Request.URL.RawQuery`
- 组合为完整请求路径（如 `/api/captain/site/update?instance_id=xxx`）
- 写入 AuditLog.RequestURL 字段

## 4. 前端展示
- `views/System/AuditLog.tsx` 列表新增「请求路径」列（width: 180）
- 详情弹窗展示完整请求路径
- 空值显示为 "—"

## 5. 列宽调整
- 原「请求体」列宽度从 360 调整为 280，避免总宽溢出

约束条件和限制:
- 仅记录本系统的请求路径，Captain-2 代理请求记录本地路径 `/api/captain/*`
- Query String 可能被截断（500字符限制）
- 历史审计日志该字段为空，不影响现有功能

# STEPS

## 1. 修改数据模型
修改 `domain/audit_log/model/audit_log.go`，新增 RequestURL 字段。

## 2. 修改中间件
修改 `server/midware/audit.go`，在创建 AuditLog 时提取并记录请求URL。

## 3. 修改前端列表
修改 `views/System/AuditLog.tsx`，新增请求路径列，调整其他列宽。

## 4. 数据库迁移
执行 SQL：
```sql
ALTER TABLE audit_logs ADD COLUMN request_url VARCHAR(500);
```

## 5. 验证测试
- 登录后执行任意操作（如创建、修改）
- 查看系统管理-审计日志
- 验证列表展示请求路径
- 点击详情查看完整URL
- 验证含Query String的接口（如 Captain 代理）

# RULES

遵循项目 Go + Vue 2 + TSX 编码规范。
数据库字段使用 snake_case，Go 模型使用 CamelCase。
前端列宽总和不超出屏幕可视区域。
历史数据兼容处理（空值显示为"—"）。
