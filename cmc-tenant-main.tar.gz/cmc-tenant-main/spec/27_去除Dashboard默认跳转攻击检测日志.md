---
issue_key: 去除 Dashboard，登录后默认跳转攻击检测日志页面
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: shicheng
dev_env: local
start_from: shicheng
merge_to: main
estimated_loc: 10
priority: low
---

# DESCRIPTION

原始需求: 去除刚登陆系统时的 Dashboard 页面，改为直接显示攻击检测日志页面。
背景: 当前系统登录后默认显示 Dashboard（总览）页面，该页面展示用户数、租户组数等统计信息。用户实际使用中最常访问的是攻击检测日志，每次登录后需手动切换页面，增加操作步骤。
目标: 登录成功后直接跳转至攻击检测日志页面，提升使用效率。

# DESIGN

方案设计: 通过路由重定向实现：根路径 `/` 重定向至 `/threat/detect-log`，同时保持登录跳转逻辑的一致性。
思路:
1. 路由层：将根路径 `/` 从 Dashboard 组件改为重定向到攻击检测日志
2. 登录层：登录成功后直接跳转至攻击检测日志路由，避免不必要的重定向
3. Dashboard 组件保留但不再作为默认入口，作为可选页面保留

详细设计:
- 修改 `router/index.ts`：将 `{ path: '', name: RouteName.dashboard, ... }` 改为 `{ path: '', redirect: { name: RouteName.detectLog } }`
- 修改 `views/Login/index.tsx`：两处 `this.$router.push('/')` 改为 `this.$router.push({ name: 'detectLog' })`
- Dashboard 路由可保留备用（如改为 `/overview` 路径）或完全移除

约束条件和限制:
- 攻击检测日志页面所有角色（admin/tenant_admin/tenant）均可访问，无权限问题
- 需确保菜单默认展开"威胁监测"组，与当前行为一致
- Dashboard 组件可选择保留（但不链接）或彻底删除

# STEPS

## 1. 修改路由配置
修改 `frontend/packages/skyview-web/src/router/index.ts`，将根路径改为重定向到攻击检测日志。

## 2. 修改登录跳转逻辑
修改 `frontend/packages/skyview-web/src/views/Login/index.tsx`，登录成功后直接跳转至攻击检测日志页面。

## 3. 验证测试
- 登录后页面直接显示攻击检测日志
- 菜单默认展开"威胁监测"组，"攻击检测日志"子菜单高亮
- 手动访问 `/overview`（如保留）正常显示 Dashboard
- 刷新页面后仍保持在攻击检测日志

# RULES

遵循前端 Vue 2 + TypeScript + TSX 编码规范。
保持与现有路由命名（RouteName.detectLog）一致。
修改后运行 E2E 测试确保登录流程正常。
