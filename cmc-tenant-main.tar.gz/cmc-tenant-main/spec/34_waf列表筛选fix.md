---
issue_key: waf列表筛选功能失效fix
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: shicheng
start_from: main
merge_to: main
estimated_loc: 60
priority: high
---

# DESCRIPTION

原始需求：修复防护管理 WAF 列表页面筛选功能完全失效的问题。

背景：用户在 WAF 列表页（`WafList.tsx`）通过"实例名称 / 状态 / 版本"筛选框搜索，无论输入什么内容，列表结果始终不变，筛选形同虚设。

根因：后端 `WafBindingList` handler 解析了前端发来的 `conditions`，但只从中提取了 `tenant_group_id`，其余三个筛选字段（`instance_name`、`instance_status`、`version`）被完全丢弃。且这三个字段来自 Captain API（不在本地 DB），必须在 `enrichWafBindings` 之后做内存过滤。

目标：最小改动修复后端过滤逻辑，使三个筛选字段正确生效，零前端改动。

# DESIGN

## 问题根因分析

### 数据流

```
前端 WafList.tsx
  → listQueryGet('/api/binding/waf/list', offset, count, conditions)
  → GET /api/binding/waf/list?conditions=JSON&offset=0&count=20

后端 WafBindingList
  → 解析 conditions（只取 tenant_group_id）← 问题所在
  → bindingOp.ListWafBindings(tgID, offset, count)  // DB 层分页，无 name/status/version
  → fetchInstanceMap()  // 从 Captain /api/group/detail 拿实例信息
  → enrichWafBindings() // 把 instance_name/status/version 写进返回结构
  → 返回（未过滤）
```

### 问题 1：conditions 只用了 tenant_group_id

`WafBindingList`（`binding.go:51-74`）解析 conditions 后只提取 `tenant_group_id`，
`instance_name`、`instance_status`、`version` 三个字段被静默丢弃。

### 问题 2：三个字段不在本地 DB，无法 SQL 过滤

`waf_bindings` 表只有 `tenant_group_id` 和 `captain_instance_id`。
`instance_name`、`instance_status`、`version` 来自 Captain `/api/group/detail`，
在 `enrichWafBindings()` 之后才写入返回结构，必须做内存过滤。

### 问题 3：DB 分页在内存过滤之前

`ListWafBindings(tgID, offset, count)` 在 DB 层直接 `OFFSET/LIMIT`，
如果先分页再过滤，`total` 和结果都不正确。

有实例级筛选条件时，必须先取全量数据，内存过滤后再手动分页。

## 修复方案

**改动范围：仅后端两个文件，零前端改动。**

### 整体流程（修复后）

```
有 instance_name/status/version 筛选条件时：
  1. ListWafBindings(tgID, 0, -1)   // 取全量（GORM Limit(-1) 移除限制）
  2. enrichWafBindings()             // 写入 name/status/version
  3. filterByWafConditions()         // 内存过滤，支持 = 和 like
  4. total = len(filtered)           // 过滤后计 total
  5. 手动切片 [offset:offset+count]  // 内存分页
  6. 返回

无实例级筛选条件时：
  原有逻辑不变（DB 层分页，DB total）
```

### oper 语义

内存过滤统一按 `oper` 分支，不按字段名写死匹配方式：
- `oper = "="` → 精确匹配
- 其他（`like` 等）→ 大小写不敏感的包含匹配

### 涉及字段

| 前端字段 | DTO 字段 | 来源 | 过滤方式 |
|---|---|---|---|
| `instance_name` | `InstanceName` | Captain | like（包含匹配） |
| `instance_status` | `InstanceStatus` | Captain | = 或 like |
| `version` | `Version` | Captain | like（包含匹配） |

## 改动范围

### binding_helper.go（新增）

- `wafCondition` struct：过滤条件的内部表示（Target/Oper/Value）
- `filterByWafConditions(items, conds)` → 内存过滤，返回过滤后的 slice
- `matchWafField(fieldVal, oper, filterVal)` → 单字段匹配逻辑

### binding.go（修改 WafBindingList）

1. 解析 conditions 时，把实例级字段提取为 `[]wafCondition`
2. 有实例过滤时：`ListWafBindings(tgID, 0, -1)` 取全量
3. 无实例过滤时：原有 DB 分页逻辑不变
4. enrich 后调用 `filterByWafConditions`，重算 total，手动切片

## 不影响的范围

- 无筛选条件时的默认列表行为
- `tenant_group_id` 条件提取逻辑（保持不变）
- 非 admin 用户的 tgID 注入逻辑
- SiteBindingList 及其他接口
- 前端代码（零改动）

## 验证方案

```bash
# 1. 按实例名称筛选（like）
curl "http://localhost:8080/api/binding/waf/list?offset=0&count=20&conditions=%5B%7B%22target%22%3A%22instance_name%22%2C%22items%22%3A%5B%7B%22oper%22%3A%22like%22%2C%22value%22%3A%22waf%22%7D%5D%7D%5D"

# 2. 按状态筛选（精确）
curl "http://localhost:8080/api/binding/waf/list?offset=0&count=20&conditions=%5B%7B%22target%22%3A%22instance_status%22%2C%22items%22%3A%5B%7B%22oper%22%3A%22%3D%22%2C%22value%22%3A%22ONLINE%22%7D%5D%7D%5D"

# 3. 无条件（原有行为不变）
curl "http://localhost:8080/api/binding/waf/list?offset=0&count=20"
```

预期：
- 有筛选条件时，返回的 items 全部满足条件，total 为过滤后数量
- 无筛选条件时，行为与修复前完全一致

# STEPS

## Step 1：binding_helper.go 新增过滤类型和函数

新增 `wafCondition` struct、`filterByWafConditions`、`matchWafField`，添加 `"strings"` import。

## Step 2：binding.go 修改 WafBindingList

解析 conditions 时同时提取实例级筛选字段；有过滤时取全量数据并内存分页。

# RULES

- 无实例级筛选条件时，原有 DB 分页逻辑完全不变
- oper 语义统一由 `matchWafField` 处理，不按字段名写死
- 全量查询用 GORM `Limit(-1)` 语义（传 count=-1），不用 `math.MaxInt32`
- 零前端改动
