---
issue_key: requirements/admin资源映射自动同步
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: tian.zq
dev_env: container://devbox:ubuntu
start_from: tzq
merge_to: main
estimated_loc: 370
priority: high
---

# DESCRIPTION

原始需求: 解决 admin 写操作后，已绑定相关站点的租户组无法看到或误看到资源的映射覆盖缺口。

背景: 当前所有资源创建 handler 中，映射写入被 `!isAdmin(c)` 条件跳过——admin 创建资源不产生任何映射记录。站点绑定时 `SyncSiteResourceMappings` 只在站点首次绑定时执行一次，之后 admin 在该站点上新增的资源不会触发映射同步。资源更新 handler 中，间接关联变更（PolicyUpdate 的 block page、PolicyRuleUpdate 的 ingroup IP组）缺少映射同步，导致脏数据——旧映射残留使 binding_count 虚高，影响 spec24 共享保护准确性。admin 删除资源时仅 PolicyDelete 清理了全部映射，其他 4 种资源残留孤儿映射。

复现步骤:
1. admin 创建自定义规则"333"，关联站点 test（site_id=40）
2. test 站点已绑定租户组 1（neibuyonghu 所在组）
3. neibuyonghu 登录，自定义规则列表中看不到"333"

目标:
1. admin 写操作（创建/更新/删除/绑定）后，确保映射记录与资源-站点关联的真实状态一致
2. 仅改变站点关联的操作触发映射同步；不改变站点关联的操作无须同步
3. admin 删除资源后，清理所有租户组的映射记录
4. 覆盖全部资源类型：自定义规则、IP组、SSL证书、防护策略、拦截页面

## 映射同步触发原则

**只有改变资源-站点关联关系的操作才需要触发映射同步。**

| 操作 | 是否改变站点关联 | 是否需要映射同步 |
|------|:---:|:---:|
| 创建规则（含 websites） | ✅ | ✅ |
| 创建规则（不含 websites） | ❌（空关联） | ❌（无需映射，后续 Bind 时补上） |
| 更新规则（含 websites） | ✅ | ✅ |
| Enable/Disable 规则 | ❌（仅开关状态） | ❌ |
| Module/SkynetRule | ❌（仅检测配置） | ❌ |
| Bind 规则到站点 | ✅ | ✅ |
| Unbind 规则从站点 | ❌（仅增不删） | ❌ |
| 更新 SSL 证书（CertEdit/CertUpdate） | ❌（内容变，站点关联不变） | ❌ |
| 更新防护策略 | ⚠️（间接：block page 可能变） | ✅ block page 重新校验 |
| 更新 IP 组（Update/ItemAdd/ItemDel） | ❌（内容变，引用关系不变） | ❌ |
| 更新站点配置 | ✅（改变站点引用的资源） | ✅ |
| 删除资源 | ✅（移除映射） | ✅（清理映射） |

全局规则（`is_global=true`）不在 CMC 代理范围内，无需处理。

# DESIGN

## 当前状态

| 资源类型 | 创建 Handler | admin 跳过映射的代码位置 |
|---------|-------------|----------------------|
| 自定义规则 | `PolicyRuleCreate` | policy_rule.go:178 `if !isAdmin(c)` |
| IP组 | `IPGroupCreate` | ip_group.go:79 `if !isAdmin(c)` |
| SSL证书 | `CertUpload` | cert.go:150 `if !isAdmin(c)` |
| 防护策略 | `PolicyCreate` | policy.go:110 `if !isAdmin(c)` |
| 拦截页面 | `BlockPageUpload` | block_page.go:113 `if !isAdmin(c)` |

**admin 删除映射清理现状**：

| 资源类型 | 删除 Handler | admin 是否清理映射 |
|---------|-------------|-----------------|
| 防护策略 | `PolicyDelete` | ✅ 清理全部（policy.go:239-243） |
| 自定义规则 | `PolicyRuleDelete` | ❌ 仅 `if !isAdmin(c)` 清理 |
| IP组 | `IPGroupDelete` | ❌ 仅 `if !isAdmin(c)` 清理 |
| SSL证书 | `CertDelete` | ❌ 仅 `if !isAdmin(c)` 清理 |
| 拦截页面 | `BlockPageDelete` | ❌ 仅 `if !isAdmin(c)` 清理 |

## 资源与站点的关联方式

| 资源类型 | 站点关联方式 | 创建时可提取站点 | 更新时可提取站点 |
|---------|-----------|:---:|:---:|
| 自定义规则 | `websites` + `website` | ✅（可能为空） | ✅ body 中字段 |
| SSL证书 | cert detail `websites` | ❌ 上传时无站点关联 | ❌ 更新不影响站点关联 |
| 防护策略 | 站点 `policy_group` | ❌ 创建时无站点关联 | ⚠️ 策略站点关联不变，但 block page 可能变 |
| IP组 | 规则 `ingroup` → 规则 `websites` | ❌ 创建时无站点关联 | ❌ 更新不影响引用关系 |
| 拦截页面 | 策略 `forbidden_page_config` | ❌ 上传时无站点关联 | ❌ 无 edit API |
| 站点 | 站点配置引用资源 | — | ✅ SyncSiteResourceMappings |

**自定义规则特殊情况**：
- 创建时 `websites` 可能为空 → 不写映射、不报错，后续 Bind 时补上
- Enable/Disable、Module/SkynetRule 不改变 `websites` → 无须同步
- 全局规则（`is_global=true`）不在代理范围内 → 无须处理

**间接关联变更场景**：
- PolicyUpdate 改 `forbidden_page_config` → 使用该策略的站点关联的 block page 间接变更 → 需重新校验 block page 映射（增缺删余）
- PolicyRuleUpdate 改 pattern 中的 `ingroup` → 使用该规则的站点关联的 IP 组间接变更 → 需重新校验 IP 组映射（增缺删余）

**不触发同步的资源更新**：
- CertEdit/CertUpdate：证书内容/备注变更，站点通过 ID 引用证书，关联不变
- IPGroupUpdate/ItemAdd/ItemDelete：IP 组内容变更，规则通过 ID 引用 IP 组，引用关系不变

## 映射同步的两种模式

### 模式 A：仅增不删（直接关联操作）

适用于 admin 创建/绑定规则到站点的场景。映射仅增加，不删除已有映射。

原因：admin 移除规则的站点关联（Unbind）时，该租户组可能通过其他站点仍需访问此规则。映射的存在是安全的（多一个不影响功能），缺失则有害（租户看不到资源）。

适用操作：PolicyRuleCreate、PolicyRuleBind

### 模式 B：增缺删余（间接关联变更重新校验）

适用于间接关联变更场景。旧映射变成脏数据——binding_count 虚高，影响 spec24 共享保护准确性。必须清理。

举例：策略 P 的 `forbidden_page_config` 从 block page A 改为 B → 使用 P 的站点关联从 A 变为 B → T1、T2 对 A 的映射变成脏数据（binding_count 虚高）→ 需删除 A 映射（前提：A 不被 T1 其他站点使用）。

适用操作：
- **PolicyUpdate** → block page 间接变更 → `reconcileBlockPageMappings`
- **PolicyRuleUpdate** → IP 组间接变更 → `reconcileIPGroupMappings`

### 重新校验函数设计

**`reconcileMappings(instanceID, tenantGroupID, table)`**

通用重新校验逻辑：
1. 计算该租户组**实际应映射**的资源 ID 集合（actualSet）——必须查该租户组**全部站点**，而非仅受影响站点
2. 查映射表中**已有**的资源 ID 集合（mappedSet）
3. actualSet - mappedSet → 缺失的 → writeMapping 补上
4. mappedSet - actualSet → 多余的 → deleteMapping 删除

**各资源类型的 actualSet 计算**：

| 资源类型 | actualSet 计算方式 |
|---------|------------------|
| Block Page | 该租户组全部站点的策略详情中 `forbidden_page_config.path` 对应的 block page ID |
| IP Group | 该租户组全部站点的 `proxy_ip_groups` + 关联规则 pattern 中的 ingroup IP 组 ID |

便捷入口：
- `reconcileBlockPageMappings(instanceID, policyID)` — 找使用此策略的站点→找租户组→对每组调 `reconcileMappings(mappingBlockPage)`
- `reconcileIPGroupMappingsForSites(instanceID, siteIDs)` — 找租户组→对每组调 `reconcileMappings(mappingIPGroup)`

## 方案

### 通用函数

**`getTenantGroupIDsForSites(instanceID int, siteIDs []int) []uint`**
- 查 `site_bindings`：`SELECT DISTINCT tenant_group_id FROM site_bindings WHERE captain_instance_id = ? AND site_id IN ?`
- 返回去重的 tenant_group_id 列表

**`writeMappingForSiteTenantGroups(table, instanceID, resourceID, siteIDs)`**
- 调 `getTenantGroupIDsForSites` 获取租户组列表
- 对每个 tenantGroupID 调 `writeMappingIfNotExists(table, instanceID, resourceID, tgID, "inherited")`
- 幂等，`resourceID <= 0` 或空 siteIDs 时直接返回

**`extractWebsitesFromBody(body map[string]interface{}) []int`**
- 提取 `body["websites"]`/`body["Websites"]`（数组）和 `body["website"]`/`body["Website"]`（单值）
- 复用 `extractIntID` 处理类型转换，去重后返回

**`extractRuleIDsFromBody(body map[string]interface{}) []int`**
- 提取 `body["ids"]`/`body["policy_rule_ids"]` 及 PascalCase 变体
- 供 PolicyRuleBind 使用

**`fetchRuleInGroupIDs(client, instanceID, ruleID) []int`**
- 获取规则详情，从 pattern 提取 ingroup IP 组 ID
- 供 PolicyRuleBind 使用（bind body 不含 pattern）

### 自定义规则（模式 A：仅增不删）

**PolicyRuleCreate** — if/else 分支，admin 路径从 body 提取 websites → writeMappingForSiteTenantGroups（规则+IP组）

**PolicyRuleUpdate** — if/else 分支 + IP 组重新校验：
- admin 路径：writeMappingForSiteTenantGroups（规则+新IP组）
- 同时调 `reconcileIPGroupMappingsForSites(instanceID, websites)` 清理旧 IP 组映射

**PolicyRuleBind** — 改为内联调用：
- admin 路径：提取 website + ruleIDs → writeMappingForSiteTenantGroups（规则+fetchRuleInGroupIDs 提取的 IP 组）
- Bind 不改变现有 ingroup 引用，不需要 IP 组重新校验

### 站点更新（全量同步）

将 SiteUpdate 从 `proxyAndRecordOp` 改为内联调用。仅 admin 时触发：

```go
if resp.StatusCode < 300 && siteID > 0 && isAdmin(c) {
    tenantGroupIDs := getTenantGroupIDsForSites(instanceID, []int{siteID})
    for _, tgID := range tenantGroupIDs {
        SyncSiteResourceMappings(instanceID, siteID, tgID)
    }
}
```

### 防护策略更新（模式 B：block page 重新校验）

将 PolicyUpdate 从 `proxyRequest` 改为内联调用。仅 admin 时触发：

```go
if resp.StatusCode < 300 && isAdmin(c) && resourceID > 0 {
    reconcileBlockPageMappings(instanceID, resourceID)
}
```

### SSL证书、IP组更新 — 不触发映射同步

CertEdit/CertUpdate：证书内容变更不影响站点关联，不需要映射同步。
IPGroupUpdate/ItemAdd/ItemDelete：IP组内容变更不影响规则引用关系，不需要映射同步。

### admin 删除映射清理

参照 PolicyDelete（policy.go:239-243）的模式：

| Handler | 表名 | 列名 |
|---------|------|------|
| CertDelete | `captain_cert_bindings` | `cert_id` |
| IPGroupDelete | `captain_ip_group_bindings` | `ip_group_id` |
| PolicyRuleDelete | `captain_policy_rule_bindings` | `rule_id` |
| BlockPageDelete | `captain_block_page_bindings` | `block_page_id` |

> **实际触发约束**：admin 删除资源受运行时保护（资源使用中不可删）和多租户保护（binding_count > 1 不可删）双重硬限制，正常运行中不会触发这些删除操作。映射清理代码作为安全兜底存在，确保极端场景（如 Captain 侧资源被直接删除）下映射仍能被清理。

### 创建操作 — 不做直接映射同步

IP组/证书/策略/拦截页面的 Create 不做映射同步，原因：
- 创建时请求 body 不含站点关联字段
- 无法确定哪些租户组应该看到新创建的资源
- 映射通过后续操作间接覆盖

### Resync 鉴权与异步改造

ResyncSiteMappings 从同步改为异步任务模式：

**鉴权**：
- `X-Resync-Key` header 校验 — 与配置文件 `resync.secret_key` 比对，空密钥 = 功能关闭
- 提交接口和查询接口都需要密钥鉴权
- tenant_group_id 存活性校验 — 查 DB 确认租户组存在

**请求参数**：
```json
{
  "tenant_group_ids": [1, 2, 3],
  "captain_instance_id": 40
}
```

**异步任务流程**：
1. 提交请求 → 校验密钥 + 限频 → 生成 task_id → 立即返回 `{"task_id": "xxx"}`
2. 后台 goroutine 执行同步：
   - 每批 5 个站点（`resync.batch_size` 可配置）
   - 批间间隔 2s（`resync.batch_interval` 可配置）
   - 失效站点标注「站点已失效，建议人工清理绑定」，不自动清理
   - 每批完成后更新 Redis 进度
3. 查询接口：`GET /api/binding/site/resync/{task_id}` + `X-Resync-Key`
   - 返回进度和逐站点结果详情

**限频**：Redis 限制同一 tenant_group_id 在 `rate_limit_minutes`（默认 30，可配置）分钟内只能 resync 一次

**任务状态存 Redis**：
```json
{
  "task_id": "resync:abc123",
  "status": "running",
  "total_sites": 25,
  "completed_sites": 10,
  "results": [
    {"site_id": 40, "instance_id": 1, "status": "success"},
    {"site_id": 41, "instance_id": 1, "status": "invalid", "message": "站点已失效，建议人工清理绑定"}
  ]
}
```

**不依赖 spec25**：resync 是手动运维兜底操作，独立实现异步任务机制，不依赖 spec25 的 compensation_tasks。

### 站点绑定失效检测

SiteBindingList 查询时：
1. 对 Captain API 返回中没有名称的站点，标记 `status: "invalid"` 而非显示空名称
2. Resync 执行时如果发现失效站点，在结果中标记该站点为 `invalid`，**不自动清理绑定记录和映射**

## 与 spec 24 的关系

| 维度 | spec 24 | 本 spec |
|------|---------|--------|
| 关注点 | 写保护（谁能操作） | 映射覆盖（谁能看到） |
| 触发时机 | 写操作前校验 | 写操作后同步 |
| 保护维度 | 运行时引用 + 多租户共享 | 映射完整性 |

两者互补：spec 24 确保有映射的资源操作安全，本 spec 确保该有映射的资源都有映射。

## 与 spec 25 的关系

本 spec 的映射写入依赖 `writeMappingIfNotExists`（幂等），不涉及补偿机制。`writeMapping` 失败时仅 log warning。spec 25 的 compensation_tasks 可提供兜底，本 spec 实现时不引入补偿，与 spec 25 解耦。

# STEPS

## 1. 新增通用映射同步函数

在 `mapping.go` 中新增：
- `getTenantGroupIDsForSites` — 查 site_bindings 获取租户组列表
- `writeMappingForSiteTenantGroups` — 幂等写映射
- `extractWebsitesFromBody` — 从请求 body 提取 website ID
- `extractRuleIDsFromBody` — 从请求 body 提取规则 ID（Bind 用）
- `fetchRuleInGroupIDs` — 从规则详情提取 ingroup IP 组

## 2. 新增重新校验函数

在 `mapping.go` 中新增：
- `reconcileMappings` — 通用增缺删余逻辑
- `collectActualBlockPageIDs` — 计算租户组实际使用的 block page
- `collectActualIPGroupIDs` — 计算租户组实际使用的 IP 组
- `getMappedResourceIDs` — 查映射表已有资源 ID
- `reconcileBlockPageMappings` — 便捷入口（PolicyUpdate 用）
- `reconcileIPGroupMappingsForSites` — 便捷入口（PolicyRuleUpdate 用）

## 3. PolicyRuleCreate 增加 admin 映射同步

修改 `policy_rule.go`：if/else 分支。admin 路径从 body 提取 websites → writeMappingForSiteTenantGroups（规则+IP组）。

## 4. PolicyRuleUpdate 增加 admin 映射同步 + IP组重新校验

修改 `policy_rule.go`：if/else 分支。admin 路径 writeMappingForSiteTenantGroups + reconcileIPGroupMappingsForSites。

## 5. PolicyRuleBind 增加 admin 映射同步

修改 `policy_rule.go`：内联 Captain API 调用。admin 路径提取 ruleIDs + website → writeMappingForSiteTenantGroups（规则+fetchRuleInGroupIDs 提取的 IP组）。

## 6. SiteUpdate 增加 admin 后同步

修改 `site.go`：内联调用以捕获状态码。仅 admin 时 getTenantGroupIDsForSites → SyncSiteResourceMappings。

## 7. PolicyUpdate 增加 admin block page 重新校验

修改 `policy.go`：内联调用以捕获状态码。仅 admin 时 reconcileBlockPageMappings(instanceID, resourceID)。

## 8. admin 删除映射清理

修改 cert.go、ip_group.go、policy_rule.go、block_page.go 的 Delete handler：增加 `if isAdmin(c)` 全量映射清理。

## 9. Resync 鉴权与异步改造

修改 `binding.go`：
- ResyncSiteMappings 改为异步任务模式
- 增加 `X-Resync-Key` header 校验
- 支持多租户组 + WAF 过滤参数
- 分批执行（每批 5 站点，间隔 2s）
- 任务状态存 Redis
- 新增查询接口 `GET /api/binding/site/resync/{task_id}` + `X-Resync-Key`
- Redis 限频（同一租户组 `rate_limit_minutes` 分钟一次，默认 30）
- 配置项：`resync.secret_key` / `resync.batch_size` / `resync.batch_interval` / `resync.rate_limit_minutes`

## 10. 站点绑定失效检测

修改 `binding.go` SiteBindingList：
- 获取不到名称的站点标记 `status: "invalid"` 而非显示空名称

# RULES

1. `writeMappingForSiteTenantGroups` 必须幂等——使用 `writeMappingIfNotExists`，不删除已有映射。
2. admin 路径的映射 source 为 `"inherited"`（非 `"created"`），因为资源并非由该租户组创建。
3. 非 admin 路径的行为不变——仍然写 `"created"` 映射。
4. 直接关联操作（Create/Bind）仅增不删——admin 移除站点关联时不清理映射，租户组可能通过其他站点仍需访问。
5. 间接关联变更（PolicyUpdate→block page、PolicyRuleUpdate→IP组）需重新校验——增缺删余，清理脏数据避免 binding_count 虚高。
6. 重新校验计算 actualSet 时必须查该租户组**全部站点**，而非仅受影响站点，因为其他站点可能仍在使用旧资源。
7. `extractWebsitesFromBody` 需兼容 Captain API 的 PascalCase（`Websites`/`Website`）。
8. 新增映射不影响 `binding_count` 的准确性——inherited 映射也被计入。
9. 重新校验的 Captain API 调用应容错——获取关联站点失败时仅 log warning，不阻塞主操作响应。
10. admin 删除映射清理必须删除**所有租户组**的映射记录（不限 `tenant_group_id`）。
11. SiteUpdate 后同步仅 admin 时触发——非 admin 已有映射写入机制。
12. 创建操作不做直接映射同步（IP组/证书/策略/拦截页面），依赖后续更新/站点更新间接覆盖。
13. 不改变站点关联的操作无须映射同步：Enable/Disable、Module/SkynetRule、CertEdit/CertUpdate、IPGroupUpdate/ItemAdd/ItemDelete。
14. 创建规则时不指定 websites → 不写映射、不报错。后续 Bind 时补上。
15. 全局规则（`is_global=true`）不在代理范围内，不触发映射同步。
16. Resync 接口需要双重鉴权——admin JWT + `X-Resync-Key` header，缺一不可。空密钥 = 功能关闭。
17. Resync 提交和查询接口都需要 `X-Resync-Key` 鉴权。
18. Resync 同一 tenant_group_id 在 `rate_limit_minutes`（默认 30 分钟，可配置）内限频一次。
19. Resync 异步执行，分批处理站点（每批 5 个，间隔 2s），任务状态存 Redis，不依赖 spec25。
20. Resync 发现失效站点时标注「建议人工清理绑定」，不自动清理绑定记录和映射。
21. 站点绑定列表中失效站点标记 `status: "invalid"`，而非显示空名称。

# TODO

## 通用函数

| # | 待办 |
|---|------|
| 1 | 新增 `getTenantGroupIDsForSites` 函数 |
| 2 | 新增 `writeMappingForSiteTenantGroups` 函数 |
| 3 | 新增 `extractWebsitesFromBody` 函数 |
| 4 | 新增 `extractRuleIDsFromBody` 函数 |
| 5 | 新增 `fetchRuleInGroupIDs` 函数 |

## 重新校验函数

| # | 待办 |
|---|------|
| 6 | 新增 `reconcileMappings` 函数（通用增缺删余） |
| 7 | 新增 `collectActualBlockPageIDs` 函数 |
| 8 | 新增 `collectActualIPGroupIDs` 函数 |
| 9 | 新增 `getMappedResourceIDs` 函数 |
| 10 | 新增 `reconcileBlockPageMappings` 便捷入口 |
| 11 | 新增 `reconcileIPGroupMappingsForSites` 便捷入口 |

## 自定义规则

| # | 待办 |
|---|------|
| 12 | PolicyRuleCreate admin 映射同步（if/else 分支） |
| 13 | PolicyRuleUpdate admin 映射同步 + IP组重新校验 |
| 14 | PolicyRuleBind admin 映射同步（内联调用） |
| 15 | PolicyRuleDelete admin 映射清理 |

## 站点

| # | 待办 |
|---|------|
| 16 | SiteUpdate admin 后同步（内联调用 + SyncSiteResourceMappings） |

## 防护策略

| # | 待办 |
|---|------|
| 17 | PolicyUpdate admin block page 重新校验（内联调用 + reconcileBlockPageMappings） |

## 删除映射清理

| # | 待办 |
|---|------|
| 18 | CertDelete admin 映射清理 |
| 19 | IPGroupDelete admin 映射清理 |
| 20 | BlockPageDelete admin 映射清理 |

## Resync 鉴权与异步改造

| # | 待办 |
|---|------|
| 21 | ResyncSiteMappings 改为异步任务模式（提交返回 task_id） |
| 22 | 增加 `X-Resync-Key` header 校验（提交 + 查询接口） |
| 23 | 支持多租户组 + WAF 过滤参数 |
| 24 | 分批执行（每批 5 站点，间隔 2s） |
| 25 | Redis 限频（同一租户组 `rate_limit_minutes` 分钟一次，默认 30） |
| 26 | 新增查询接口 `GET /api/binding/site/resync/{task_id}` |
| 27 | 失效站点标注「建议人工清理绑定」，不自动清理 |
| 28 | 配置项：`resync.secret_key` / `resync.batch_size` / `resync.batch_interval` / `resync.rate_limit_minutes` |

## 站点绑定失效检测

| # | 待办 |
|---|------|
| 29 | SiteBindingList 失效站点标记 `status: "invalid"` |

# RESYNC 使用指南

Resync 是管理员手动触发的映射同步兜底操作，用于修复映射与真实资源状态不一致的场景。**UI 不暴露按钮**，仅通过 API 调用。

## 密钥配置

Resync 需要双重鉴权：admin JWT/API Token + 专属密钥。密钥为静态字符串，无有效期/TTL。

| 配置方式 | 说明 |
|---------|------|
| 环境变量 | `RESYNC_SECRET_KEY=<your-key>` |
| 配置文件 | `config/production.json` 中 `"resync": {"secret_key": "<your-key>"}` |
| 默认值 | 空字符串（空 = 功能关闭，任何请求均返回 403） |

密钥建议使用随机生成（如 `openssl rand -hex 16`），长度 ≥16 字符。

其他 Resync 配置项：

| 配置键 | 环境变量 | 默认值 | 说明 |
|--------|---------|--------|------|
| `resync.secret_key` | `RESYNC_SECRET_KEY` | `""` | 鉴权密钥 |
| `resync.batch_size` | `RESYNC_BATCH_SIZE` | `5` | 每批处理的站点数量 |
| `resync.batch_interval` | `RESYNC_BATCH_INTERVAL` | `2` | 批间间隔秒数 |
| `resync.rate_limit_minutes` | `RESYNC_RATE_LIMIT_MINUTES` | `30` | 同一租户组限频窗口（分钟） |

## 接口调用方式

### 提交 Resync

```bash
curl -X POST http://<host>:8080/api/binding/site/resync \
  -H "Cookie: token=<admin-jwt>" \
  -H "X-Resync-Key: <your-key>" \
  -H "Content-Type: application/json" \
  -d '{"tenant_group_ids": [1, 2], "captain_instance_id": 40}'
```

请求参数：

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `tenant_group_ids` | `[]uint` | ✅ | 需要同步的租户组 ID 列表 |
| `captain_instance_id` | `int` | ❌ | 仅同步指定 WAF 实例下的站点。不填则同步全部 WAF |

响应：

```json
{
  "err": null,
  "msg": "success",
  "data": {
    "task_id": "resync:1749000000000",
    "total_sites": 5
  }
}
```

### 查询任务状态

```bash
curl -X GET http://<host>:8080/api/binding/site/resync/<task_id> \
  -H "Cookie: token=<admin-jwt>" \
  -H "X-Resync-Key: <your-key>"
```

响应：

```json
{
  "err": null,
  "msg": "success",
  "data": {
    "task_id": "resync:1749000000000",
    "status": "done",
    "total_sites": 5,
    "completed_sites": 5,
    "results": [
      {"site_id": 40, "instance_id": 1, "status": "success"},
      {"site_id": 41, "instance_id": 1, "status": "invalid", "message": "site no longer exists, consider manual cleanup"}
    ]
  }
}
```

`status` 取值：`pending` / `running` / `done` / `failed`

## 注意事项

- **双重鉴权**：admin JWT/API Token（由 Auth middleware 校验）+ X-Resync-Key header（由 handler 校验），缺一不可
- **限频**：同一 `tenant_group_id` 在 `rate_limit_minutes`（默认 30）分钟内只能 resync 一次（Redis `resync:rate:{tgID}` TTL 可配置）
- **任务状态 TTL**：Redis `resync:task:{taskID}` 保留 24 小时后自动过期
- **失效站点**：Resync 发现 Captain 已删除的站点时，标注 `status: "invalid"` + `message: "site no longer exists, consider manual cleanup"`，**不自动清理绑定和映射**
- **分批执行**：每批 `batch_size` 个站点，批间间隔 `batch_interval` 秒
- **空密钥 = 功能关闭**：`secret_key` 为空时，任何 Resync 请求都返回 403