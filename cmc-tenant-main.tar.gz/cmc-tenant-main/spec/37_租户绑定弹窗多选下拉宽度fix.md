---
issue_key: bug/tenant-binding-multiselect-width
code_repo: https://git.in.chaitin.net/fde/industry-telecom/cmc-tenant.git
designed_by: shicheng
dev_env: local
start_from: fix-waf-list-filter
merge_to: main
estimated_loc: 5
priority: low
---

# DESCRIPTION

原始需求：修复租户管理绑定弹窗中多选下拉框宽度过窄导致的显示错乱问题。

背景：「WAF 绑定」和「站点绑定」弹窗中的多选 `el-select` 组件未设置宽度，Element UI 多选模式下选中条目以 tag 形式展示，默认宽度不足时 tag 堆叠溢出，显示错乱。

目标：两处多选下拉框加上 `style="width: 100%"`，与项目其他同类组件保持一致。

# DESIGN

无需后端改动，纯前端样式修复。

涉及文件：
- `frontend/packages/skyview-web/src/views/Tenant/WafBinding.tsx` 第 74 行 — WAF 实例多选框
- `frontend/packages/skyview-web/src/views/Tenant/SiteBinding.tsx` 第 104 行 — 站点多选框

修复方式：两处 `el-select[multiple]` 均加上 `style="width: 100%"`。

参考：`SiteBinding.tsx` 同文件内其他 `el-select` 和 `PolicyRule.tsx` 第 641 行已正确设置宽度。

# STEPS

## 1. 修复 WafBinding.tsx

`WafBinding.tsx:74` 的 WAF 实例多选框加上 `style="width: 100%"`。

## 2. 修复 SiteBinding.tsx

`SiteBinding.tsx:104` 的站点多选框加上 `style="width: 100%"`。

# RULES

- 只改宽度样式，不改逻辑
- 不引入新组件或新依赖
