# Unlock Admin Account

Reset admin password and clear login lock state in DB + Redis.

## When to Use

- Before running e2e tests if admin account is locked ("账户已锁定")
- If password needs to be reset to the e2e default (`Admin@2024`)

## Steps

1. Reset password in PostgreSQL and clear `is_locked`:

```bash
cd /tmp && go run unlock_admin.go
```

Where `/tmp/unlock_admin.go` contains:

```go
package main

import (
	"context"
	"database/sql"
	"fmt"
	"golang.org/x/crypto/bcrypt"
	"github.com/go-redis/redis/v8"
	_ "github.com/lib/pq"
)

func main() {
	db, err := sql.Open("postgres", "host=10.2.102.76 port=5432 user=cmc password=cmc123456 dbname=cmc_tenant sslmode=disable")
	if err != nil { fmt.Println("db error:", err); return }
	defer db.Close()
	hash, _ := bcrypt.GenerateFromPassword([]byte("Admin@2024"), bcrypt.DefaultCost)
	res, err := db.Exec("UPDATE users SET is_locked=false, password=$1 WHERE username=$2", string(hash), "admin")
	if err != nil { fmt.Println("update error:", err); return }
	n, _ := res.RowsAffected()
	fmt.Printf("DB: password reset + unlocked (%d row)\n", n)

	rdb := redis.NewClient(&redis.Options{Addr: "10.2.102.76:6379"})
	ctx := context.Background()
	rdb.Del(ctx, "login_lock:admin", "login_fail:admin")
	fmt.Println("Redis: lock/fail keys cleared")
}
```

If `/tmp/go.mod` doesn't have the dependencies yet, run first:

```bash
cd /tmp && go mod init unlock && go get github.com/lib/pq golang.org/x/crypto/bcrypt github.com/go-redis/redis/v8
```

## Notes

- E2e integration tests use `Admin@2024` as admin password (defined in `e2e/integ-helpers.js`)
- The `helpers.js` (mock tests) uses `admin123` — these are two different files
- Lock state is stored in both PostgreSQL (`users.is_locked`) and Redis (`login_lock:admin`, `login_fail:admin`)
- Both must be cleared for unlock to work
- DB config is in `gateway/config/development.json`
