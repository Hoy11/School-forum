# Rebuild & Restart

Recompile and restart both frontend and backend services.

## Important

- **Execute all steps without asking for confirmation.** Combine commands into as few Bash calls as possible.
- **Run independent steps in parallel.**
- **Never use `cd` in compound/background commands** — use absolute paths instead to avoid "path resolution bypass" permission prompts.

## Steps

1. **Lint** (parallel, 2 calls):
   ```
   cd $PROJECT_ROOT/gateway && ~/go/bin/golangci-lint run ./...
   ```
   ```
   cd $PROJECT_ROOT/frontend && npx lerna run lint --scope skyview-web --stream
   ```

2. **Compile backend** (foreground):
   ```
   cd $PROJECT_ROOT/gateway && go build -o gateway .
   ```

3. **Kill old + start new** (2 parallel background calls, no cd):
   ```
   lsof -i :8080 -t | xargs kill 2>/dev/null; sleep 2; PG_HOST=10.2.102.76 REDIS_ADDR=10.2.102.76:6379 $PROJECT_ROOT/gateway/gateway &
   ```
   ```
   lsof -i :3000 -t | xargs kill 2>/dev/null; sleep 1; npm run dev --prefix $PROJECT_ROOT/frontend/packages/skyview-web &
   ```

4. **Wait for both services** (parallel, single curl each):
   ```
   for i in $(seq 1 15); do curl -sf --noproxy localhost http://localhost:8080/api/auth/current -o /dev/null && break; curl -sf --noproxy localhost http://localhost:8080/health -o /dev/null && break; sleep 2; done; echo "Backend ready"
   ```
   ```
   for i in $(seq 1 15); do curl -sf --noproxy localhost http://localhost:3000/ -o /dev/null && break; sleep 2; done; echo "Frontend ready"
   ```

5. Report status.

## Notes

- Use `$PROJECT_ROOT` for all absolute paths: `/Users/song/Documents/workspace/chaitin_project/cmc-tenant`
- Backend binary: `$PROJECT_ROOT/gateway/gateway`
- Frontend: `npm run dev --prefix` instead of `cd && npm run dev`
- Env: `PG_HOST=10.2.102.76`, `REDIS_ADDR=10.2.102.76:6379`
