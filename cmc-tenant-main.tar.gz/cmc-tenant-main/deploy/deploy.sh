#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

usage() {
    echo "Usage: $0 [command]"
    echo ""
    echo "Commands:"
    echo "  backend    Build Go backend binary for linux/amd64"
    echo "  frontend   Build frontend and copy to deploy/"
    echo "  all        Build both backend and frontend"
    echo "  up         Start services via docker compose"
    echo "  down       Stop services"
    echo "  restart    Rebuild and restart all services"
}

build_backend() {
    echo "==> Building backend binary..."
    cd "$PROJECT_ROOT/gateway"
    CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o "$SCRIPT_DIR/gateway-linux-amd64" .
    echo "==> Backend binary: $SCRIPT_DIR/gateway-linux-amd64"
}

build_frontend() {
    echo "==> Building frontend..."
    "$SCRIPT_DIR/build-frontend.sh"
}

start_services() {
    echo "==> Starting services..."
    cd "$SCRIPT_DIR"
    docker-compose up -d --build
    echo "==> Services started: http://localhost:3000"
}

stop_services() {
    echo "==> Stopping services..."
    cd "$SCRIPT_DIR"
    docker-compose down
    echo "==> Services stopped."
}

restart_all() {
    build_backend
    build_frontend
    stop_services
    start_services
}

case "${1:-}" in
    backend)  build_backend ;;
    frontend) build_frontend ;;
    all)      build_backend && build_frontend ;;
    up)       start_services ;;
    down)     stop_services ;;
    restart)  restart_all ;;
    *)        usage ;;
esac
