#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
FRONTEND_DIR="$PROJECT_ROOT/frontend/packages/skyview-web"
DIST_DIR="$SCRIPT_DIR/frontend-dist"

echo "==> Installing frontend dependencies..."
cd "$FRONTEND_DIR"
npm install

echo "==> Building frontend..."
npm run build

echo "==> Copying build output to deploy/"
rm -rf "$DIST_DIR"
mkdir -p "$DIST_DIR"
cp -r "$FRONTEND_DIR/dist/"* "$DIST_DIR/"

echo "==> Frontend build complete: $DIST_DIR"
