# 纵横（Captain-2）API Token 配置指南

## 概述

Captain-2 支持 API Token 认证，通过 Cookie 方式传递。CMC Tenant 后端通过 CaptainClient 使用此 Token 调用纵横 API。

> **注意**：纵横前端未暴露 API Token 管理入口，需通过 API 手动创建。

## 1. 登录纵横

```bash
# 登录获取 session cookie
curl -sk -c captain_cookies -X POST https://<CAPTAIN_HOST>/api/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"<PASSWORD>","auth_type":"pwd"}'
```

- `auth_type` 固定为 `"pwd"`（纵横默认认证类型）
- 登录成功返回 `{"error": null, "id": 1, "msg": "登录成功"}`

## 2. 创建 API Token

```bash
curl -sk -b captain_cookies -X POST https://<CAPTAIN_HOST>/api/user/api_token \
  -H "Content-Type: application/json" \
  -d '{"name":"cmc-tenant","expire_time":4070908800}'
```

- `name`：Token 名称，建议使用 `cmc-tenant`
- `expire_time`：过期时间，**Unix 时间戳**（非 RFC3339 字符串）。示例 `4070908800` 对应 2099-01-01

返回：

```json
{"data":{"token":"arUXjLLZnfyp3SbD5lbd"},"error":null,"msg":null}
```

> **务必保存 `data.token`**，此值只显示一次，纵横存储的是 bcrypt 哈希值。

## 3. 查看已有 Token

```bash
curl -sk -b captain_cookies https://<CAPTAIN_HOST>/api/user/api_token | python3 -m json.tool
```

返回的 `prefix` 字段是 Token 前 6 位，可用于确认 Token。

## 4. 写入 CMC Tenant 数据库

```sql
-- 写入 captain_configs 表（is_default=true 的记录会被 CaptainClient 自动加载）
INSERT INTO captain_configs (host, api_token, is_default, created_at)
VALUES ('https://<CAPTAIN_HOST>', '<API_TOKEN>', true, now())
ON CONFLICT DO NOTHING;
```

也可通过 CMC Tenant 系统管理界面配置（Phase 8 实现）。

## 5. 使用方式

CaptainClient 通过 **Cookie** `API-Token` 传递 Token，不是 HTTP Header。

```
请求示例：
GET /api/instance/newest HTTP/1.1
Host: <CAPTAIN_HOST>
Cookie: API-Token=<TOKEN>
```

### WAF 实例代理请求

访问 WAF 实例 API 时，额外添加 `Proxy` 和 `ProxyPage` Header：

```
GET /api/SoftwareReverseProxyWebsiteAPI HTTP/1.1
Host: <CAPTAIN_HOST>
Cookie: API-Token=<TOKEN>
Proxy: 1
ProxyPage: off
```

- `Proxy`：WAF 实例 ID（即 `captain_instance_id`）
- `ProxyPage: off`：禁用浏览器代理页面模式

### 认证流程

```
CaptainClient.Do(req)
  │
  ├─ 所有请求：添加 Cookie: API-Token=<TOKEN>
  │
  ├─ req.InstanceID != nil：添加 Header Proxy + ProxyPage
  │   └─ 请求经 Captain-2 转发到 WAF 实例
  │
  └─ req.InstanceID == nil：直接请求 Captain-2 管理 API
      └─ 日志查询、实例列表、筛选保存等
```

## 测试环境

| 项目 | 值 |
|---|---|
| 纵横地址 | `https://10.2.102.76/` |
| 纵横用户 | `admin` / `gc3VknP7` |
| API Token | `arUXjLLZnfyp3SbD5lbd` |

## 常见问题

### Q: 返回 `Need to login`？

检查 Cookie `API-Token` 是否正确传递。纵横**不支持** Header `API-Token` 方式，必须用 Cookie。

### Q: 返回 `User not found`？

登录时 `auth_type` 应为 `"pwd"`，不是 `"local"`。

### Q: 创建 Token 返回 `strconv.ParseFloat` 错误？

`expire_time` 必须是 **Unix 时间戳**（整数），不是 RFC3339 字符串。例如 `4070908800` 而非 `"2099-01-01T00:00:00Z"`。
