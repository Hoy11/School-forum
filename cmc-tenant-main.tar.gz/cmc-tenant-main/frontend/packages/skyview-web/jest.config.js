/* eslint-disable no-undef */
const path = require('path')

module.exports = {
  testEnvironment: 'jsdom',
  transform: {
    '^.+.tsx?$': 'babel-jest',
    '^.+.js?$': 'babel-jest',
    '.+\\.(css|styl|less|sass|scss|svg|png|jpg|ttf|woff|woff2)$': 'jest-transform-stub'
  },
  transformIgnorePatterns: [
    '<rootDir>/node_modules/(?!element-ui/)'
  ],
  testMatch: [
    '<rootDir>/**/__tests__/**/*.spec.(ts|tsx)'
  ],
  moduleFileExtensions: ['ts', 'tsx', 'js', 'jsx', 'json', 'node'],
  preset: 'ts-jest',
  globals: {
    'ts-jest': {
      tsConfig: '<rootDir>/tsconfig.json'
    }
  },
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/src/$1'
  },
  collectCoverage: true,
  coverageThreshold: {
    global: {
      functions: 1
    }
  }
}
