// Integration: site binding enhancement — resync, delete format, resource mapping visibility
const path = require('path')
const { chromium } = require('playwright')
const { launchOptions, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  let p = 0, f = 0

  // --- Login as admin ---
  let cookies
  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    cookies = await page.context().cookies()
    if (!cookies.some(c => c.name === 'token')) throw new Error('No token cookie')
    if (!cookieHeader.includes('token=')) throw new Error('No token cookie header')
    console.log('✅ Login (admin)'); p++
  } catch (e) { f++; console.log(`❌ Login: ${e.message}`); process.exit(1) }

  const headers = { Cookie: cookies.map(c => `${c.name}=${c.value}`).join('; ') }

  async function apiCall(name, method, urlPath, body, checks, timeout = 30000, extraHeaders = {}) {
    try {
      const opts = { headers: { ...headers, ...extraHeaders }, timeout }
      if (body) { opts.data = body; opts.headers['Content-Type'] = 'application/json' }
      const resp = method === 'POST' ? await page.request.post(`${BACKEND_URL}${urlPath}`, opts)
                                   : method === 'DELETE' ? await page.request.delete(`${BACKEND_URL}${urlPath}`, opts)
                                   : await page.request.get(`${BACKEND_URL}${urlPath}`, opts)
      const data = await resp.json()
      for (const [field, expected] of Object.entries(checks)) {
        const actual = field.split('.').reduce((o, k) => o?.[k], data)
        if (typeof expected === 'function') {
          if (!expected(actual)) throw new Error(`${field}=${JSON.stringify(actual)}, check failed`)
        } else if (actual !== expected) {
          throw new Error(`${field}=${JSON.stringify(actual)}, expected ${JSON.stringify(expected)}`)
        }
      }
      console.log(`✅ ${name}`); p++
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  async function apiGetExpectStatus(name, urlPath, expectedStatus, checks) {
    try {
      const resp = await page.request.get(`${BACKEND_URL}${urlPath}`, { headers })
      const data = await resp.json()
      if (resp.status() !== expectedStatus) {
        throw new Error(`status=${resp.status()}, expected ${expectedStatus}, body=${JSON.stringify(data)}`)
      }
      for (const [field, expected] of Object.entries(checks)) {
        const actual = field.split('.').reduce((o, k) => o?.[k], data)
        if (typeof expected === 'function') {
          if (!expected(actual, data)) throw new Error(`${field}=${JSON.stringify(actual)}, check failed`)
        } else if (actual !== expected) {
          throw new Error(`${field}=${JSON.stringify(actual)}, expected ${JSON.stringify(expected)}`)
        }
      }
      console.log(`✅ ${name}`); p++
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  // --- 1. Site binding delete with { ids: [] } format ---
  // Get existing site bindings first
  let siteBindings = []
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/binding/site/list?tenant_group_id=1`, { headers })
    const data = await resp.json()
    siteBindings = data.data?.items || []
    console.log(`✅ Site bindings fetched (${siteBindings.length} rows)`); p++
  } catch (e) { f++; console.log(`❌ Fetch site bindings: ${e.message}`) }

  // --- 1b. Site binding list rejects invalid query params ---
  for (const id of ['0', '-1', 'abc']) {
    await apiGetExpectStatus(`Site binding list invalid tenant_group_id=${id}`, `/api/binding/site/list?tenant_group_id=${id}`, 400, {
      'err': 'bad_request',
      'data': v => !v || !Array.isArray(v.items),
    })
  }

  for (const id of ['0', '-1', 'abc']) {
    await apiGetExpectStatus(`Site binding list invalid captain_instance_id=${id}`, `/api/binding/site/list?tenant_group_id=1&captain_instance_id=${id}`, 400, {
      'err': 'bad_request',
      'data': v => !v || !Array.isArray(v.items),
    })
  }

  // --- 1c. Site available list rejects invalid captain_instance_id ---
  for (const id of ['0', '-1', 'abc']) {
    await apiGetExpectStatus(`Site available invalid captain_instance_id=${id}`, `/api/binding/site/available?tenant_group_id=1&captain_instance_id=${id}`, 400, {
      'err': 'bad_request',
      'data': v => !v || !Array.isArray(v),
    })
  }

  if (siteBindings.length > 0) {
    // Test delete with correct { ids: [id] } format
    await apiCall('Site binding delete (ids array)', 'DELETE', '/api/binding/site/delete',
      { ids: [siteBindings[0].id] },
      { 'err': null, 'msg': 'success' }
    )

    // Re-create the binding for subsequent tests
    await apiCall('Site binding re-create', 'POST', '/api/binding/site/create',
      { tenant_group_id: siteBindings[0].tenant_group_id, captain_instance_id: siteBindings[0].captain_instance_id, site_ids: [siteBindings[0].site_id] },
      { 'err': null, 'msg': 'success' }
    )
  }

  // --- 2. Site binding delete with wrong { id } format should fail ---
  await apiCall('Site binding delete (single id, should fail)', 'DELETE', '/api/binding/site/delete',
    { id: 999 },
    { 'err': 'bad_request' }
  )

  // --- 3. WAF binding delete with { ids: [] } format ---
  let wafBindings = []
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=1`, { headers })
    const data = await resp.json()
    wafBindings = data.data?.items || []
    console.log(`✅ WAF bindings fetched (${wafBindings.length} rows)`); p++
  } catch (e) { f++; console.log(`❌ Fetch WAF bindings: ${e.message}`) }

  // --- 4. WAF binding delete with wrong { id } format should fail ---
  await apiCall('WAF binding delete (single id, should fail)', 'DELETE', '/api/binding/waf/delete',
    { id: 999 },
    { 'err': 'bad_request' }
  )

  const RESYNC_KEY = 'dev-resync-key-2024'
  // Use the first site binding's tenant_group_id (works in any environment, not hardcoded)
  const resyncTgID = siteBindings.length > 0 ? siteBindings[0].tenant_group_id : 1

  // --- 5. Site resync endpoint (spec23: requires X-Resync-Key + returns async task) ---
  await apiCall('Site resync', 'POST', '/api/binding/site/resync',
    { tenant_group_ids: [resyncTgID] },
    { 'err': v => v === null || v === 'rate_limit' },
    120000,
    { 'X-Resync-Key': RESYNC_KEY }
  )

  // --- 6. Site resync missing X-Resync-Key → 403 ---
  await apiCall('Site resync (missing key, should fail)', 'POST', '/api/binding/site/resync',
    { tenant_group_ids: [resyncTgID] },
    { 'err': 'forbidden' }
  )

  // --- 7. Tenant user: resource visibility after resync ---
  let tenantCookies
  try {
    const resp = await page.request.post(`${BACKEND_URL}/api/auth/login`, {
      data: { username: 'neibuyonghu', password: 'Chaitin@123' },
    })
    const data = await resp.json()
    if (data.err !== null) throw new Error(`Tenant login failed: ${data.msg}`)
    const allCookies = await page.context().cookies()
    tenantCookies = allCookies.map(c => `${c.name}=${c.value}`).join('; ')
    console.log('✅ Login (tenant)'); p++
  } catch (e) { f++; console.log(`❌ Tenant login: ${e.message}`) }

  if (tenantCookies) {
    const tenantHeaders = { Cookie: tenantCookies }
    const tenantCaptainInstanceId = await getActiveWafId(page, tenantCookies)
    console.log(`  Tenant using captain_instance_id=${tenantCaptainInstanceId}`)

    // Policy list should have at least 1 item after resync
    await apiCall('Tenant: policy visible', 'GET', `/api/captain/policy/list?captain_instance_id=${tenantCaptainInstanceId}`, null,
      { 'err': null, 'data.items': v => Array.isArray(v) && v.length >= 1 },
      30000,
      tenantHeaders
    )

    // Policy rule list should have at least 1 item
    await apiCall('Tenant: policy rule visible', 'GET', `/api/captain/policy-rule/list?captain_instance_id=${tenantCaptainInstanceId}`, null,
      { 'err': null },
      30000,
      tenantHeaders
    )

    // Cert list
    await apiCall('Tenant: cert visible', 'GET', `/api/captain/cert/list?captain_instance_id=${tenantCaptainInstanceId}`, null,
      { 'err': null },
      30000,
      tenantHeaders
    )

    // IP group list — should be visible if mapped via rule ingroup
    await apiCall('Tenant: IP group visible', 'GET', `/api/captain/ip-group/list?captain_instance_id=${tenantCaptainInstanceId}`, null,
      { 'err': null },
      30000,
      tenantHeaders
    )
  }

  console.log(`\n📊 Site Binding Enhancement: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
