// Integration: system config pages
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  await loginAs(page)
  let p = 0, f = 0

  const tests = [
    ['对接配置', '系统管理', '对接配置', async () => {
      await page.locator('.el-form-item:has-text("纵横地址") span').first().waitFor({ state: 'visible', timeout: 5000 })
      const content = await page.locator('.layout__content').first().textContent()
      if (!content.includes('10.2.102.76')) throw new Error('Content check failed')
    }],
    ['密码策略', '系统管理', '密码策略', () => true],
    ['登录安全', '系统管理', '登录安全', () => true],
    ['高亮 IP', '系统管理', '高亮 IP', () => true],
    ['API Token', '个人设置', 'API Token', () => true],
  ]

  for (const [name, submenu, item, check] of tests) {
    try {
      await navTo(page, submenu, item)
      await check()
      console.log(`✅ ${name}`); p++
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  console.log(`\n📊 System: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
