// Test data helpers — seed and cleanup test data, only touch what we create
const path = require('path')
const { chromium } = require('playwright')
const { launchOptions, getAuthCookieHeader } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'

const SEED_SITE_PREFIX = '__seed_'

// Standard site creation payload (minimal valid fields for Software Reverse Proxy)
function sitePayload(name, port, captainInstanceId) {
  if (!captainInstanceId) throw new Error('captainInstanceId is required')
  return {
    captain_instance_id: captainInstanceId,
    is_enabled: true,
    name,
    server_names: [`${name}.example.com`],
    url_paths: [{ op: 'pre', url_path: '/' }],
    ports: [{ port, ssl: false, non_http: false, http2: false, sni: false, proxy_protocol: false }],
    remark: 'seed data for e2e',
    ssl_cert: null,
    policy_group: null,
    session_method: { type: 'off', param: '' },
    detector_ip_source: [],
    proxy_ip_list: [],
    proxy_ip_groups: [],
    access_log: { is_enabled: true, log_request_header: false, log_response_header: false, log_option: 'Drop', req_body: false, rsp_body: false },
    backend_config: {
      type: 'proxy', load_balance_policy: 'Round Robin',
      servers: [{ host: '10.0.0.1', port: 80, protocol: 'http', is_enabled: true, weight: 1, health_check_status: '' }],
      x_forwarded_for_action: 'append', keepalive_config: 'default_keepalive_config',
      keepalive: '0', keepalive_timeout: '0',
      custom_config: { ignore_types: [], custom: {}, custom_web: [] },
      slow_attack: { is_enabled: false },
    },
    health_check_status: '',
    dynamic_resolve_upstream_config: { is_enabled: false, dynamic_resolve_fallback: 'next', dynamic_resolve_fail_timeout: 10, resolver_config: { valid: 0, resolver_timeout: 30 } },
    deep_detection_config: { is_enabled: false },
    anti_tamper_status: 'not_enabled',
    anti_tamper_rules: [],
    proxy_bind_config: { enable: false, hash_select_ip_method: 'remote_addr_and_port', proxy_bind_ip_list: [] },
    bot_config: { is_enabled: false },
    ntlm_enabled: false,
    selected_tengine: { type: 'all', tengine_list: null },
    proxy_protocol: false,
    realip_config_enable: false,
    realip_config: { set_real_ip_from: '', real_ip_header: 'proxy_protocol' },
    asset_group: 1,
    ip: [],
    ssl_protocols: [],
    ssl_ciphers: '',
    operation_mode: 'Software Reverse Proxy',
  }
}

// Login and return cookie header + page context
async function login(page) {
  return getAuthCookieHeader(page, 'admin')
}

// Ensure at least `minCount` sites exist on the given Captain instance.
// Creates seed sites if needed. Returns array of site IDs created by this call.
async function ensureSites(page, cookieHeader, captainInstanceId, minCount = 2) {
  if (!captainInstanceId) throw new Error('captainInstanceId is required')
  const resp = await page.request.get(`${BACKEND_URL}/api/captain/site/list?captain_instance_id=${captainInstanceId}`, {
    headers: { Cookie: cookieHeader },
  })
  const data = await resp.json()
  const existing = data.data?.items || []
  const needed = Math.max(0, minCount - existing.length)
  const created = []
  for (let i = 0; i < needed; i++) {
    const name = `${SEED_SITE_PREFIX}${Date.now()}_${i}`
    const port = 20000 + Math.floor(Math.random() * 10000)
    const createResp = await page.request.post(`${BACKEND_URL}/api/captain/site`, {
      headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
      data: sitePayload(name, port, captainInstanceId),
    })
    const createData = await createResp.json()
    if (createData.err === null && createData.data?.id) {
      created.push(createData.data.id)
      // Also create site binding for tenant_group 1
      await page.request.post(`${BACKEND_URL}/api/binding/site/create`, {
        headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
        data: { tenant_group_id: 1, captain_instance_id: captainInstanceId, site_ids: [createData.data.id] },
      }).catch(() => {})
    }
  }
  return created
}

// Delete only the sites we created (by ID list)
// Uses id__in format matching SafeLine's Captain API (NOT delete_all_resources which deletes ALL sites)
async function cleanupSites(page, cookieHeader, siteIds, captainInstanceId) {
  if (!captainInstanceId) throw new Error('captainInstanceId is required')
  for (const id of siteIds) {
    await page.request.delete(`${BACKEND_URL}/api/captain/site`, {
      headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
      data: { captain_instance_id: captainInstanceId, id__in: [id] },
    }).catch(() => {})
  }
}

module.exports = { BACKEND_URL, SEED_SITE_PREFIX, sitePayload, login, ensureSites, cleanupSites }
