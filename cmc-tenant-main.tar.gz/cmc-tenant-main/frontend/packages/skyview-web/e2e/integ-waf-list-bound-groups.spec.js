// Integration: WAF list — admin sees "绑定租户组" column, non-admin does not; binding sync
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, navTo, getRows, getTopMenuTexts, CREDENTIALS, launchOptions, loginAs, waitForTableData, getAuthCookieHeader } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'

;(async () => {
  const browser = await chromium.launch(launchOptions())
  let p = 0, f = 0

  // --- Test 1: Admin user should see "绑定租户组" column ---
  const adminPage = await browser.newPage()
  let adminCookies
  try {
    // Login via API to get cookies for subsequent API calls
    adminCookies = await getAuthCookieHeader(adminPage, 'admin')
  } catch (e) { f++; console.log(`❌ Admin API login: ${e.message}`); process.exit(1) }

  const apiHeaders = { Cookie: adminCookies, 'Content-Type': 'application/json' }

  // Helper: get column cell texts by header name
  async function getColumnCells(page, headerName) {
    const headerTexts = await page.locator('.el-table__header-wrapper th').allTextContents()
    const colIndex = headerTexts.findIndex(t => t.includes(headerName))
    if (colIndex < 0) return null
    return page.locator('.el-table__body-wrapper .el-table__row').evaluateAll(
      (rows, idx) => rows.map(r => r.children[idx]?.textContent?.trim() || ''),
      colIndex
    )
  }

  try {
    await loginAs(adminPage, 'admin')
    await navTo(adminPage, '防护管理', 'WAF 列表')
    await waitForTableData(adminPage)

    // Check column header exists
    const headerTexts = await adminPage.locator('.el-table__header-wrapper th').allTextContents()
    const hasBoundColumn = headerTexts.some(t => t.includes('绑定租户组'))
    if (!hasBoundColumn) throw new Error('"绑定租户组" column header not found')
    console.log('✅ Admin: "绑定租户组" column visible'); p++

    // Verify column data
    const rows = await getRows(adminPage)
    if (rows > 0) {
      const cells = await getColumnCells(adminPage, '绑定租户组')
      if (cells) {
        const hasValidData = cells.every(c => typeof c === 'string')
        if (!hasValidData) throw new Error('Invalid cell data in "绑定租户组" column')
        console.log(`✅ Admin: "绑定租户组" column data valid (${rows} rows, e.g. "${cells[0] || '(empty)'}")`); p++
      }
    } else {
      console.log('✅ Admin: "绑定租户组" column data (no rows, column present)'); p++
    }
  } catch (e) { f++; console.log(`❌ Admin "绑定租户组": ${e.message}`) }

  // --- Test 2: Create new WAF binding, verify "绑定租户组" updates in WAF list ---
  try {
    // Get all tenant groups
    const tgResp = await adminPage.request.get(`${BACKEND_URL}/api/tenant-group/list?offset=0&count=100`, { headers: apiHeaders })
    const tgData = await tgResp.json()
    const groups = tgData.data?.items || []
    if (groups.length < 2) throw new Error('Need at least 2 tenant groups to test binding sync')

    // Get WAF bindings for first group
    const list1Resp = await adminPage.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=${groups[0].id}`, { headers: apiHeaders })
    const list1Data = await list1Resp.json()
    const tg1Bindings = list1Data.data?.items || []
    if (tg1Bindings.length === 0) throw new Error('First tenant group has no WAF bindings')
    const targetWafId = tg1Bindings[0].captain_instance_id

    // Check if second group already bound to this WAF
    const list2Resp = await adminPage.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=${groups[1].id}`, { headers: apiHeaders })
    const list2Data = await list2Resp.json()
    const tg2BoundIds = (list2Data.data?.items || []).map(b => b.captain_instance_id)
    let createdBindingId = null

    if (!tg2BoundIds.includes(targetWafId)) {
      // Bind second group to the same WAF
      const createResp = await adminPage.request.post(`${BACKEND_URL}/api/binding/waf/create`, {
        headers: apiHeaders,
        data: { tenant_group_id: groups[1].id, captain_instance_ids: [targetWafId] },
      })
      const createData = await createResp.json()
      if (createData.err !== null) throw new Error(`Create binding failed: ${createData.msg}`)
      // Find the new binding id
      const afterResp = await adminPage.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=${groups[1].id}`, { headers: apiHeaders })
      const afterData = await afterResp.json()
      const newBinding = (afterData.data?.items || []).find(b => b.captain_instance_id === targetWafId)
      createdBindingId = newBinding?.id || null
      console.log(`✅ Created binding: group "${groups[1].name}" → WAF ${targetWafId}`);
    } else {
      console.log(`ℹ️  Group "${groups[1].name}" already bound to WAF ${targetWafId}, skip create`);
    }

    // Navigate to WAF list and verify "绑定租户组" now shows both groups
    await navTo(adminPage, '防护管理', 'WAF 列表')
    await waitForTableData(adminPage)

    const cells = await getColumnCells(adminPage, '绑定租户组')
    if (!cells) throw new Error('"绑定租户组" column not found after refresh')

    // Find the row for targetWafId — match by instance ID column
    const idCells = await getColumnCells(adminPage, '实例 ID')
    const targetRowIndex = idCells ? idCells.findIndex(c => String(c) === String(targetWafId)) : -1
    if (targetRowIndex < 0) throw new Error(`WAF ${targetWafId} row not found in list`)

    const boundGroupsText = cells[targetRowIndex]
    const group1Name = groups[0].name
    const group2Name = groups[1].name
    const hasGroup1 = boundGroupsText.includes(group1Name)
    const hasGroup2 = boundGroupsText.includes(group2Name)
    if (!hasGroup1 || !hasGroup2) throw new Error(`Expected both "${group1Name}" and "${group2Name}" in "${boundGroupsText}"`)
    console.log(`✅ Binding sync: WAF ${targetWafId} "绑定租户组" = "${boundGroupsText}"`); p++

    // Cleanup: delete the binding we created
    if (createdBindingId) {
      await adminPage.request.delete(`${BACKEND_URL}/api/binding/waf/delete`, {
        headers: apiHeaders,
        data: { ids: [createdBindingId] },
      })
      console.log(`✅ Cleanup: deleted binding ${createdBindingId}`)

      // Verify cleanup reflected in WAF list
      await navTo(adminPage, '防护管理', 'WAF 列表')
      await waitForTableData(adminPage)
      const afterCells = await getColumnCells(adminPage, '绑定租户组')
      const afterIdCells = await getColumnCells(adminPage, '实例 ID')
      const afterRowIndex = afterIdCells ? afterIdCells.findIndex(c => String(c) === String(targetWafId)) : -1
      if (afterRowIndex >= 0 && afterCells) {
        const afterText = afterCells[afterRowIndex]
        const stillHasGroup2 = afterText.includes(group2Name)
        if (stillHasGroup2) throw new Error(`Group "${group2Name}" still visible after unbind: "${afterText}"`)
        console.log(`✅ Cleanup sync: after unbind, "绑定租户组" = "${afterText}"`); p++
      }
    }
  } catch (e) { f++; console.log(`❌ Binding sync: ${e.message}`) }

  // --- Test 3: Non-admin user should NOT see "绑定租户组" column ---
  const tenantPage = await browser.newPage()
  try {
    await loginAs(tenantPage, 'tenant_admin')
    await navTo(tenantPage, '防护管理', 'WAF 列表')
    await waitForTableData(tenantPage)

    const headerTexts = await tenantPage.locator('.el-table__header-wrapper th').allTextContents()
    const hasBoundColumn = headerTexts.some(t => t.includes('绑定租户组'))
    if (hasBoundColumn) throw new Error('"绑定租户组" column should NOT be visible for non-admin')
    console.log('✅ Non-admin: "绑定租户组" column hidden'); p++
  } catch (e) { f++; console.log(`❌ Non-admin "绑定租户组": ${e.message}`) }

  console.log(`\n📊 WAF List Bound Tenant Group: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
