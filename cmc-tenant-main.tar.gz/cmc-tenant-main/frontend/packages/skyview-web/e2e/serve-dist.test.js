#!/usr/bin/env node
// Unit checks for the lightweight E2E dist server.

const assert = require('assert')
const fs = require('fs')
const http = require('http')
const os = require('os')
const path = require('path')
const { createDistServer, safeStaticPath } = require('./serve-dist')

function listen(server) {
  return new Promise(resolve => {
    server.listen(0, '127.0.0.1', () => resolve(server.address().port))
  })
}

function close(server) {
  return new Promise(resolve => server.close(resolve))
}

function request(port, requestPath, options = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      hostname: '127.0.0.1',
      port,
      path: requestPath,
      method: options.method || 'GET',
      headers: options.headers || {},
    }, res => {
      let body = ''
      res.setEncoding('utf8')
      res.on('data', chunk => { body += chunk })
      res.on('end', () => resolve({
        status: res.statusCode,
        headers: res.headers,
        body,
      }))
    })
    req.on('error', reject)
    if (options.body) req.write(options.body)
    req.end()
  })
}

;(async () => {
  const tmpRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'cmc-e2e-dist-'))
  const distDir = path.join(tmpRoot, 'dist')
  fs.mkdirSync(path.join(distDir, 'static'), { recursive: true })
  fs.writeFileSync(path.join(distDir, 'index.html'), '<!doctype html><div id="app">index</div>')
  fs.writeFileSync(path.join(distDir, 'static', 'app.js'), 'window.__ok = true')
  fs.writeFileSync(path.join(tmpRoot, 'secret.txt'), 'do-not-serve')

  let capturedApiRequest = null
  const backend = http.createServer((req, res) => {
    let body = ''
    req.on('data', chunk => { body += chunk })
    req.on('end', () => {
      capturedApiRequest = {
        method: req.method,
        url: req.url,
        header: req.headers['x-test-header'],
        body,
      }
      res.writeHead(418, {
        'content-type': 'application/json',
        'x-backend-header': 'forwarded',
      })
      res.end(JSON.stringify({ ok: true }))
    })
  })

  const backendPort = await listen(backend)
  const frontend = createDistServer({
    backendUrl: `http://127.0.0.1:${backendPort}`,
    distDir,
  })
  const frontendPort = await listen(frontend)

  try {
    assert.strictEqual(safeStaticPath('/%2e%2e/secret.txt', distDir), null)

    const indexResp = await request(frontendPort, '/')
    assert.strictEqual(indexResp.status, 200)
    assert.match(indexResp.headers['content-type'], /text\/html/)
    assert.match(indexResp.body, /id="app"/)

    const jsResp = await request(frontendPort, '/static/app.js')
    assert.strictEqual(jsResp.status, 200)
    assert.match(jsResp.headers['content-type'], /application\/javascript/)
    assert.strictEqual(jsResp.headers['cache-control'], 'no-store')
    assert.match(jsResp.body, /__ok/)

    const fallbackResp = await request(frontendPort, '/tenant/groups')
    assert.strictEqual(fallbackResp.status, 200)
    assert.match(fallbackResp.body, /id="app"/)

    const traversalResp = await request(frontendPort, '/%2e%2e/secret.txt')
    assert.strictEqual(traversalResp.status, 403)
    assert.doesNotMatch(traversalResp.body, /do-not-serve/)

    const apiResp = await request(frontendPort, '/api/auth/current?x=1', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-test-header': 'keep-me',
      },
      body: '{"hello":"world"}',
    })
    assert.strictEqual(apiResp.status, 418)
    assert.strictEqual(apiResp.headers['x-backend-header'], 'forwarded')
    assert.deepStrictEqual(capturedApiRequest, {
      method: 'POST',
      url: '/api/auth/current?x=1',
      header: 'keep-me',
      body: '{"hello":"world"}',
    })

    console.log('serve-dist checks passed')
  } finally {
    await close(frontend)
    await close(backend)
    fs.rmSync(tmpRoot, { recursive: true, force: true })
  }
})().catch(error => {
  console.error(error)
  process.exit(1)
})
