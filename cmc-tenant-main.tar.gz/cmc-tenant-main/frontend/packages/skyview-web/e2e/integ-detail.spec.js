const { chromium } = require('playwright')
const path = require('path')
const { TARGET_URL, CREDENTIALS, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, getAuthCookieHeader } = require(path.join(__dirname, 'integ-helpers'))

function findRowByLabel(page, label) {
  return page.locator('.editable-row').filter({ hasText: new RegExp(`^${label}`) })
}

async function clickEdit(page, label) {
  const row = findRowByLabel(page, label)
  await row.locator('.el-icon-edit').first().click()
  await page.waitForTimeout(400)
  return row
}

async function saveInline(page, label) {
  // Click save button in the editing row identified by label
  const row = findRowByLabel(page, label)
  const saveBtn = row.locator('button.el-button--primary:has-text("确定")').first()
  await saveBtn.click()
  // Wait for the input/textarea inside this row to disappear (edit mode exits)
  await row.locator('input, textarea').first()
    .waitFor({ state: 'hidden', timeout: 10000 })
    .catch(() => page.waitForTimeout(3000))
  await page.waitForTimeout(800)
}

async function cancelInline(page, label) {
  const row = findRowByLabel(page, label)
  const cancelBtn = row.locator('button:has-text("取消")').first()
  await cancelBtn.click()
  await page.waitForTimeout(400)
}

// Read the value from the second direct-child <span> of the editable-row
async function getRowValue(page, label) {
  const row = findRowByLabel(page, label)
  // EditableRow renders: <span=label> <span=value-container> ... <button>
  // The value container is the 2nd direct child span
  const valueContainer = row.locator(':scope > span').nth(1)
  return (await valueContainer.textContent()).trim()
}

// Close all dialog wrappers and wait for them to clear
async function closeAllDialogs(page) {
  for (let i = 0; i < 3; i++) {
    const visible = page.locator('.el-dialog:visible')
    if (await visible.count() === 0) break
    // Click the X close button or cancel button
    await visible.locator('.el-dialog__headerbtn').first().click().catch(() =>
      visible.locator('button:has-text("取消")').first().click().catch(() => {}))
    await page.waitForTimeout(500)
  }
  // Wait for any remaining visible dialog wrappers to disappear
  await page.waitForTimeout(300)
}

async function openDialog(page, label) {
  await closeAllDialogs(page)
  const row = findRowByLabel(page, label)
  await row.locator('.el-icon-edit').first().click()
  await page.waitForTimeout(500)
  const dialog = page.locator('.el-dialog:visible')
  if (await dialog.count() === 0) throw new Error('Dialog not opened')
  return dialog
}

async function saveDialog(page) {
  const confirmBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("确定")').first()
  await confirmBtn.click()
  await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 10000 }).catch(() => page.waitForTimeout(2000))
  await page.waitForTimeout(500)
}

async function cancelDialog(page) {
  const cancelBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("取消")').first()
  await cancelBtn.click()
  await page.waitForTimeout(500)
}

// Ensure no dialog is blocking
async function dismissAnyDialog(page) {
  await closeAllDialogs(page)
  // Also dismiss any remaining inline edit modes
  const inlineCancel = page.locator('.editable-row button:has-text("取消")').first()
  if (await inlineCancel.count() > 0) {
    await inlineCancel.click().catch(() => {})
    await page.waitForTimeout(300)
  }
}

async function resetTenantAdminPassword(page) {
  const backendURL = TARGET_URL.replace(':3000', ':8080')
  const tenantCred = CREDENTIALS.tenant_admin

  try {
    const adminCookieHeader = await getAuthCookieHeader(page, 'admin')

    const listResp = await page.request.post(`${backendURL}/api/user/list`, {
      headers: { Cookie: adminCookieHeader },
      data: { offset: 0, count: 100 },
    })
    const listData = await listResp.json()
    const testAdmin = (listData.data?.items || []).find(u => u.username === tenantCred.username)
    if (!testAdmin) return false

    const credResp = await page.request.put(`${backendURL}/api/user/credential`, {
      headers: { Cookie: adminCookieHeader },
      data: { id: testAdmin.id },
    })
    const credData = await credResp.json()
    const tempPwd = credData.data?.password
    if (!tempPwd) return false

    const tmpLoginResp = await page.request.post(`${backendURL}/api/auth/login`, {
      data: { username: tenantCred.username, password: tempPwd },
    })
    const tmpLoginData = await tmpLoginResp.json()
    if (tmpLoginData.err !== null) return false

    const tmpCookies = await page.context().cookies()
    const tmpCookieHeader = tmpCookies.map(c => `${c.name}=${c.value}`).join('; ')
    const changeResp = await page.request.put(`${backendURL}/api/user/current/password`, {
      headers: { Cookie: tmpCookieHeader },
      data: {
        old_password: tempPwd,
        new_password: tenantCred.password,
        dup_password: tenantCred.password,
      },
    })
    const changeData = await changeResp.json()
    return changeData.err === null
  } catch {
    return false
  }
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  let p = 0, f = 0

  // ─── Navigate to site detail ───
  try {
    await navTo(page, '防护管理', '站点管理')
    await waitForWafSelector(page)
    await waitForTableData(page)
    if ((await getRows(page)) === 0) throw new Error('No site rows')
    await Promise.all([
      page.waitForNavigation({ waitUntil: 'domcontentloaded' }).catch(() => {}),
      page.locator('.el-table__row').first().locator('button:has-text("详情")').click(),
    ])
    await page.locator('.el-page-header, .layout__content').first().waitFor({ state: 'visible', timeout: 5000 })
    if (!page.url().includes('/detail')) throw new Error('Not on detail page')
    console.log('✅ 进入站点详情页'); p++
  } catch (e) { f++; console.log(`❌ 进入站点详情页: ${e.message}`); await browser.close(); process.exit(1) }

  await page.locator('.editable-row').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => page.waitForTimeout(2000))

  // ─── Read-only fields ───
  try {
    const typeText = await getRowValue(page, '站点类型')
    if (!typeText || typeText === '-') throw new Error('站点类型为空')
    console.log(`✅ 只读字段有值 (站点类型: ${typeText})`); p++
  } catch (e) { f++; console.log(`❌ 只读字段有值: ${e.message}`) }

  // ─── SAVE: site name ───
  let originalName = ''
  try {
    originalName = await getRowValue(page, '站点名称')
    await clickEdit(page, '站点名称')
    await findRowByLabel(page, '站点名称').locator('input').first().fill('E2E测试站点')
    await saveInline(page, '站点名称')
    const saved = await getRowValue(page, '站点名称')
    if (!saved.includes('E2E测试站点')) throw new Error(`got: ${saved}`)
    console.log('✅ 站点名称保存成功 (→ E2E测试站点)'); p++
  } catch (e) { f++; console.log(`❌ 站点名称保存: ${e.message}`); await dismissAnyDialog(page) }

  // ─── RESTORE: site name ───
  try {
    await clickEdit(page, '站点名称')
    await findRowByLabel(page, '站点名称').locator('input').first().fill(originalName || '测试站点')
    await saveInline(page, '站点名称')
    console.log('✅ 站点名称还原'); p++
  } catch (e) { f++; console.log(`❌ 站点名称还原: ${e.message}`); await dismissAnyDialog(page) }

  // ─── CANCEL: site name does not save ───
  try {
    const before = await getRowValue(page, '站点名称')
    await clickEdit(page, '站点名称')
    await findRowByLabel(page, '站点名称').locator('input').first().fill('ShouldNotSave')
    await cancelInline(page, '站点名称')
    const after = await getRowValue(page, '站点名称')
    if (after.includes('ShouldNotSave')) throw new Error('Cancel saved the value')
    console.log('✅ 取消编辑不保存'); p++
  } catch (e) { f++; console.log(`❌ 取消编辑不保存: ${e.message}`) }

  // ─── SAVE: site status toggle ───
  try {
    const before = await getRowValue(page, '站点状态')
    const wasEnabled = before.includes('正常') || before.includes('启用')
    await clickEdit(page, '站点状态')
    const select = findRowByLabel(page, '站点状态').locator('.el-select').first()
    await select.click()
    const target = wasEnabled ? '禁用' : '启用'
    await page.locator('.el-select-dropdown__item').filter({ hasText: target }).first().click()
    await page.waitForTimeout(200)
    await saveInline(page, '站点状态')
    const after = await getRowValue(page, '站点状态')
    // After disabling, should show "禁用"; after enabling, could show "正常" or "启用"
    const expectedText = wasEnabled ? '禁用' : '正常'
    if (!after.includes(expectedText) && !after.includes(target)) throw new Error(`${before} → ${after}`)
    console.log(`✅ 站点状态切换保存 (${before} → ${after})`); p++
    // Restore
    await clickEdit(page, '站点状态')
    const select2 = findRowByLabel(page, '站点状态').locator('.el-select').first()
    await select2.click()
    await page.locator('.el-select-dropdown__item').filter({ hasText: wasEnabled ? '启用' : '禁用' }).first().click()
    await page.waitForTimeout(200)
    await saveInline(page, '站点状态')
    console.log('✅ 站点状态还原'); p++
  } catch (e) { f++; console.log(`❌ 站点状态切换: ${e.message}`) }

  // ─── SAVE: remark ───
  let originalRemark = ''
  try {
    originalRemark = await getRowValue(page, '备注信息')
    await clickEdit(page, '备注信息')
    await findRowByLabel(page, '备注信息').locator('textarea').first().fill('E2E备注测试')
    await saveInline(page, '备注信息')
    const saved = await getRowValue(page, '备注信息')
    if (!saved.includes('E2E备注测试')) throw new Error(`got: ${saved}`)
    console.log('✅ 备注信息保存成功 (→ E2E备注测试)'); p++
  } catch (e) { f++; console.log(`❌ 备注信息保存: ${e.message}`) }

  // Restore remark
  try {
    await clickEdit(page, '备注信息')
    await findRowByLabel(page, '备注信息').locator('textarea').first().fill(originalRemark === '-' ? '' : originalRemark)
    await saveInline(page, '备注信息')
    console.log('✅ 备注信息还原'); p++
  } catch (e) { f++; console.log(`❌ 备注信息还原: ${e.message}`) }

  // ─── INLINE SAVE: domain (comma-separated input) ───
  let originalDomain = ''
  try {
    originalDomain = await getRowValue(page, '域名')
    await clickEdit(page, '域名')
    await findRowByLabel(page, '域名').locator('input').first().fill('e2e.example.com')
    await saveInline(page, '域名')
    const saved = await getRowValue(page, '域名')
    if (!saved.includes('e2e.example.com')) throw new Error(`got: ${saved}`)
    console.log('✅ 域名保存成功 (→ e2e.example.com)'); p++
  } catch (e) { f++; console.log(`❌ 域名保存: ${e.message}`); await dismissAnyDialog(page) }

  // Restore domain — use original value since server_names is required
  try {
    await clickEdit(page, '域名')
    await findRowByLabel(page, '域名').locator('input').first().fill(originalDomain || 'localhost')
    await saveInline(page, '域名')
    console.log('✅ 域名还原'); p++
  } catch (e) { f++; console.log(`❌ 域名还原: ${e.message}`); await dismissAnyDialog(page) }

  // ─── DIALOG: ports ───
  try {
    const dialog = await openDialog(page, '监听端口')
    const title = await dialog.locator('.el-dialog__title').textContent()
    if (!title.includes('监听端口')) throw new Error(`title: ${title}`)
    await cancelDialog(page)
    console.log('✅ 监听端口弹窗打开'); p++
  } catch (e) { f++; console.log(`❌ 监听端口弹窗: ${e.message}`); await dismissAnyDialog(page) }

  // ─── DIALOG: url_paths ───
  try {
    const dialog = await openDialog(page, '生效地址')
    const title = await dialog.locator('.el-dialog__title').textContent()
    if (!title.includes('生效地址')) throw new Error(`title: ${title}`)
    await cancelDialog(page)
    console.log('✅ 生效地址弹窗打开'); p++
  } catch (e) { f++; console.log(`❌ 生效地址弹窗: ${e.message}`); await dismissAnyDialog(page) }

  // ─── DIALOG: IP ───
  try {
    const dialog = await openDialog(page, 'IP')
    if (await dialog.locator('.el-select').count() === 0) throw new Error('No IP select')
    await cancelDialog(page)
    console.log('✅ IP弹窗打开'); p++
  } catch (e) { f++; console.log(`❌ IP弹窗: ${e.message}`); await dismissAnyDialog(page) }

  // ─── Non-editable fields ───
  try {
    for (const label of ['站点类型', '创建时间', '最后更新时间']) {
      const row = findRowByLabel(page, label)
      if (await row.count() > 0 && await row.locator('.el-icon-edit').count() > 0)
        throw new Error(`${label} has edit icon`)
    }
    console.log('✅ 不可编辑字段无编辑图标'); p++
  } catch (e) { f++; console.log(`❌ 不可编辑字段: ${e.message}`) }

  // ─── tenant_admin ───
  try {
    const tenantReady = await resetTenantAdminPassword(page)
    if (!tenantReady) {
      console.log('⚠️ tenant_admin 测试账号不可用，跳过可编辑性验证'); p++
      throw new Error('__tenant_admin_skipped__')
    }
    await loginAs(page, 'tenant_admin')
    const layoutVisible = await page.locator('.layout').first().isVisible().catch(() => false)
    if (!layoutVisible || page.url().includes('/login')) {
      console.log('⚠️ tenant_admin 未进入系统，跳过可编辑性验证'); p++
      throw new Error('__tenant_admin_skipped__')
    }
    await navTo(page, '防护管理', '站点管理')
    await waitForWafSelector(page)
    await waitForTableData(page)
    if ((await getRows(page)) > 0) {
      await Promise.all([
        page.waitForNavigation({ waitUntil: 'domcontentloaded' }).catch(() => {}),
        page.locator('.el-table__row').first().locator('button:has-text("详情")').click(),
      ])
      await page.locator('.el-page-header, .layout__content').first().waitFor({ state: 'visible', timeout: 5000 })
      await page.waitForTimeout(1000)
      const editIcons = await page.locator('.editable-row .el-icon-edit').count()
      if (editIcons === 0) throw new Error('no edit icons')
      console.log(`✅ tenant_admin 可编辑 (${editIcons} fields)`); p++
    } else { console.log('⚠️ 无数据'); p++ }
  } catch (e) {
    if (e.message !== '__tenant_admin_skipped__') {
      f++; console.log(`❌ tenant_admin: ${e.message}`)
    }
  }

  // ─── Other pages ───
  try {
    await loginAs(page, 'admin')
    await navTo(page, '威胁监测', '攻击检测日志')
    if ((await getRows(page)) > 0) {
      const beforeDetailURL = page.url()
      await page.locator('.el-table__row').first().locator('button:has-text("详情")').first().click()
      await waitForContent(page, 3000)
      console.log('✅ 攻击检测日志详情'); p++
      if (page.url() !== beforeDetailURL) {
        await page.goBack(); await waitForContent(page, 2000)
      }
    } else { console.log('⚠️ 无日志数据'); p++ }
  } catch (e) { f++; console.log(`❌ 攻击检测日志详情: ${e.message}`) }

  try {
    await navTo(page, '系统管理', '高亮 IP')
    if (await page.locator('.el-collapse-item__header').count() > 0) throw new Error('Old collapse exists')
    console.log('✅ 高亮 IP (无折叠面板)'); p++
  } catch (e) { f++; console.log(`❌ 高亮 IP: ${e.message}`) }

  console.log(`\n📊 Detail & edit: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
