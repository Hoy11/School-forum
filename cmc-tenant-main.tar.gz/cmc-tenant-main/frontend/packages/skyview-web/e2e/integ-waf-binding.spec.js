// Integration: WAF binding enhancement — multi-select create, cascade delete check
const path = require('path')
const { chromium } = require('playwright')
const { launchOptions, getAuthCookieHeader } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  let p = 0, f = 0

  // --- Login as admin ---
  let cookies
  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    cookies = await page.context().cookies()
    if (!cookies.some(c => c.name === 'token')) throw new Error('No token cookie')
    if (!cookieHeader.includes('token=')) throw new Error('No token cookie header')
    console.log('✅ Login (admin)'); p++
  } catch (e) { f++; console.log(`❌ Login: ${e.message}`); process.exit(1) }

  const headers = { Cookie: cookies.map(c => `${c.name}=${c.value}`).join('; ') }

  async function apiCall(name, method, urlPath, body, checks) {
    try {
      const opts = { headers: { ...headers } }
      if (body) { opts.data = body; opts.headers['Content-Type'] = 'application/json' }
      const resp = method === 'POST' ? await page.request.post(`${BACKEND_URL}${urlPath}`, opts)
                                   : method === 'DELETE' ? await page.request.delete(`${BACKEND_URL}${urlPath}`, opts)
                                   : method === 'PUT' ? await page.request.put(`${BACKEND_URL}${urlPath}`, opts)
                                   : await page.request.get(`${BACKEND_URL}${urlPath}`, opts)
      const data = await resp.json()
      for (const [field, expected] of Object.entries(checks)) {
        const actual = field.split('.').reduce((o, k) => o?.[k], data)
        if (typeof expected === 'function') {
          if (!expected(actual)) throw new Error(`${field}=${JSON.stringify(actual)}, check failed`)
        } else if (actual !== expected) {
          throw new Error(`${field}=${JSON.stringify(actual)}, expected ${JSON.stringify(expected)}`)
        }
      }
      console.log(`✅ ${name}`); p++
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  async function apiGetExpectStatus(name, urlPath, expectedStatus, checks) {
    try {
      const resp = await page.request.get(`${BACKEND_URL}${urlPath}`, { headers })
      const data = await resp.json()
      if (resp.status() !== expectedStatus) {
        throw new Error(`status=${resp.status()}, expected ${expectedStatus}, body=${JSON.stringify(data)}`)
      }
      for (const [field, expected] of Object.entries(checks)) {
        const actual = field.split('.').reduce((o, k) => o?.[k], data)
        if (typeof expected === 'function') {
          if (!expected(actual, data)) throw new Error(`${field}=${JSON.stringify(actual)}, check failed`)
        } else if (actual !== expected) {
          throw new Error(`${field}=${JSON.stringify(actual)}, expected ${JSON.stringify(expected)}`)
        }
      }
      console.log(`✅ ${name}`); p++
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  async function missingTenantGroupID() {
    const resp = await page.request.get(`${BACKEND_URL}/api/tenant-group/list?offset=0&count=1000`, { headers })
    const data = await resp.json()
    const groups = data.data?.items || []
    const maxID = groups.reduce((max, group) => Math.max(max, Number(group.id) || 0), 0)
    return maxID + 100000
  }

  // --- 1. WAF available API returns proper format ---
  await apiCall('WAF available list', 'GET', '/api/binding/waf/available?tenant_group_id=1', null, {
    'err': null,
    'data': v => Array.isArray(v),
  })

  // Verify AvailableWaf field names (captain_instance_id, instance_name, instance_host, instance_status)
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/binding/waf/available?tenant_group_id=1`, { headers })
    const data = await resp.json()
    if (data.err !== null) throw new Error(`err=${data.err}`)
    if (!Array.isArray(data.data)) throw new Error('data is not array')
    if (data.data.length > 0) {
      const waf = data.data[0]
      if (typeof waf.captain_instance_id !== 'number') throw new Error(`captain_instance_id missing or not number: ${typeof waf.captain_instance_id}`)
      if (typeof waf.instance_name !== 'string') throw new Error(`instance_name missing or not string`)
      if (typeof waf.instance_host !== 'string') throw new Error(`instance_host missing or not string`)
      if (typeof waf.instance_status !== 'string') throw new Error(`instance_status missing or not string`)
      console.log('✅ AvailableWaf field names correct'); p++
    } else {
      console.log('✅ AvailableWaf field names (empty list, format OK)'); p++
    }
  } catch (e) { f++; console.log(`❌ AvailableWaf field names: ${e.message}`) }

  // --- 1b. WAF available rejects invalid or missing tenant_group_id ---
  for (const id of ['0', '-1', 'abc']) {
    await apiGetExpectStatus(`WAF available invalid tenant_group_id=${id}`, `/api/binding/waf/available?tenant_group_id=${id}`, 400, {
      'err': 'bad_request',
      'msg': v => typeof v === 'string' && v.length > 0,
      'data': v => !v || !Array.isArray(v.items),
    })
  }

  try {
    const missingID = await missingTenantGroupID()
    await apiGetExpectStatus('WAF available missing tenant group', `/api/binding/waf/available?tenant_group_id=${missingID}`, 404, {
      'err': 'not_found',
      'msg': '租户组不存在',
      'data': v => !v || !Array.isArray(v.items),
    })
  } catch (e) { f++; console.log(`❌ WAF available missing tenant group: ${e.message}`) }

  // --- 2. WAF binding create with captain_instance_ids array (singular field should fail) ---
  await apiCall('WAF create with singular field (should fail)', 'POST', '/api/binding/waf/create',
    { tenant_group_id: 1, captain_instance_id: 999 },
    { 'err': 'bad_request' }
  )

  // --- 3. WAF binding cascade delete — fetch existing bindings ---
  let wafBindings = []
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=1`, { headers })
    const data = await resp.json()
    wafBindings = data.data?.items || []
    console.log(`✅ WAF bindings fetched (${wafBindings.length} rows)`); p++
  } catch (e) { f++; console.log(`❌ Fetch WAF bindings: ${e.message}`) }

  // --- 4. WAF cascade delete — if binding has site bindings, delete should fail ---
  for (const wb of wafBindings) {
    // Check if this WAF binding has site bindings
    let siteCount = 0
    try {
      const resp = await page.request.get(
        `${BACKEND_URL}/api/binding/site/list?tenant_group_id=${wb.tenant_group_id}&captain_instance_id=${wb.captain_instance_id}`,
        { headers }
      )
      const data = await resp.json()
      siteCount = data.data?.items?.length || 0
    } catch (e) { /* ignore */ }

    if (siteCount > 0) {
      // Delete should be blocked with has_site_bindings error
      await apiCall(`WAF delete blocked (has ${siteCount} sites)`, 'DELETE', '/api/binding/waf/delete',
        { ids: [wb.id] },
        { 'err': 'has_site_bindings', 'msg': '有站点还在使用此绑定关系' }
      )
    } else {
      // No site bindings — delete should succeed (but skip to avoid data loss in test)
      console.log(`✅ WAF binding ${wb.id} has no sites (delete would succeed)`); p++
    }
    break // Only test first binding
  }

  // --- 5. WAF delete with non-existent ID is a no-op (GORM succeeds even if no rows match) ---
  await apiCall('WAF delete non-existent ID (no-op)', 'DELETE', '/api/binding/waf/delete',
    { ids: [99999] },
    { 'err': null, 'msg': 'success' }
  )

  // --- 6. WAF instance sharing — different tenant groups can bind same WAF ---
  try {
    const tgResp = await page.request.get(`${BACKEND_URL}/api/tenant-group/list?offset=0&count=100`, { headers })
    const tgData = await tgResp.json()
    const groups = tgData.data?.items || []
    if (groups.length >= 2) {
      const tg1 = groups[0].id
      const tg2 = groups[1].id
      const list1Resp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=${tg1}`, { headers })
      const list1Data = await list1Resp.json()
      const tg1Bindings = list1Data.data?.items || []
      if (tg1Bindings.length > 0) {
        const sharedInstanceID = tg1Bindings[0].captain_instance_id
        const list2Resp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=${tg2}`, { headers })
        const list2Data = await list2Resp.json()
        const tg2Ids = (list2Data.data?.items || []).map(b => b.captain_instance_id)
        if (!tg2Ids.includes(sharedInstanceID)) {
          await apiCall('WAF shared across groups (tg2 binds same WAF)', 'POST', '/api/binding/waf/create',
            { tenant_group_id: tg2, captain_instance_ids: [sharedInstanceID] },
            { 'err': null, 'msg': 'success' }
          )
          const afterResp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=${tg2}`, { headers })
          const afterData = await afterResp.json()
          const afterIds = (afterData.data?.items || []).map(b => b.captain_instance_id)
          if (!afterIds.includes(sharedInstanceID)) throw new Error('WAF binding not found in tg2 list')
          console.log('✅ WAF shared across groups verified'); p++
          const newBinding = (afterData.data?.items || []).find(b => b.captain_instance_id === sharedInstanceID)
          if (newBinding) {
            await page.request.delete(`${BACKEND_URL}/api/binding/waf/delete`, {
              headers: { ...headers, 'Content-Type': 'application/json' },
              data: { ids: [newBinding.id] }
            })
          }
        } else {
          console.log('✅ WAF shared (already bound to both groups)'); p++
        }
      } else {
        console.log('✅ WAF shared (skipped: tg1 has no bindings)'); p++
      }
    } else {
      console.log('✅ WAF shared (skipped: fewer than 2 tenant groups)'); p++
    }
  } catch (e) { f++; console.log(`❌ WAF shared across groups: ${e.message}`) }

  // --- 7. WAF multi-select create — bind multiple WAFs at once ---
  try {
    const availResp = await page.request.get(`${BACKEND_URL}/api/binding/waf/available?tenant_group_id=1`, { headers })
    const availData = await availResp.json()
    const available = availData.data || []
    if (available.length >= 2) {
      const idsToBind = available.slice(0, 2).map(w => w.captain_instance_id)
      const existResp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=1`, { headers })
      const existData = await existResp.json()
      const existingIds = (existData.data?.items || []).map(b => b.captain_instance_id)
      const newIds = idsToBind.filter(id => !existingIds.includes(id))
      if (newIds.length >= 2) {
        await apiCall('WAF multi-select create (2 WAFs)', 'POST', '/api/binding/waf/create',
          { tenant_group_id: 1, captain_instance_ids: newIds },
          { 'err': null, 'msg': 'success' }
        )
        const afterResp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?tenant_group_id=1`, { headers })
        const afterData = await afterResp.json()
        const afterIds = (afterData.data?.items || []).map(b => b.captain_instance_id)
        const allPresent = newIds.every(id => afterIds.includes(id))
        if (!allPresent) throw new Error('Not all WAF bindings were created')
        console.log('✅ Both WAF bindings verified in list'); p++
        for (const newId of newIds) {
          const wb = (afterData.data?.items || []).find(b => b.captain_instance_id === newId)
          if (wb) {
            await page.request.delete(`${BACKEND_URL}/api/binding/waf/delete`, {
              headers: { ...headers, 'Content-Type': 'application/json' },
              data: { ids: [wb.id] }
            })
          }
        }
      } else {
        console.log('✅ Multi-select create (skipped: not enough non-bound WAFs available)'); p++
      }
    } else {
      console.log('✅ Multi-select create (skipped: fewer than 2 available WAFs)'); p++
    }
  } catch (e) { f++; console.log(`❌ WAF multi-select create: ${e.message}`) }

  console.log(`\n📊 WAF Binding Enhancement: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
