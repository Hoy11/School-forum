// Shared E2E test helpers for CMC Tenant
const TARGET_URL = process.env.TARGET_URL || 'http://localhost:3000'

const CREDENTIALS = {
  admin: { username: 'admin', password: 'admin123' },
  tenant_admin: { username: 'tenant_admin', password: 'admin123' },
  tenant: { username: 'tenant', password: 'admin123' },
}

async function login(page, role = 'admin') {
  await mockLoginApi(page, role)
  await page.goto(`${TARGET_URL}/login`)
  await page.waitForSelector('.login-box')

  const cred = CREDENTIALS[role]
  await page.fill('input[placeholder="用户名"]', cred.username)
  await page.fill('input[placeholder="密码"]', cred.password)
  await page.click('button:has-text("登录")')
  await page.waitForSelector('.layout', { timeout: 10000 }).catch(() => {})
  return page
}

async function mockLoginApi(page, role = 'admin', options = {}) {
  const { needChangePassword = false } = options
  const user = {
    id: 1,
    username: CREDENTIALS[role].username,
    role,
    tenant_group_id: role !== 'admin' ? 1 : null,
    tenant_group_name: role !== 'admin' ? '默认租户组' : null,
  }

  await page.route('**/api/auth/login', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        err: null,
        msg: 'success',
        data: { ...user, need_change_password: needChangePassword, user },
      }),
    })
  })

  await page.route('**/api/auth/current', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ err: null, msg: 'success', data: user }),
    })
  })

  const emptyPage = { err: null, msg: 'success', data: { total: 0, items: [] } }
  await page.route('**/api/user/list**', (route) => {
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(emptyPage) })
  })
  await page.route('**/api/tenant-group/list**', (route) => {
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(emptyPage) })
  })
  await page.route('**/api/binding/waf/list**', (route) => {
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(emptyPage) })
  })
}

function mockApi(page, path, responseData) {
  page.route(`**${path}**`, (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ err: null, msg: 'success', data: responseData }),
    })
  })
}

function mockPageApi(page, path, items = [], total = 0) {
  page.route(`**${path}**`, (route) => {
    const url = new URL(route.request().url())
    const offset = parseInt(url.searchParams.get('offset') || '0')
    const count = parseInt(url.searchParams.get('count') || '20')
    const pageItems = items.slice(offset, offset + count)

    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        err: null,
        msg: 'success',
        data: { total: total || items.length, items: pageItems },
      }),
    })
  })
}

async function navigateToPage(page, path) {
  // Wait for Vue router to be available (retry up to 5s)
  await page.waitForFunction(() => {
    const candidates = ['.layout', '.login-page', '.side-nav', 'body > div']
    for (const sel of candidates) {
      const el = document.querySelector(sel)
      if (el && el.__vue__) {
        let vue = el.__vue__
        while (vue && vue.$parent) vue = vue.$parent
        if (vue && vue.$router) return true
      }
    }
    return false
  }, { timeout: 5000 }).catch(() => {})

  await page.evaluate((url) => {
    const candidates = ['.layout', '.login-page', '.side-nav', 'body > div']
    for (const sel of candidates) {
      const el = document.querySelector(sel)
      if (el && el.__vue__) {
        let vue = el.__vue__
        while (vue && vue.$parent) vue = vue.$parent
        if (vue && vue.$router) { vue.$router.push(url); return }
      }
    }
    throw new Error('Vue router not found')
  }, path)
  await page.waitForTimeout(500)
}

async function expandMenu(page, groupTitle) {
  const submenu = page.locator(`.el-submenu:has-text("${groupTitle}")`)
  const title = submenu.locator('.el-submenu__title')
  if (await title.isVisible()) {
    await title.click()
    await page.waitForTimeout(300)
  }
}

async function loginAsRole(page, role = 'admin') {
  await mockLoginApi(page, role)
  await page.goto(`${TARGET_URL}/login`)
  await page.waitForSelector('.login-box')
  await page.fill('input[placeholder="用户名"]', CREDENTIALS[role].username)
  await page.fill('input[placeholder="密码"]', CREDENTIALS[role].password)
  await page.click('button:has-text("登录")')
  await page.waitForSelector('.layout', { timeout: 5000 })
}

function mockWafBindingList(page, items = [
  { id: 1, captain_instance_id: 1, instance_name: 'WAF-1', instance_host: '10.0.0.1', instance_status: 'running', tenant_group_id: 1, tenant_group_name: '默认组' },
]) {
  mockPageApi(page, '/api/binding/waf/list', items)
}

async function getTopMenuTexts(page) {
  const texts = await page.locator('.el-menu--horizontal > .el-menu-item').allTextContents()
  return texts.map((text) => text.trim()).filter(Boolean)
}

async function selectTopMenu(page, title) {
  await page.locator(`.el-menu--horizontal > .el-menu-item:has-text("${title}")`).first().click()
  await page.waitForTimeout(300)
}

function launchOptions() {
  const headless = !!(process.env.PLAYWRIGHT_HEADLESS || process.env.CI)
  return { headless, slowMo: headless ? 0 : 100 }
}

module.exports = {
  TARGET_URL,
  CREDENTIALS,
  login,
  loginAsRole,
  mockLoginApi,
  mockApi,
  mockPageApi,
  mockWafBindingList,
  navigateToPage,
  expandMenu,
  launchOptions,
  getTopMenuTexts,
  selectTopMenu,
}
