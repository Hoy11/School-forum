#!/usr/bin/env node
// Behavioral checks for select-tests.js.

const { execFileSync } = require('child_process')
const suites = require('./suites')

const suiteByFile = new Map(suites.map(suite => [suite.file, suite]))

function runSelect(args) {
  const output = execFileSync('node', ['e2e/select-tests.js', '--json', ...args], {
    cwd: __dirname + '/..',
    encoding: 'utf8',
    stdio: ['pipe', 'pipe', 'pipe'],
  })
  return JSON.parse(output)
}

function assert(condition, message) {
  if (!condition) throw new Error(message)
}

function hasSuite(result, file) {
  return result.suites.includes(file)
}

function layerSuites(layer) {
  return suites.filter(suite => !suite.disabled && suite.layers.includes(layer)).map(suite => suite.file).sort()
}

function assertContainsAll(actual, expected, label) {
  const missing = expected.filter(item => !actual.includes(item))
  assert(missing.length === 0, `${label} missing: ${missing.join(', ')}`)
}

const checks = [
  {
    name: 'matched impact-map path selects policy-rule/captain-proxy suites',
    run() {
      const result = runSelect(['--files', 'gateway/server/apis/captain/handler/policy_rule.go'])
      assert(result.fallback === null, 'matched path should not fallback')
      assert(result.changed_modules.includes('captain-proxy'), 'captain-proxy module not detected')
      assert(result.changed_modules.includes('policy-rule'), 'policy-rule module not detected')
      assert(hasSuite(result, 'integ-policy-rule.spec.js'), 'policy-rule suite not selected')
      assert(hasSuite(result, 'integ-api.spec.js'), 'api suite not selected')
    },
  },
  {
    name: 'unmatched product path falls back to smoke + critical',
    run() {
      const result = runSelect(['--files', 'gateway/some/new_unknown.go'])
      assert(result.fallback, 'unmatched product path should fallback')
      assertContainsAll(result.suites, layerSuites('smoke'), 'fallback smoke suites')
      assertContainsAll(result.suites, layerSuites('critical'), 'fallback critical suites')
    },
  },
  {
    name: 'changed E2E spec selects itself',
    run() {
      const result = runSelect(['--files', 'frontend/packages/skyview-web/e2e/integ-rbac.spec.js'])
      assert(result.fallback === null, 'changed E2E spec should not fallback')
      assert(result.changed_e2e_suites.includes('integ-rbac.spec.js'), 'changed E2E suite not reported')
      assert(hasSuite(result, 'integ-rbac.spec.js'), 'changed E2E suite not selected')
    },
  },
  {
    name: 'changed registered non-integ E2E spec selects itself',
    run() {
      const result = runSelect(['--files', 'frontend/packages/skyview-web/e2e/waf-list-version.spec.js'])
      assert(result.fallback === null, 'changed registered non-integ E2E spec should not fallback')
      assert(result.changed_e2e_suites.includes('waf-list-version.spec.js'), 'changed non-integ E2E suite not reported')
      assert(hasSuite(result, 'waf-list-version.spec.js'), 'changed non-integ E2E suite not selected')
    },
  },
  {
    name: 'E2E infra-only changes do not select product suites',
    run() {
      const result = runSelect(['--files', 'frontend/packages/skyview-web/e2e/run-integration.js,.gitlab-ci.yml'])
      assert(result.fallback === null, 'infra-only change should not fallback')
      assert(result.suites.length === 0, `infra-only change selected suites: ${result.suites.join(', ')}`)
    },
  },
  {
    name: 'invalid git diff falls back to smoke + critical',
    run() {
      const result = runSelect(['--base', 'definitely-missing-base-ref', '--head', 'definitely-missing-head-ref'])
      assert(result.fallback, 'invalid diff should fallback')
      assertContainsAll(result.suites, layerSuites('smoke'), 'invalid diff smoke suites')
      assertContainsAll(result.suites, layerSuites('critical'), 'invalid diff critical suites')
    },
  },
  {
    name: 'selected suites are registered',
    run() {
      const result = runSelect(['--files', 'gateway/some/new_unknown.go'])
      const unregistered = result.suites.filter(file => !suiteByFile.has(file))
      assert(unregistered.length === 0, `unregistered selected suites: ${unregistered.join(', ')}`)
    },
  },
]

let passed = 0
const failures = []

for (const check of checks) {
  try {
    check.run()
    passed++
    console.log(`ok - ${check.name}`)
  } catch (error) {
    failures.push({ name: check.name, message: error.message })
    console.error(`not ok - ${check.name}: ${error.message}`)
  }
}

if (failures.length > 0) {
  console.error(`Selection checks failed: ${failures.length}/${checks.length}`)
  process.exit(1)
}

console.log(`Selection checks passed: ${passed}/${checks.length}`)
