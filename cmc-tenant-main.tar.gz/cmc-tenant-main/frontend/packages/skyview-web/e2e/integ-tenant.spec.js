// Integration: tenant management pages
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForTableData, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  await loginAs(page)
  let p = 0, f = 0

  // Tenant group
  try {
    await navTo(page, '租户管理', '租户组')
    await waitForTableData(page)
    // Retry: wait for rows to actually render (concurrent runs may cause timing issues)
    let rows = 0
    for (let retry = 0; retry < 3; retry++) {
      rows = await getRows(page)
      if (rows > 0) break
      await page.waitForTimeout(2000)
    }
    if (rows === 0) throw new Error('No tenant groups visible')
    console.log(`✅ Tenant group (${rows} rows)`); p++
  } catch (e) { f++; console.log(`❌ Tenant group: ${e.message}`) }

  // WAF binding
  try {
    await navTo(page, '租户管理', 'WAF 绑定')
    await waitForTableData(page)
    const rows = await getRows(page)
    console.log(`✅ WAF binding (${rows} rows)`); p++
  } catch (e) { f++; console.log(`❌ WAF binding: ${e.message}`) }

  // Site binding
  try {
    await navTo(page, '租户管理', '站点绑定')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content) throw new Error('Page empty')
    console.log('✅ Site binding'); p++
  } catch (e) { f++; console.log(`❌ Site binding: ${e.message}`) }

  // Global users
  try {
    await navTo(page, '租户管理', '全局用户')
    const rows = await getRows(page)
    console.log(`✅ Global users (${rows} rows)`); p++
  } catch (e) { f++; console.log(`❌ Global users: ${e.message}`) }

  console.log(`\n📊 Tenant: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
