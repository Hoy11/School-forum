// Integration: custom rule (PolicyRule) — UI fields aligned with 纵横
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

async function visibleDropdown(page, timeout = 10000) {
  const dropdown = page.locator('.el-select-dropdown:visible').last()
  await dropdown.waitFor({ state: 'visible', timeout })
  return dropdown
}

async function waitForDropdownOptionCount(page, expected, timeout = 15000) {
  const dropdown = await visibleDropdown(page, timeout)
  const startedAt = Date.now()
  let actual = await dropdown.locator('.el-select-dropdown__item').count()

  while (actual !== expected && Date.now() - startedAt < timeout) {
    await page.waitForTimeout(100)
    actual = await dropdown.locator('.el-select-dropdown__item').count()
  }

  return actual
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  const adminCookieHeader = await getAuthCookieHeader(page, 'admin')
  const captainInstanceId = await getActiveWafId(page, adminCookieHeader)
  console.log(`  Using captain_instance_id=${captainInstanceId}`)
  let p = 0, f = 0

  // Navigate to custom rule page
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    console.log('✅ 自定义规则页面加载'); p++
  } catch (e) { f++; console.log(`❌ 自定义规则页面加载: ${e.message}`) }

  // Verify column headers: should have "动作" (spec30 renamed from "模式")
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    if (!headers.some(h => h.includes('动作'))) throw new Error('Missing 动作 column')
    console.log('✅ 列头包含"动作"'); p++
  } catch (e) { f++; console.log(`❌ 列头检查: ${e.message}`) }

  // Open "新建规则" dialog and verify form fields
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)

    // Click new rule button
    await page.locator('button:has-text("新建规则")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })

    const dialog = page.locator('.el-dialog:visible').first()

    // Verify "状态" is a select (not switch)
    const statusSelect = dialog.locator('.el-form-item:has-text("状态") .el-select')
    if (await statusSelect.count() === 0) throw new Error('状态 should be el-select, not el-switch')
    console.log('✅ 新建对话框：状态为下拉框'); p++

    // Verify "模式" label (not "动作")
    const dialogText = await dialog.textContent()
    if (!dialogText.includes('模式')) throw new Error('Missing 模式 label in dialog')
    if (dialogText.includes('动作') && !dialogText.includes('动作模式')) throw new Error('Old 动作 label still present')
    console.log('✅ 新建对话框：标签为"模式"'); p++

    // Verify "匹配条件" section exists
    if (!dialogText.includes('匹配条件')) throw new Error('Missing 匹配条件')
    console.log('✅ 新建对话框：包含匹配条件'); p++

    // Verify no "延迟" or "采样比例" in advanced settings
    // First expand advanced settings
    await dialog.locator('.el-collapse-item__header').first().click()
    await page.waitForTimeout(500)
    const advancedText = await dialog.textContent()
    if (advancedText.includes('延迟')) throw new Error('延迟 field should be removed')
    if (advancedText.includes('采样比例')) throw new Error('采样比例 field should be removed')
    console.log('✅ 新建对话框：无"延迟"和"采样比例"'); p++

    // Verify "是否记录日志" label (not "日志选项") + description text
    if (!advancedText.includes('是否记录日志')) throw new Error('Missing 是否记录日志 label')
    if (!advancedText.includes('记录但不存储日志') && !advancedText.includes('记录并存储日志')) throw new Error('Missing log option descriptions')
    if (!advancedText.includes('不记录日志')) throw new Error('Missing log option description text')
    console.log('✅ 新建对话框："是否记录日志"含描述文字'); p++

    // Verify "阻断状态码" input (only visible when action=deny, so switch to 拦截 first)
    const actionSelect = dialog.locator('.el-form-item:has-text("模式") .el-select')
    if (await actionSelect.count() > 0) {
      await actionSelect.click()
      await page.locator('.el-select-dropdown__item:visible').filter({ hasText: '拦截' }).first().click()
      await page.waitForTimeout(500)
    }
    const statusCodeInput = dialog.locator('.el-form-item:has-text("阻断状态码") .el-input')
    if (await statusCodeInput.count() === 0) throw new Error('Missing 阻断状态码 input')
    console.log('✅ 新建对话框：包含阻断状态码输入'); p++

    // Re-fetch advanced text after action switch (dialog re-rendered)
    const updatedAdvancedText = await dialog.textContent()

    // Verify "检测前解码" switch + description (spec30: label changed from 解码前检测→检测前解码)
    if (!updatedAdvancedText.includes('检测前解码')) throw new Error('Missing 检测前解码 label')
    if (!updatedAdvancedText.includes('开关开启后')) throw new Error('Missing 检测前解码 description')
    const decodeSwitch = dialog.locator('.el-form-item:has-text("检测前解码") .el-switch')
    if (await decodeSwitch.count() === 0) throw new Error('Missing 检测前解码 switch')
    console.log('✅ 新建对话框：包含检测前解码开关+描述'); p++

    // Verify "规则生效时间" radio group with 3 options
    const cronRadio = dialog.locator('.el-form-item:has-text("规则生效时间") .el-radio-group')
    if (await cronRadio.count() === 0) throw new Error('Missing 规则生效时间 radio group')
    const radioLabels = await cronRadio.locator('.el-radio').allTextContents()
    if (!radioLabels.some(l => l.includes('永久'))) throw new Error('Missing 永久 option')
    if (!radioLabels.some(l => l.includes('定时'))) throw new Error('Missing 定时 option')
    if (!radioLabels.some(l => l.includes('周期'))) throw new Error('Missing 周期 option')
    console.log('✅ 新建对话框：规则生效时间含永久/定时/周期'); p++

    // Verify "过期时间" date picker
    const datePicker = dialog.locator('.el-form-item:has-text("过期时间") .el-date-editor')
    if (await datePicker.count() === 0) throw new Error('Missing 过期时间 date picker')
    console.log('✅ 新建对话框：包含过期时间日期选择器'); p++

    // Close dialog
    await dialog.locator('.el-dialog__headerbtn').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
  } catch (e) { f++; console.log(`❌ 新建对话框检查: ${e.message}`)
    // Ensure dialog is closed even on failure to prevent cascade failures
    await page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click().catch(() => {})
    await page.keyboard.press('Escape').catch(() => {})
    await page.waitForTimeout(500)
  }

  // Edit first non-shared rule — verify form backfills correctly
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows > 0) {
      // Find a non-shared rule (binding_count <= 1) via API
      const ruleListResp = await page.evaluate(async (captainInstanceId) => {
        const r = await fetch(`/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`, { credentials: 'include' })
        return r.json()
      }, captainInstanceId)
      const rules = ruleListResp.data?.items || []
      const nonSharedIdx = rules.findIndex(r => (r.binding_count ?? 0) <= 1)

      if (nonSharedIdx >= 0) {
        // Use nth() to locate the row — el-tooltip wraps button, must use evaluate to click
        const row = page.locator('.el-table__row').nth(nonSharedIdx)
        await row.locator('.el-icon-edit').first().evaluate(el => {
          const btn = el.closest('button')
          if (btn) btn.click()
          else el.click()
        })
        await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
      const dialog = page.locator('.el-dialog:visible').first()
      const title = await dialog.locator('.el-dialog__title').textContent()
      if (!title.includes('编辑规则')) throw new Error(`Dialog title should be 编辑规则, got: ${title}`)

      // Expand advanced settings
      await dialog.locator('.el-collapse-item__header').first().click()
      await page.waitForTimeout(500)

      // Verify status select has a value (either 启用 or 禁用)
      const statusValue = await dialog.locator('.el-form-item:has-text("状态") .el-select .el-input__inner').first().inputValue()
      if (!['启用', '禁用', 'true', 'false'].some(v => statusValue.includes(v))) throw new Error(`Status select has unexpected value: ${statusValue}`)
      console.log('✅ 编辑对话框：状态回填为下拉框值'); p++

      // Close dialog
        await dialog.locator('.el-dialog__headerbtn').first().click()
        await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
      } else {
        console.log('⚠️ 无非共享规则，跳过编辑测试'); p++
      }
    } else {
      console.log('⚠️ 无自定义规则数据，跳过编辑测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 编辑对话框检查: ${e.message}`) }

  // Verify dropdown menu items on a rule row
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows > 0) {
      // Click "more" button to open dropdown
      const moreBtn = page.locator('.el-table__row').first().locator('.el-icon-more').first()
      await moreBtn.click()
      await page.waitForTimeout(300)

      const dropdownText = await page.locator('.el-dropdown-menu:visible').first().textContent()
      if (!dropdownText.includes('查看日志')) throw new Error('Missing 查看日志')
      if (!dropdownText.includes('启用规则')) throw new Error('Missing 启用规则')
      if (!dropdownText.includes('禁用规则')) throw new Error('Missing 禁用规则')
      if (!dropdownText.includes('删除规则')) throw new Error('Missing 删除规则')
      console.log('✅ 操作下拉菜单：4个选项完整'); p++

      // Close dropdown
      await page.keyboard.press('Escape')
    } else {
      console.log('⚠️ 无自定义规则数据，跳过下拉菜单测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 操作下拉菜单检查: ${e.message}`) }

  // === 共享规则保护测试 ===

  // Find a shared rule (binding_count > 1) and verify operations are blocked
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)

    // Get rule list via API to find a shared rule
    const ruleListResp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch(`/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    }, captainInstanceId)
    const sharedRule = (ruleListResp.data?.items || []).find(r => (r.binding_count ?? 0) > 1)

    if (sharedRule) {
      // Test 1: Edit a shared rule should open read-only mode (not editable)
      const editBtn = page.locator(`.el-table__row:has-text("${sharedRule.id}")`).first().locator('.el-icon-edit').first()
      if (await editBtn.count() > 0) {
        await editBtn.click()
        await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
        // Should open dialog in read-only mode with title "查看规则"
        const dialog = page.locator('.el-dialog:visible').first()
        const title = await dialog.locator('.el-dialog__title').textContent()
        if (!title.includes('查看规则')) throw new Error('Shared rule should open in read-only mode (查看规则), got: ' + title)
        // Close
        await dialog.locator('.el-dialog__headerbtn').first().click()
        await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
        console.log(`✅ 共享规则(id=${sharedRule.id})编辑以只读模式打开`); p++
      } else {
        console.log('⚠️ 共享规则行未找到编辑按钮'); p++
      }

      // Test 2: Enable/disable a shared rule should show warning
      const row2 = page.locator(`.el-table__row`).filter({ hasText: String(sharedRule.id) }).first()
      const dropdownTrigger = row2.locator('.el-dropdown').first()
      if (await dropdownTrigger.count() > 0) {
        await dropdownTrigger.click()
        await page.waitForTimeout(500)

        // Click "启用规则" — Element UI uses el-dropdown-menu__item class
        const enableItem = page.locator('.el-dropdown-menu:visible .el-dropdown-menu__item:has-text("启用规则")').first()
        await enableItem.click()
        await page.waitForTimeout(500)

        const warningMsg = await page.locator('.el-message').filter({ hasText: '多个租户组绑定' }).count()
        if (warningMsg === 0) throw new Error('Shared rule enable should show warning')
        console.log(`✅ 共享规则(id=${sharedRule.id})启用被阻止`); p++
      } else {
        console.log('⚠️ 共享规则行未找到更多按钮'); p++
      }

      // Test 3: Delete a shared rule should show warning
      const row3 = page.locator(`.el-table__row`).filter({ hasText: String(sharedRule.id) }).first()
      const dropdownTrigger2 = row3.locator('.el-dropdown').first()
      if (await dropdownTrigger2.count() > 0) {
        await dropdownTrigger2.click()
        await page.waitForTimeout(500)

        const deleteItem = page.locator('.el-dropdown-menu:visible .el-dropdown-menu__item:has-text("删除规则")').first()
        await deleteItem.click()
        await page.waitForTimeout(500)

        const warningMsg = await page.locator('.el-message').filter({ hasText: '多个租户组绑定' }).count()
        // If warning shown, rule is protected. If confirm dialog opens, that's a bug.
        const confirmVisible = await page.locator('.el-message-box:visible').count()
        if (confirmVisible > 0 && warningMsg === 0) {
          await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click().catch(() => {})
          throw new Error('Shared rule delete should show warning, not confirm dialog')
        }
        // Close any confirm dialog that may have appeared
        if (confirmVisible > 0) {
          await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click().catch(() => {})
        }
        console.log(`✅ 共享规则(id=${sharedRule.id})删除被阻止`); p++
      } else {
        console.log('⚠️ 共享规则行未找到更多按钮'); p++
      }
    } else {
      console.log('⚠️ 无共享规则(binding_count>1)，跳过保护测试'); p += 3
    }
  } catch (e) { f++; console.log(`❌ 共享规则保护: ${e.message}`) }

  // === 租户权限隔离测试 ===

  // Get admin-visible resource counts via API for comparison
  let adminIpGroupCount = 0
  let adminSiteCount = 0
  try {
    // Get first WAF instance ID from the selector
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const selectInput = page.locator('.el-select:not(.is-disabled) input').first()
    const wafId = await selectInput.inputValue().catch(() => '')
    // Get WAF options from dropdown
    await selectInput.click()
    await page.waitForTimeout(300)
    const wafOptions = await page.locator('.el-select-dropdown__item:visible').allTextContents()
    await page.keyboard.press('Escape')

    // Call IP group list and site list as admin (with captain_instance_id to ensure data)
    const ipGroupResp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch(`/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    }, captainInstanceId)
    adminIpGroupCount = ipGroupResp.data?.items?.length || 0

    const siteResp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch(`/api/captain/site/list?captain_instance_id=${captainInstanceId}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    }, captainInstanceId)
    adminSiteCount = siteResp.data?.items?.length || 0

    console.log(`  Admin sees: ${adminIpGroupCount} IP groups, ${adminSiteCount} sites`)
    p++
  } catch (e) { f++; console.log(`❌ Admin资源计数: ${e.message}`) }

  // Login as tenant_admin and verify scoped resource visibility
  let tenantIpGroupCount = 0
  let tenantSiteCount = 0
  try {
    const tenantCred = CREDENTIALS.tenant_admin

    // Reset tenant_admin password to known state via backend API (server-side, avoids page.evaluate issues)
    try {
      const BACKEND_URL = TARGET_URL.replace(':3000', ':8080')
      // Login as admin
      const cookieHeader = await getAuthCookieHeader(page, 'admin')
      if (cookieHeader) {

        // Get user list
        const listResp = await page.request.post(`${BACKEND_URL}/api/user/list`, {
          headers: { Cookie: cookieHeader },
          data: { offset: 0, count: 50 },
        })
        const listData = await listResp.json()
        const testAdmin = (listData.data?.items || []).find(u => u.username === tenantCred.username)
        if (testAdmin) {
          // Reset password
          const credResp = await page.request.put(`${BACKEND_URL}/api/user/credential`, {
            headers: { Cookie: cookieHeader },
            data: { id: testAdmin.id },
          })
          const credData = await credResp.json()
          const tempPwd = credData.data?.password
          if (tempPwd) {
            // Login with temp password
            const tmpLoginResp = await page.request.post(`${BACKEND_URL}/api/auth/login`, {
              data: { username: tenantCred.username, password: tempPwd },
            })
            const tmpLoginData = await tmpLoginResp.json()
            if (tmpLoginData.err === null) {
              const tmpCookies = await page.context().cookies()
              const tmpCookieHeader = tmpCookies.map(c => `${c.name}=${c.value}`).join('; ')
              // Set desired password
              await page.request.put(`${BACKEND_URL}/api/user/current/password`, {
                headers: { Cookie: tmpCookieHeader },
                data: { old_password: tempPwd, new_password: tenantCred.password, dup_password: tenantCred.password },
              })
            }
          }
        }
      }
    } catch { /* non-fatal */ }

    // Login as tenant_admin via UI
    await loginAs(page, 'tenant_admin')
    const tenantCookieHeader = await getAuthCookieHeader(page, 'tenant_admin')
    const tenantCaptainInstanceId = await getActiveWafId(page, tenantCookieHeader)
    console.log(`  tenant_admin using captain_instance_id=${tenantCaptainInstanceId}`)

    // Navigate to custom rule page as tenant_admin
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)

    // Get tenant-visible resource counts via API
    const tenantIpGroupResp = await page.evaluate(async (tenantCaptainInstanceId) => {
      const r = await fetch(`/api/captain/ip-group/list?captain_instance_id=${tenantCaptainInstanceId}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    }, tenantCaptainInstanceId)
    tenantIpGroupCount = tenantIpGroupResp.data?.items?.length || 0

    const tenantSiteResp = await page.evaluate(async (tenantCaptainInstanceId) => {
      const r = await fetch(`/api/captain/site/list?captain_instance_id=${tenantCaptainInstanceId}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    }, tenantCaptainInstanceId)
    tenantSiteCount = tenantSiteResp.data?.items?.length || 0

    console.log(`  tenant_admin sees: ${tenantIpGroupCount} IP groups, ${tenantSiteCount} sites`)
    console.log('✅ tenant_admin 资源范围查询完成'); p++
  } catch (e) { f++; console.log(`❌ tenant_admin 资源范围查询: ${e.message}`) }

  // Verify tenant_admin sees fewer or equal IP groups compared to admin
  try {
    if (tenantIpGroupCount > adminIpGroupCount) throw new Error(`tenant_admin sees ${tenantIpGroupCount} IP groups > admin ${adminIpGroupCount}`)
    if (tenantIpGroupCount === 0 && adminIpGroupCount > 0) console.log(`⚠️ tenant_admin 无可见IP组（可能未绑定）`)
    else console.log(`✅ tenant_admin IP组范围: ${tenantIpGroupCount} ≤ admin ${adminIpGroupCount}`)
    p++
  } catch (e) { f++; console.log(`❌ tenant_admin IP组范围: ${e.message}`) }

  // Verify tenant_admin sees fewer or equal sites compared to admin
  try {
    if (tenantSiteCount > adminSiteCount) throw new Error(`tenant_admin sees ${tenantSiteCount} sites > admin ${adminSiteCount}`)
    if (tenantSiteCount === 0 && adminSiteCount > 0) console.log(`⚠️ tenant_admin 无可见站点（可能未绑定）`)
    else console.log(`✅ tenant_admin 站点范围: ${tenantSiteCount} ≤ admin ${adminSiteCount}`)
    p++
  } catch (e) { f++; console.log(`❌ tenant_admin 站点范围: ${e.message}`) }

  // Verify IP group dropdown in new rule dialog is tenant-scoped
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)

    await page.locator('button:has-text("新建规则")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    const dialog = page.locator('.el-dialog:visible').first()

    // Select "IP 组" match type in condition editor
    const matchSelect = dialog.locator('.el-select').nth(1) // 2nd select is the match type
    await matchSelect.click()
    let dropdown = await visibleDropdown(page)
    await dropdown.locator('.el-select-dropdown__item').first().waitFor({ state: 'visible', timeout: 10000 })
    const ingroupOption = dropdown.locator('.el-select-dropdown__item').filter({ hasText: 'IP 组' }).first()
    if (await ingroupOption.count() > 0) {
      await ingroupOption.click()

      // Now check the IP group dropdown options count
      const ipGroupSelect = dialog.locator('.el-select').nth(2) // 3rd select is IP group
      await ipGroupSelect.click()
      const dropdownItems = await waitForDropdownOptionCount(page, tenantIpGroupCount)
      await page.keyboard.press('Escape')

      if (dropdownItems !== tenantIpGroupCount) {
        throw new Error(`IP group dropdown has ${dropdownItems} options, expected ${tenantIpGroupCount}`)
      }
      console.log(`✅ 新建规则IP组下拉框: ${dropdownItems}个（与tenant_admin可见数一致）`); p++
    } else {
      console.log('⚠️ 匹配条件中无"IP 组"选项，跳过'); p++
    }

    await dialog.locator('.el-dialog__headerbtn').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
  } catch (e) { f++; console.log(`❌ 新建规则IP组下拉框范围: ${e.message}`)
    await page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click().catch(() => {})
    await page.keyboard.press('Escape').catch(() => {})
  }

  // Verify site selector in new rule dialog is tenant-scoped
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)

    await page.locator('button:has-text("新建规则")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    const dialog = page.locator('.el-dialog:visible').first()

    // Click site selector dropdown
    const siteSelect = dialog.locator('.el-form-item:has-text("使用范围") .el-select')
    await siteSelect.click()
    const siteOptions = await waitForDropdownOptionCount(page, tenantSiteCount)
    await page.keyboard.press('Escape')

    if (siteOptions !== tenantSiteCount) {
      throw new Error(`Site selector has ${siteOptions} options, expected ${tenantSiteCount}`)
    }
    console.log(`✅ 新建规则站点选择器: ${siteOptions}个（与tenant_admin可见数一致）`); p++

    await dialog.locator('.el-dialog__headerbtn').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
  } catch (e) { f++; console.log(`❌ 新建规则站点选择器范围: ${e.message}`)
    await page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click().catch(() => {})
    await page.keyboard.press('Escape').catch(() => {})
  }

  // Re-login as admin for any remaining tests
  try {
    await loginAs(page, 'admin')
  } catch { /* non-fatal */ }

  console.log(`\n📊 PolicyRule: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
