// E2E Test: Error Handling
const { chromium } = require('playwright')
const { loginAsRole, navigateToPage, launchOptions } = require('./helpers')

;(async () => {
  let browser
  let passed = 0
  let failed = 0

  try {
    browser = await chromium.launch(launchOptions())
  } catch (e) {
    console.log(`❌ Browser launch FAILED: ${e.message}`)
    console.log(`\n📊 Error Handling: 0 passed, 1 failed`)
    process.exit(1)
  }

  // Test 1: 429 rate limit handled gracefully
  try {
    const page = await browser.newPage()
    await loginAsRole(page, 'admin')

    await page.route('**/api/tenant-group/list**', (route) => {
      route.fulfill({
        status: 429,
        headers: { 'Retry-After': '30' },
        contentType: 'application/json',
        body: JSON.stringify({ err: 'rate_limited', msg: '操作过于频繁', data: null }),
      })
    })

    await navigateToPage(page, '/tenant/groups')
    await page.waitForTimeout(1500)

    const body = await page.locator('body').textContent()
    if (!body) throw new Error('Page should still render after 429')

    await page.close()
    passed++
    console.log('✅ Test 1: 429 rate limit handled gracefully')
  } catch (e) {
    failed++
    console.log(`❌ Test 1 FAILED: ${e.message}`)
  }

  // Test 2: Network error handled gracefully
  try {
    const page = await browser.newPage()
    await loginAsRole(page, 'admin')

    await page.route('**/api/tenant-group/list**', (route) => {
      route.abort('failed')
    })

    await navigateToPage(page, '/tenant/groups')
    await page.waitForTimeout(1500)

    const content = await page.locator('.layout__content').textContent()
    if (content === undefined) throw new Error('Page should not crash on network error')

    await page.close()
    passed++
    console.log('✅ Test 2: Network error handled gracefully')
  } catch (e) {
    failed++
    console.log(`❌ Test 2 FAILED: ${e.message}`)
  }

  // Test 3: Grid sends correct offset on load
  try {
    const page = await browser.newPage()
    await loginAsRole(page, 'admin')

    let capturedOffset = -1
    await page.route('**/api/tenant-group/list**', (route) => {
      const url = new URL(route.request().url())
      capturedOffset = parseInt(url.searchParams.get('offset') || '0')
      const count = parseInt(url.searchParams.get('count') || '20')
      const items = Array.from({ length: 50 }, (_, i) => ({
        id: i + 1, name: `租户组${i + 1}`, comment: '', created_at: '2024-01-01',
      }))
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          err: null, msg: 'success',
          data: { total: 50, items: items.slice(capturedOffset, capturedOffset + count) },
        }),
      })
    })

    await navigateToPage(page, '/tenant/groups')
    await page.waitForTimeout(1000)

    if (capturedOffset !== 0) throw new Error(`Expected initial offset 0, got: ${capturedOffset}`)

    await page.close()
    passed++
    console.log('✅ Test 3: Grid sends correct offset on load')
  } catch (e) {
    failed++
    console.log(`❌ Test 3 FAILED: ${e.message}`)
  }

  console.log(`\n📊 Error Handling: ${passed} passed, ${failed} failed`)
  await browser.close()
  process.exit(failed > 0 ? 1 : 0)
})()
