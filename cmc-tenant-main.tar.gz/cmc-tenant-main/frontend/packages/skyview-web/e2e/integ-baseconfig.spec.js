// Integration: Site base config tab editing — inline and dialog fields
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'

function findRowByLabel(page, label) {
  return page.locator('.editable-row:visible').filter({ hasText: new RegExp(`^${label}`) })
}

async function waitForDropdownOptions(page, timeout = 5000) {
  await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').first()
    .waitFor({ state: 'visible', timeout })
}

async function waitForBaseConfigReady(page, timeout = 30000) {
  await page.waitForFunction(
    (tabText) => document.body.innerText.includes(tabText),
    '基础配置',
    { timeout }
  )
  const tab = page.locator('.el-tabs__item').filter({ hasText: '基础配置' }).first()
  await tab.waitFor({ state: 'visible', timeout })
  await tab.click({ force: true })
  await page.waitForFunction(
    (targetText) => document.body.innerText.includes(targetText) &&
      Array.from(document.querySelectorAll('.editable-row')).some(node => node.offsetParent !== null),
    '请求处理方式',
    { timeout }
  )
}

async function clickEdit(page, label) {
  const row = findRowByLabel(page, label)
  await row.locator('.el-icon-edit').first().click()
  await row.locator('input:visible, textarea:visible, .el-select:visible, button:has-text("确定"):visible').first()
    .waitFor({ state: 'visible', timeout: 5000 })
  return row
}

async function saveInline(page, label) {
  const row = findRowByLabel(page, label)
  const saveBtn = row.locator('button.el-button--primary:has-text("确定")').first()
  await saveBtn.click()
  await row.locator('input, textarea, .el-select').first()
    .waitFor({ state: 'hidden', timeout: 10000 })
    .catch(async () => {
      await row.locator('button.el-button--primary:has-text("确定"):visible').first()
        .waitFor({ state: 'hidden', timeout: 5000 })
    })
}

async function cancelInline(page, label) {
  const row = findRowByLabel(page, label)
  await row.locator('button:has-text("取消")').first().click()
  await row.locator('button:has-text("确定"):visible').first()
    .waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
}

async function getRowValue(page, label) {
  const row = findRowByLabel(page, label)
  const valueContainer = row.locator(':scope > span').nth(1)
  return (await valueContainer.textContent()).trim()
}

async function openDialog(page, label) {
  const row = findRowByLabel(page, label)
  await row.locator('.el-icon-edit').first().click()
  const dialog = page.locator('.el-dialog:visible').first()
  await dialog.waitFor({ state: 'visible', timeout: 5000 })
  return dialog
}

async function saveDialog(page) {
  const confirmBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("确定")').first()
  await confirmBtn.click()
  await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 10000 })
}

async function closeDialog(page) {
  const cancelBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("取消")').first()
  await cancelBtn.click().catch(() =>
    page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click().catch(() => {}))
  await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
}

async function apiGet(page, path) {
  return page.evaluate(async (p) => {
    const r = await fetch(p)
    const d = await r.json()
    if (d.err !== null) throw new Error('API error: ' + d.msg)
    return d.data
  }, path)
}

  ;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  const cookieHeader = await getAuthCookieHeader(page, 'admin')
  const captainInstanceId = await getActiveWafId(page, cookieHeader, { requireSiteList: true })
  console.log(`  Using captain_instance_id=${captainInstanceId}`)
  let p = 0, f = 0

  // Navigate to a reverse proxy site detail — try rows until we find one with tabs
  try {
    const data = await apiGet(page, `/api/captain/site/list?captain_instance_id=${captainInstanceId}`)
    const items = data.items || data.data?.items || data.data || []
    const site = items.find(item => String(item.operation_mode || '').includes('Reverse Proxy')) || items[0]
    if (!site) throw new Error('No sites')
    await page.goto(`${TARGET_URL}/protection/sites/detail?id=${site.id}&waf=${captainInstanceId}`, { waitUntil: 'domcontentloaded' })
    await waitForBaseConfigReady(page)
    console.log('✅ 进入站点详情页'); p++
  } catch (e) { f++; console.log(`❌ 进入站点详情页: ${e.message}`); await browser.close(); process.exit(1) }

  // Switch to base config tab
  try {
    await waitForBaseConfigReady(page)
    const cards = await page.locator('.el-card__header').allTextContents()
    if (!cards.some(c => c.includes('请求处理方式'))) throw new Error('请求处理方式卡片未找到, cards: ' + cards.join(', '))
    console.log('✅ 基础配置 tab 渲染成功 (cards: ' + cards.join(', ') + ')'); p++
  } catch (e) { f++; console.log(`❌ 基础配置 tab 渲染: ${e.message}`) }

  await page.locator('.editable-row:visible').first().waitFor({ state: 'visible', timeout: 5000 })

  // === 1. Inline edit: X-Forwarded-For ===
  try {
    const original = await getRowValue(page, 'X-Forwarded-For')
    await clickEdit(page, 'X-Forwarded-For')
    const select = page.locator('.editable-row:visible').filter({ hasText: 'X-Forwarded-For' }).locator('.el-select:visible').first()
    await select.click()
    await waitForDropdownOptions(page)
    const options = page.locator('.el-select-dropdown:visible .el-select-dropdown__item')
    const count = await options.count()
    if (count > 1) {
      const optionTexts = (await options.allTextContents()).map(t => t.trim())
      const targetIndex = optionTexts.findIndex(t => t !== original)
      if (targetIndex < 0) throw new Error('No alternative option found')
      await options.nth(targetIndex).click()
      await saveInline(page, 'X-Forwarded-For')
      const newVal = await getRowValue(page, 'X-Forwarded-For')
      if (newVal === original) throw new Error('Value did not change')
      console.log(`✅ 内联编辑 X-Forwarded-For (${original} → ${newVal})`); p++
      // Restore
      await clickEdit(page, 'X-Forwarded-For')
      const select2 = page.locator('.editable-row:visible').filter({ hasText: 'X-Forwarded-For' }).locator('.el-select:visible').first()
      await select2.click()
      await waitForDropdownOptions(page)
      const restoreOptions = page.locator('.el-select-dropdown:visible .el-select-dropdown__item')
      const restoreTexts = (await restoreOptions.allTextContents()).map(t => t.trim())
      const restoreIndex = restoreTexts.findIndex(t => t === original)
      if (restoreIndex < 0) throw new Error('Original option not found for restore')
      await restoreOptions.nth(restoreIndex).click()
      await saveInline(page, 'X-Forwarded-For')
    } else {
      await cancelInline(page, 'X-Forwarded-For')
      console.log('✅ 内联编辑 X-Forwarded-For (select opened, only 1 option)'); p++
    }
  } catch (e) { f++; console.log(`❌ 内联编辑 X-Forwarded-For: ${e.message}`); await cancelInline(page, 'X-Forwarded-For').catch(() => {}) }

  // === 2. Inline compound: 调度算法 ===
  try {
    await clickEdit(page, '调度算法')
    const select = page.locator('.editable-row:visible').filter({ hasText: '调度算法' }).locator('.el-select:visible').first()
    if ((await select.count()) > 0) {
      console.log('✅ 内联编辑 调度算法 (compound select visible)'); p++
    } else {
      throw new Error('No select found for 调度算法')
    }
    await cancelInline(page, '调度算法')
  } catch (e) { f++; console.log(`❌ 内联编辑 调度算法: ${e.message}`); await cancelInline(page, '调度算法').catch(() => {}) }

  // === 3. Inline compound: 保持连接配置 ===
  try {
    await clickEdit(page, '保持连接配置')
    const select = page.locator('.editable-row:visible').filter({ hasText: '保持连接配置' }).locator('.el-select:visible').first()
    if ((await select.count()) > 0) {
      console.log('✅ 内联编辑 保持连接配置 (select visible)'); p++
    } else {
      throw new Error('No select found for 保持连接配置')
    }
    await cancelInline(page, '保持连接配置')
  } catch (e) { f++; console.log(`❌ 内联编辑 保持连接配置: ${e.message}`); await cancelInline(page, '保持连接配置').catch(() => {}) }

  // === 4. Inline compound: 记录访问日志 ===
  try {
    await clickEdit(page, '记录访问日志')
    const select = page.locator('.editable-row:visible').filter({ hasText: '记录访问日志' }).locator('.el-select:visible').first()
    if ((await select.count()) > 0) {
      console.log('✅ 内联编辑 记录访问日志 (select visible)'); p++
    } else {
      throw new Error('No select found for 记录访问日志')
    }
    await cancelInline(page, '记录访问日志')
  } catch (e) { f++; console.log(`❌ 内联编辑 记录访问日志: ${e.message}`); await cancelInline(page, '记录访问日志').catch(() => {}) }

  // === 5. Inline: 检测节点 ===
  try {
    await clickEdit(page, '检测节点')
    const select = page.locator('.editable-row:visible').filter({ hasText: '检测节点' }).locator('.el-select:visible').first()
    if ((await select.count()) > 0) {
      console.log('✅ 内联编辑 检测节点 (select visible)'); p++
    } else {
      throw new Error('No select found for 检测节点')
    }
    await cancelInline(page, '检测节点')
  } catch (e) { f++; console.log(`❌ 内联编辑 检测节点: ${e.message}`); await cancelInline(page, '检测节点').catch(() => {}) }

  // === 6. Inline: 响应方式 ===
  try {
    await clickEdit(page, '响应方式')
    const select = page.locator('.editable-row:visible').filter({ hasText: '响应方式' }).locator('.el-select:visible').first()
    if ((await select.count()) > 0) {
      console.log('✅ 内联编辑 响应方式 (select visible)'); p++
    } else {
      throw new Error('No select found for 响应方式')
    }
    await cancelInline(page, '响应方式')
  } catch (e) { f++; console.log(`❌ 内联编辑 响应方式: ${e.message}`); await cancelInline(page, '响应方式').catch(() => {}) }

  // === 7. Dialog edit: Proxy Protocol ===
  try {
    const dialog = await openDialog(page, 'Proxy Protocol 配置')
    const sw = dialog.locator('.el-switch').first()
    if ((await sw.count()) > 0) {
      console.log('✅ 弹窗编辑 Proxy Protocol (dialog opened)'); p++
    } else {
      console.log('✅ 弹窗编辑 Proxy Protocol (dialog opened, no switch)'); p++
    }
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 Proxy Protocol: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 8. Dialog edit: 业务服务器地址 ===
  try {
    const dialog = await openDialog(page, '业务服务器地址')
    const table = dialog.locator('.el-table')
    if ((await table.count()) > 0) {
      console.log('✅ 弹窗编辑 业务服务器地址 (table found)'); p++
    } else {
      console.log('✅ 弹窗编辑 业务服务器地址 (dialog opened)'); p++
    }
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 业务服务器地址: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 9. Dialog edit: HTTP 头设置 ===
  try {
    const dialog = await openDialog(page, 'HTTP 头设置')
    console.log('✅ 弹窗编辑 HTTP 头设置 (dialog opened)'); p++
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 HTTP 头设置: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 10. Dialog edit: 忽略特定 content_type ===
  try {
    const dialog = await openDialog(page, '忽略特定 content_type')
    const input = dialog.locator('input[placeholder*="content_type"]')
    if ((await input.count()) > 0) {
      await input.fill('application/test')
      await dialog.locator('button:has-text("添加")').click()
      await dialog.locator('.el-tag, .el-table__row, input[value="application/test"]').first()
        .waitFor({ state: 'visible', timeout: 5000 }).catch(() => {})
      console.log('✅ 弹窗编辑 忽略 content_type (added type)'); p++
    } else {
      console.log('✅ 弹窗编辑 忽略 content_type (dialog opened)'); p++
    }
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 忽略 content_type: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 11. Dialog edit: 回源 IP 配置 ===
  try {
    const dialog = await openDialog(page, '回源 IP 配置')
    console.log('✅ 弹窗编辑 回源 IP 配置 (dialog opened)'); p++
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 回源 IP 配置: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 12. Dialog edit: 代理服务器详细配置 ===
  try {
    const dialog = await openDialog(page, '代理服务器详细配置')
    const table = dialog.locator('.el-table')
    if ((await table.count()) > 0) {
      console.log('✅ 弹窗编辑 代理服务器详细配置 (table found)'); p++
    } else {
      console.log('✅ 弹窗编辑 代理服务器详细配置 (dialog opened)'); p++
    }
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 代理服务器详细配置: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 13. Dialog edit: 业务服务器健康检查 ===
  try {
    const dialog = await openDialog(page, '业务服务器健康检查')
    const sw = dialog.locator('.el-switch').first()
    if ((await sw.count()) > 0) {
      console.log('✅ 弹窗编辑 业务服务器健康检查 (dialog opened)'); p++
    } else {
      console.log('✅ 弹窗编辑 业务服务器健康检查 (dialog opened, no switch)'); p++
    }
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 业务服务器健康检查: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 14. Dialog edit: 动态域名解析 ===
  try {
    const dialog = await openDialog(page, '动态域名解析')
    const sw = dialog.locator('.el-switch').first()
    if ((await sw.count()) > 0) {
      console.log('✅ 弹窗编辑 动态域名解析 (dialog opened)'); p++
    } else {
      console.log('✅ 弹窗编辑 动态域名解析 (dialog opened, no switch)'); p++
    }
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 动态域名解析: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 15. Dialog: 源 IP 获取方式 ===
  try {
    const dialog = await openDialog(page, '源 IP 获取方式')
    console.log('✅ 弹窗编辑 源 IP 获取方式 (dialog opened)'); p++
    await closeDialog(page)
  } catch (e) { f++; console.log(`❌ 弹窗编辑 源 IP 获取方式: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // === 16. Inline: 用户识别方式 ===
  try {
    await clickEdit(page, '用户识别方式')
    const select = page.locator('.editable-row:visible').filter({ hasText: '用户识别方式' }).locator('.el-select:visible').first()
    if ((await select.count()) > 0) {
      console.log('✅ 内联编辑 用户识别方式 (select visible)'); p++
    } else {
      throw new Error('No select found for 用户识别方式')
    }
    await cancelInline(page, '用户识别方式')
  } catch (e) { f++; console.log(`❌ 内联编辑 用户识别方式: ${e.message}`); await cancelInline(page, '用户识别方式').catch(() => {}) }

  // === 17. Cancel inline edit should not save ===
  try {
    const original = await getRowValue(page, 'X-Forwarded-For')
    await clickEdit(page, 'X-Forwarded-For')
    const select = page.locator('.editable-row:visible').filter({ hasText: 'X-Forwarded-For' }).locator('.el-select:visible').first()
    await select.click()
    await waitForDropdownOptions(page)
    const opts = page.locator('.el-select-dropdown:visible .el-select-dropdown__item')
    if ((await opts.count()) > 1) {
      await opts.nth(1).click()
    }
    await cancelInline(page, 'X-Forwarded-For')
    const afterCancel = await getRowValue(page, 'X-Forwarded-For')
    if (afterCancel !== original) throw new Error(`Cancel should not save: ${original} → ${afterCancel}`)
    console.log('✅ 取消编辑不保存'); p++
  } catch (e) { f++; console.log(`❌ 取消编辑不保存: ${e.message}`); await cancelInline(page, 'X-Forwarded-For').catch(() => {}) }

  // === 18. All proxy fields have edit icons ===
  try {
    const expectedLabels = ['检测节点', '响应方式', '调度算法', '保持连接配置', 'X-Forwarded-For',
      '业务服务器健康检查', '业务服务器地址', '记录访问日志', 'HTTP 头设置', '回源 IP 配置',
      '动态域名解析', 'Proxy Protocol', '忽略特定 content_type', '代理服务器详细配置']
    let found = 0
    for (const label of expectedLabels) {
      const row = findRowByLabel(page, label)
      const icon = row.locator('.el-icon-edit')
      if ((await icon.count()) > 0) found++
    }
    if (found < expectedLabels.length) throw new Error(`Only ${found}/${expectedLabels.length} fields have edit icons`)
    console.log(`✅ 所有必要字段有编辑图标 (${found}/${expectedLabels.length})`); p++
  } catch (e) { f++; console.log(`❌ 编辑图标检查: ${e.message}`) }

  // === 19. Source IP card has edit icon ===
  try {
    const srcEdit = findRowByLabel(page, '源 IP 获取方式').locator('.el-icon-edit')
    if ((await srcEdit.count()) > 0) {
      console.log('✅ 源 IP 获取方式有编辑图标'); p++
    } else {
      throw new Error('No edit icon on source IP row')
    }
  } catch (e) { f++; console.log(`❌ 源 IP 获取方式: ${e.message}`) }

  // === 20. Session card has edit icon ===
  try {
    const sessEdit = findRowByLabel(page, '用户识别方式').locator('.el-icon-edit')
    if ((await sessEdit.count()) > 0) {
      console.log('✅ 用户识别有编辑图标'); p++
    } else {
      throw new Error('No edit icon on session row')
    }
  } catch (e) { f++; console.log(`❌ 用户识别: ${e.message}`) }

  console.log(`\n📊 Base Config Edit: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
