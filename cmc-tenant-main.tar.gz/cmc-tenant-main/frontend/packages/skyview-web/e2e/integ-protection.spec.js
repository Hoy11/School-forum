// Integration: protection pages — WAF selector auto-loads, data renders
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))
const { ensureSites, cleanupSites, login: apiLogin } = require(path.join(__dirname, 'test-data'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page)
  let p = 0, f = 0

  // Seed test data: ensure at least 2 sites exist
  let seedSiteIds = []
  try {
    const cookieHeader = await apiLogin(page)
    const captainInstanceId = await getActiveWafId(page, cookieHeader, { requireSiteList: true })
    seedSiteIds = await ensureSites(page, cookieHeader, captainInstanceId, 2)
    if (seedSiteIds.length > 0) console.log(`  Seeded ${seedSiteIds.length} sites`)
  } catch (e) { console.log(`  Seed warning: ${e.message}`) }

  // WAF list
  try {
    await navTo(page, '防护管理', 'WAF 列表')
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows < 1) throw new Error('No WAF rows')
    console.log(`✅ WAF list: ${rows} instances`); p++
  } catch (e) { f++; console.log(`❌ WAF list: ${e.message}`) }

  // Sub-pages: each should show WAF selector, auto-select first WAF, load data
  const subPages = [
    { name: '站点管理', menu: '站点管理', expectRows: true, checkColumns: true, needsWafSelector: true },
    { name: 'IP 组', menu: 'IP 组', expectRows: false, needsWafSelector: true },
    { name: 'SSL 证书', menu: 'SSL 证书', expectRows: false, needsWafSelector: true },
    { name: '攻击检测引擎', menu: '攻击检测引擎', expectRows: true, needsWafSelector: true },
    { name: '自定义规则', menu: '自定义规则', expectRows: false, needsWafSelector: true },
  ]

  for (const { name, menu, expectRows, checkColumns, needsWafSelector } of subPages) {
    try {
      await navTo(page, '防护管理', menu)
      if (needsWafSelector) await waitForWafSelector(page)
      await waitForTableData(page)

      const disabled = await page.locator('.el-select.is-disabled').count()
      if (disabled > 0) throw new Error('WAF selector still disabled')

      if (expectRows) {
        const rows = await getRows(page)
        if (rows < 1) throw new Error('No rows loaded')

        if (checkColumns) {
          const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
          const requiredCols = ['站点名称', '端口', '域名', '创建时间']
          const missingCols = requiredCols.filter(c => !headers.some(h => h.includes(c)))
          if (missingCols.length) throw new Error(`Missing columns: ${missingCols.join(', ')}`)
        }

        console.log(`✅ ${name}: WAF selector enabled, ${rows} rows`); p++
      } else {
        const content = await page.locator('.layout__content').first().textContent()
        if (!content) throw new Error('Page empty')
        console.log(`✅ ${name}: WAF selector enabled, page loads`); p++
      }
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  // WAF selector: verify dropdown opens and shows options
  try {
    await navTo(page, '防护管理', '站点管理')
    const selectInput = page.locator('.el-select input').first()
    await selectInput.waitFor({ state: 'visible', timeout: 10000 })
    await selectInput.click()
    await page.waitForTimeout(500)
    const optionCount = await page.locator('.el-select-dropdown__item:visible').count()
    await page.keyboard.press('Escape')
    console.log(`✅ WAF selector dropdown: ${optionCount} option(s)`); p++
  } catch (e) { f++; console.log(`❌ WAF dropdown: ${e.message}`) }

  // No cleanup: seed data persists for other tests

  console.log(`\n📊 Protection: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
