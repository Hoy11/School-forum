# E2E 测试指南

## 测试套件

### Error Handling（mock，无需后端）

测试前端对边界场景的处理：429 限流、网络错误、Grid offset。

### Integration（需后端 + 纵横）

| 套件 | 文件 | 覆盖范围 |
|---|---|---|
| API | `integ-api.spec.js` | 后端 API 直连验证 |
| Auth | `integ-auth.spec.js` | 登录/登出/当前用户 |
| Captain | `integ-captain.spec.js` | 纵横代理联调 |
| CRUD | `integ-crud.spec.js` | IP组/SSL/规则/标记/配置 |
| Detail | `integ-detail.spec.js` | 日志详情/策略详情/交互操作 |
| Monitor | `integ-monitor.spec.js` | 攻击检测日志/频率控制日志/日志下载 |
| Pages | `integ-pages.spec.js` | 全页面导航（22页） |
| Protection | `integ-protection.spec.js` | WAF选择器+防护管理页面 |
| RBAC | `integ-rbac.spec.js` | tenant_admin 权限验证 |
| System | `integ-system.spec.js` | 系统管理页面 |
| Tenant | `integ-tenant.spec.js` | 租户组/WAF绑定/站点绑定/用户 |
| Binding | `integ-binding.spec.js` | 站点绑定增强：解绑参数格式、resync、租户资源可见性 |

## 运行方式

### 前置条件

```bash
# 启动后端
cd gateway && go run main.go    # 默认 8080

# 启动前端
cd frontend/packages/skyview-web && npm run dev    # 默认 3000
```

### 运行全量测试

```bash
cd frontend/packages/skyview-web

# 校验 E2E 清单（不启服务）
node e2e/check-manifest.js

# Error Handling（仅需前端）
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run.js

# Integration 全量（需前端 + 后端）
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --all
```

> 注意：当前自测和 CI 连接的是公用 Captain-2/纵横环境。涉及创建、删除、绑定、resync、写保护、详情编辑的 E2E 可能互相影响。CI 默认通过 `resource_group` 串行 E2E job，并设置 `E2E_WORKERS=1`，避免多个 suite 同时写共享 Captain。若本地排查疑似并发冲突，也使用 `E2E_WORKERS=1`。

### 分层运行

`e2e/suites.js` 是所有 `*.spec.js` 的唯一登记清单。新增 E2E 文件必须登记到该文件，否则 `check-manifest.js` 会失败。

```bash
# 冒烟层：登录、页面导航、核心页面不空白、基础 API 契约
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --layer smoke

# 关键回归层：权限、租户隔离、Captain 代理、绑定、写保护
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --layer critical

# 按模块运行
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --module policy-rule

# 按标签运行
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --tag write-protection

# 只查看会跑哪些 suite，不真正执行
node e2e/run-integration.js --layer smoke --dry-run

# 共享 Captain 环境下建议串行执行
E2E_WORKERS=1 PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --layer critical
```

### 按改动自动选测

`e2e/impact-map.js` 维护「代码路径 → 影响模块 → 必跑 E2E」关系，`select-tests.js` 根据 git diff 输出本次必须运行的 suite。`e2e/impact-map-check.js` 会扫描仓库产品代码文件，确保每个文件至少命中一条 impact-map 规则。`e2e/check-selection.js` 会断言选测器在命中、fallback、改动 E2E spec、纯 E2E infra、无效 diff 等场景下的行为。

```bash
# 使用 git diff 自动选测
node e2e/select-tests.js --base origin/main --head HEAD --out selected-e2e.json

# 执行选中的测试
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --from selected-e2e.json

# 手动验证某些文件会选出哪些测试
node e2e/select-tests.js --files gateway/server/apis/captain/handler/policy_rule.go,frontend/packages/skyview-web/src/api/captain.ts

# 被修改的 E2E spec 会自动加入 selected suites
node e2e/select-tests.js --files frontend/packages/skyview-web/e2e/integ-rbac.spec.js
```

选测规则：

- 修改产品代码：按 `impact-map.js` 匹配相关模块和 suite。
- 修改产品代码但未匹配任何模块：fallback 到 `smoke + critical`。
- 修改 `e2e/integ-*.spec.js`：被修改的 spec 必须进入 selected suites。
- 同时修改产品代码和 E2E spec：运行两者的并集。
- 仅修改 E2E 基础设施（runner、manifest、impact-map、README、CI E2E job 等）：不 fallback 到 `smoke + critical`，由 `e2e-manifest-check` 的 infra 校验兜底。

### 运行单个测试

```bash
cd frontend/packages/skyview-web

# 例：只跑 RBAC 测试
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/integ-rbac.spec.js

# 或通过 runner 运行单个登记 suite
PLAYWRIGHT_HEADLESS=1 TARGET_URL=http://localhost:3000 node e2e/run-integration.js --suite integ-rbac.spec.js
```

### CI 中运行

GitLab CI 包含以下 E2E job：

- `e2e-manifest-check` — 不启服务，只检查所有 `integ-*.spec.js` 是否登记到 `suites.js`
- `e2e-smoke` — 使用 `frontend-build` 的 `dist/` 产物启动轻量静态服务，跑 `run-integration.js --layer smoke`；MR/普通分支会在同一次服务启动内继续跑 impact selected suites
- `e2e-critical` — main/release 自动跑，其他分支可手动跑关键回归层
- `e2e-full` — 定时任务或手动触发全量 `--all`

`INTEGRATION_ENABLED=0` 时会跳过需要真实后端和 Captain 的 integration 部分，但 `e2e-manifest-check` 仍会执行。

由于 Captain-2 是共享环境，所有 `.e2e` job 使用同一个 GitLab `resource_group`：`cmc-tenant-shared-captain-e2e`。这会让 `e2e-smoke`、`e2e-critical`、`e2e-full` 串行执行，避免不同 pipeline/job 同时修改同一套纵横数据。

### 新增 E2E 准入要求

1. 新增功能必须有对应 E2E，文件放在 `e2e/integ-*.spec.js`。
2. 新增 E2E 必须登记到 `e2e/suites.js`，填写 `layers/modules/tags/group`。
3. 新增或移动业务代码目录时，应同步更新 `e2e/impact-map.js`。
4. `e2e/impact-map-check.js` 必须通过，不能留下未映射的产品代码路径。
5. 涉及权限、租户隔离、Captain 代理、写保护、删除保护、资源绑定的测试应加入 `critical` 层。
6. 无法自动化的场景必须在审计任务中给出豁免原因和人工验证步骤。
7. 关键 E2E 不允许长期通过 `⚠️ ... 跳过` 规避断言；现存待改造项记录在 `e2e/E2E_TODO.md`。
8. 临时下线的 suite 必须在 `e2e/suites.js` 标记 `disabled: true` 和 `disabledReason`，runner/impact 默认不执行；仅手工诊断时使用 `run-integration.js --include-disabled`。

## 测试账号

| 角色 | 用户名 | 密码 |
|---|---|---|
| admin | admin | Admin@2024 |
| tenant_admin | test_admin | Tenant@2024 |

## 关键注意事项

### 系统代理

macOS 如有 HTTP 代理（如 Clash），Playwright 需配置 bypass：
```js
proxy: { server: 'http://127.0.0.1:7890', bypass: 'localhost,127.0.0.1' }
```
curl 测试后端时用 `--noproxy localhost`。

### 登录态

- 用 `navTo(groupName, menuItem)` 辅助函数处理横版布局（TopNav + 左侧子菜单）
- 不要用 `page.goto()` 跳转到需认证的页面（会丢失 session）
- Integration E2E 默认按角色缓存登录 cookie 到 `e2e/.auth/`，后续 suite 会先校验 `/api/auth/current`，有效则复用，失效才重新登录。
- 登录功能专项 `integ-auth.spec.js` 不复用缓存，确保登录/登出本身仍走真实流程。
- 排查登录相关问题时可设置 `E2E_AUTH_CACHE=0` 关闭缓存。

### captain_instance_id 传参

前端必须将 `captain_instance_id` 作为独立 query 参数传递，不能放在 conditions JSON 里。

### Captain API 响应格式

- Captain 返回列表是裸数组 `{"data": [...]}`，后端用 `wrapListAsPage()` 统一包装为分页格式
- Captain API 返回 PascalCase 字段名（`Name`、`ID` 等）

### WAF 选择器时序

子页面通过 `WafSelectorMixin` 获取 `wafId`，Mixin `mounted` 异步加载 WAF 列表后自动选中第一个。

## 测试环境

| 服务 | 地址 |
|---|---|
| Captain-2 | https://10.2.102.76 |
| PostgreSQL | 10.2.102.76:5432 (cmc/cmc123456/cmc_tenant) |
| Redis | 10.2.102.76:6379 |
