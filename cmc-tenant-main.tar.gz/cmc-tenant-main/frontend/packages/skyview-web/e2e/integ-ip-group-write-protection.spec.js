// Integration: IP group write protection — runtime (in_use) + shared + edit (has_external_ref) protection
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

// API helpers (browser-context fetch with auto cookies)
async function apiGet(page, urlPath) {
  return page.evaluate(async (p) => {
    const r = await fetch(p, { credentials: 'include' })
    return r.json()
  }, urlPath)
}

async function apiPost(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return r.json()
  }, [urlPath, body])
}

async function apiPut(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return r.json()
  }, [urlPath, body])
}

async function apiDelete(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return { status: r.status, body: await r.json() }
  }, [urlPath, body])
}

// Check if style contains gray color (#ccc or rgb(204,...))
function isGrayColor(style) {
  return style.includes('#ccc') || style.includes('rgb(204') || style.includes('rgb(204, 204, 204)')
}

// Find delete/edit button in a row by icon class
async function findIconButton(row, iconClass) {
  const btns = row.locator('.el-button')
  const count = await btns.count()
  for (let i = 0; i < count; i++) {
    const hasIcon = await btns.nth(i).evaluate((el, cls) => {
      return el.querySelector(`.${cls}`) !== null
    }, iconClass)
    if (hasIcon) return btns.nth(i)
  }
  return null
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  let p = 0, f = 0
  let captainInstanceId
  let fixtureGroupId = null
  const fixtureGroupName = `cmc-e2e-ipg-${Date.now()}`

  // --- Seed: login as tenant_admin (non-admin gets protection fields injected) ---
  await loginAs(page, 'tenant_admin')

  try {
    const cookieHeader = await getAuthCookieHeader(page, 'tenant_admin')
    captainInstanceId = await getActiveWafId(page, cookieHeader)
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)
    console.log(`  Using captain_instance_id=${captainInstanceId}`)
  } catch (e) {
    console.log(`❌ WAF selection: ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  async function ensureTenantIPGroup() {
    const listPath = `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`
    const currentResp = await apiGet(page, listPath)
    if (currentResp.err !== null) throw new Error(`API error: ${currentResp.msg}`)
    let items = currentResp.data?.items || []
    if (items.length > 0) return items

    const createResp = await apiPost(page, `${TARGET_URL}/api/captain/ip-group/create`, {
      name: fixtureGroupName,
      comment: 'e2e write protection fixture',
      captain_instance_id: captainInstanceId,
    })
    if (createResp.err !== null) throw new Error(`Create fixture IP group failed: ${createResp.msg || createResp.err}`)
    fixtureGroupId = createResp.data?.id || null

    const refreshedResp = await apiGet(page, listPath)
    if (refreshedResp.err !== null) throw new Error(`API error after fixture create: ${refreshedResp.msg}`)
    items = refreshedResp.data?.items || []
    const created = items.find(g => g.name === fixtureGroupName)
    if (created?.id) fixtureGroupId = created.id
    if (items.length === 0) throw new Error('No IP groups returned after fixture create')
    return items
  }

  // ═══════════════════════════════════════════
  // Test 1: List injection — protection fields for tenant_admin
  // ═══════════════════════════════════════════
  let ipGroups = []
  try {
    ipGroups = await ensureTenantIPGroup()
    const sample = ipGroups[0]
    if (!('used_count' in sample)) throw new Error('Missing used_count field')
    if (!('source' in sample)) throw new Error('Missing source field')
    if (!('has_external_ref' in sample)) throw new Error('Missing has_external_ref field')
    console.log(`✅ [列表注入] 保护字段存在 (used_count=${sample.used_count}, source=${sample.source}, has_external_ref=${sample.has_external_ref})`); p++
  } catch (e) { f++; console.log(`❌ [列表注入] 保护字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 2: List injection — admin has no source field (source only for non-admin)
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'admin')
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    if (items.length === 0) throw new Error('No IP groups returned for admin after fixture create')

    const sample = items[0]
    // source is only injected for non-admin users — admin should NOT have it
    if ('source' in sample) {
      console.log(`✅ [列表注入] admin 可见 source 字段 (source=${sample.source})`); p++
    } else {
      console.log(`✅ [列表注入] admin 无 source 字段（source 仅注入非 admin 用户）`); p++
    }
    // Re-login as tenant_admin for remaining API tests
    await loginAs(page, 'tenant_admin')
  } catch (e) { f++; console.log(`❌ [列表注入] source 字段: ${e.message}`); await loginAs(page, 'tenant_admin').catch(() => {}) }

  // ═══════════════════════════════════════════
  // Test 3: Runtime protection — in_use delete returns err=in_use
  // ═══════════════════════════════════════════
  try {
    // Refresh list as tenant_admin
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseGroup = items.find(g => (g.used_count ?? 0) > 0)

    if (inUseGroup) {
      const resp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
        id: inUseGroup.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Expected err=in_use, got err=${resp.body?.err}, status=${resp.status}`)
      console.log(`✅ [运行时保护] 删除使用中IP组返回 in_use 错误`); p++
    } else {
      console.log('⚠️ 无使用中IP组(used_count>0)，跳过运行时保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [运行时保护] 删除使用中IP组: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 4: Runtime protection — error message contains "防护策略"
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseGroup = items.find(g => (g.used_count ?? 0) > 0)

    if (inUseGroup) {
      const resp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
        id: inUseGroup.id,
        captain_instance_id: captainInstanceId,
      })
      if (!resp.body?.msg || !resp.body.msg.includes('防护策略')) throw new Error(`msg should mention 防护策略: ${resp.body?.msg}`)
      console.log(`✅ [运行时保护] 错误消息包含引用数 (msg=${resp.body.msg})`); p++
    } else {
      console.log('⚠️ 无使用中IP组，跳过错误消息测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [运行时保护] 错误消息: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 5: Shared protection — shared delete returns err=shared or in_use (priority)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    // Prefer shared but NOT in use (to test shared protection specifically)
    const sharedNotInUse = items.find(g => (g.binding_count ?? 0) > 1 && (g.used_count ?? 0) === 0)
    const sharedAny = items.find(g => (g.binding_count ?? 0) > 1)

    if (sharedNotInUse) {
      console.log(`  [共享保护] 选中 IP 组: id=${sharedNotInUse.id}, name=${sharedNotInUse.name}, binding_count=${sharedNotInUse.binding_count}, used_count=${sharedNotInUse.used_count}`)
      const resp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
        id: sharedNotInUse.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'shared' && resp.body?.err !== 'in_use')
        throw new Error(`Expected err=shared or in_use, got err=${resp.body?.err}`)
      if (resp.body?.err === 'shared') {
        console.log(`✅ [共享保护] 删除共享IP组返回 shared 错误`)
      } else {
        console.log(`✅ [共享保护] 共享IP组实际也有引用，返回 in_use（优先级: in_use > shared）`)
      }
      p++
    } else if (sharedAny) {
      console.log(`  [共享保护] 选中 IP 组(含引用): id=${sharedAny.id}, name=${sharedAny.name}, binding_count=${sharedAny.binding_count}, used_count=${sharedAny.used_count}`)
      // Shared + in_use — in_use takes priority (check order: in_use → shared)
      const resp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
        id: sharedAny.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use' && resp.body?.err !== 'shared') throw new Error(`Expected err=in_use or shared, got err=${resp.body?.err}`)
      console.log(`✅ [共享保护] 共享+使用中IP组删除返回 ${resp.body?.err}（检查顺序: in_use 优先）`); p++
    } else {
      console.log('⚠️ 无共享IP组(binding_count>1)，跳过共享保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [共享保护] 删除共享IP组: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 6: Shared protection — error message text (only for pure shared)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedNotInUse = items.find(g => (g.binding_count ?? 0) > 1 && (g.used_count ?? 0) === 0)

    if (sharedNotInUse) {
      const resp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
        id: sharedNotInUse.id,
        captain_instance_id: captainInstanceId,
      })
      if (!resp.body?.msg || !resp.body.msg.includes('共享')) throw new Error(`msg should mention 共享: ${resp.body?.msg}`)
      console.log(`✅ [共享保护] 错误消息包含共享文本 (msg=${resp.body.msg})`); p++
    } else {
      console.log('⚠️ 无纯共享IP组，跳过错误消息测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [共享保护] 错误消息: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 7: Shared edit protection — binding_count>1 UPDATE returns err=shared
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedEditGroup = items.find(g => (g.binding_count ?? 0) > 1)

    if (sharedEditGroup) {
      const resp = await apiPut(page, `${TARGET_URL}/api/captain/ip-group/update`, {
        id: sharedEditGroup.id,
        name: sharedEditGroup.name,
        captain_instance_id: captainInstanceId,
      })
      if (resp.err !== 'shared') throw new Error(`Expected err=shared, got err=${resp.err}`)
      console.log(`✅ [共享保护] 编辑共享IP组返回 shared 错误`); p++
    } else {
      console.log('⚠️ 无 binding_count>1 的 IP组，跳过 shared 编辑保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [共享保护] 编辑共享IP组: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 8: Priority — in_use + shared both true → in_use takes priority
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const bothProtected = items.find(g => (g.used_count ?? 0) > 0 && (g.binding_count ?? 0) > 1)

    if (bothProtected) {
      const resp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
        id: bothProtected.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Expected err=in_use (priority), got err=${resp.body?.err}`)
      console.log(`✅ [优先级] in_use + shared 同时满足时优先返回 in_use`); p++
    } else {
      console.log('⚠️ 无同时 in_use+shared 的IP组，跳过优先级测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [优先级] in_use 优先: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 9: Edit protection — has_external_ref UPDATE returns err=has_external_ref
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const extRefGroup = items.find(g => g.has_external_ref === true && (g.binding_count ?? 0) <= 1)

    if (extRefGroup) {
      const resp = await apiPut(page, `${TARGET_URL}/api/captain/ip-group/update`, {
        id: extRefGroup.id,
        name: extRefGroup.name,
        captain_instance_id: captainInstanceId,
      })
      if (resp.err !== 'has_external_ref') throw new Error(`Expected err=has_external_ref, got err=${resp.err}`)
      console.log(`✅ [编辑保护] has_external_ref 编辑保护`); p++
    } else {
      console.log('⚠️ 没有 has_external_ref=true 且 binding_count<=1 的IP组，跳过编辑保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [编辑保护] has_external_ref: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 10: Edit protection — source=created bypasses has_external_ref
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const createdGroup = items.find(g => g.source === 'created' && (g.binding_count ?? 0) <= 1)

    if (createdGroup) {
      const resp = await apiPut(page, `${TARGET_URL}/api/captain/ip-group/update`, {
        id: createdGroup.id,
        name: createdGroup.name,
        comment: createdGroup.comment || '',
        captain_instance_id: captainInstanceId,
      })
      if (resp.err === 'has_external_ref') throw new Error('source=created should bypass has_external_ref check')
      // err=null means success, other errors (proxy etc) are also acceptable for this test
      console.log(`✅ [编辑保护] source=created 允许编辑 (err=${resp.err})`); p++
    } else {
      console.log('⚠️ 没有 source=created 的IP组，跳过编辑绕过测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [编辑保护] source=created 编辑: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 11: Ownership — non-owner tenant group delete returns err=forbidden
  // ═══════════════════════════════════════════
  try {
    // Login as admin to get full list
    await loginAs(page, 'admin')
    const adminListResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const adminItems = adminListResp.data?.items || []

    // Login as tenant_admin to get filtered list
    await loginAs(page, 'tenant_admin')
    const tenantListResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantItems = tenantListResp.data?.items || []

    if (tenantItems.length > 0 && adminItems.length > tenantItems.length) {
      // Find an IP group visible to admin but NOT in tenant list (non-owned)
      const tenantIds = new Set(tenantItems.map(i => i.id))
      const notOwned = adminItems.find(i => !tenantIds.has(i.id))

      if (notOwned) {
        // Still logged in as tenant_admin, try to delete a non-owned resource
        const resp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
          id: notOwned.id,
          captain_instance_id: captainInstanceId,
        })
        if (resp.body?.err !== 'forbidden') throw new Error(`Expected err=forbidden, got err=${resp.body?.err}`)
        console.log(`✅ [所有权] 非本组资源删除返回 forbidden`); p++
      } else {
        console.log('⚠️ 无非本组IP组，跳过所有权测试'); p++
      }
    } else {
      console.log('⚠️ 租户可见范围等于admin或列表为空，跳过所有权测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [所有权] 非本组资源: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 12: UI — in-use IP group delete button grayed + tooltip
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseGroup = items.find(g => (g.used_count ?? 0) > 0)

    if (inUseGroup) {
      const row = page.locator('.el-table__row').filter({ hasText: inUseGroup.name || String(inUseGroup.id) }).first()
      const deleteBtn = await findIconButton(row, 'el-icon-delete')

      if (deleteBtn) {
        const btnStyle = await deleteBtn.evaluate(el => el.getAttribute('style') || '')
        if (!isGrayColor(btnStyle)) throw new Error(`In-use IP group delete button not grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const anyWarning = await page.locator('.el-message--warning').count()
        if (anyWarning === 0) throw new Error('No warning toast for in-use IP group delete')
        console.log(`✅ [UI] 使用中IP组删除按钮置灰+警告提示`); p++
      } else {
        console.log('⚠️ 使用中IP组行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无使用中IP组，跳过UI使用中删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 使用中IP组删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 13: UI — shared IP group delete button grayed + tooltip
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedGroup = items.find(g => (g.binding_count ?? 0) > 1)

    if (sharedGroup) {
      const row = page.locator('.el-table__row').filter({ hasText: sharedGroup.name || String(sharedGroup.id) }).first()
      const deleteBtn = await findIconButton(row, 'el-icon-delete')

      if (deleteBtn) {
        const btnStyle = await deleteBtn.evaluate(el => el.getAttribute('style') || '')
        if (!isGrayColor(btnStyle)) throw new Error(`Shared IP group delete button not grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const anyWarning = await page.locator('.el-message--warning').count()
        if (anyWarning === 0) throw new Error('No warning toast for shared IP group delete')
        console.log(`✅ [UI] 共享IP组删除按钮置灰+警告提示`); p++
      } else {
        console.log('⚠️ 共享IP组行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无共享IP组，跳过UI共享删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 共享IP组删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 14: UI — has_external_ref IP group edit button grayed
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const extRefGroup = items.find(g => g.has_external_ref === true && (g.binding_count ?? 0) <= 1)

    if (extRefGroup) {
      const row = page.locator('.el-table__row').filter({ hasText: extRefGroup.name || String(extRefGroup.id) }).first()
      const editBtn = await findIconButton(row, 'el-icon-edit')

      if (editBtn) {
        const btnStyle = await editBtn.evaluate(el => el.getAttribute('style') || '')
        if (!isGrayColor(btnStyle)) throw new Error(`has_external_ref IP group edit button not grayed, style=${btnStyle}`)
        console.log(`✅ [UI] has_external_ref IP组编辑按钮置灰`); p++
      } else {
        console.log('⚠️ has_external_ref IP组行未找到编辑按钮'); p++
      }
    } else {
      console.log('⚠️ 无 has_external_ref=true 的非共享IP组，跳过UI编辑按钮测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] has_external_ref 编辑按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 15: UI — normal IP group buttons dark + clickable (confirm dialog)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const normalGroup = items.find(g => (g.binding_count ?? 0) <= 1 && (g.used_count ?? 0) === 0 && !(g.has_external_ref ?? false))

    if (normalGroup) {
      const row = page.locator('.el-table__row').filter({ hasText: normalGroup.name || String(normalGroup.id) }).first()
      const deleteBtn = await findIconButton(row, 'el-icon-delete')

      if (deleteBtn) {
        const btnStyle = await deleteBtn.evaluate(el => el.getAttribute('style') || '')
        if (isGrayColor(btnStyle)) throw new Error(`Normal IP group delete button should NOT be grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        // Should show confirm dialog, not warning
        const confirmVisible = await page.locator('.el-message-box:visible').count()
        if (confirmVisible > 0) {
          await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click()
          console.log(`✅ [UI] 正常IP组删除按钮深色+弹出确认框`); p++
        } else {
          console.log('⚠️ 正常IP组点击删除未弹出确认框（可能有其他弹窗）'); p++
        }
      } else {
        console.log('⚠️ 正常IP组行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无可删除IP组，跳过UI正常删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 正常IP组删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 16: Tenant — source field injection for tenant_admin
  // ═══════════════════════════════════════════
  try {
    // Already logged in as tenant_admin
    const tenantListResp = await apiGet(page, `${TARGET_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantItems = tenantListResp.data?.items || []
    if (tenantItems.length > 0) {
      const sample = tenantItems[0]
      if (!('source' in sample)) throw new Error('Missing source field for tenant user')
      console.log(`✅ [租户] source 字段注入正确 (source=${sample.source})`); p++
    } else {
      console.log('⚠️ 租户无可见IP组，跳过 source 字段检查'); p++
    }
  } catch (e) { f++; console.log(`❌ [租户] source 字段: ${e.message}`) }

  if (fixtureGroupId) {
    try {
      const cleanupResp = await apiDelete(page, `${TARGET_URL}/api/captain/ip-group/delete`, {
        id: fixtureGroupId,
        captain_instance_id: captainInstanceId,
      })
      if (cleanupResp.body?.err === null) {
        console.log(`  🧹 已清理测试 IP 组 id=${fixtureGroupId}`)
      } else {
        console.log(`  ⚠️ 测试 IP 组清理返回 err=${cleanupResp.body?.err}`)
      }
    } catch (e) {
      console.log(`  ⚠️ 测试 IP 组清理失败: ${e.message}`)
    }
  }

  console.log(`\n📊 IP Group Write Protection: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
