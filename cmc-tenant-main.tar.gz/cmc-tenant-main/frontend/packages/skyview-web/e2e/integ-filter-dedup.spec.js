// E2E Test: ConditionFilter field dedup — selected fields should not appear in other condition dropdowns
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, waitForTableData, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

const EXPECTED_DETECT_FILTER_LABELS = [
  '防护站点名称', '日志来源', '攻击类型', '国家', '省份', '源 IP', 'Socket IP', '源端口', '目的 IP',
  '目的端口', 'Host 端口', '域名', 'URL 路径', 'Event ID', '规则 ID', '请求规则 ID', '响应规则 ID',
  '请求方法', '执行动作', '风险等级', '响应码', '请求开始时间', '响应开始时间', '时间范围',
  '请求检测时长', '响应检测时长', '请求体截断', '响应体截断', 'HTTP Body 丢弃', '请求检测引擎',
  '响应检测引擎', '请求解码路径', '响应解码路径', '威胁置信度', '威胁风险等级', '威胁最近时间',
  '威胁标签', '信誉库 IP 最近发现时间', '信誉库 FP 最近发现时间', '信誉库 IP 置信度',
  '信誉库 FP 置信度', '信誉库 IP 命中标签', '信誉库 FP 命中标签', '内层 VLAN ID', '外层 VLAN ID',
  'X-Forwarded-For', '指纹', '上游地址', '请求 Payload 解释', '响应 Payload 解释', '攻击有效性',
]

const REPRESENTATIVE_FILL_FIELDS = [
  '防护站点名称',
  '日志来源',
  '攻击类型',
  '源 IP',
  '源端口',
  '域名',
  '目的 IP',
  '请求方法',
  '执行动作',
  '风险等级',
  'Event ID',
  '时间范围',
]

// Helper: navigate to detect log page with a fresh page load (avoids Vue component state persistence)
async function goToDetectLog(page) {
  await navTo(page, '威胁监测', '检测日志')
  await page.reload({ waitUntil: 'domcontentloaded' })
  await waitForTableData(page)
  // Wait for the condition filter component to render (may be delayed when API returns errors in CI)
  await page.locator('.condition-filter').waitFor({ state: 'visible', timeout: 10000 })
}

async function waitForConditionCount(page, count) {
  await page.locator('.condition-filter__item').nth(count - 1)
    .waitFor({ state: 'visible', timeout: 5000 })
}

async function addCondition(page, addBtn) {
  const before = await page.locator('.condition-filter__item').count()
  await addBtn.click()
  await waitForConditionCount(page, before + 1)
  return page.locator('.condition-filter__item').nth(before)
}

async function waitForDropdownOptions(page) {
  const dropdown = page.locator('.el-select-dropdown:not([style*="display: none"])').last()
  await dropdown.locator('.el-select-dropdown__item').first()
    .waitFor({ state: 'visible', timeout: 10000 })
  return dropdown
}

async function getVisibleOptionLabels(page) {
  const dropdown = await waitForDropdownOptions(page)
  return dropdown.locator('.el-select-dropdown__item:visible').evaluateAll(items =>
    items
      .map(item => (item.textContent || '').trim())
      .filter(Boolean)
  )
}

// Helper: select a field from the condition's field dropdown, then wait for value input to render
async function selectField(page, itemLocator, label) {
  await itemLocator.locator('.el-select .el-input__inner').first().click()
  const dropdown = await waitForDropdownOptions(page)
  const option = dropdown.locator('.el-select-dropdown__item').filter({ hasText: label }).first()
  await option.waitFor({ state: 'visible', timeout: 10000 })
  await option.click()
  // Wait for the value input area to render after field change triggers Vue re-render
  await itemLocator.locator('.condition-filter__sub-item').waitFor({ state: 'visible', timeout: 5000 })
}

// Helper: fill a value in a condition to make it complete (so addBtn re-enables)
async function fillConditionValue(page, itemLocator) {
  const subItem = itemLocator.locator('.condition-filter__sub-item')

  // Find value selects — skip operator dropdowns. The operator width changed
  // from 80px to 112px when more labels were added.
  const allSelects = subItem.locator('.el-select')
  let valueSelectIdx = -1
  for (let i = 0; i < await allSelects.count(); i++) {
    const w = await allSelects.nth(i).evaluate(el => el.style.width)
    if (!['80px', '112px'].includes(w)) { valueSelectIdx = i; break }
  }

  if (valueSelectIdx >= 0) {
    // choice / multi_choice — click the value select (wait for it to be actionable)
    await allSelects.nth(valueSelectIdx).locator('.el-input__inner').click()
    // Wait for dropdown options to become visible
    const visibleDd = page.locator('.el-select-dropdown:not([style*="display: none"])').last()
    const firstOption = visibleDd.locator('.el-select-dropdown__item').first()
    await firstOption.waitFor({ state: 'visible', timeout: 10000 })
    await firstOption.click()
    await itemLocator.locator('.condition-filter__sub-item').waitFor({ state: 'visible', timeout: 5000 })
    await page.keyboard.press('Escape')
    return
  }

  // time_range field — el-date-picker with datetimerange
  // Use JS to set value directly via Vue component, then trigger change event
  const dateEditor = subItem.locator('.el-date-editor, [class*="el-date-editor"]')
  if (await dateEditor.count() > 0) {
    const now = new Date()
    const start = new Date(now.getTime() - 3600000)
    const end = new Date(now.getTime() + 3600000)
    await dateEditor.evaluate((el, s, e) => {
      const vm = el.__vue__
      if (vm) { vm.$emit('input', [new Date(s), new Date(e)]); vm.$emit('change', [new Date(s), new Date(e)]) }
    }, start.toISOString(), end.toISOString())
    await itemLocator.locator('.condition-filter__sub-item').waitFor({ state: 'visible', timeout: 5000 })
    return
  }

  // text field — find the writable input (readonly=false)
  const inputs = subItem.locator('input')
  for (let i = 0; i < await inputs.count(); i++) {
    const inp = inputs.nth(i)
    const isReadonly = await inp.evaluate(el => el.readOnly)
    if (!isReadonly && (await inp.isVisible())) {
      await inp.fill('test')
      await itemLocator.locator('.condition-filter__sub-item').waitFor({ state: 'visible', timeout: 5000 })
      return
    }
  }
}

async function fillAllConditionsProgrammatically(page) {
  return page.locator('.condition-filter').evaluate(el => {
    const vm = el.__vue__
    if (!vm || !Array.isArray(vm.fields)) throw new Error('ConditionFilter Vue instance not found')

    const conditions = vm.fields.map(field => {
      let value = 'test'
      if (field.type === 'time_range') value = '0-4102444800'
      else if (field.type === 'multi_choice' || field.type === 'flag') value = [String(field.choices?.[0]?.value ?? '1')]
      else if (field.type === 'choice') value = String(field.choices?.[0]?.value ?? '1')
      else if (field.type === 'number') value = '1'

      return {
        target: field.value,
        items: [{ oper: field.defaultOper || 'exact', value }],
      }
    })

    vm.$emit('change', conditions)
    return conditions.length
  })
}

function findCondition(body, target) {
  return (body.conditions || []).find(cond => cond.target === target)
}

async function emitSearchConditions(page, conditions) {
  return page.locator('.condition-filter').evaluate((el, nextConditions) => {
    const vm = el.__vue__
    if (!vm) throw new Error('ConditionFilter Vue instance not found')
    vm.$emit('change', nextConditions)
    vm.$emit('search', nextConditions)
    return nextConditions.length
  }, conditions)
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()

  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  let p = 0, f = 0

  // ---- Test 1: Detect log page — add filter button exists ----
  try {
    await goToDetectLog(page)

    const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')
    await addBtn.waitFor({ state: 'visible', timeout: 10000 })
    console.log('✅ Detect log: add filter button exists'); p++
  } catch (e) { f++; console.log(`❌ Detect log add filter button: ${e.message}`) }

  // ---- Test 2: Selected field not in second condition dropdown ----
  try {
    await goToDetectLog(page)

    const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')
    await addBtn.waitFor({ state: 'visible', timeout: 10000 })

    // Add first condition, select "攻击类型", fill a value to make it complete
    const firstItem = await addCondition(page, addBtn)
    await selectField(page, firstItem, '攻击类型')
    await fillConditionValue(page, firstItem)

    // Now add second condition
    const secondItem = await addCondition(page, addBtn)

    // Open second condition's field dropdown
    await secondItem.locator('.el-select .el-input__inner').first().click()
    await waitForDropdownOptions(page)

    // "攻击类型" should NOT appear in the dropdown
    const duplicateOption = page.locator('.el-select-dropdown:not([style*="display: none"]) .el-select-dropdown__item:has-text("攻击类型")')
    if (await duplicateOption.count() > 0) throw new Error('Already-selected field should not appear in other condition dropdown')

    // Other fields like "源 IP" should still be available
    const availableOption = page.locator('.el-select-dropdown:not([style*="display: none"]) .el-select-dropdown__item:has-text("源 IP")')
    if (await availableOption.count() === 0) throw new Error('Unselected field should be available in dropdown')

    await page.keyboard.press('Escape')
    console.log('✅ Selected field excluded from other condition dropdown'); p++
  } catch (e) { f++; console.log(`❌ Selected field dedup: ${e.message}`) }

  // ---- Test 3: Detect-log fields are aligned and representative field types can be filled ----
  try {
    await goToDetectLog(page)

    const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')

    await addBtn.click()
    const firstItem = page.locator('.condition-filter__item').first()
    await firstItem.locator('.el-select .el-input__inner').first().click()
    const availableLabels = await getVisibleOptionLabels(page)
    await page.keyboard.press('Escape')
    await firstItem.locator('.condition-filter__remove').click()

    const missing = EXPECTED_DETECT_FILTER_LABELS.filter(label => !availableLabels.some(opt => opt.includes(label)))
    if (missing.length > 0) throw new Error(`Expected fields missing from dropdown: ${missing.join(', ')}`)
    if (availableLabels.length !== EXPECTED_DETECT_FILTER_LABELS.length) {
      throw new Error(`Expected ${EXPECTED_DETECT_FILTER_LABELS.length} detect-log filters, got ${availableLabels.length}`)
    }

    for (const label of REPRESENTATIVE_FILL_FIELDS) {
      if (await addBtn.isDisabled()) break
      const lastItem = await addCondition(page, addBtn)
      await selectField(page, lastItem, label)
      await fillConditionValue(page, lastItem)
    }

    // Verify all fields are actually used (not just button disabled for wrong reason)
    const usedCount = await page.locator('.condition-filter__item--active').count()
    if (usedCount !== REPRESENTATIVE_FILL_FIELDS.length) throw new Error(`Only ${usedCount}/${REPRESENTATIVE_FILL_FIELDS.length} conditions have active values — fillConditionValue may have failed`)

    // Detect log now has many more fields than this representative set, so the button should remain enabled.
    const isDisabled = await addBtn.isDisabled()
    if (isDisabled) throw new Error('Add filter button should remain enabled while unused fields are available')
    console.log('✅ Detect-log filter fields aligned and representative types fillable'); p++
  } catch (e) { f++; console.log(`❌ Detect-log filter field alignment: ${e.message}`) }

  // ---- Test 4: Detect-log search sends enum, IP operator, and number conditions ----
  try {
    await goToDetectLog(page)

    const conditions = [
      { target: 'attack_type', items: [{ oper: 'in', value: ['0'] }] },
      { target: 'risk_level', items: [{ oper: 'in', value: ['3'] }] },
      { target: 'src_ip', items: [{ oper: 'net_contained_or_equal', value: '10.0.0.0/8' }] },
      { target: 'src_port', items: [{ oper: 'gt', value: '1024' }] },
    ]

    const reqPromise = page.waitForRequest(req => {
      if (req.method() !== 'POST' || !req.url().includes('/api/captain/detect-log/list')) return false
      try { return JSON.parse(req.postData() || '{}').conditions?.length >= 4 } catch { return false }
    }, { timeout: 10000 })
    await emitSearchConditions(page, conditions)
    const body = JSON.parse((await reqPromise).postData() || '{}')

    const attackType = findCondition(body, 'attack_type')
    const riskLevel = findCondition(body, 'risk_level')
    const srcIp = findCondition(body, 'src_ip')
    const srcPort = findCondition(body, 'src_port')

    if (!attackType?.items?.[0]?.value?.includes('0')) throw new Error(`attack_type SQL 注入 should submit value 0: ${JSON.stringify(attackType)}`)
    if (!riskLevel?.items?.[0]?.value?.includes('3')) throw new Error(`risk_level 高危 should submit value 3: ${JSON.stringify(riskLevel)}`)
    if (srcIp?.items?.[0]?.oper !== 'net_contained_or_equal' || srcIp.items[0].value !== '10.0.0.0/8') {
      throw new Error(`src_ip CIDR condition mismatch: ${JSON.stringify(srcIp)}`)
    }
    if (srcPort?.items?.[0]?.oper !== 'gt' || srcPort.items[0].value !== '1024') {
      throw new Error(`src_port number condition mismatch: ${JSON.stringify(srcPort)}`)
    }

    console.log('✅ Detect-log search request contains enum, CIDR, and number filters'); p++
  } catch (e) { f++; console.log(`❌ Detect-log search request filters: ${e.message}`) }

  // ---- Test 5: Deleted field becomes available again ----
  try {
    await goToDetectLog(page)

    const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')

    // Add first condition with "攻击类型" and fill value
    const firstItem = await addCondition(page, addBtn)
    await selectField(page, firstItem, '攻击类型')
    await fillConditionValue(page, firstItem)

    // Add second condition with "源 IP" and fill value
    const secondItem = await addCondition(page, addBtn)
    await selectField(page, secondItem, '源 IP')
    await fillConditionValue(page, secondItem)

    // Delete first condition
    const beforeDelete = await page.locator('.condition-filter__item').count()
    await firstItem.locator('.condition-filter__remove').click()
    await page.waitForFunction(
      (count) => document.querySelectorAll('.condition-filter__item').length === count - 1,
      beforeDelete,
      { timeout: 5000 }
    )

    // Now add a new condition and check "攻击类型" is available again
    const newItem = await addCondition(page, addBtn)
    await newItem.locator('.el-select .el-input__inner').first().click()
    await waitForDropdownOptions(page)
    const recoveredOption = page.locator('.el-select-dropdown:not([style*="display: none"]) .el-select-dropdown__item:has-text("攻击类型")')
    if (await recoveredOption.count() === 0) throw new Error('Deleted field should be available in dropdown again')
    await page.keyboard.press('Escape')
    console.log('✅ Deleted field becomes available again'); p++
  } catch (e) { f++; console.log(`❌ Deleted field recovery: ${e.message}`) }

  // ---- Test 6: Route policy_rule_id initializes rule_id condition ----
  try {
    await page.goto(`${TARGET_URL}/threat/detect-log?policy_rule_id=12345`, { waitUntil: 'domcontentloaded' })
    await waitForTableData(page)
    await page.locator('.condition-filter').waitFor({ state: 'visible', timeout: 10000 })

    const conditions = await page.locator('.condition-filter').evaluate(el => {
      const vm = el.__vue__
      return vm?.conditions || []
    })
    const ruleCond = conditions.find(c => c.target === 'rule_id')
    if (!ruleCond) throw new Error(`rule_id condition not found: ${JSON.stringify(conditions)}`)
    const item = ruleCond.items?.[0] || {}
    if (item.oper !== 'exact' || String(item.value) !== '12345') {
      throw new Error(`Unexpected rule_id condition: ${JSON.stringify(ruleCond)}`)
    }
    console.log('✅ Route policy_rule_id initializes rule_id condition'); p++
  } catch (e) { f++; console.log(`❌ Route policy_rule_id condition: ${e.message}`) }

  // ---- Test 7: Number field uses default operator ----
  try {
    await goToDetectLog(page)

    const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')
    await addBtn.waitFor({ state: 'visible', timeout: 10000 })
    const itemLocator = await addCondition(page, addBtn)
    await selectField(page, itemLocator, '源端口')

    const condition = await page.locator('.condition-filter').evaluate(el => {
      const vm = el.__vue__
      return (vm?.conditions || []).find(c => c.target === 'src_port')
    })
    if (!condition) throw new Error('src_port condition not found')
    const item = condition.items?.[0] || {}
    if (item.oper !== 'exact') throw new Error(`src_port default oper = ${item.oper}, want exact`)
    const visibleInputs = await itemLocator.locator('.condition-filter__sub-item input:visible').count()
    if (visibleInputs === 0) throw new Error('src_port value input not rendered')
    console.log('✅ Number field default operator renders'); p++
  } catch (e) { f++; console.log(`❌ Number field default operator: ${e.message}`) }

  // ---- Test 8: ACL log filter also has dedup behavior ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')
    if (await addBtn.count() === 0) throw new Error('Add filter button not found on ACL page')

    await addBtn.click()
    const firstItem = page.locator('.condition-filter__item').first()
    const firstSelect = firstItem.locator('.el-select').first()

    // Just verify the select is present (dedup logic is component-level, tested above)
    if (await firstSelect.count() === 0) throw new Error('Field select not found on ACL filter')
    console.log('✅ ACL log filter component renders correctly'); p++
  } catch (e) { f++; console.log(`❌ ACL log filter: ${e.message}`) }

  await browser.close()
  console.log('')
  console.log(`📊 ConditionFilter Dedup: ${p} passed, ${f} failed`)
  process.exit(f > 0 ? 1 : 0)
})()
