// Integration Test: All pages navigation — real backend
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()

  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  let p = 0, f = 0

  const pages = [
    // System
    ['对接配置', '系统管理', '对接配置'],
    ['密码策略', '系统管理', '密码策略'],
    ['登录安全', '系统管理', '登录安全'],
    ['审计日志', '系统管理', '审计日志'],
    ['高亮 IP', '系统管理', '高亮 IP'],
    // Tenant
    ['租户组', '租户管理', '租户组'],
    ['全局用户', '租户管理', '全局用户'],
    ['WAF 绑定', '租户管理', 'WAF 绑定'],
    ['站点绑定', '租户管理', '站点绑定'],
    // Protection
    ['WAF 列表', '防护管理', 'WAF 列表'],
    ['站点管理', '防护管理', '站点管理'],
    ['IP 组', '防护管理', 'IP 组'],
    ['SSL 证书', '防护管理', 'SSL 证书'],
    ['攻击检测引擎', '防护管理', '攻击检测引擎'],
    ['自定义规则', '防护管理', '自定义规则'],
    // Threat
    ['攻击检测日志', '威胁监测', '攻击检测日志'],
    ['频率控制日志', '威胁监测', '频率控制日志'],
    ['日志下载', '威胁监测', '日志下载'],
    // Profile
    ['修改密码', '个人设置', '修改密码'],
    ['用户信息', '个人设置', '用户信息'],
    ['API Token', '个人设置', 'API Token'],
  ]

  for (const [name, submenu, menuItem] of pages) {
    try {
      await navTo(page, submenu, menuItem)
      // navTo/waitForContent 在"内容已可见"上判断，连续导航同组下的不同页面时
      // 会被前一页残留的同一个 .layout__content 元素直接命中，读不到新内容，需要额外等一下。
      if (name === '用户信息') await page.waitForTimeout(300)
      const content = await page.locator('.layout__content').first().textContent()
      if (!content || content.trim().length < 10) throw new Error('Page empty')
      // 用户信息曾因 <el-descriptions> 组件未注册（element-ui 版本不支持）渲染成无标签的乱码文本（spec/60）。
      // 仅判断"内容非空"测不出来，必须断言标签文案确实存在。
      if (name === '用户信息' && !content.includes('用户名')) throw new Error('字段标签缺失，疑似组件渲染异常')
      console.log(`✅ ${name}`); p++
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  console.log(`\n📊 Integration Navigation: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
