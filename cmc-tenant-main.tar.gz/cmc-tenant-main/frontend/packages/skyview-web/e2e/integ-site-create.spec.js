// Integration: site creation — tests reverse proxy 4-step wizard via API + UI
const path = require('path')
const { chromium } = require('playwright')
const { launchOptions, loginAs, navTo, waitForWafSelector, waitForTableData, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))
const { BACKEND_URL, sitePayload, ensureSites, login: apiLogin } = require(path.join(__dirname, 'test-data'))

const TARGET_URL = process.env.TARGET_URL || 'http://localhost:3000'

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  let p = 0, f = 0

  // --- Login ---
  try {
    await loginAs(page, 'admin')
    console.log('✅ Login'); p++
  } catch (e) { f++; console.log(`❌ Login: ${e.message}`); await browser.close(); process.exit(1) }

  const cookieHeader = await apiLogin(page)
  const captainInstanceId = await getActiveWafId(page, cookieHeader, { requireSiteList: true })
  console.log(`  Using captain_instance_id=${captainInstanceId}`)

  // Seed: ensure at least 2 sites exist for UI tests
  let seedSiteIds = []
  try {
    seedSiteIds = await ensureSites(page, cookieHeader, captainInstanceId, 2)
    if (seedSiteIds.length > 0) console.log(`  Seeded ${seedSiteIds.length} sites`)
  } catch (e) { console.log(`  Seed warning: ${e.message}`) }

  // --- API: Create reverse proxy site ---
  const siteName = `e2e-rp-${Date.now()}`
  let createdId = null
  try {
    const resp = await page.request.post(`${BACKEND_URL}/api/captain/site`, {
      headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
      data: sitePayload(siteName, 19090, captainInstanceId),
    })
    const data = await resp.json()
    if (data.err !== null) throw new Error(`err=${data.err}, msg=${data.msg}`)
    createdId = data.data?.id
    console.log(`✅ API: Create site (id=${createdId})`); p++
  } catch (e) { f++; console.log(`❌ API: Create site: ${e.message}`) }

  // --- API: Verify site in list ---
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/captain/site/list?captain_instance_id=${captainInstanceId}`, {
      headers: { Cookie: cookieHeader },
    })
    const data = await resp.json()
    const found = data.data?.items?.some(s => s.name === siteName)
    if (!found) throw new Error(`site "${siteName}" not found in list`)
    console.log('✅ API: Site appears in list'); p++
  } catch (e) { f++; console.log(`❌ API: Site in list: ${e.message}`) }

  // --- API: Get site detail ---
  if (createdId) {
    try {
      const resp = await page.request.get(`${BACKEND_URL}/api/captain/site/detail?captain_instance_id=${captainInstanceId}&id=${createdId}`, {
        headers: { Cookie: cookieHeader },
      })
      const data = await resp.json()
      if (data.err !== null) throw new Error(`err=${data.err}`)
      const site = data.data
      if (site.name !== siteName) throw new Error(`name=${site.name}`)
      if (!site.ports?.some(p => p.port === 19090)) throw new Error('port 19090 not found')
      if (site.backend_config?.type !== 'proxy') throw new Error('backend_config.type not proxy')
      console.log('✅ API: Site detail correct'); p++
    } catch (e) { f++; console.log(`❌ API: Site detail: ${e.message}`) }
  }

  // --- API: Bind created site to tenant group ---
  if (createdId) {
    try {
      const resp = await page.request.post(`${BACKEND_URL}/api/binding/site/create`, {
        headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
        data: { tenant_group_id: 1, captain_instance_id: captainInstanceId, site_ids: [createdId] },
      })
      const data = await resp.json()
      if (data.err !== null) throw new Error(`err=${data.err}, msg=${data.msg}`)

      const listResp = await page.request.get(`${BACKEND_URL}/api/binding/site/list?tenant_group_id=1&captain_instance_id=${captainInstanceId}&offset=0&count=1000`, {
        headers: { Cookie: cookieHeader },
      })
      const listData = await listResp.json()
      const found = (listData.data?.items || []).some(item => Number(item.site_id) === Number(createdId))
      if (!found) throw new Error(`site binding for site_id=${createdId} not found`)
      console.log('✅ API: Site binding created for deleted-site cleanup assertion'); p++
    } catch (e) { f++; console.log(`❌ API: Site binding create: ${e.message}`) }
  }

  // --- API: Delete site accepts all supported ID body formats ---
  const deleteFormatCases = [
    { label: 'ids', body: id => ({ captain_instance_id: captainInstanceId, ids: [id] }) },
    { label: 'site_ids', body: id => ({ captain_instance_id: captainInstanceId, site_ids: [id] }) },
    { label: 'id', body: id => ({ captain_instance_id: captainInstanceId, id }) },
    { label: 'ID', body: id => ({ captain_instance_id: captainInstanceId, ID: id }) },
  ]
  const formatCaseSiteIds = []
  try {
    for (const [index, testCase] of deleteFormatCases.entries()) {
      const name = `e2e-delete-format-${testCase.label}-${Date.now()}-${index}`
      const port = 23000 + Math.floor(Math.random() * 5000)
      const createResp = await page.request.post(`${BACKEND_URL}/api/captain/site`, {
        headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
        data: sitePayload(name, port, captainInstanceId),
      })
      const createData = await createResp.json()
      if (createData.err !== null || !createData.data?.id) {
        throw new Error(`${testCase.label}: create err=${createData.err}, msg=${createData.msg}`)
      }
      const siteId = createData.data.id
      formatCaseSiteIds.push(siteId)

      const bindResp = await page.request.post(`${BACKEND_URL}/api/binding/site/create`, {
        headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
        data: { tenant_group_id: 1, captain_instance_id: captainInstanceId, site_ids: [siteId] },
      })
      const bindData = await bindResp.json()
      if (bindData.err !== null) throw new Error(`${testCase.label}: bind err=${bindData.err}, msg=${bindData.msg}`)

      const deleteResp = await page.request.delete(`${BACKEND_URL}/api/captain/site`, {
        headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
        data: testCase.body(siteId),
      })
      const deleteData = await deleteResp.json()
      if (deleteData.err !== null) throw new Error(`${testCase.label}: delete err=${deleteData.err}, msg=${deleteData.msg}`)

      const listResp = await page.request.get(`${BACKEND_URL}/api/binding/site/list?tenant_group_id=1&captain_instance_id=${captainInstanceId}&offset=0&count=1000`, {
        headers: { Cookie: cookieHeader },
      })
      const listData = await listResp.json()
      const stillBound = (listData.data?.items || []).some(item => Number(item.site_id) === Number(siteId))
      if (stillBound) throw new Error(`${testCase.label}: site binding for deleted site_id=${siteId} still exists`)

      formatCaseSiteIds.splice(formatCaseSiteIds.indexOf(siteId), 1)
    }
    console.log('✅ API: Delete site ID parsing supports ids/site_ids/id/ID'); p++
  } catch (e) {
    f++
    console.log(`❌ API: Delete site ID parsing formats: ${e.message}`)
  } finally {
    for (const siteId of formatCaseSiteIds) {
      await page.request.delete(`${BACKEND_URL}/api/captain/site`, {
        headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
        data: { captain_instance_id: captainInstanceId, id__in: [siteId] },
      }).catch(() => {})
    }
  }

  // --- UI: Site management page shows site ---
  try {
    await navTo(page, '防护管理', '站点管理')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rowText = await page.locator('.el-table__body-wrapper').textContent()
    if (!rowText.includes(siteName)) throw new Error(`"${siteName}" not visible in table`)
    console.log('✅ UI: Site visible in management page'); p++
  } catch (e) { f++; console.log(`❌ UI: Site visible: ${e.message}`) }

  // --- UI: Open create dialog ---
  try {
    const createBtn = page.locator('button:has-text("新建站点")')
    if (await createBtn.count() === 0) throw new Error('新建站点 button not found')
    await createBtn.first().click()
    await page.locator('.el-dialog:visible').waitFor({ state: 'visible', timeout: 5000 })
    const dialogTitle = await page.locator('.el-dialog:visible .el-dialog__title').textContent()
    if (dialogTitle !== '新建站点') throw new Error(`dialog title="${dialogTitle}"`)
    const steps = page.locator('.el-dialog:visible .el-step')
    if (await steps.count() < 4) throw new Error(`only ${await steps.count()} steps`)
    console.log('✅ UI: Create dialog opens with 4-step wizard'); p++
  } catch (e) { f++; console.log(`❌ UI: Create dialog: ${e.message}`) }

  // Close dialog
  await page.locator('.el-dialog:visible .el-dialog__headerbtn').click().catch(() => {})
  await page.waitForTimeout(500)

  // Cleanup: only delete the site we created (not seed data)
  if (createdId) {
    try {
      const resp = await page.request.delete(`${BACKEND_URL}/api/captain/site`, {
        headers: { 'Content-Type': 'application/json', Cookie: cookieHeader },
        data: { captain_instance_id: captainInstanceId, id__in: [createdId] },
      })
      const data = await resp.json()
      if (data.err !== null) throw new Error(`err=${data.err}, msg=${data.msg}`)
      console.log('✅ API: Delete site (created by this test)'); p++

      const listResp = await page.request.get(`${BACKEND_URL}/api/binding/site/list?tenant_group_id=1&captain_instance_id=${captainInstanceId}&offset=0&count=1000`, {
        headers: { Cookie: cookieHeader },
      })
      const listData = await listResp.json()
      const stillBound = (listData.data?.items || []).some(item => Number(item.site_id) === Number(createdId))
      if (stillBound) throw new Error(`site binding for deleted site_id=${createdId} still exists`)
      console.log('✅ API: Delete site cleans local site binding'); p++
    } catch (e) { f++; console.log(`❌ API: Delete site: ${e.message}`) }
  }
  // No cleanup of seed data — it persists for other tests

  console.log(`\n📊 Site creation: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
