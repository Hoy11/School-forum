#!/usr/bin/env node
// Selects integration E2E suites from the current git diff.

const { execFileSync } = require('child_process')
const fs = require('fs')
const path = require('path')
const suites = require('./suites')
const impactMap = require('./impact-map')

const suitesByFile = new Map(suites.map(suite => [suite.file, suite]))
const E2E_DIR = 'frontend/packages/skyview-web/e2e/'

function isEnabledSuite(suite) {
  return suite && !suite.disabled
}

function collect(values, value) {
  if (!value) return
  for (const item of String(value).split(',')) {
    const trimmed = item.trim()
    if (trimmed) values.push(trimmed)
  }
}

function parseArgs(argv) {
  const args = {
    base: process.env.CI_MERGE_REQUEST_DIFF_BASE_SHA || process.env.CI_COMMIT_BEFORE_SHA || '',
    head: process.env.CI_COMMIT_SHA || 'HEAD',
    out: '',
    files: [],
    includeSmoke: false,
    json: false,
  }

  if (/^0+$/.test(args.base)) args.base = ''

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    const [flag, inlineValue] = arg.split('=', 2)
    const nextValue = inlineValue === undefined ? argv[i + 1] : inlineValue
    const consumesNext = inlineValue === undefined

    if (flag === '--base') { args.base = nextValue; if (consumesNext) i++ }
    else if (flag === '--head') { args.head = nextValue; if (consumesNext) i++ }
    else if (flag === '--out') { args.out = nextValue; if (consumesNext) i++ }
    else if (flag === '--files') { collect(args.files, nextValue); if (consumesNext) i++ }
    else if (flag === '--include-smoke') args.includeSmoke = true
    else if (flag === '--json') args.json = true
    else {
      console.error(`Unknown argument: ${arg}`)
      process.exit(2)
    }
  }

  return args
}

function gitDiffFiles(base, head) {
  const attempts = []
  if (base && head) attempts.push(['diff', '--name-only', base, head])
  if (base) attempts.push(['diff', '--name-only', `${base}...${head || 'HEAD'}`])
  if (!base) attempts.push(['diff', '--name-only', 'HEAD~1', 'HEAD'])

  for (const args of attempts) {
    try {
      const output = execFileSync('git', args, { encoding: 'utf8' })
      return output.split('\n').map(line => line.trim()).filter(Boolean)
    } catch {
      // Try the next diff form.
    }
  }

  return null
}

function escapeRegExp(char) {
  return char.replace(/[|\\{}()[\]^$+?.]/g, '\\$&')
}

function globToRegExp(pattern) {
  let out = '^'
  for (let i = 0; i < pattern.length; i++) {
    const char = pattern[i]
    if (char === '*') {
      if (pattern[i + 1] === '*') {
        out += '.*'
        i++
      } else {
        out += '[^/]*'
      }
    } else {
      out += escapeRegExp(char)
    }
  }
  out += '$'
  return new RegExp(out)
}

const compiledImpactMap = impactMap.map(entry => ({
  ...entry,
  matchers: entry.paths.map(pattern => globToRegExp(pattern)),
}))

function changedIntegrationSpec(file) {
  if (!file.startsWith(E2E_DIR)) return null
  const specFile = path.basename(file)
  return specFile.endsWith('.spec.js') && suitesByFile.has(specFile) ? specFile : null
}

function isE2EInfraChange(file) {
  if (file === '.gitlab-ci.yml') return true
  if (file === 'frontend/packages/skyview-web/package.json') return true
  if (!file.startsWith(E2E_DIR)) return false
  return changedIntegrationSpec(file) === null
}

function isProductCodeChange(file) {
  if (file.startsWith('spec/') || file.startsWith('requirements/')) return false
  if (file.endsWith('.md') || file.endsWith('.txt')) return false
  if (file.includes('/__tests__/') || file.endsWith('_test.go')) return false
  if (changedIntegrationSpec(file)) return false
  if (isE2EInfraChange(file)) return false
  return true
}

function addSuite(selected, file) {
  const suite = suitesByFile.get(file)
  if (!suite) {
    throw new Error(`Impact map references unregistered suite: ${file}`)
  }
  if (suite.disabled) return
  selected.add(file)
}

function addLayer(selected, layer) {
  for (const suite of suites) {
    if (!isEnabledSuite(suite)) continue
    if (suite.layers.includes(layer)) selected.add(suite.file)
  }
}

function selectFromFiles(changedFiles, includeSmoke) {
  const selected = new Set()
  const matchedModules = new Set()
  const matchedRules = []
  const changedE2ESuites = []

  for (const file of changedFiles) {
    const changedSpec = changedIntegrationSpec(file)
    if (!changedSpec) continue
    addSuite(selected, changedSpec)
    changedE2ESuites.push(changedSpec)
    matchedRules.push({ file, module: 'changed-e2e-suite', suite: changedSpec })
  }

  for (const file of changedFiles) {
    for (const entry of compiledImpactMap) {
      if (entry.matchers.some(matcher => matcher.test(file))) {
        matchedModules.add(entry.module)
        matchedRules.push({ file, module: entry.module })
        for (const suite of entry.suites) addSuite(selected, suite)
      }
    }
  }

  for (const suite of suites) {
    if (!isEnabledSuite(suite)) continue
    if (!suite.critical) continue
    if (suite.modules.some(module => matchedModules.has(module))) selected.add(suite.file)
  }

  if (includeSmoke) addLayer(selected, 'smoke')

  const hasProductCodeChanges = changedFiles.some(isProductCodeChange)
  let fallback = null
  if (selected.size === 0 && hasProductCodeChanges) {
    fallback = 'No impact-map rule matched code changes; selected smoke + critical suites.'
    addLayer(selected, 'smoke')
    addLayer(selected, 'critical')
  }

  return {
    changed_files: changedFiles,
    changed_modules: [...matchedModules].sort(),
    changed_e2e_suites: [...new Set(changedE2ESuites)].sort(),
    matched_rules: matchedRules,
    fallback,
    suites: [...selected].sort(),
  }
}

function printHuman(result) {
  console.log('Changed files:')
  for (const file of result.changed_files) console.log(`  - ${file}`)

  console.log('\nChanged modules:')
  if (result.changed_modules.length === 0) console.log('  - (none)')
  for (const module of result.changed_modules) console.log(`  - ${module}`)

  if (result.changed_e2e_suites && result.changed_e2e_suites.length > 0) {
    console.log('\nChanged E2E suites:')
    for (const file of result.changed_e2e_suites) console.log(`  - ${file}`)
  }

  if (result.fallback) console.log(`\nFallback: ${result.fallback}`)

  console.log('\nSelected E2E suites:')
  if (result.suites.length === 0) console.log('  - (none)')
  for (const file of result.suites) {
    const suite = suitesByFile.get(file)
    console.log(`  - ${file} (${suite.layers.join(', ')})`)
  }
}

;(function main() {
  const args = parseArgs(process.argv.slice(2))
  const changedFiles = args.files.length > 0 ? args.files : gitDiffFiles(args.base, args.head)

  if (!changedFiles) {
    const result = {
      changed_files: [],
      changed_modules: [],
      changed_e2e_suites: [],
      matched_rules: [],
      fallback: 'Could not determine git diff; selected smoke + critical suites.',
      suites: suites.filter(suite => isEnabledSuite(suite) && (suite.layers.includes('smoke') || suite.layers.includes('critical'))).map(suite => suite.file).sort(),
    }
    writeResult(args, result)
    return
  }

  const result = selectFromFiles(changedFiles, args.includeSmoke)
  writeResult(args, result)
})()

function writeResult(args, result) {
  const payload = JSON.stringify(result, null, 2)
  if (args.out) {
    fs.writeFileSync(path.resolve(process.cwd(), args.out), `${payload}\n`)
  }
  if (args.json) {
    console.log(payload)
  } else {
    printHuman(result)
    if (args.out) console.log(`\nWrote selection to ${args.out}`)
  }
}
