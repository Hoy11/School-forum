// Integration: site detail main flow — one created site covers detail tabs.
const path = require('path')
const { chromium } = require('playwright')
const { loginAs, waitForLaunchLoaderGone, launchOptions, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))
const { sitePayload, cleanupSites } = require(path.join(__dirname, 'test-data'))

const TARGET_URL = process.env.TARGET_URL || 'http://localhost:3000'
let captainInstanceId

function findRowByLabel(page, label) {
  return page.locator('.editable-row:visible').filter({ hasText: new RegExp(`^${label}`) })
}

function apiGet(page, path) {
  return page.evaluate(async (p) => {
    const r = await fetch(p)
    return r.json()
  }, path)
}

function apiPost(page, path, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) })
    return r.json()
  }, [path, body])
}

function apiDelete(page, path, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) })
    return r.json()
  }, [path, body])
}

async function waitForDropdownOptions(page, timeout = 5000) {
  await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').first()
    .waitFor({ state: 'visible', timeout })
}

async function openSiteDetail(page, siteId) {
  await page.goto(`${TARGET_URL}/protection/sites/detail?id=${siteId}&waf=${captainInstanceId}`, { waitUntil: 'domcontentloaded' })
  await waitForLaunchLoaderGone(page, 30000).catch(() => {})
  await page.locator('.el-page-header, .layout__content').first().waitFor({ state: 'visible', timeout: 15000 })
}

async function openTab(page, siteId, tabText) {
  await openSiteDetail(page, siteId)
  const tab = page.locator('.el-tabs__item').filter({ hasText: tabText }).first()
  await tab.waitFor({ state: 'visible', timeout: 15000 })
  await tab.click({ force: true })
  await page.waitForTimeout(600)
}

async function openBaseConfig(page, siteId, markerText) {
  await openTab(page, siteId, '基础配置')
  await page.waitForFunction(
    (text) => document.body.innerText.includes(text) &&
      Array.from(document.querySelectorAll('.editable-row')).some(node => node.offsetParent !== null),
    markerText,
    { timeout: 15000 }
  )
}

async function cancelInline(page, label) {
  const row = findRowByLabel(page, label)
  const cancel = row.locator('button:has-text("取消")')
  if ((await cancel.count()) > 0) await cancel.first().click().catch(() => {})
  await row.locator('button:has-text("确定"):visible').first()
    .waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
}

async function openSourceIpDialog(page) {
  const row = findRowByLabel(page, '源 IP 获取方式')
  await row.locator('.el-icon-edit').first().click()
  const dialog = page.locator('.el-dialog:visible').first()
  await dialog.waitFor({ state: 'visible', timeout: 5000 })
  return dialog
}

async function closeDialog(page) {
  const cancelBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("取消")').first()
  await cancelBtn.click().catch(() =>
    page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click().catch(() => {}))
  await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
}

async function saveDialog(page) {
  const confirmBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("确定")').first()
  await confirmBtn.click()
  await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 10000 })
}

async function getSite(page, siteId) {
  const resp = await apiGet(page, `/api/captain/site/detail?id=${siteId}&captain_instance_id=${captainInstanceId}`)
  if (resp.err !== null) throw new Error(resp.msg || 'site detail failed')
  return resp.data
}

async function findAssignablePolicyId(page) {
  const resp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}`)
  const items = resp.data?.items || resp.data || []
  return items[0]?.id || null
}

async function createBoundSite(page) {
  const policyId = await findAssignablePolicyId(page).catch(() => null)
  const name = `__e2e_site_detail_${Date.now()}`
  const port = 44000 + Math.floor(Math.random() * 10000)
  const payload = sitePayload(name, port, captainInstanceId)
  if (policyId) payload.policy_group = policyId

  const createResp = await apiPost(page, '/api/captain/site', { ...payload, captain_instance_id: captainInstanceId })
  if (createResp.err !== null || !createResp.data?.id) {
    throw new Error(`Create site failed: ${createResp.msg || createResp.err}`)
  }

  const siteId = createResp.data.id
  await apiPost(page, '/api/binding/site/create', {
    tenant_group_id: 1,
    captain_instance_id: captainInstanceId,
    site_ids: [siteId],
  }).catch(() => {})

  return { siteId, policyId }
}

async function createSourceIpGroup(page) {
  const name = `__e2e_source_ip_group_${Date.now()}`
  const createResp = await apiPost(page, '/api/captain/ip-group/create', {
    name,
    comment: 'source ip dialog e2e',
    captain_instance_id: captainInstanceId,
  })
  if (createResp.err !== null) throw new Error(`Create IP group failed: ${createResp.msg || createResp.err}`)
  let groupId = createResp.data?.id || null
  if (!groupId) {
    const listResp = await apiGet(page, `/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=1000`)
    groupId = (listResp.data?.items || []).find(item => item.name === name)?.id || null
  }
  if (!groupId) throw new Error('Created IP group not found')
  return { id: groupId, name }
}

function buildSiteCondition(siteId) {
  return { target: 'site_id', items: [{ oper: '=', value: siteId }] }
}

function getRuleSiteIds(rule) {
  const websites = Array.isArray(rule.websites) ? rule.websites : []
  const website = rule.website ? [rule.website] : []
  return websites.concat(website)
}

async function openCustomRuleTab(page, siteId) {
  await openTab(page, siteId, '自定义规则')
  await page.waitForFunction(
    () => document.body.innerText.includes('自定义规则'),
    null,
    { timeout: 10000 }
  )
}

async function waitForRuleRow(page, siteId, ruleText, timeout = 30000) {
  const deadline = Date.now() + timeout
  let lastStatus = 'not loaded'
  while (Date.now() < deadline) {
    const row = page.locator('.el-table__row').filter({ hasText: ruleText })
    if ((await row.count()) > 0) return row

    const conditions = encodeURIComponent(JSON.stringify([buildSiteCondition(siteId)]))
    const resp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=200&is_global=false&rule_type=1&conditions=${conditions}`).catch(err => ({ err: err.message }))
    const items = resp.data?.items || []
    const matched = items.filter(rule => getRuleSiteIds(rule).map(Number).includes(Number(siteId))).length
    lastStatus = `api err=${resp.err}, total=${resp.data?.total}, matched=${matched}`
    if (matched > 0) await openCustomRuleTab(page, siteId)
    await page.waitForTimeout(1000)
  }
  throw new Error(`Rule row not loaded: ${lastStatus}`)
}

async function cleanupRule(page, ruleId) {
  if (!ruleId) return
  await apiDelete(page, '/api/captain/policy-rule/unbind', {
    captain_instance_id: captainInstanceId,
    ids: [ruleId],
  }).catch(() => {})
  await apiDelete(page, '/api/captain/policy-rule/delete', {
    captain_instance_id: captainInstanceId,
    id__in: [ruleId],
  }).catch(() => {})
}

async function cleanupIPGroup(page, groupId) {
  if (!groupId) return
  await apiDelete(page, '/api/captain/ip-group/delete', {
    captain_instance_id: captainInstanceId,
    id: groupId,
  }).catch(() => {})
}

async function selectSourceType(page, dialog, label) {
  const select = dialog.locator('.el-select').first()
  await select.click()
  await waitForDropdownOptions(page)
  await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').filter({ hasText: label }).click()
}

async function sourceRowsSnapshot(dialog) {
  return dialog.locator('.source-ip-source-row').evaluateAll(rows => rows.map((row, index) => {
    const editButton = row.querySelector('.el-icon-edit')?.closest('button')
    return {
      index,
      text: (row.textContent || '').trim(),
      hasDelete: !!row.querySelector('.el-icon-delete'),
      editDisabled: editButton ? editButton.disabled : null,
    }
  }))
}

async function sourceDialogSnapshot(dialog) {
  return {
    rows: await sourceRowsSnapshot(dialog).catch(err => [{ error: err.message }]),
    body: await dialog.locator('.el-dialog__body').innerText().catch(err => `body unavailable: ${err.message}`),
  }
}

async function waitForSourceLocator(dialog, locator, step, timeout = 10000) {
  await locator.waitFor({ state: 'visible', timeout }).catch(async () => {
    throw new Error(`${step} not visible: ${JSON.stringify(await sourceDialogSnapshot(dialog))}`)
  })
}

async function sourceRowByTag(dialog, text, step) {
  const row = dialog.locator('.source-ip-source-row').filter({ hasText: text }).first()
  await row.waitFor({ state: 'visible', timeout: 10000 }).catch(async () => {
    throw new Error(`${step} source row not found: ${JSON.stringify(await sourceDialogSnapshot(dialog))}`)
  })
  return row
}

async function assertSocketLocked(dialog) {
  const rows = await sourceRowsSnapshot(dialog)
  const socket = rows.find(row => row.text === 'Socket')
  if (!socket) throw new Error(`Socket source row missing: ${JSON.stringify(rows)}`)
  if (socket.editDisabled !== true) throw new Error(`Socket edit button should be disabled: ${JSON.stringify(socket)}`)
  if (socket.hasDelete) throw new Error(`Socket delete button should be hidden: ${JSON.stringify(socket)}`)
}

async function clickSourceRowIcon(row, iconClass) {
  await row.locator(`.${iconClass}`).locator('xpath=ancestor::button').first().click()
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400) {
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
    }
  })

  let p = 0, f = 0
  let siteId = 0
  let policyId = null
  let ruleId = 0
  let sourceIpGroup = null

  try {
    await loginAs(page, 'admin')
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    captainInstanceId = await getActiveWafId(page, cookieHeader, { requireSiteList: true })
    console.log(`  Using captain_instance_id=${captainInstanceId}`)
    ;({ siteId, policyId } = await createBoundSite(page))
    sourceIpGroup = await createSourceIpGroup(page)
    console.log(`  Prepared site detail fixture (site=${siteId}, policy=${policyId || 'none'})`)
  } catch (e) {
    console.log(`❌ Setup: ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  try {
    await openBaseConfig(page, siteId, '用户识别方式')
    const headers = await page.locator('.el-card__header').allTextContents()
    if (!headers.some(header => header.includes('用户识别方式'))) throw new Error('用户识别方式 card missing')

    const row = findRowByLabel(page, '用户识别方式')
    await row.locator('.el-icon-edit').first().click()
    const select = row.locator('.el-select:visible').first()
    await select.click()
    await waitForDropdownOptions(page)
    const options = await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').allTextContents()
    if (!options.some(option => option.includes('WAF 用户系统'))) throw new Error('WAF 用户系统 option missing')
    await page.keyboard.press('Escape')
    await cancelInline(page, '用户识别方式')
    console.log('✅ Site detail: 用户识别方式面板与选项'); p++
  } catch (e) { f++; console.log(`❌ Site detail: 用户识别方式: ${e.message}`); await cancelInline(page, '用户识别方式').catch(() => {}) }

  try {
    await openBaseConfig(page, siteId, '源 IP 获取方式')
    const dialog = await openSourceIpDialog(page)

    await selectSourceType(page, dialog, 'X-Forwarded-For 左起')
    await dialog.locator('button:has-text("添加")').click()
    await sourceRowByTag(dialog, 'X-Forwarded-For 左起第1层', 'Add XFF level 1')

    await assertSocketLocked(dialog)

    const xffRow = await sourceRowByTag(dialog, 'X-Forwarded-For 左起第1层', 'Find XFF level 1 for edit')
    await clickSourceRowIcon(xffRow, 'el-icon-edit')
    if (!(await dialog.locator('.el-select input').first().isDisabled())) {
      throw new Error(`Editing source type select should be disabled: ${JSON.stringify(await sourceDialogSnapshot(dialog))}`)
    }
    await waitForSourceLocator(dialog, dialog.locator('.el-dialog__body button:has-text("保存")'), 'XFF edit save button')
    await waitForSourceLocator(dialog, dialog.locator('.el-dialog__body button:has-text("取消")'), 'XFF edit cancel button')
    await dialog.locator('.el-input-number input:visible').first().fill('2')
    await dialog.locator('.el-dialog__body button:has-text("保存")').click()
    await sourceRowByTag(dialog, 'X-Forwarded-For 左起第2层', 'Save XFF level 2')

    const xffEditedRow = await sourceRowByTag(dialog, 'X-Forwarded-For 左起第2层', 'Find XFF level 2 for cancel')
    await clickSourceRowIcon(xffEditedRow, 'el-icon-edit')
    await dialog.locator('.el-input-number input:visible').first().fill('3')
    await dialog.locator('.el-dialog__body button:has-text("取消")').click()
    await waitForSourceLocator(dialog, dialog.locator('.el-dialog__body').filter({ hasText: '添加源 IP 获取方式' }), 'Add source title after cancel XFF edit')
    if (await dialog.locator('.el-select input').first().isDisabled()) {
      throw new Error(`Source type select should be enabled after cancel: ${JSON.stringify(await sourceDialogSnapshot(dialog))}`)
    }
    if ((await dialog.locator('.el-tag').filter({ hasText: 'X-Forwarded-For 左起第3层' }).count()) > 0) {
      throw new Error('Cancel edit should not apply XFF level 3')
    }

    await selectSourceType(page, dialog, 'HTTP 头')
    const headerInput = dialog.locator('input[placeholder="X-Real-IP"]')
    await waitForSourceLocator(dialog, headerInput, 'Custom header input')
    await headerInput.fill('X-E2E-Detail-IP')
    await dialog.locator('button:has-text("添加")').click()
    await sourceRowByTag(dialog, 'X-E2E-Detail-IP', 'Add custom header')

    await selectSourceType(page, dialog, '最后一层非信任 IP')
    await dialog.locator('.el-radio').filter({ hasText: '选择 IP 组' }).click()
    const groupSelect = dialog.locator('.el-select:visible').last()
    await groupSelect.click()
    await waitForDropdownOptions(page)
    await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').filter({ hasText: sourceIpGroup.name }).click()
    await page.keyboard.press('Escape')
    await dialog.locator('button:has-text("添加")').click()
    await sourceRowByTag(dialog, '最后一层非信任代理IP', 'Add rightmost non-proxy source')
    await saveDialog(page)

    const site = await getSite(page, siteId)
    const sources = site.detector_ip_source || []
    if (!sources.includes('X-E2E-Detail-IP')) throw new Error(`custom header not saved: ${sources.join(',')}`)
    if (sources.includes('custom:X-E2E-Detail-IP')) throw new Error('custom header saved with custom: prefix')
    if (!sources.includes('X-Forwarded-For:2')) throw new Error(`edited XFF level not saved: ${sources.join(',')}`)
    if (sources.includes('X-Forwarded-For:3')) throw new Error('cancelled XFF level was saved')
    if (!sources.includes('rightmost_non_proxy_ip')) throw new Error(`rightmost non-proxy source not saved: ${sources.join(',')}`)
    if (!(site.proxy_ip_groups || []).map(Number).includes(Number(sourceIpGroup.id))) {
      throw new Error(`proxy_ip_groups missing ${sourceIpGroup.id}: ${(site.proxy_ip_groups || []).join(',')}`)
    }
    console.log('✅ Site detail: 源 IP 编辑态、Socket保护与IP组下拉'); p++
  } catch (e) { f++; console.log(`❌ Site detail: 源 IP: ${e.stack || e.message}`); await closeDialog(page).catch(() => {}) }

  try {
    await openTab(page, siteId, 'Cookie')
    const card = page.locator('.el-card').filter({ hasText: 'Cookie 防护策略' })
    await card.waitFor({ state: 'visible', timeout: 8000 })
    await card.locator('div').filter({ hasText: /防护状态/ }).first().waitFor({ state: 'visible', timeout: 5000 })
    await card.locator('button').filter({ hasText: '编辑' }).first().click()
    await card.locator('.el-switch').first().waitFor({ state: 'visible', timeout: 3000 })
    await card.locator('button').filter({ hasText: '保存' }).first().waitFor({ state: 'visible', timeout: 3000 })
    await card.locator('button').filter({ hasText: '取消' }).first().click()
    await card.locator('button').filter({ hasText: '编辑' }).first().waitFor({ state: 'visible', timeout: 3000 })
    console.log('✅ Site detail: Cookie 防护读写态切换'); p++
  } catch (e) { f++; console.log(`❌ Site detail: Cookie 防护: ${e.message}`) }

  try {
    await openTab(page, siteId, '语义引擎防护')
    const policyCard = page.locator('.el-card').filter({ hasText: '攻击防护策略' })
    await policyCard.first().waitFor({ state: 'visible', timeout: 10000 })
    if (policyId) {
      const deepDetection = page.locator('.el-card').filter({ hasText: '深度检测' })
      await deepDetection.first().waitFor({ state: 'visible', timeout: 10000 })
    } else {
      const warning = page.locator('.el-alert--warning').filter({ hasText: '不使用防护策略' })
      await warning.first().waitFor({ state: 'visible', timeout: 10000 })
    }
    console.log('✅ Site detail: 语义引擎策略面板'); p++
  } catch (e) { f++; console.log(`❌ Site detail: 语义引擎: ${e.message}`) }

  try {
    await openCustomRuleTab(page, siteId)
    await page.locator('button').filter({ hasText: '添加自定义规则' }).first()
      .waitFor({ state: 'visible', timeout: 10000 })

    const ruleResp = await apiPost(page, '/api/captain/policy-rule/create', {
      captain_instance_id: captainInstanceId,
      is_global: false,
      is_enabled: true,
      action: 'dry_run',
      comment: `E2E site detail rule ${Date.now()}`,
      risk_level: 0,
      pattern: { $AND: [{ remote_addr: { values: ['10.20.30.40'], op: 'ipmatch' }, decode_methods: [] }] },
      websites: [siteId],
      attack_type: -1,
      log_option: 'Persistence',
      cron_config: { type: 'all' },
      expire_time: 0,
    })
    if (ruleResp.err !== null || !ruleResp.data?.id) throw new Error(`Create rule failed: ${ruleResp.msg || ruleResp.err}`)
    ruleId = ruleResp.data.id
    await openCustomRuleTab(page, siteId)
    const row = await waitForRuleRow(page, siteId, 'E2E site detail rule')
    await row.locator('.el-tag').filter({ hasText: '观察' }).first().waitFor({ state: 'visible', timeout: 5000 })
    console.log('✅ Site detail: 自定义规则列表与动作标签'); p++
  } catch (e) { f++; console.log(`❌ Site detail: 自定义规则: ${e.message}`) }

  await cleanupRule(page, ruleId)
  if (siteId) {
    const cookieHeader = await page.context().cookies()
      .then(cookies => cookies.map(cookie => `${cookie.name}=${cookie.value}`).join('; '))
    await cleanupSites(page, cookieHeader, [siteId], captainInstanceId).catch(() => {})
  }
  await cleanupIPGroup(page, sourceIpGroup?.id)

  console.log(`\n📊 Site detail: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
