// Integration: SSL cert write protection — system_cert + in_use + shared + external ref
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND = TARGET_URL.replace(':3000', ':8080')

// API helpers (browser-context fetch with auto cookies)
async function apiGet(page, urlPath) {
  return page.evaluate(async (p) => {
    const r = await fetch(p, { credentials: 'include' })
    return r.json()
  }, urlPath)
}

async function apiPut(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return { status: r.status, body: await r.json() }
  }, [urlPath, body])
}

async function apiDelete(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return { status: r.status, body: await r.json() }
  }, [urlPath, body])
}

// Check if style contains gray color (#ccc or rgb(204,...))
function isGrayColor(style) {
  if (!style) return false
  return style.includes('#ccc') || style.includes('rgb(204') || style.includes('rgb(204, 204, 204)')
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  let p = 0, f = 0
  let captainInstanceId

  // --- Seed: login as admin ---
  await loginAs(page, 'admin')

  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    captainInstanceId = await getActiveWafId(page, cookieHeader)
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)
    console.log(`  Using captain_instance_id=${captainInstanceId}`)
  } catch (e) {
    console.log(`❌ WAF selection: ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  // ═══════════════════════════════════════════
  // Test 1: List injection — binding_count field
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    if (certs.length === 0) throw new Error('No certs returned')

    const sample = certs[0]
    if (!('binding_count' in sample)) throw new Error('Missing binding_count field')
    console.log(`✅ [列表注入] binding_count 字段存在`); p++
  } catch (e) { f++; console.log(`❌ [列表注入] 保护字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 2: Detail injection — binding_count + is_mgt_api_cert
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    if (certs.length === 0) throw new Error('No certs available')

    const firstCert = certs[0]
    const detailResp = await apiGet(page, `/api/captain/cert/detail?id=${firstCert.id}&captain_instance_id=${captainInstanceId}`)
    const detail = detailResp.data
    if (!detail) throw new Error('No detail data returned')

    if (!('binding_count' in detail)) throw new Error('Missing binding_count in detail')
    console.log(`✅ [详情注入] binding_count 字段存在，is_mgt_api_cert=${detail.is_mgt_api_cert}`); p++
  } catch (e) { f++; console.log(`❌ [详情注入] 保护字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 3: System cert edit — admin succeeds, tenant_admin blocked
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const systemCert = certs.find(c => c.is_mgt_api_cert === true || c.is_system_cert === true)

    if (systemCert) {
      // Admin: edit system cert should succeed (backend skips system_cert for admin)
      const adminResp = await apiPut(page, '/api/captain/cert/update', {
        id: systemCert.id,
        captain_instance_id: captainInstanceId,
        name: systemCert.name, // restore original name
      })
      if (adminResp.body?.err === 'system_cert') throw new Error('Admin should bypass system_cert edit check, got err=system_cert')
      console.log(`✅ [系统证书] Admin CertUpdate 成功（豁免 system_cert）`); p++

      // Tenant: edit system cert should be blocked
      try { await loginAs(page, 'tenant_admin') } catch { /* non-fatal */ }
      await waitForWafSelector(page)
      const tenantResp = await apiPut(page, '/api/captain/cert/update', {
        id: systemCert.id,
        captain_instance_id: captainInstanceId,
        name: 'test-system-cert-edit',
      })
      if (tenantResp.body?.err !== 'system_cert' && tenantResp.body?.err !== 'forbidden') throw new Error(`Tenant should be blocked, got err=${tenantResp.body?.err}, status=${tenantResp.status}`)
      console.log(`✅ [系统证书] Tenant CertUpdate 返回 ${tenantResp.body?.err} 错误`); p++

      // Re-login as admin
      try { await loginAs(page, 'admin') } catch { /* non-fatal */ }
      await waitForWafSelector(page)
    } else {
      console.log('⚠️ 无系统证书，跳过 CertUpdate 保护测试'); p++; p++
    }
  } catch (e) { f++; console.log(`❌ [系统证书] CertUpdate 保护: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 4: System cert delete blocked
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const systemCert = certs.find(c => c.is_mgt_api_cert === true || c.is_system_cert === true)

    if (systemCert) {
      const resp = await apiDelete(page, '/api/captain/cert/delete', {
        id: systemCert.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'system_cert') throw new Error(`Expected err=system_cert, got err=${resp.body?.err}`)
      console.log(`✅ [系统证书] CertDelete 返回 system_cert 错误`); p++
    } else {
      console.log('⚠️ 无系统证书，跳过 CertDelete 保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [系统证书] CertDelete 保护: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 5: In-use cert delete blocked (cert with websites)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const inUseCert = certs.find(c => (c.websites?.length ?? 0) > 0 && !c.is_mgt_api_cert && !c.is_system_cert)

    if (inUseCert) {
      const resp = await apiDelete(page, '/api/captain/cert/delete', {
        id: inUseCert.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Expected err=in_use, got err=${resp.body?.err}`)
      if (!resp.body?.msg || !resp.body.msg.includes('站点')) throw new Error(`msg should mention sites: ${resp.body?.msg}`)
      console.log(`✅ [运行时保护] 删除使用中证书返回 in_use 错误 (msg=${resp.body.msg})`); p++
    } else {
      console.log('⚠️ 无使用中非系统证书，跳过 in_use 保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [运行时保护] 删除使用中证书: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 6: In-use protection only blocks delete, not edit
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const inUseCert = certs.find(c => (c.websites?.length ?? 0) > 0 && !c.is_mgt_api_cert && !c.is_system_cert && (c.binding_count ?? 0) <= 1)

    if (inUseCert) {
      const resp = await apiPut(page, '/api/captain/cert/update', {
        id: inUseCert.id,
        captain_instance_id: captainInstanceId,
        name: inUseCert.name,
      })
      if (resp.body?.err === 'in_use') throw new Error('Edit should NOT be blocked by in_use protection')
      console.log(`✅ [运行时保护] 使用中证书仍可编辑（in_use 仅阻止删除）`); p++
    } else {
      console.log('⚠️ 无使用中非共享非系统证书，跳过编辑测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [运行时保护] 使用中证书编辑: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 7: Shared cert edit — admin succeeds, tenant_admin blocked
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const sharedCert = certs.find(c => (c.binding_count ?? 0) > 1)

    if (sharedCert) {
      // Admin: edit shared cert should succeed (backend skips shared for admin)
      const adminResp = await apiPut(page, '/api/captain/cert/update', {
        id: sharedCert.id,
        captain_instance_id: captainInstanceId,
        name: sharedCert.name, // restore original name
      })
      if (adminResp.body?.err === 'shared') throw new Error('Admin should bypass shared edit check')
      console.log(`✅ [共享保护] Admin CertUpdate 成功（豁免 shared）`); p++

      // Tenant: edit shared cert should be blocked
      try { await loginAs(page, 'tenant_admin') } catch { /* non-fatal */ }
      await waitForWafSelector(page)
      const tenantResp = await apiPut(page, '/api/captain/cert/update', {
        id: sharedCert.id,
        captain_instance_id: captainInstanceId,
        name: 'test-shared-edit',
      })
      if (tenantResp.body?.err !== 'shared' && tenantResp.body?.err !== 'forbidden') throw new Error(`Tenant should be blocked, got err=${tenantResp.body?.err}`)
      console.log(`✅ [共享保护] Tenant CertUpdate 返回 ${tenantResp.body?.err} 错误`); p++

      // Re-login as admin
      try { await loginAs(page, 'admin') } catch { /* non-fatal */ }
      await waitForWafSelector(page)
    } else {
      console.log('⚠️ 无共享证书(binding_count>1)，跳过共享编辑测试'); p++; p++
    }
  } catch (e) { f++; console.log(`❌ [共享保护] CertUpdate: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 8: Shared cert delete — admin succeeds if not in_use; in_use takes priority
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    // Prefer cert that is shared but NOT in use (websites empty) — admin should succeed
    const sharedNotInUse = certs.find(c => (c.binding_count ?? 0) > 1 && (c.websites?.length ?? 0) === 0)
    const sharedAny = certs.find(c => (c.binding_count ?? 0) > 1)

    if (sharedNotInUse) {
      const resp = await apiDelete(page, '/api/captain/cert/delete', {
        id: sharedNotInUse.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err === 'shared') throw new Error(`Admin should bypass shared delete, got err=shared`)
      console.log(`✅ [共享保护] Admin CertDelete 共享+无引用证书成功（豁免 shared）`); p++
    } else if (sharedAny) {
      // Shared cert is also in-use — in_use hard limit for all roles
      const resp = await apiDelete(page, '/api/captain/cert/delete', {
        id: sharedAny.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Expected err=in_use (hard limit for all roles), got err=${resp.body?.err}`)
      console.log(`✅ [共享保护] 共享+使用中证书删除返回 in_use（所有角色硬限制）`); p++
    } else {
      console.log('⚠️ 无共享证书，跳过共享删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [共享保护] CertDelete: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 9: External ref edit — admin succeeds, tenant_admin blocked
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const extRefCert = certs.find(c => c.has_external_ref === true && !c.is_system_cert && (c.binding_count ?? 0) <= 1)

    if (extRefCert) {
      // Admin: edit should succeed (backend skips external ref for admin)
      const adminResp = await apiPut(page, '/api/captain/cert/update', {
        id: extRefCert.id,
        captain_instance_id: captainInstanceId,
        name: extRefCert.name, // restore original name
      })
      if (adminResp.body?.err === 'in_use') throw new Error('Admin should bypass external ref edit check')
      console.log(`✅ [外部引用] Admin CertUpdate 成功（豁免 external ref）`); p++

      // Tenant: edit should be blocked
      try { await loginAs(page, 'tenant_admin') } catch { /* non-fatal */ }
      await waitForWafSelector(page)
      const tenantResp = await apiPut(page, '/api/captain/cert/update', {
        id: extRefCert.id,
        captain_instance_id: captainInstanceId,
        name: 'test-extref-edit',
      })
      if (tenantResp.body?.err !== 'in_use' && tenantResp.body?.err !== 'forbidden') throw new Error(`Tenant should be blocked, got err=${tenantResp.body?.err}`)
      console.log(`✅ [外部引用] Tenant CertUpdate 返回 ${tenantResp.body?.err} 错误`); p++

      // Re-login as admin
      try { await loginAs(page, 'admin') } catch { /* non-fatal */ }
      await waitForWafSelector(page)
    } else {
      console.log('⚠️ 无外部引用证书(has_external_ref=true)，跳过测试'); p++; p++
    }
  } catch (e) { f++; console.log(`❌ [外部引用] CertUpdate 保护: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 10: UI — system cert delete button grayed + tooltip
  // Locate by "系统使用中" usage text visible in the table, not by API name match.
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const systemRow = page.locator('.el-table__row').filter({ hasText: '系统使用中' }).first()

    if (await systemRow.count() > 0) {
      const deleteBtn = systemRow.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (!isGrayColor(btnStyle)) throw new Error(`System cert delete button not grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message').filter({ hasText: '系统管理接口证书' }).count()
        if (warningVisible === 0) throw new Error('No warning toast for system cert delete')
        console.log(`✅ [UI] 系统证书删除按钮置灰+警告提示`); p++
      } else {
        console.log('⚠️ 系统证书行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ UI 当前页无"系统使用中"证书行，跳过UI系统证书删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 系统证书删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 11: UI — in-use cert delete button grayed + tooltip
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const inUseCert = certs.find(c => (c.websites?.length ?? 0) > 0 && !c.is_mgt_api_cert && !c.is_system_cert)

    if (inUseCert) {
      const row = page.locator('.el-table__row').filter({ hasText: inUseCert.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (!isGrayColor(btnStyle)) throw new Error(`In-use cert delete button not grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message').filter({ hasText: '站点使用' }).count()
        if (warningVisible === 0) throw new Error('No warning toast for in-use cert delete')
        console.log(`✅ [UI] 使用中证书删除按钮置灰+警告提示`); p++
      } else {
        console.log('⚠️ 使用中证书行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无使用中非系统证书，跳过UI使用中删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 使用中证书删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 12: UI — admin detail page system cert edit icon blue + confirm; tenant grayed
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const systemCert = certs.find(c => c.is_mgt_api_cert === true || c.is_system_cert === true)

    if (systemCert) {
      const row = page.locator('.el-table__row').filter({ hasText: systemCert.name }).first()
      await row.locator('.el-icon-view').first().click()
      await page.waitForTimeout(2000)

      const editIcons = page.locator('.el-icon-edit')
      if ((await editIcons.count()) > 0) {
        const firstIcon = editIcons.first()
        const iconStyle = await firstIcon.getAttribute('style')

        // Admin: icon should be blue (#409EFF), not grayed
        if (isGrayColor(iconStyle)) throw new Error(`Admin system cert edit icon should be blue, style=${iconStyle}`)
        if (iconStyle.includes('not-allowed')) throw new Error(`Admin system cert edit cursor should be pointer, style=${iconStyle}`)
        console.log(`✅ [UI] Admin 详情页系统证书编辑图标蓝色可点击`); p++
      } else {
        console.log('⚠️ 系统证书详情页无编辑图标'); p++
      }

      // Tenant: icon should be grayed
      try { await loginAs(page, 'tenant_admin') } catch { /* non-fatal */ }
      await navTo(page, '防护管理', 'SSL 证书')
      await waitForWafSelector(page)
      await waitForTableData(page)

      try {
        // Check tenant list has system cert
        const tListResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
        const tCerts = tListResp.data?.items || []
        const tSystemCert = tCerts.find(c => c.is_mgt_api_cert === true || c.is_system_cert === true)
        if (tSystemCert) {
          const tRow = page.locator('.el-table__row').filter({ hasText: tSystemCert.name }).first()
          await tRow.locator('.el-icon-view').first().click()
          await page.waitForTimeout(2000)

          const tEditIcons = page.locator('.el-icon-edit')
          if ((await tEditIcons.count()) > 0) {
            const tIconStyle = await tEditIcons.first().getAttribute('style')
            if (!isGrayColor(tIconStyle)) throw new Error(`Tenant system cert edit icon should be grayed, style=${tIconStyle}`)
            if (!tIconStyle.includes('not-allowed')) throw new Error(`Tenant cursor should be not-allowed, style=${tIconStyle}`)
            console.log(`✅ [UI] Tenant 详情页系统证书编辑图标置灰`); p++
          } else {
            console.log('⚠️ Tenant 系统证书详情页无编辑图标'); p++
          }
        } else {
          console.log('⚠️ Tenant 无可见系统证书，跳过图标测试'); p++
        }
      } catch (e) {
        // Don't fail the whole test if tenant check fails
        console.log(`⚠️ Tenant 检查异常: ${e.message}`); p++
      }

      // Re-login as admin
      try { await loginAs(page, 'admin') } catch { /* non-fatal */ }
    } else {
      console.log('⚠️ 无系统证书，跳过详情页编辑图标测试'); p++; p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 详情页系统证书编辑图标: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 13: UI — detail page shared cert edit icon
  //   Admin:  BLUE icon + confirmation dialog (admin bypasses shared block)
  //   Tenant: GRAY icon + warning toast
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const sharedCert = certs.find(c => (c.binding_count ?? 0) > 1)

    if (sharedCert) {
      // ── 段 A：Admin 视角 ── 编辑图标蓝色 + 确认框
      const row = page.locator('.el-table__row').filter({ hasText: sharedCert.name }).first()
      await row.locator('.el-icon-view').first().click()
      await page.waitForTimeout(2000)

      const editIcons = await page.locator('.el-icon-edit').count()
      if (editIcons > 0) {
        const firstIcon = page.locator('.el-icon-edit').first()
        const iconStyle = await firstIcon.getAttribute('style')
        if (isGrayColor(iconStyle)) throw new Error(`Admin shared cert edit icon should be BLUE, style=${iconStyle}`)

        await firstIcon.click()
        await page.waitForTimeout(500)
        const confirmVisible = await page.locator('.el-message-box').filter({ hasText: '确认编辑' }).count()
        if (confirmVisible === 0) throw new Error('Admin should see confirmation dialog for shared cert edit')
        await page.locator('.el-message-box__btns .el-button:not(.el-button--primary)').first().click()
        await page.waitForTimeout(300)
        console.log(`✅ [UI] Admin 详情页共享证书编辑图标蓝色+确认框`); p++
      } else {
        console.log('✅ [UI] Admin 共享证书详情页编辑图标已隐藏（无编辑入口）'); p++
      }

      // ── 段 B：Tenant 视角 ── 编辑图标置灰 + 警告 toast
      try { await loginAs(page, 'tenant_admin') } catch { /* non-fatal */ }
      await page.goto(`${TARGET_URL}/protection/ssl-cert/detail?id=${sharedCert.id}&waf=${captainInstanceId}`)
      await page.waitForTimeout(2000)

      const tEditIcons = await page.locator('.el-icon-edit').count()
      if (tEditIcons > 0) {
        const tIcon = page.locator('.el-icon-edit').first()
        const tIconStyle = await tIcon.getAttribute('style')
        if (!isGrayColor(tIconStyle)) throw new Error(`Tenant shared cert edit icon should be grayed, style=${tIconStyle}`)

        await tIcon.click()
        await page.waitForTimeout(500)
        const warnVisible = await page.locator('.el-message').filter({ hasText: '多个租户组' }).count()
        if (warnVisible === 0) throw new Error('Tenant should see warning for shared cert edit')
        console.log(`✅ [UI] Tenant 详情页共享证书编辑图标置灰+警告`); p++
      } else {
        console.log('✅ [UI] Tenant 共享证书详情页编辑图标已隐藏'); p++
      }
      try { await loginAs(page, 'admin') } catch { /* non-fatal */ }
    } else {
      console.log('⚠️ 无共享证书，跳过详情页共享编辑图标测试'); p++; p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 详情页共享证书编辑图标: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 14: Tenant — protection fields injected
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')

    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const tenantListResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantCerts = tenantListResp.data?.items || []
    if (tenantCerts.length > 0) {
      const sample = tenantCerts[0]
      if (!('source' in sample)) throw new Error('Missing source field for tenant user')
      if (!('is_system_cert' in sample)) throw new Error('Missing is_system_cert field for tenant user')
      if (!('has_external_ref' in sample)) throw new Error('Missing has_external_ref field for tenant user')
      console.log(`✅ [租户] source, is_system_cert, has_external_ref 字段注入正确`); p++
    } else {
      console.log('⚠️ 租户无可见证书，跳过字段检查'); p++
    }

    // Try deleting a system cert as tenant via API
    const systemCert = tenantCerts.find(c => c.is_mgt_api_cert === true || c.is_system_cert === true)
    if (systemCert) {
      const resp = await apiDelete(page, '/api/captain/cert/delete', {
        id: systemCert.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err === 'system_cert' || resp.body?.err === 'forbidden') {
        console.log(`✅ [租户] 删除系统证书被阻止 (err=${resp.body?.err})`); p++
      } else if (resp.body?.err === null) {
        throw new Error('Tenant should not be able to delete system cert')
      } else {
        console.log(`⚠️ [租户] 删除系统证书返回 err=${resp.body?.err}`); p++
      }
    } else {
      console.log('⚠️ 租户无可见系统证书，跳过删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [租户] 保护字段+权限: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 15: Admin list injection — shared_group_names
  // ═══════════════════════════════════════════
  await loginAs(page, 'admin')
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    const sharedCert = certs.find(c => (c.binding_count ?? 0) > 1)

    if (sharedCert) {
      if (!('shared_group_names' in sharedCert)) throw new Error('Missing shared_group_names for shared cert')
      if (!Array.isArray(sharedCert.shared_group_names)) throw new Error('shared_group_names should be an array')
      console.log(`✅ [Admin列表注入] shared_group_names 字段存在 (${sharedCert.shared_group_names.length} groups)`); p++
    } else {
      console.log('⚠️ 无共享证书，跳过 shared_group_names 测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [Admin列表注入] shared_group_names: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 16: Admin list injection — has_external_ref + is_system_cert
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    if (certs.length === 0) throw new Error('No certs returned')

    const sample = certs[0]
    if (!('has_external_ref' in sample)) throw new Error('Missing has_external_ref field')
    if (!('is_system_cert' in sample)) throw new Error('Missing is_system_cert field')
    console.log(`✅ [Admin列表注入] has_external_ref=${sample.has_external_ref}, is_system_cert=${sample.is_system_cert}`); p++
  } catch (e) { f++; console.log(`❌ [Admin列表注入] has_external_ref/is_system_cert: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 17: Admin non-protected cert delete API success
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    // Cert with binding_count<=1, no websites, not system cert
    const normalCert = certs.find(c =>
      (c.binding_count ?? 0) <= 1 &&
      (c.websites?.length ?? 0) === 0 &&
      !c.is_mgt_api_cert && !c.is_system_cert
    )

    if (normalCert) {
      // admin should be able to delete via API (no in_use, no system_cert, no shared)
      const resp = await apiDelete(page, '/api/captain/cert/delete', {
        id: normalCert.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err === 'system_cert' || resp.body?.err === 'in_use' || resp.body?.err === 'shared') {
        throw new Error(`Admin should be able to delete normal cert, got err=${resp.body?.err}`)
      }
      console.log(`✅ [Admin删除] 非保护证书删除API调用成功 (err=${resp.body?.err})`); p++
    } else {
      console.log('⚠️ 无非保护证书，跳过admin删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [Admin删除] 非保护证书删除: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 18: UI — Admin list page shared cert delete button not grayed
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const certs = listResp.data?.items || []
    // Shared cert that is NOT in_use and NOT system_cert
    const sharedNotInUse = certs.find(c =>
      (c.binding_count ?? 0) > 1 &&
      (c.websites?.length ?? 0) === 0 &&
      !c.is_mgt_api_cert && !c.is_system_cert
    )

    if (sharedNotInUse) {
      const row = page.locator('.el-table__row').filter({ hasText: sharedNotInUse.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        // Admin: shared cert without in_use should have clickable button (not grayed)
        if (isGrayColor(btnStyle)) throw new Error(`Admin shared cert delete button should not be grayed, style=${btnStyle}`)
        console.log(`✅ [UI] Admin 列表页共享证书删除按钮可点击（非置灰）`); p++
      } else {
        console.log('⚠️ 共享证书行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无共享+无引用+非系统证书，跳过admin删除按钮测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] Admin 列表页共享删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 19: 租户可见系统证书（is_mgt_api_cert=true）
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')
    const listResp = await apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=200`)
    const items = listResp.data?.items || []
    const systemCerts = items.filter(c => c.is_mgt_api_cert === true || c.is_system_cert === true)
    if (systemCerts.length === 0) {
      console.log('⚠️ WAF 上无系统证书，跳过租户系统证书可见测试'); p++
    } else {
      console.log(`✅ [租户] 系统证书可见（共 ${systemCerts.length} 个），如：${systemCerts[0].name}`); p++
    }
  } catch (e) { f++; console.log(`❌ [租户] 系统证书可见: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 20: 站点编辑证书下拉租户过滤（aux/cert 只含系统证书+当前租户绑定证书）
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')
    const [auxResp, listResp] = await Promise.all([
      apiGet(page, `/api/captain/site/aux/cert-list?captain_instance_id=${captainInstanceId}`),
      apiGet(page, `/api/captain/cert/list?captain_instance_id=${captainInstanceId}&offset=0&count=500`),
    ])
    const auxItems = auxResp.data || []
    const visibleItems = listResp.data?.items || []
    const visibleIDs = new Set(visibleItems.map(c => c.id))

    const leaked = auxItems.filter(c => !visibleIDs.has(c.id))
    if (leaked.length > 0) {
      throw new Error(`aux/cert 包含租户不可见的证书：${leaked.map(c => c.id).join(', ')}`)
    }
    if (auxItems.length === 0) {
      console.log('⚠️ aux/cert 返回空列表，跳过过滤验证'); p++
    } else {
      console.log(`✅ [租户] 站点证书下拉过滤正确（${auxItems.length} 个，无越权证书）`); p++
    }
  } catch (e) { f++; console.log(`❌ [租户] 站点证书下拉过滤: ${e.message}`) }

  // Re-login as admin
  try { await loginAs(page, 'admin') } catch { /* non-fatal */ }

  console.log(`\n📊 CertWriteProtection: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
