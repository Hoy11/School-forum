#!/usr/bin/env node
// Lightweight static server for CI E2E: serves dist/ and proxies /api to backend.

const fs = require('fs')
const http = require('http')
const path = require('path')

const mimeTypes = {
  '.css': 'text/css; charset=utf-8',
  '.gif': 'image/gif',
  '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.txt': 'text/plain; charset=utf-8',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, headers)
  res.end(body)
}

function safeStaticPath(reqUrl, distDir) {
  let pathname
  let rawPathname
  try {
    rawPathname = decodeURIComponent(String(reqUrl).split('?')[0].split('#')[0])
    pathname = decodeURIComponent(new URL(reqUrl, 'http://localhost').pathname)
  } catch {
    return null
  }
  if (pathname.includes('\0') || rawPathname.includes('\0')) return null
  if (rawPathname.split(/[\\/]/).includes('..')) return null

  const root = path.resolve(distDir)
  const filePath = path.resolve(root, `.${pathname}`)
  if (filePath !== root && !filePath.startsWith(`${root}${path.sep}`)) return null
  return filePath
}

function serveStatic(req, res, options) {
  const distDir = options.distDir
  const indexFile = path.join(distDir, 'index.html')

  if (!fs.existsSync(indexFile)) {
    send(res, 500, `Missing frontend build artifact: ${indexFile}\n`, {
      'content-type': 'text/plain; charset=utf-8',
    })
    return
  }

  let filePath = safeStaticPath(req.url, distDir)
  if (!filePath) {
    send(res, 403, 'Forbidden\n', { 'content-type': 'text/plain; charset=utf-8' })
    return
  }

  if (fs.existsSync(filePath) && fs.statSync(filePath).isDirectory()) {
    filePath = path.join(filePath, 'index.html')
  }
  if (!fs.existsSync(filePath)) filePath = indexFile

  const ext = path.extname(filePath)
  res.writeHead(200, {
    'content-type': mimeTypes[ext] || 'application/octet-stream',
    'cache-control': 'no-store',
  })
  fs.createReadStream(filePath).pipe(res)
}

function proxyApi(req, res, options) {
  const target = new URL(req.url, options.backendUrl)
  const proxyReq = http.request(target, {
    method: req.method,
    headers: {
      ...req.headers,
      host: target.host,
    },
  }, proxyRes => {
    res.writeHead(proxyRes.statusCode || 502, proxyRes.headers)
    proxyRes.pipe(res)
  })

  proxyReq.on('error', err => {
    send(res, 502, `Backend proxy error: ${err.message}\n`, {
      'content-type': 'text/plain; charset=utf-8',
    })
  })

  req.pipe(proxyReq)
}

function createDistServer(options = {}) {
  const backendPort = options.backendPort || process.env.BACKEND_PORT || '8080'
  const serverOptions = {
    backendUrl: options.backendUrl || process.env.BACKEND_URL || `http://localhost:${backendPort}`,
    distDir: path.resolve(options.distDir || path.join(__dirname, '..', 'dist')),
  }

  return http.createServer((req, res) => {
    if (req.url.startsWith('/api/')) {
      proxyApi(req, res, serverOptions)
      return
    }
    serveStatic(req, res, serverOptions)
  })
}

if (require.main === module) {
  const frontendPort = parseInt(process.env.FRONTEND_PORT || '3000', 10)
  const backendPort = process.env.BACKEND_PORT || '8080'
  const backendUrl = process.env.BACKEND_URL || `http://localhost:${backendPort}`
  const server = createDistServer({ backendUrl })

  server.listen(frontendPort, '0.0.0.0', () => {
    console.log(`E2E dist server listening on http://localhost:${frontendPort}`)
    console.log(`Proxying /api to ${backendUrl}`)
  })
}

module.exports = {
  createDistServer,
  mimeTypes,
  safeStaticPath,
}
