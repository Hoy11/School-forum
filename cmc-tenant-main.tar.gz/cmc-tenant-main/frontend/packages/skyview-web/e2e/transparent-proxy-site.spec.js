// E2E Test: transparent proxy site create/update payload alignment
const { chromium } = require('playwright')
const { loginAsRole, navigateToPage, launchOptions } = require('./helpers')

const TP_WAF = {
  id: 77,
  tenant_group_id: 1,
  tenant_group_name: '默认组',
  captain_instance_id: 77,
  instance_name: 'tp-waf',
  instance_host: '10.0.0.77',
  instance_status: 'HEALTHY',
  operation_mode: 'Hardware Transparent Proxy',
  version: '23.01.014_r6',
}

const baseSite = {
  id: 501,
  is_enabled: true,
  name: 'tp-existing',
  interface: 'wg-tp',
  operation_mode: 'Hardware Transparent Proxy',
  server_names: ['tp-existing.example.com'],
  url_paths: [{ op: 'pre', url_path: '/' }],
  addrs: [{ ip_port: '10.10.0.20:18080', ssl: false, http2: false, sni: false, non_http: false }],
  ssl_cert: null,
  ssl_protocols: [],
  ssl_ciphers: '',
  policy_group: null,
  session_method: { type: 'off', param: '' },
  detector_ip_source: [],
  proxy_ip_list: [],
  proxy_ip_groups: [],
  access_log: { is_enabled: false, log_option: 'Drop', req_body: false, rsp_body: false },
  backend_config: {
    type: 'proxy',
    header_config: [],
    custom_config: { ignore_types: [], custom: {}, custom_web: [] },
    keepalive_config: 'default_keepalive_config',
    keepalive: 0,
    keepalive_timeout: 0,
    preserve_source_port: false,
  },
  deep_detection_config: { is_enabled: false },
  ntlm_enabled: false,
  asset_group: 1,
  remark: '',
  create_time: 0,
  last_update_time: 0,
}

function ok(data) {
  return { err: null, msg: 'success', data }
}

async function installTransparentProxyMocks(page, state) {
  await page.route('**/api/binding/waf/list**', route => route.fulfill({
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify(ok({ total: 1, items: [TP_WAF] })),
  }))

  await page.route('**/api/captain/site/list**', route => route.fulfill({
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify(ok({ total: state.sites.length, items: state.sites })),
  }))

  await page.route('**/api/captain/site/detail**', route => {
    const site = state.sites[0] || baseSite
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok(site)) })
  })

  await page.route('**/api/captain/site/aux/policy-list**', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok([])) }))
  await page.route('**/api/captain/site/aux/cert-list**', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok([])) }))
  await page.route('**/api/captain/site/aux/node-list**', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok([])) }))
  await page.route('**/api/captain/site/aux/asset-group-list**', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok([{ id: 1, name: '默认资产组' }])) }))
  await page.route('**/api/captain/site/aux/work-group-list**', route => route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok([{ name: 'wg-tp' }])) }))

  await page.route('**/api/captain/site', async route => {
    const method = route.request().method()
    const body = route.request().postDataJSON()
    if (method === 'POST') {
      state.createdPayload = body
      state.sites = [{ ...baseSite, ...body, id: 502 }]
      await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok({ id: 502 })) })
      return
    }
    if (method === 'PUT') {
      state.updatedPayload = body
      state.sites = [{ ...state.sites[0], ...body }]
      await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(ok(null)) })
      return
    }
    await route.continue()
  })
}

async function chooseVisibleOption(page, text) {
  await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').filter({ hasText: text }).first().click()
}

;(async () => {
  let browser
  let passed = 0
  let failed = 0

  try {
    browser = await chromium.launch(launchOptions())
  } catch (e) {
    console.log(`❌ Browser launch FAILED: ${e.message}`)
    console.log('\n📊 Transparent Proxy Site: 0 passed, 1 failed')
    process.exit(1)
  }

  try {
    const page = await browser.newPage()
    const state = { sites: [], createdPayload: null, updatedPayload: null }
    await loginAsRole(page, 'admin')
    await installTransparentProxyMocks(page, state)

    await navigateToPage(page, '/protection/sites')
    await page.locator('button:has-text("新建站点")').first().click()
    const dialog = page.locator('.el-dialog:visible')
    await dialog.waitFor({ state: 'visible', timeout: 5000 })

    await dialog.locator('.el-form-item').filter({ hasText: '站点名称' }).locator('input').fill('tp-created')
    await dialog.locator('.el-form-item').filter({ hasText: '工作组' }).locator('.el-select').click()
    await chooseVisibleOption(page, 'wg-tp')
    await dialog.locator('.el-form-item').filter({ hasText: '服务器地址' }).locator('textarea').fill('10.10.0.20:18080')
    await dialog.locator('.el-form-item').filter({ hasText: '绑定域名' }).locator('textarea').fill('tp-created.example.com')
    await dialog.locator('.el-form-item').filter({ hasText: 'SSL 配置' }).locator('label').filter({ hasText: 'TCP 流量转发' }).click()
    const createRequest = page.waitForRequest(req => req.url().endsWith('/api/captain/site') && req.method() === 'POST')
    await dialog.locator('.el-button--primary:has-text("确定")').click()
    await createRequest
    await page.waitForTimeout(300)

    const payload = state.createdPayload
    if (!payload) throw new Error('create payload not captured')
    if (payload.operation_mode !== 'Hardware Transparent Proxy') throw new Error(`operation_mode=${payload.operation_mode}`)
    if (!Array.isArray(payload.addrs) || payload.addrs.length !== 1) throw new Error('addrs missing')
    if (payload.addrs[0].ip_port !== '10.10.0.20:18080') throw new Error(`ip_port=${payload.addrs[0].ip_port}`)
    if (payload.addrs[0].non_http !== true) throw new Error('non_http should be true')
    if (payload.ports) throw new Error('transparent proxy payload should not include ports')
    if (payload.url_paths?.length !== 1 || payload.url_paths[0].url_path !== '/' || payload.url_paths[0].op !== 'pre') throw new Error('non_http should force / prefix url path')
    if (payload.backend_config?.preserve_source_port !== false) throw new Error('preserve_source_port default should be false')
    await page.close()
    passed++
    console.log('✅ Test 1: Create transparent proxy site submits addrs-only payload and TCP url path')
  } catch (e) {
    failed++
    console.log(`❌ Test 1 FAILED: ${e.message}`)
  }

  try {
    const page = await browser.newPage()
    const state = { sites: [{ ...baseSite }], createdPayload: null, updatedPayload: null }
    await loginAsRole(page, 'admin')
    await installTransparentProxyMocks(page, state)

    await navigateToPage(page, '/protection/sites/detail?id=501&waf=77')
    const row = page.locator('.editable-row').filter({ hasText: '源端口透传' })
    await row.waitFor({ state: 'visible', timeout: 5000 })
    await row.locator('.el-icon-edit').click()
    await row.locator('.el-select').click()
    await chooseVisibleOption(page, '开启')
    const updateRequest = page.waitForRequest(req => req.url().endsWith('/api/captain/site') && req.method() === 'PUT')
    await row.locator('.el-button--primary:has-text("确定")').click()
    await updateRequest
    await page.waitForTimeout(300)

    const payload = state.updatedPayload
    if (!payload) throw new Error('update payload not captured')
    if (payload.operation_mode !== 'Hardware Transparent Proxy') throw new Error(`operation_mode=${payload.operation_mode}`)
    if (payload.backend_config?.preserve_source_port !== true) throw new Error('preserve_source_port should be true')
    if (!Array.isArray(payload.addrs) || payload.addrs[0].ip_port !== '10.10.0.20:18080') throw new Error('addrs should be preserved on detail update')
    if (payload.ports) throw new Error('transparent proxy update should not include ports')
    await page.close()
    passed++
    console.log('✅ Test 2: Detail source-port edit uses preserve_source_port and preserves addrs')
  } catch (e) {
    failed++
    console.log(`❌ Test 2 FAILED: ${e.message}`)
  }

  console.log(`\n📊 Transparent Proxy Site: ${passed} passed, ${failed} failed`)
  await browser.close()
  process.exit(failed > 0 ? 1 : 0)
})()
