#!/usr/bin/env node
// Integration E2E Test Runner — manifest-driven layered execution.

const { execFileSync } = require('child_process')
const fs = require('fs')
const path = require('path')
const suites = require('./suites')

const TARGET_URL = process.env.TARGET_URL || 'http://localhost:3000'
const BACKEND_PORT = process.env.BACKEND_PORT || '8080'
const BACKEND_URL = process.env.BACKEND_URL || deriveBackendUrl(TARGET_URL, BACKEND_PORT)
const e2eDir = __dirname

function deriveBackendUrl(targetUrl, backendPort) {
  try {
    const url = new URL(targetUrl)
    url.port = backendPort
    return url.toString().replace(/\/$/, '')
  } catch {
    return `http://localhost:${backendPort}`
  }
}

function collect(values, value) {
  if (!value) return
  for (const item of String(value).split(',')) {
    const trimmed = item.trim()
    if (trimmed) values.add(trimmed)
  }
}

function parseArgs(argv) {
  const args = {
    layers: new Set(),
    modules: new Set(),
    tags: new Set(),
    suites: new Set(),
    excludeLayers: new Set(),
    from: null,
    all: false,
    list: false,
    dryRun: false,
    allowEmpty: false,
    includeDisabled: false,
    workers: parseInt(process.env.E2E_WORKERS || (process.env.CI ? '1' : '6'), 10),
  }

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]
    const [flag, inlineValue] = arg.split('=', 2)
    const nextValue = inlineValue === undefined ? argv[i + 1] : inlineValue
    const consumesNext = inlineValue === undefined

    if (flag === '--all') args.all = true
    else if (flag === '--list') args.list = true
    else if (flag === '--dry-run') args.dryRun = true
    else if (flag === '--allow-empty') args.allowEmpty = true
    else if (flag === '--include-disabled') args.includeDisabled = true
    else if (flag === '--layer') { collect(args.layers, nextValue); if (consumesNext) i++ }
    else if (flag === '--exclude-layer') { collect(args.excludeLayers, nextValue); if (consumesNext) i++ }
    else if (flag === '--module') { collect(args.modules, nextValue); if (consumesNext) i++ }
    else if (flag === '--tag') { collect(args.tags, nextValue); if (consumesNext) i++ }
    else if (flag === '--suite') { collect(args.suites, nextValue); if (consumesNext) i++ }
    else if (flag === '--from') { args.from = nextValue; if (consumesNext) i++ }
    else if (flag === '--workers') { args.workers = parseInt(nextValue, 10); if (consumesNext) i++ }
    else {
      console.error(`Unknown argument: ${arg}`)
      process.exit(2)
    }
  }

  if (!Number.isInteger(args.workers) || args.workers < 1) args.workers = 1
  return args
}

function readSuiteListFromFile(filePath) {
  const resolved = path.resolve(process.cwd(), filePath)
  const body = JSON.parse(fs.readFileSync(resolved, 'utf8'))
  const list = body.suites || body.files || body
  if (!Array.isArray(list)) throw new Error(`Invalid selected suite file: ${filePath}`)
  return list
}

function suiteMatchesFilter(suite, args) {
  const hasLayer = args.layers.size > 0
  const hasModule = args.modules.size > 0
  const hasTag = args.tags.size > 0
  const hasSuite = args.suites.size > 0

  if (hasSuite && !args.suites.has(suite.file)) return false
  if (hasLayer && !suite.layers.some(layer => args.layers.has(layer))) return false
  if (hasModule && !suite.modules.some(module => args.modules.has(module))) return false
  if (hasTag && !suite.tags.some(tag => args.tags.has(tag))) return false

  return hasSuite || hasLayer || hasModule || hasTag
}

function excludeSuites(selected, args) {
  return selected.filter(suite => {
    if (!args.includeDisabled && suite.disabled) return false
    if (args.excludeLayers.size > 0 && suite.layers.some(layer => args.excludeLayers.has(layer))) return false
    return true
  })
}

function selectSuites(args) {
  let selected
  if (args.from) {
    const selectedFiles = new Set(readSuiteListFromFile(args.from))
    selected = suites.filter(suite => selectedFiles.has(suite.file))
    const missing = [...selectedFiles].filter(file => !suites.some(suite => suite.file === file))
    if (missing.length > 0) {
      console.error(`Selected suite file(s) are not registered: ${missing.join(', ')}`)
      process.exit(2)
    }
    return excludeSuites(selected, args)
  }

  if (args.all) return excludeSuites([...suites], args)

  const hasFilter = args.layers.size > 0 || args.modules.size > 0 || args.tags.size > 0 || args.suites.size > 0
  if (!hasFilter) return excludeSuites([...suites], args)

  selected = suites.filter(suite => suiteMatchesFilter(suite, args))
  return excludeSuites(selected, args)
}

function printSuiteList(selected) {
  for (const suite of selected) {
    console.log([
      suite.file,
      `layers=${suite.layers.join(',')}`,
      `modules=${suite.modules.join(',')}`,
      `tags=${suite.tags.join(',')}`,
      `group=${suite.group}`,
      suite.disabled ? `disabled=${suite.disabledReason || true}` : null,
    ].filter(Boolean).join('  '))
  }
}

function runSuite(suite) {
  const start = Date.now()
  const filePath = path.join(e2eDir, suite.file)
  try {
    const output = execFileSync('node', [filePath], {
      timeout: suite.timeout || 360000,
      encoding: 'utf-8',
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, TARGET_URL, BACKEND_URL },
    })
    return parseResult(suite, output, start)
  } catch (e) {
    const output = [e.stdout, e.stderr, e.message].filter(Boolean).join('\n')
    return parseResult(suite, output, start, true)
  }
}

function parseResult(suite, output, start, commandFailed = false) {
  const match = output.match(/📊.*?:\s*(\d+)\s*passed,\s*(\d+)\s*failed/)
  const passed = match ? parseInt(match[1], 10) : 0
  const failed = match ? parseInt(match[2], 10) : 1
  const lines = output
    .split('\n')
    .filter(line => line.includes('✅') || line.includes('❌') || line.includes('⚠️'))
    .map(line => '  ' + line.trim())
  const duration = ((Date.now() - start) / 1000).toFixed(1)
  return {
    name: suite.name,
    file: suite.file,
    passed,
    failed: commandFailed && !match ? 1 : failed,
    lines,
    duration,
  }
}

function groupSuites(selected) {
  const byGroup = new Map()
  for (const suite of selected) {
    const group = suite.group || 99
    if (!byGroup.has(group)) byGroup.set(group, [])
    byGroup.get(group).push(suite)
  }
  return [...byGroup.entries()]
    .sort(([a], [b]) => a - b)
    .map(([, groupSuites]) => groupSuites)
}

async function runWithWorkers(items, workers, task) {
  const results = new Array(items.length)
  let nextIndex = 0
  const workerCount = Math.min(workers, items.length)

  async function runWorker() {
    while (nextIndex < items.length) {
      const current = nextIndex++
      results[current] = await task(items[current])
    }
  }

  await Promise.all(Array.from({ length: workerCount }, () => runWorker()))
  return results
}

;(async () => {
  const args = parseArgs(process.argv.slice(2))
  const selectedSuites = selectSuites(args)

  if (args.list || args.dryRun) {
    printSuiteList(selectedSuites)
    process.exit(0)
  }

  if (selectedSuites.length === 0) {
    if (args.allowEmpty) {
      console.log('No integration E2E suites selected')
      process.exit(0)
    }
    console.error('No integration E2E suites selected')
    process.exit(1)
  }

  console.log('═══════════════════════════════════════════')
  console.log('  CMC Tenant Integration E2E Test Suite')
  console.log(`  Target: ${TARGET_URL}`)
  console.log(`  Backend: ${BACKEND_URL}`)
  console.log(`  Registered suites: ${suites.length}`)
  console.log(`  Selected suites: ${selectedSuites.length}`)
  console.log(`  Workers: ${args.workers}`)
  console.log('═══════════════════════════════════════════\n')

  try {
    const resp = await fetch(TARGET_URL, { signal: AbortSignal.timeout(5000) })
    if (!resp.ok) throw new Error(`Frontend returned ${resp.status}`)
    console.log('Frontend is accessible')
  } catch (e) {
    console.error(`Frontend not accessible at ${TARGET_URL}`)
    process.exit(1)
  }

  try {
    const resp = await fetch(`${BACKEND_URL}/health`, { signal: AbortSignal.timeout(5000) })
    if (!resp.ok) throw new Error(`Backend returned ${resp.status}`)
    console.log('Backend is accessible\n')
  } catch (e) {
    console.error(`Backend not accessible at ${BACKEND_URL}/health`)
    process.exit(1)
  }

  let totalPassed = 0
  let totalFailed = 0
  const results = []

  for (const group of groupSuites(selectedSuites)) {
    console.log(`▶ Running group (${group.length} suites): ${group.map(suite => suite.name).join(', ')}`)
    console.log('─'.repeat(40))

    const groupResults = await runWithWorkers(group, args.workers, suite =>
      new Promise(resolve => {
        setImmediate(() => resolve(runSuite(suite)))
      })
    )

    for (const result of groupResults) {
      results.push(result)
      totalPassed += result.passed
      totalFailed += result.failed
      for (const line of result.lines) console.log(line)
    }
    console.log('')
  }

  console.log('═══════════════════════════════════════════')
  console.log('  Integration E2E Test Summary')
  console.log('═══════════════════════════════════════════')
  for (const result of results) {
    const icon = result.failed === 0 ? '✓' : '✗'
    console.log(`  ${icon} ${result.name} (${result.file}): ${result.passed} passed, ${result.failed} failed (${result.duration}s)`)
  }
  console.log('───────────────────────────────────────────')
  console.log(`  Total: ${totalPassed} passed, ${totalFailed} failed`)
  if (totalFailed > 0) {
    console.log('───────────────────────────────────────────')
    console.log('  Failed cases:')
    for (const result of results.filter(r => r.failed > 0)) {
      console.log(`  ✗ ${result.name} (${result.file})`)
      const failedLines = result.lines.filter(line => line.includes('❌'))
      for (const line of failedLines) console.log(line)
    }
  }
  console.log('═══════════════════════════════════════════')

  process.exit(totalFailed > 0 ? 1 : 0)
})()
