// Integration: IP group enhancement — enrich columns, shared check, cross-tenant binding, CRUD
const path = require('path')
const { chromium } = require('playwright')
const { launchOptions, getAuthCookieHeader, getActiveWafId, loginAs, navTo, waitForWafSelector, waitForTableData, getRows } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  let p = 0, f = 0

  // --- Helper ---
  async function apiCall(name, method, urlPath, body, checks) {
    try {
      const opts = { headers }
      if (body) { opts.data = body; opts.headers['Content-Type'] = 'application/json' }
      const resp = method === 'POST' ? await page.request.post(`${BACKEND_URL}${urlPath}`, opts)
                                   : method === 'DELETE' ? await page.request.delete(`${BACKEND_URL}${urlPath}`, opts)
                                   : method === 'PUT' ? await page.request.put(`${BACKEND_URL}${urlPath}`, opts)
                                   : await page.request.get(`${BACKEND_URL}${urlPath}`, opts)
      const data = await resp.json()
      for (const [field, expected] of Object.entries(checks)) {
        const actual = field.split('.').reduce((o, k) => o?.[k], data)
        if (typeof expected === 'function') {
          if (!expected(actual)) throw new Error(`${field}=${JSON.stringify(actual)}, check failed`)
        } else if (actual !== expected) {
          throw new Error(`${field}=${JSON.stringify(actual)}, expected ${JSON.stringify(expected)}`)
        }
      }
      console.log(`✅ ${name}`); p++
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  // --- Login as admin ---
  let cookies
  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    cookies = await page.context().cookies()
    if (!cookies.some(c => c.name === 'token')) throw new Error('No token cookie')
    if (!cookieHeader.includes('token=')) throw new Error('No token cookie header')
    console.log('✅ Login (admin)'); p++
  } catch (e) { f++; console.log(`❌ Login: ${e.message}`); process.exit(1) }

  const headers = { Cookie: cookies.map(c => `${c.name}=${c.value}`).join('; ') }
  const captainInstanceId = await getActiveWafId(page, headers.Cookie)
  console.log(`  Using captain_instance_id=${captainInstanceId}`)

  async function requestJson(method, urlPath, headerSet, body) {
    const opts = { headers: { ...headerSet } }
    if (body) {
      opts.data = body
      opts.headers['Content-Type'] = 'application/json'
    }
    const url = `${BACKEND_URL}${urlPath}`
    if (method === 'POST') return (await page.request.post(url, opts)).json()
    if (method === 'DELETE') return (await page.request.delete(url, opts)).json()
    if (method === 'PUT') return (await page.request.put(url, opts)).json()
    return (await page.request.get(url, opts)).json()
  }

  // === 1. IP 组列表包含 FilterV2 完整字段 ===
  let ipGroups = []
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}`, { headers })
    const data = await resp.json()
    ipGroups = data.data?.items || []
    if (ipGroups.length === 0) throw new Error('No IP groups found')
    const item = ipGroups[0]
    if (!('binding_count' in item)) throw new Error('Missing binding_count field')
    if (!('original' in item)) throw new Error('Missing original field')
    if (!('comment' in item)) throw new Error('Missing comment field')
    console.log(`✅ IP 组列表 FilterV2 完整字段 (${ipGroups.length} items, binding_count=${item.binding_count})`); p++
  } catch (e) { f++; console.log(`❌ IP 组列表 FilterV2 完整字段: ${e.message}`) }

  // === 2. tenant_admin IP 组列表走 FilterV2 + 本地分页 ===
  let tenantFixtureId = null
  try {
    const tenantCookie = await getAuthCookieHeader(page, 'tenant_admin')
    const tenantHeaders = { Cookie: tenantCookie }
    const listPath = `/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}&offset=0&count=1`
    let tenantList = await requestJson('GET', listPath, tenantHeaders)
    if (tenantList.err !== null) throw new Error(`Tenant list failed: ${tenantList.msg || tenantList.err}`)

    if ((tenantList.data?.total || 0) === 0) {
      const fixtureName = `e2e-tenant-filterv2-${Date.now()}`
      const createResp = await requestJson('POST', '/api/captain/ip-group/create', tenantHeaders, {
        name: fixtureName,
        comment: 'tenant filterv2 pagination',
        captain_instance_id: captainInstanceId,
      })
      if (createResp.err !== null) throw new Error(`Create tenant fixture failed: ${createResp.msg || createResp.err}`)
      tenantFixtureId = createResp.data?.id || null
      tenantList = await requestJson('GET', listPath, tenantHeaders)
      if (tenantList.err !== null) throw new Error(`Tenant list after create failed: ${tenantList.msg || tenantList.err}`)
    }

    const total = tenantList.data?.total || 0
    const items = tenantList.data?.items || []
    if (total < 1) throw new Error('Tenant list still empty after fixture ensure')
    if (items.length !== 1) throw new Error(`Expected local page size 1, got ${items.length}`)
    const item = items[0]
    if (!('comment' in item)) throw new Error('Missing comment field')
    if (!('original' in item)) throw new Error('Missing original field')
    if (!('binding_count' in item)) throw new Error('Missing binding_count field')
    if (!('source' in item)) throw new Error('Missing source field')
    if (!('used_count' in item)) throw new Error('Missing used_count field')
    if (!('has_external_ref' in item)) throw new Error('Missing has_external_ref field')
    console.log(`✅ tenant_admin FilterV2 本地分页字段完整 (total=${total}, page=${items.length})`); p++
  } catch (e) { f++; console.log(`❌ tenant_admin FilterV2 本地分页: ${e.message}`) }
  if (tenantFixtureId) {
    try {
      const tenantCookie = await getAuthCookieHeader(page, 'tenant_admin')
      await requestJson('DELETE', '/api/captain/ip-group/delete', { Cookie: tenantCookie }, {
        id: tenantFixtureId,
        captain_instance_id: captainInstanceId,
      })
    } catch { /* best effort cleanup */ }
  }

  // === 3. IP 组列表响应时间 < 3000ms ===
  try {
    const start = Date.now()
    await page.request.get(`${BACKEND_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}`, { headers })
    const elapsed = Date.now() - start
    if (elapsed >= 2000) throw new Error(`Response time ${elapsed}ms >= 2000ms`)
    console.log(`✅ IP 组列表响应时间 ${elapsed}ms < 2000ms`); p++
  } catch (e) { f++; console.log(`❌ IP 组列表响应时间: ${e.message}`) }

  // === 4. 共享 IP 组编辑返回 shared ===
  const sharedGroup = ipGroups.find(g => (g.binding_count ?? 0) > 1)
  if (sharedGroup) {
    await apiCall('共享 IP 组编辑返回 shared', 'PUT', '/api/captain/ip-group/update',
      { id: sharedGroup.id, name: sharedGroup.name, captain_instance_id: captainInstanceId },
      { 'err': 'shared' }
    )
  } else {
    console.log('⚠️ 没有共享 IP 组，跳过编辑 shared 测试')
  }

  // === 5. 共享 IP 组删除返回 shared 或 in_use（优先级: in_use > shared） ===
  if (sharedGroup) {
    await apiCall('共享 IP 组删除返回 shared 或 in_use', 'DELETE', '/api/captain/ip-group/delete',
      { id: sharedGroup.id, captain_instance_id: captainInstanceId },
      { 'err': (v) => v === 'shared' || v === 'in_use' }
    )
  } else {
    console.log('⚠️ 没有共享 IP 组，跳过删除 shared 测试')
  }

  // === 6. 跨租户组 binding 共存 ===
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/binding/site/list?offset=0&count=100`, { headers })
    const data = await resp.json()
    const siteBindings = data.data?.items || []
    const instanceGroups = {}
    for (const sb of siteBindings) {
      const key = sb.captain_instance_id
      if (!instanceGroups[key]) instanceGroups[key] = new Set()
      instanceGroups[key].add(sb.tenant_group_id)
    }
    const sharedInstance = Object.entries(instanceGroups).find(([, groups]) => groups.size > 1)
    if (sharedInstance) {
      const instanceId = sharedInstance[0]
      const resp2 = await page.request.get(`${BACKEND_URL}/api/captain/ip-group/list?captain_instance_id=${instanceId}`, { headers })
      const data2 = await resp2.json()
      const items = data2.data?.items || []
      const sharedItems = items.filter(g => (g.binding_count ?? 0) > 1)
      console.log(`✅ 跨租户组 binding 共存 (${sharedItems.length} shared IP groups on instance ${instanceId})`); p++
    } else {
      console.log('⚠️ 无多租户组共享 WAF，跳过跨组 binding 测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 跨租户组 binding: ${e.message}`) }

  // === 7. IP 组创建后列表可读回完整字段 ===
  let createdGroupId = null
  await apiCall('IP 组创建', 'POST', '/api/captain/ip-group/create',
    { name: 'e2e-test-group', comment: 'e2e test', captain_instance_id: captainInstanceId },
    { 'err': null }
  )
  try {
    const resp = await page.request.get(`${BACKEND_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}`, { headers })
    const data = await resp.json()
    const items = data.data?.items || []
    const created = items.find(g => g.name === 'e2e-test-group')
    if (created) {
      createdGroupId = created.id
      if (created.comment !== 'e2e test') throw new Error(`comment="${created.comment}", expected "e2e test"`)
      if (!('original' in created)) throw new Error('Missing original field after create')
      console.log(`✅ IP 组 FilterV2 完整字段验证 (id=${created.id}, comment="${created.comment}")`); p++
    } else {
      throw new Error('Created group not found in list')
    }
  } catch (e) { f++; console.log(`❌ IP 组 FilterV2 完整字段验证: ${e.message}`) }

  // Cleanup: delete the test group
  if (createdGroupId) {
    await apiCall('IP 组清理删除', 'DELETE', '/api/captain/ip-group/delete',
      { id: createdGroupId, captain_instance_id: captainInstanceId },
      { 'err': null }
    )
  }

  // === 8. IP 组创建 + 添加 IP 后验证 original 字段 ===
  let createdGroupId2 = null
  await apiCall('IP 组创建(带IP) - 创建', 'POST', '/api/captain/ip-group/create',
    { name: 'e2e-test-ipadd', comment: 'with ip', captain_instance_id: captainInstanceId },
    { 'err': null }
  )
  try {
    const listResp = await page.request.get(`${BACKEND_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}`, { headers })
    const listData = await listResp.json()
    const items = listData.data?.items || []
    const created = items.find(g => g.name === 'e2e-test-ipadd')
    if (!created) throw new Error('Created group not found')
    createdGroupId2 = created.id

    // Add IP address via targets
    const addResp = await page.request.post(`${BACKEND_URL}/api/captain/ip-group/item/add`, {
      headers: { ...headers, 'Content-Type': 'application/json' },
      data: { id: createdGroupId2, captain_instance_id: captainInstanceId, targets: ['192.168.100.1', '10.0.0.0/24'] },
    })
    const addData = await addResp.json()
    if (addData.err !== null) throw new Error(`Add IP failed: ${addData.msg}`)

    // Verify original field in list
    const listResp2 = await page.request.get(`${BACKEND_URL}/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}`, { headers })
    const listData2 = await listResp2.json()
    const updated = listData2.data?.items?.find(g => g.id === createdGroupId2)
    if (!updated) throw new Error('Group not found after IP add')
    if (!updated.original || updated.original.length === 0) throw new Error(`original is empty: ${JSON.stringify(updated.original)}`)
    console.log(`✅ IP 组添加IP后 original 字段正确 (original=${JSON.stringify(updated.original)})`); p++
  } catch (e) { f++; console.log(`❌ IP 组添加IP后 original 字段: ${e.message}`) }

  // Cleanup: delete the second test group
  if (createdGroupId2) {
    await apiCall('IP 组清理删除(带IP)', 'DELETE', '/api/captain/ip-group/delete',
      { id: createdGroupId2, captain_instance_id: captainInstanceId },
      { 'err': null }
    )
  }

  // === 9. UI 表单路径：新建 IP 组 → 输入 IP → 提交 → 验证 original 列 ===
  let createdGroupId3 = null
  try {
    // Login via UI to ensure session is fresh
    await loginAs(page, 'admin')
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)

    // Click create button
    await page.locator('button:has-text("新建")').first().click()
    await page.locator('.el-dialog').first().waitFor({ state: 'visible', timeout: 5000 })

    // Fill name and comment
    await page.locator('.el-dialog input').nth(0).fill('e2e-ui-test')
    await page.locator('.el-dialog input').nth(1).fill('ui e2e test')

    // Fill IPs in textarea
    await page.locator('.el-dialog textarea').first().fill('10.0.0.1\n10.0.0.0/24\n192.168.1.1')

    // Submit
    await page.locator('.el-dialog .el-button--primary').click()
    await page.waitForTimeout(2000)
    await waitForTableData(page)

    // Find created group in list and check original column
    const rows = await page.locator('.el-table__row').all()
    let found = false
    for (const row of rows) {
      const nameCell = await row.locator('td').nth(1).innerText()
      if (nameCell.trim() === 'e2e-ui-test') {
        found = true
        const ipCell = await row.locator('td').nth(2).innerText()
        if (!ipCell.includes('10.0.0.1')) throw new Error(`original column missing expected IP: "${ipCell}"`)
        // Extract ID for cleanup
        const idCell = await row.locator('td').first().innerText()
        createdGroupId3 = parseInt(idCell.trim(), 10)
        break
      }
    }
    if (!found) throw new Error('Created group not found in list')
    console.log(`✅ IP 组 UI 表单路径测试 (id=${createdGroupId3}, original 列正确)`); p++
  } catch (e) { f++; console.log(`❌ IP 组 UI 表单路径测试: ${e.message}`) }

  // Cleanup
  if (createdGroupId3) {
    await apiCall('IP 组清理删除(UI)', 'DELETE', '/api/captain/ip-group/delete',
      { id: createdGroupId3, captain_instance_id: captainInstanceId },
      { 'err': null }
    )
  }

  console.log(`\n📊 IP Group Enhancement: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
