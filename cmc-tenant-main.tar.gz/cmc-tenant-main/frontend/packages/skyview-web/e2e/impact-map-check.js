#!/usr/bin/env node
// Validates impact-map coverage for product code paths.

const { execFileSync } = require('child_process')
const impactMap = require('./impact-map')
const suites = require('./suites')

const suiteFiles = new Set(suites.map(suite => suite.file))

function escapeRegExp(char) {
  return char.replace(/[|\\{}()[\]^$+?.]/g, '\\$&')
}

function globToRegExp(pattern) {
  let out = '^'
  for (let i = 0; i < pattern.length; i++) {
    const char = pattern[i]
    if (char === '*') {
      if (pattern[i + 1] === '*') {
        out += '.*'
        i++
      } else {
        out += '[^/]*'
      }
    } else {
      out += escapeRegExp(char)
    }
  }
  out += '$'
  return new RegExp(out)
}

const compiledImpactMap = impactMap.map(entry => ({
  ...entry,
  matchers: entry.paths.map(pattern => globToRegExp(pattern)),
}))

function gitFiles() {
  const root = execFileSync('git', ['rev-parse', '--show-toplevel'], { encoding: 'utf8' }).trim()
  const output = execFileSync('git', ['-C', root, 'ls-files'], { encoding: 'utf8' })
  return output.split('\n').map(line => line.trim()).filter(Boolean)
}

function isProductPath(file) {
  if (file.endsWith('_test.go')) return false
  if (file.includes('/__tests__/')) return false
  if (file.includes('/e2e/')) return false
  if (file.startsWith('spec/') || file.startsWith('requirements/') || file.startsWith('cmc_rpc/')) return false
  if (file.endsWith('.md') || file.endsWith('.txt')) return false
  if (file.endsWith('.lock') || file.endsWith('-lock.yaml')) return false

  if (file.startsWith('gateway/')) return true
  if (file.startsWith('frontend/packages/skyview-web/src/')) return true
  if (file.startsWith('frontend/packages/skyview-web/build/')) return true
  if (file.startsWith('frontend/packages/skyview-web/config/')) return true
  if (file.startsWith('deploy/')) return true
  if (file === 'Dockerfile' || file.startsWith('docker-compose')) return true
  return false
}

function matchedModules(file) {
  return compiledImpactMap
    .filter(entry => entry.matchers.some(matcher => matcher.test(file)))
    .map(entry => entry.module)
}

const errors = []

for (const entry of impactMap) {
  if (!entry.module) errors.push('impact-map entry missing module')
  if (!Array.isArray(entry.paths) || entry.paths.length === 0) errors.push(`${entry.module}: missing paths`)
  if (!Array.isArray(entry.suites) || entry.suites.length === 0) errors.push(`${entry.module}: missing suites`)
  for (const suite of entry.suites || []) {
    if (!suiteFiles.has(suite)) errors.push(`${entry.module}: references unregistered suite ${suite}`)
  }
}

const productFiles = gitFiles().filter(isProductPath)
const uncovered = productFiles.filter(file => matchedModules(file).length === 0)

if (uncovered.length > 0) {
  errors.push(`Uncovered product paths (${uncovered.length}):`)
  for (const file of uncovered) errors.push(`  ${file}`)
}

if (errors.length > 0) {
  console.error('Impact map check failed:')
  for (const error of errors) console.error(`  - ${error}`)
  process.exit(1)
}

console.log(`Impact map check passed: ${productFiles.length} product files covered by ${impactMap.length} rules`)
