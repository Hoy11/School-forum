// Integration: role-based access control — tenant_admin permissions
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, navTo, getRows, getTopMenuTexts, CREDENTIALS, launchOptions, loginAs } = require(path.join(__dirname, 'integ-helpers'))

const TENANT_ADMIN = CREDENTIALS.tenant_admin

async function resetTenantAdminPassword() {
  try {
    // Login as admin
    const adminLogin = await fetch(`${TARGET_URL}/api/auth/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: 'admin', password: CREDENTIALS.admin.password }),
    })
    const adminData = await adminLogin.json()
    const adminCookie = adminLogin.headers?.get('set-cookie') || `token=${document?.cookie?.match(/token=([^;]+)/)?.[1]}`

    // Get admin token from set-cookie header
    const setCookie = adminLogin.headers.get('set-cookie') || ''
    const tokenMatch = setCookie.match(/token=([^;]+)/)
    if (!tokenMatch) return
    const token = tokenMatch[1]

    // Find test_admin user ID
    const listResp = await fetch(`${TARGET_URL}/api/user/list`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Cookie': `token=${token}` },
      body: JSON.stringify({ offset: 0, count: 50 }),
    })
    const listData = await listResp.json()
    const testAdmin = (listData.data?.items || []).find(u => u.username === TENANT_ADMIN.username)
    if (!testAdmin) return

    // Reset password (get temp password)
    const credResp = await fetch(`${TARGET_URL}/api/user/credential`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', 'Cookie': `token=${token}` },
      body: JSON.stringify({ id: testAdmin.id }),
    })
    const credData = await credResp.json()
    const tempPwd = credData.data?.password
    if (!tempPwd) return

    // Login with temp password
    const tmpLogin = await fetch(`${TARGET_URL}/api/auth/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username: TENANT_ADMIN.username, password: tempPwd }),
    })
    const tmpData = await tmpLogin.json()
    const tmpSetCookie = tmpLogin.headers.get('set-cookie') || ''
    const tmpTokenMatch = tmpSetCookie.match(/token=([^;]+)/)
    if (!tmpTokenMatch) return
    const tmpToken = tmpTokenMatch[1]

    // Change to desired password
    await fetch(`${TARGET_URL}/api/user/current/password`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json', 'Cookie': `token=${tmpToken}` },
      body: JSON.stringify({
        old_password: tempPwd,
        new_password: TENANT_ADMIN.password,
        dup_password: TENANT_ADMIN.password,
      }),
    })
  } catch (e) {
    // Non-fatal: if reset fails, tests will just try with current password
  }
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  let p = 0, f = 0

  // Reset tenant_admin password to ensure known state
  await resetTenantAdminPassword()

  // Login as tenant_admin
  const page = await browser.newPage()
  await loginAs(page, 'tenant_admin')
  console.log('Logged in as tenant_admin, URL:', page.url())

  // Test 1: tenant_admin should NOT see 系统管理 or 租户管理 in top nav
  try {
    const menus = await getTopMenuTexts(page)
    const hasSystem = menus.some(m => m.includes('系统管理'))
    const hasTenant = menus.some(m => m.includes('租户管理'))
    if (hasSystem) throw new Error('Should NOT see 系统管理')
    if (hasTenant) throw new Error('Should NOT see 租户管理')
    console.log('✅ tenant_admin: no 系统管理/租户管理'); p++
  } catch (e) { f++; console.log(`❌ Menu restriction: ${e.message}`) }

  // Test 2: tenant_admin should see 防护管理 and 威胁监测
  try {
    const menus = await getTopMenuTexts(page)
    const hasProtection = menus.some(m => m.includes('防护管理'))
    const hasThreat = menus.some(m => m.includes('威胁监测'))
    if (!hasProtection || !hasThreat) throw new Error('Should see 防护管理 and 威胁监测')
    console.log('✅ tenant_admin: has 防护管理+威胁监测'); p++
  } catch (e) { f++; console.log(`❌ Menu access: ${e.message}`) }

  // Test 3: tenant_admin should see 组内管理 menu
  try {
    const menus = await getTopMenuTexts(page)
    const hasGroup = menus.some(m => m.includes('组内管理'))
    if (!hasGroup) throw new Error('Should see 组内管理')
    console.log('✅ tenant_admin: has 组内管理'); p++
  } catch (e) { f++; console.log(`❌ Group menu: ${e.message}`) }

  // Test 4: tenant_admin can view detect log
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content || content.length < 10) throw new Error('Page empty')
    console.log('✅ tenant_admin: can view 攻击检测日志'); p++
  } catch (e) { f++; console.log(`❌ Detect log: ${e.message}`) }

  // Test 5: tenant_admin can view WAF list
  try {
    await navTo(page, '防护管理', 'WAF 列表')
    const rows = await getRows(page)
    console.log(`✅ tenant_admin: WAF list (${rows} rows)`); p++
  } catch (e) { f++; console.log(`❌ WAF list: ${e.message}`) }

  // Test 6: direct URL access to admin-only pages should be blocked
  try {
    await page.evaluate(() => window.$router?.push('/system/soc')).catch(() => {})
    await page.waitForTimeout(500)
    // Check if redirected or blocked (not still on /system/soc with content)
    const url = page.url()
    if (url.includes('/system/soc') && await page.locator('.el-card').count() > 0) {
      throw new Error('Should not access SOC config')
    }
    console.log('✅ tenant_admin: blocked from /system/soc'); p++
  } catch (e) { f++; console.log(`❌ URL guard: ${e.message}`) }

  // Test 7: API access — tenant_admin cannot call admin-only APIs
  try {
    const resp = await page.evaluate(async () => {
      const r = await fetch('/api/system/captain', { credentials: 'include' })
      return { status: r.status, body: await r.json().catch(() => null) }
    })
    if (resp.status === 200 && resp.body?.err === null) throw new Error('Should not access captain config API')
    console.log('✅ tenant_admin: blocked from captain config API'); p++
  } catch (e) { f++; console.log(`❌ API guard: ${e.message}`) }

  console.log(`\n📊 RBAC: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
