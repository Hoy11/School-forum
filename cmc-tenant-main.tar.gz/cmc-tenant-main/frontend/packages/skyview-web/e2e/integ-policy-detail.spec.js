// Integration: Policy Detail — 基础配置 + 语义分析引擎 + 内置规则 tabs
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

// Navigate to policy detail page: policy list → click detail on first row
async function goToPolicyDetail(page) {
  await navTo(page, '防护管理', '攻击检测引擎')
  await waitForWafSelector(page)
  await waitForTableData(page)
  const total = await getRows(page)
  if (total === 0) throw new Error('No policies')
  await page.locator('.el-table__row').first().locator('button .el-icon-document').click()
  await page.locator('.el-page-header').waitFor({ state: 'visible', timeout: 10000 })
  await page.waitForTimeout(2000)
}

// Find a BasicConfigTab row by label and click its edit button
// Each row is: div[style*=flex] containing spans and a button.el-button with .el-icon-edit
async function clickRowEdit(page, label) {
  // Find the flex row that contains the label text, then click its edit button
  const editBtn = page.locator('div[style*="flex"]').filter({ hasText: label }).locator('button .el-icon-edit').first()
  if ((await editBtn.count()) === 0) throw new Error('No edit icon for: ' + label)
  await editBtn.click({ force: true })
  await page.waitForTimeout(800)
}

// Close FieldEditDialog (used by BasicConfigTab)
async function closeFieldDialog(page) {
  const cancelBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("取消")').first()
  if ((await cancelBtn.count()) > 0) {
    await cancelBtn.click()
  } else {
    await page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click()
  }
  await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => page.waitForTimeout(1000))
}

// Close el-dialog (used by BuiltInRulesTab)
async function closeDialog(page) {
  const cancelBtn = page.locator('.el-dialog:visible .el-dialog__footer button:has-text("取消")').first()
  if ((await cancelBtn.count()) > 0) {
    await cancelBtn.click()
  } else {
    await page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click()
  }
  await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => page.waitForTimeout(1000))
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  let p = 0, f = 0

  // Login
  try {
    await loginAs(page, 'admin')
    console.log('✅ 登录成功'); p++
  } catch (e) { f++; console.log(`❌ 登录: ${e.message}`); await browser.close(); process.exit(1) }

  // Navigate to policy detail
  try {
    await goToPolicyDetail(page)
    const hasTabs = (await page.locator('.el-tabs__item').count()) > 0
    if (!hasTabs) throw new Error('No tabs found')
    const tabTexts = await page.locator('.el-tabs__item').allTextContents()
    if (!tabTexts.some(t => t.includes('基础配置'))) throw new Error('Missing 基础配置 tab')
    if (!tabTexts.some(t => t.includes('语义分析引擎'))) throw new Error('Missing 语义分析引擎 tab')
    if (!tabTexts.some(t => t.includes('内置规则'))) throw new Error('Missing 内置规则 tab')
    console.log('✅ 策略详情页加载（3个Tab完整）'); p++
  } catch (e) { f++; console.log(`❌ 策略详情页加载: ${e.message}`); await browser.close(); process.exit(1) }

  // ==============================
  // 基础配置 Tab
  // ==============================

  // BC1: Verify all config rows have edit icons
  try {
    const expectedLabels = ['解码方法', '拦截方式', '反向代理默认响应页配置', 'HTTP 响应处理', 'HTTP 请求体检测', 'HTTP Body 记录限制', '检测超时限制', '大包绕过防护', '载荷分析']
    let found = 0
    for (const label of expectedLabels) {
      const row = page.locator('div[style*="flex"]').filter({ hasText: label })
      const editIcon = row.locator('button .el-icon-edit')
      if ((await editIcon.count()) > 0) found++
    }
    if (found < expectedLabels.length) throw new Error(`Only ${found}/${expectedLabels.length} rows have edit icons`)
    console.log(`✅ BC1: 基础配置所有行有编辑图标 (${found}/${expectedLabels.length})`); p++
  } catch (e) { f++; console.log(`❌ BC1: 基础配置编辑图标: ${e.message}`) }

  // BC2: Decode method dialog opens with checkboxes
  try {
    await clickRowEdit(page, '解码方法')
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No dialog opened')
    const title = await dialog.locator('.el-dialog__title').textContent()
    if (!title.includes('解码方法')) throw new Error('Wrong dialog title: ' + title)
    const checkboxes = dialog.locator('.el-checkbox')
    if ((await checkboxes.count()) === 0) throw new Error('No checkboxes found')
    await closeFieldDialog(page)
    console.log(`✅ BC2: 解码方法弹窗打开 (${await checkboxes.count()}个选项)`); p++
  } catch (e) { f++; console.log(`❌ BC2: 解码方法弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // BC3: Forbidden page dialog opens with number input for status code
  try {
    await clickRowEdit(page, '拦截方式')
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No dialog opened')
    const dialogText = await dialog.textContent()
    if (!dialogText.includes('HTTP 状态码')) throw new Error('Missing HTTP 状态码 field')
    const numberInput = dialog.locator('input[type="number"]')
    if ((await numberInput.count()) === 0) throw new Error('No number input in dialog')
    // 阻断页面 select only shows when status_code is set and non-redirect
    // Check if el-select exists (may or may not depending on current policy config)
    const selectCount = await dialog.locator('.el-select').count()
    const hasSelectOrRedirect = selectCount > 0 || dialogText.includes('重定向地址')
    if (!hasSelectOrRedirect && !dialogText.includes('默认返回')) throw new Error('No block page select or redirect field')
    await closeFieldDialog(page)
    console.log(`✅ BC3: 拦截方式弹窗含数字输入+配置项(${selectCount > 0 ? '阻断页面选择' : '重定向/警告'})`); p++
  } catch (e) { f++; console.log(`❌ BC3: 拦截方式弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // BC4: HTTP response detection dialog opens with switch
  try {
    await clickRowEdit(page, 'HTTP 响应处理')
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No dialog opened')
    const sw = dialog.locator('.el-switch')
    if ((await sw.count()) === 0) throw new Error('No switch in dialog')
    await closeFieldDialog(page)
    console.log('✅ BC4: HTTP响应处理弹窗含开关'); p++
  } catch (e) { f++; console.log(`❌ BC4: HTTP响应处理弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // BC5: Timeout dialog opens with switch and number inputs
  try {
    await clickRowEdit(page, '检测超时限制')
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No dialog opened')
    const switches = dialog.locator('.el-switch')
    if ((await switches.count()) < 1) throw new Error('No switch in timeout dialog')
    const inputs = dialog.locator('input[type="number"], input[autocomplete="off"]')
    if ((await inputs.count()) === 0) throw new Error('No number input in timeout dialog')
    await closeFieldDialog(page)
    console.log('✅ BC5: 检测超时弹窗含开关+数字输入'); p++
  } catch (e) { f++; console.log(`❌ BC5: 检测超时弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // BC6: Body size check dialog opens
  try {
    await clickRowEdit(page, '大包绕过防护')
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No dialog opened')
    const title = await dialog.locator('.el-dialog__title').textContent()
    if (!title.includes('大包绕过')) throw new Error('Wrong dialog: ' + title)
    await closeFieldDialog(page)
    console.log('✅ BC6: 大包绕过防护弹窗正常'); p++
  } catch (e) { f++; console.log(`❌ BC6: 大包绕过防护弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // BC7: Payload explain dialog opens with switch
  try {
    await clickRowEdit(page, '载荷分析')
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No dialog opened')
    const sw = dialog.locator('.el-switch')
    if ((await sw.count()) === 0) throw new Error('No switch in payload dialog')
    await closeFieldDialog(page)
    console.log('✅ BC7: 载荷分析弹窗含开关'); p++
  } catch (e) { f++; console.log(`❌ BC7: 载荷分析弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // BC8: Edit + cancel does not save (decode method)
  try {
    const row = page.locator('div[style*="flex"]').filter({ hasText: '解码方法' })
    const valueSpan = row.locator('span').nth(1)
    const originalValue = (await valueSpan.textContent()).trim()
    await clickRowEdit(page, '解码方法')
    const dialog = page.locator('.el-dialog:visible').first()
    const firstCb = dialog.locator('.el-checkbox').first()
    await firstCb.click()
    await page.waitForTimeout(300)
    await closeFieldDialog(page)
    await page.waitForTimeout(800)
    const afterCancel = (await valueSpan.textContent()).trim()
    if (afterCancel !== originalValue) throw new Error(`Cancel should not save: "${originalValue}" → "${afterCancel}"`)
    console.log('✅ BC8: 取消编辑不保存'); p++
  } catch (e) { f++; console.log(`❌ BC8: 取消不保存: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // ==============================
  // 语义分析引擎 Tab
  // ==============================

  // SE1: Switch to semantic engine tab
  try {
    await page.locator('.el-tabs__item').filter({ hasText: '语义分析引擎' }).click()
    await page.waitForTimeout(2000)
    console.log('✅ SE1: 语义分析引擎Tab渲染成功'); p++
  } catch (e) { f++; console.log(`❌ SE1: 语义分析引擎Tab: ${e.message}`) }

  // SE2: Master switch card shows status tag (已启用/已禁用)
  // Note: page header has a "默认策略" tag, the status tag is inside the master switch card
  try {
    const statusTag = page.locator('div[style*="flex"]').filter({ hasText: '攻击检测模块' }).locator('.el-tag')
    if ((await statusTag.count()) === 0) throw new Error('No status tag in master switch card')
    const tagText = (await statusTag.first().textContent()).trim()
    if (!['已启用', '已禁用'].includes(tagText)) throw new Error('Unexpected tag text: ' + tagText)
    console.log(`✅ SE2: 总开关状态标签: ${tagText}`); p++
  } catch (e) { f++; console.log(`❌ SE2: 总开关状态: ${e.message}`) }

  // SE3: Master switch edit icon opens dialog with switch + 2 sliders
  try {
    const masterEditBtn = page.locator('div[style*="flex"]').filter({ hasText: '攻击检测模块' }).locator('button .el-icon-edit')
    await masterEditBtn.click({ force: true })
    await page.waitForTimeout(1000)
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No dialog opened')
    const switches = dialog.locator('.el-switch')
    const sliders = dialog.locator('.el-slider')
    if ((await switches.count()) === 0) throw new Error('No switch in dialog')
    if ((await sliders.count()) < 2) throw new Error(`Expected 2 sliders, got ${await sliders.count()}`)
    await closeFieldDialog(page)
    console.log('✅ SE3: 总开关编辑弹窗含开关+2个滑块'); p++
  } catch (e) { f++; console.log(`❌ SE3: 总开关编辑弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // SE4: Module cards are rendered (16 modules)
  try {
    const moduleNames = ['SQL注入', 'XSS', 'CSRF', 'SSRF', '模板注入', 'PHP序列化', 'Java反序列化', '文件上传', '文件包含', 'PHP注入', 'Java注入', '命令注入', '服务端响应', '扫描器', 'HTTP协议', 'ASP注入']
    let found = 0
    for (const name of moduleNames) {
      const el = page.locator('div[style*="flex"]').filter({ hasText: name }).locator('button .el-icon-edit')
      if ((await el.count()) > 0) found++
    }
    if (found < 10) throw new Error(`Only ${found}/16 module cards found`)
    console.log(`✅ SE4: 模块卡片渲染 (${found}/16)`); p++
  } catch (e) { f++; console.log(`❌ SE4: 模块卡片: ${e.message}`) }

  // SE5: Edit a module card opens dialog with blocking + logging sliders (4-level, max=3)
  try {
    // Use evaluate to click the SQL注入 module edit button (avoids Playwright locator conflicts)
    await page.evaluate(() => {
      const flexDivs = document.querySelectorAll('div[style*="flex"]')
      for (const div of flexDivs) {
        if (div.offsetWidth > 0 && div.textContent?.includes('SQL注入检测模块')) {
          const btn = div.querySelector('button')
          if (btn) { btn.click(); break }
        }
      }
    })
    await page.waitForTimeout(2000)
    const dialog = page.locator('.el-dialog:visible').first()
    if ((await dialog.count()) === 0) throw new Error('No module dialog opened')
    // Verify slider has max=3 (4-level) via Vue instance (Element UI slider has no native input)
    const sliderState = await page.evaluate(() => {
      const dialogs = document.querySelectorAll('.el-dialog')
      let visibleDialog = null
      for (const d of dialogs) {
        if (d.offsetWidth > 0 && d.offsetHeight > 0) visibleDialog = d
      }
      if (!visibleDialog) return null
      const sliders = visibleDialog.querySelectorAll('.el-slider')
      return Array.from(sliders).map(s => {
        const vm = s.__vue__
        return vm ? { value: vm.value, min: vm.min, max: vm.max } : null
      }).filter(Boolean)
    })
    if (!sliderState || sliderState.length < 2) throw new Error(`Expected 2 sliders, got ${sliderState?.length || 0}`)
    if (sliderState[0].max !== 3) throw new Error(`Blocking slider max should be 3, got ${sliderState[0].max}`)
    if (sliderState[1].max !== 3) throw new Error(`Logging slider max should be 3, got ${sliderState[1].max}`)
    await closeFieldDialog(page)
    console.log('✅ SE5: 模块编辑弹窗含4级阻断+日志滑块 (max=3)'); p++
  } catch (e) { f++; console.log(`❌ SE5: 模块编辑弹窗: ${e.message}`); await closeFieldDialog(page).catch(() => {}) }

  // ==============================
  // 内置规则 Tab
  // ==============================

  // BR1: Switch to built-in rules tab
  try {
    await page.locator('.el-tabs__item').filter({ hasText: '内置规则' }).click()
    await page.waitForTimeout(3000)
    await waitForTableData(page).catch(() => page.waitForTimeout(2000))
    console.log('✅ BR1: 内置规则Tab加载'); p++
  } catch (e) { f++; console.log(`❌ BR1: 内置规则Tab: ${e.message}`) }

  // BR2: Table has expected column headers
  try {
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    const required = ['状态', '动作', '规则名称', '攻击类型']
    const missing = required.filter(h => !headers.some(th => th.includes(h)))
    if (missing.length > 0) throw new Error('Missing columns: ' + missing.join(', '))
    console.log('✅ BR2: 内置规则表列头完整'); p++
  } catch (e) { f++; console.log(`❌ BR2: 列头检查: ${e.message}`) }

  // BR3: Table has rows (rules exist)
  try {
    const total = await getRows(page)
    if (total === 0) throw new Error('No rules in table')
    console.log(`✅ BR3: 内置规则表有数据 (${total}行)`); p++
  } catch (e) { f++; console.log(`❌ BR3: 内置规则数据: ${e.message}`) }

  // BR4: Edit button exists in each row
  try {
    const editButtons = page.locator('.el-table__body button .el-icon-edit')
    const count = await editButtons.count()
    if (count === 0) throw new Error('No edit buttons in table')
    console.log(`✅ BR4: 编辑按钮存在 (${count}个)`); p++
  } catch (e) { f++; console.log(`❌ BR4: 编辑按钮: ${e.message}`) }

  // BR5: Edit dialog opens with correct form fields
  try {
    const editBtn = page.locator('.el-table__body button .el-icon-edit').first()
    await editBtn.click({ force: true })
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    const dialog = page.locator('.el-dialog:visible').first()

    // Verify form field labels
    const dialogText = await dialog.textContent()
    const requiredLabels = ['规则名称', '状态', '备注', '模式', '记录日志', '严重级别']
    const missing = requiredLabels.filter(l => !dialogText.includes(l))
    if (missing.length > 0) throw new Error('Missing form fields: ' + missing.join(', '))

    // Verify action select has 拦截/观察 options — click the "模式" select (2nd select, after tag)
    const selects = dialog.locator('.el-select')
    const selectCount = await selects.count()
    // The action select is the one showing "拦截" or "观察" as current value
    let actionSelectIdx = -1
    for (let i = 0; i < selectCount; i++) {
      const val = await selects.nth(i).locator('input').first().inputValue().catch(() => '')
      if (val.includes('拦截') || val.includes('观察') || val.includes('deny') || val.includes('dry_run')) {
        actionSelectIdx = i
        break
      }
    }
    // If not found by value, try the 2nd select (1st is tag)
    if (actionSelectIdx === -1) actionSelectIdx = Math.min(1, selectCount - 1)
    await selects.nth(actionSelectIdx).click()
    await page.waitForTimeout(300)
    const actionOptions = await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').allTextContents()
    await page.keyboard.press('Escape')
    await page.waitForTimeout(300)
    if (!actionOptions.some(o => o.includes('拦截'))) throw new Error('Missing 拦截 option, got: ' + actionOptions.join(', '))
    if (!actionOptions.some(o => o.includes('观察'))) throw new Error('Missing 观察 option, got: ' + actionOptions.join(', '))

    await closeDialog(page)
    console.log('✅ BR5: 编辑弹窗含所有必要字段'); p++
  } catch (e) { f++; console.log(`❌ BR5: 编辑弹窗字段: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // BR6: Edit dialog has switches for 状态 and 记录日志
  try {
    const editBtn = page.locator('.el-table__body button .el-icon-edit').first()
    await editBtn.click({ force: true })
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    const dialog = page.locator('.el-dialog:visible').first()
    const switches = dialog.locator('.el-switch')
    if ((await switches.count()) < 2) throw new Error(`Expected at least 2 switches, got ${await switches.count()}`)
    await closeDialog(page)
    console.log('✅ BR6: 编辑弹窗含状态+日志开关'); p++
  } catch (e) { f++; console.log(`❌ BR6: 编辑弹窗开关: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // BR7: 严重级别 select has 4 options (低危/中危/高危/严重)
  try {
    const editBtn = page.locator('.el-table__body button .el-icon-edit').first()
    await editBtn.click({ force: true })
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    const dialog = page.locator('.el-dialog:visible').first()

    // Find the risk_level select by looking for one with 低危/中危/高危/严重 current value
    const selects = dialog.locator('.el-select')
    const selectCount = await selects.count()
    let riskSelectIdx = -1
    for (let i = 0; i < selectCount; i++) {
      const val = await selects.nth(i).locator('input').first().inputValue().catch(() => '')
      if (val.match(/危|严重/)) { riskSelectIdx = i; break }
    }
    if (riskSelectIdx === -1) riskSelectIdx = selectCount - 1
    await selects.nth(riskSelectIdx).click()
    await page.waitForTimeout(300)
    const riskOptions = await page.locator('.el-select-dropdown:visible .el-select-dropdown__item').allTextContents()
    await page.keyboard.press('Escape')
    const expected = ['低危', '中危', '高危', '严重']
    const missing = expected.filter(e => !riskOptions.some(o => o.includes(e)))
    if (missing.length > 0) throw new Error('Missing risk options: ' + missing.join(', '))

    await closeDialog(page)
    console.log('✅ BR7: 严重级别含4个选项'); p++
  } catch (e) { f++; console.log(`❌ BR7: 严重级别选项: ${e.message}`); await closeDialog(page).catch(() => {}) }

  // BR8: Obsolete rules show tag
  try {
    const obsoleteTag = page.locator('.el-table__body .el-tag--info').filter({ hasText: /已停用|停用/ })
    const obsoleteCount = await obsoleteTag.count()
    if (obsoleteCount > 0) {
      console.log(`✅ BR8: 已停用规则标记正常 (${obsoleteCount}条)`); p++
    } else {
      console.log('✅ BR8: 无已停用规则（正常）'); p++
    }
  } catch (e) { f++; console.log(`❌ BR8: 已停用标记: ${e.message}`) }

  // BR9: Pagination works
  try {
    const pagination = page.locator('.el-pagination')
    if ((await pagination.count()) > 0) {
      const totalText = await pagination.locator('.el-pagination__total').first().textContent().catch(() => '')
      console.log(`✅ BR9: 分页组件存在 (total: ${totalText.trim() || 'N/A'})`); p++
    } else {
      console.log('✅ BR9: 分页组件存在（规则数少无需分页）'); p++
    }
  } catch (e) { f++; console.log(`❌ BR9: 分页: ${e.message}`) }

  console.log(`\n📊 PolicyDetail: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
