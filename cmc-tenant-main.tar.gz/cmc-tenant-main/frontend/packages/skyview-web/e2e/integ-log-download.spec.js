// E2E Test: Detect log download feature — real backend + real Captain
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForTableData, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

async function getLogTasks(page) {
  const resp = await page.evaluate(async () => {
    const r = await fetch('/api/captain/log-task/list?offset=0&count=20', { credentials: 'include' })
    return r.json()
  })
  return resp.data?.items || []
}

async function waitForNewCompletedTask(page, beforeIds, type, timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const tasks = await getLogTasks(page)
    const task = tasks.find(t => (
      !beforeIds.has(Number(t.id)) &&
      t.name === 'detect_log' &&
      t.type === type &&
      t.status === 'completed'
    ))
    if (task) return task
    await page.waitForTimeout(1500)
  }
  throw new Error(`Timed out waiting for completed ${type} log task`)
}

async function waitForNewTask(page, beforeIds, type, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const tasks = await getLogTasks(page)
    const task = tasks.find(t => (
      !beforeIds.has(Number(t.id)) &&
      t.name === 'detect_log' &&
      t.type === type
    ))
    if (task) return task
    await page.waitForTimeout(1000)
  }
  throw new Error(`Timed out waiting for new ${type} log task`)
}

async function downloadTaskSize(page, id) {
  return page.evaluate(async taskId => {
    const r = await fetch(`/api/captain/log-task/${taskId}/download`, {
      method: 'POST',
      credentials: 'include',
    })
    if (!r.ok) throw new Error(`download failed: ${r.status}`)
    const buf = await r.arrayBuffer()
    return buf.byteLength
  }, id)
}

async function deleteLogTask(page, id) {
  await page.evaluate(async taskId => {
    await fetch('/api/captain/log-task/delete', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: [taskId] }),
      credentials: 'include',
    })
  }, id).catch(() => {})
}

async function ensureFirstRowSelected(page) {
  const downloadBtn = page.locator('button:has-text("下载选中日志")').first()
  if (await downloadBtn.getAttribute('disabled')) {
    await page.locator('.el-table__body-wrapper .el-checkbox').first().click()
    await page.waitForTimeout(500)
  }
  if (await downloadBtn.getAttribute('disabled')) {
    throw new Error('Download button should be enabled after selecting a row')
  }
}

async function waitForDropdownOptions(page) {
  const dropdown = page.locator('.el-select-dropdown:not([style*="display: none"])').last()
  await dropdown.locator('.el-select-dropdown__item').first()
    .waitFor({ state: 'visible', timeout: 10000 })
  return dropdown
}

async function addTextFilter(page, label, value) {
  const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')
  await addBtn.waitFor({ state: 'visible', timeout: 10000 })
  await addBtn.click()
  const item = page.locator('.condition-filter__item').last()
  await item.locator('.el-select .el-input__inner').first().click()
  const dropdown = await waitForDropdownOptions(page)
  await dropdown.locator('.el-select-dropdown__item').filter({ hasText: label }).first().click()

  const inputs = item.locator('.condition-filter__sub-item input')
  for (let i = 0; i < await inputs.count(); i++) {
    const input = inputs.nth(i)
    if ((await input.isVisible()) && !(await input.evaluate(el => el.readOnly))) {
      await input.fill(value)
      return
    }
  }
  throw new Error(`No writable input for ${label}`)
}

async function firstRowWebsiteName(page) {
  const cells = await page.locator('.el-table__body-wrapper .el-table__row').first().locator('td').allTextContents()
  const firstText = cells.map(t => t.trim()).find(Boolean)
  return (firstText || 'cmc-e2e-no-such-site').split(/\s+/)[0]
}

async function createFilteredDownloadTask(page, type, websiteName) {
  return page.evaluate(async ({ format, siteName }) => {
    const r = await fetch('/api/captain/log-task/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'detect_log',
        type: format,
        ids: [],
        all: true,
        conditions: [{
          target: 'website_name',
          items: [{ oper: 'contains', value: siteName }],
        }],
      }),
      credentials: 'include',
    })
    const body = await r.json().catch(() => ({}))
    return { status: r.status, body }
  }, { format: type, siteName: websiteName })
}

async function createSelectedDownloadTaskFromUI(page, type) {
  const createReqPromise = page.waitForRequest(req => (
    req.method() === 'POST' &&
    req.url().includes('/api/captain/log-task/create')
  ), { timeout: 10000 })
  const createRespPromise = page.waitForResponse(resp => (
    resp.request().method() === 'POST' &&
    resp.url().includes('/api/captain/log-task/create')
  ), { timeout: 10000 }).catch(() => null)

  await page.locator('button:has-text("下载选中日志")').first().click()
  const option = page.locator(`.el-dropdown-menu:visible .el-dropdown-menu__item:has-text("下载选中日志(.${type})")`).first()
  await option.click({ timeout: 5000 })

  const confirmBtn = page.locator('.el-message-box__wrapper:visible .el-button--primary').first()
  await confirmBtn.click({ timeout: 5000 }).catch(() => {})

  const req = await createReqPromise
  const resp = await createRespPromise
  if (resp && resp.status() >= 400) throw new Error(`create task failed: ${resp.status()}`)

  return JSON.parse(req.postData() || '{}')
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()

  // Capture API errors for easier CI debugging
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  let p = 0, f = 0

  // ---- Test 1: Download buttons visible on detect log page ----
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await waitForTableData(page)

    // Check download dropdown button exists
    const downloadBtn = page.locator('button:has-text("下载选中日志")')
    if (await downloadBtn.count() === 0) throw new Error('Download button not found')
    console.log('✅ Download button visible on detect log page'); p++
  } catch (e) { f++; console.log(`❌ Download button visibility: ${e.message}`) }

  // ---- Test 2: Download button disabled when no rows selected ----
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await waitForTableData(page)

    const downloadBtn = page.locator('button:has-text("下载选中日志")')
    if (await downloadBtn.count() === 0) throw new Error('Download button not found')
    const isDisabled = await downloadBtn.first().getAttribute('disabled')
    if (!isDisabled) throw new Error('Download button should be disabled when no rows selected')
    console.log('✅ Download button disabled when no selection'); p++
  } catch (e) { f++; console.log(`❌ Download button disabled state: ${e.message}`) }

  // ---- Test 3: Download button enabled after selecting rows ----
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No detect log rows to select, skipping selection test'); p++
    } else {
      // Select first row checkbox
      await page.locator('.el-table__body-wrapper .el-checkbox').first().click()
      await page.waitForTimeout(500)

      const downloadBtn = page.locator('button:has-text("下载选中日志")')
      if (await downloadBtn.count() === 0) throw new Error('Download button not found')
      const isDisabled = await downloadBtn.first().getAttribute('disabled')
      if (isDisabled) throw new Error('Download button should be enabled after selection')
      console.log('✅ Download button enabled after row selection'); p++
    }
  } catch (e) { f++; console.log(`❌ Download button enabled state: ${e.message}`) }

  // ---- Test 4: Download dropdown shows JSON and CSV options ----
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No detect log rows, skipping dropdown test'); p++
    } else {
      // Select a row first
      await ensureFirstRowSelected(page)

      // Force click the dropdown trigger (bypass disabled check since we just selected)
      const downloadBtn = page.locator('button:has-text("下载选中日志")')
      await downloadBtn.first().click({ force: true })
      await page.waitForTimeout(500)

      // Check dropdown items
      const jsonOption = page.locator('.el-dropdown-menu__item:has-text("下载选中日志(.json)")')
      const csvOption = page.locator('.el-dropdown-menu__item:has-text("下载选中日志(.csv)")')
      if (await jsonOption.count() === 0 && await csvOption.count() === 0) throw new Error('No download dropdown options found')
      console.log('✅ Download dropdown shows JSON and CSV options'); p++

      // Close dropdown by clicking elsewhere
      await page.keyboard.press('Escape')
    }
  } catch (e) { f++; console.log(`❌ Download dropdown options: ${e.message}`) }

  // ---- Test 5: Create download task (JSON) with website_name condition ----
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No detect log rows, skipping download task creation test'); p++
    } else {
      const beforeIds = new Set((await getLogTasks(page)).map(t => Number(t.id)))
      const siteName = await firstRowWebsiteName(page)
      const resp = await createFilteredDownloadTask(page, 'json', siteName)
      if (resp.status >= 400) throw new Error(`create task failed: ${resp.status} ${JSON.stringify(resp.body)}`)
      if (resp.body?.err) throw new Error(`create task returned err=${resp.body.err}`)

      const task = await waitForNewCompletedTask(page, beforeIds, 'json', 10000).catch(() => null)
      if (task) await deleteLogTask(page, task.id)
      console.log(`✅ Download task created with website_name condition: site=${siteName}, status=${resp.status}`); p++
    }
  } catch (e) { f++; console.log(`❌ Filtered download task creation: ${e.message}`) }

  // ---- Test 6: CSV task downloads non-empty content for a real selected log ----
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await page.reload({ waitUntil: 'domcontentloaded' })
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No detect log rows, skipping CSV content test'); p++
    } else {
      const beforeIds = new Set((await getLogTasks(page)).map(t => Number(t.id)))

      await ensureFirstRowSelected(page)
      const body = await createSelectedDownloadTaskFromUI(page, 'csv')
      if (body.name !== 'detect_log') throw new Error(`Expected name="detect_log", got "${body.name}"`)
      if (body.type !== 'csv') throw new Error(`Expected type="csv", got "${body.type}"`)
      if (!Array.isArray(body.ids) || body.ids.length === 0) throw new Error('ids should be non-empty array')

      const task = await waitForNewCompletedTask(page, beforeIds, 'csv')
      let size = 0
      try {
        size = await downloadTaskSize(page, task.id)
      } finally {
        await deleteLogTask(page, task.id)
      }
      if (size <= 500) throw new Error(`CSV download is too small (${size} bytes)`)
      console.log(`✅ CSV download contains data: task=${task.id}, zip=${size} bytes`); p++
    }
  } catch (e) { f++; console.log(`❌ CSV download content: ${e.message}`) }

  // ---- Test 7: Empty selected IDs are rejected before creating Captain task ----
  try {
    const resp = await page.evaluate(async () => {
      const r = await fetch('/api/captain/log-task/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'detect_log',
          type: 'csv',
          ids: [],
          all: false,
        }),
        credentials: 'include',
      })
      const body = await r.json().catch(() => ({}))
      return { status: r.status, body }
    })

    if (resp.status !== 400) throw new Error(`Expected 400, got ${resp.status}`)
    if (resp.body?.err !== 'bad_request') throw new Error(`Expected err=bad_request, got ${resp.body?.err}`)
    console.log('✅ Empty selected IDs rejected with 400'); p++
  } catch (e) { f++; console.log(`❌ Empty selected IDs rejection: ${e.message}`) }

  // ---- Test 8: tenant_admin detect_log download task is scoped and visible ----
  try {
    await loginAs(page, 'tenant_admin')
    const beforeIds = new Set((await getLogTasks(page)).map(t => Number(t.id)))
    const listResp = await page.evaluate(async () => {
      const r = await fetch('/api/captain/detect-log/list', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ offset: 0, count: 1 }),
        credentials: 'include',
      })
      const body = await r.json().catch(() => ({}))
      return { status: r.status, body }
    })
    if (listResp.status >= 400) throw new Error(`detect log list failed: ${listResp.status}`)
    if (listResp.body?.err !== null) throw new Error(`detect log list err=${listResp.body?.err}`)

    const firstLog = listResp.body?.data?.items?.[0]
    const logId = firstLog?.id || firstLog?.uuid
    if (!logId) {
      console.log('⏭️  No tenant detect log rows, skipping tenant task creation test'); p++
    } else {
      const resp = await page.evaluate(async selectedLogId => {
        const r = await fetch('/api/captain/log-task/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: 'detect_log',
            type: 'json',
            ids: [selectedLogId],
            all: false,
          }),
          credentials: 'include',
        })
        const body = await r.json().catch(() => ({}))
        return { status: r.status, body }
      }, logId)

      if (resp.status >= 400) throw new Error(`create failed: ${resp.status} ${resp.body?.msg || ''}`)
      if (resp.body?.err !== null) throw new Error(`Expected err=null, got ${resp.body?.err}`)

      const task = await waitForNewTask(page, beforeIds, 'json')
      await deleteLogTask(page, task.id)
      console.log(`✅ tenant_admin detect_log task created with tenant scope: task=${task.id}`); p++
    }
  } catch (e) { f++; console.log(`❌ tenant_admin detect_log task tenant scope: ${e.message}`) }

  console.log(`\n📊 Detect Log Download: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
