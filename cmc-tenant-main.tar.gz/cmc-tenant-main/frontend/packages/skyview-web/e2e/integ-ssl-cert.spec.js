// Integration: SSL cert — list/detail/upload/edit/shared protection
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  const adminCookieHeader = await getAuthCookieHeader(page, 'admin')
  const captainInstanceId = await getActiveWafId(page, adminCookieHeader)
  await page.evaluate(id => { window.__E2E_CAPTAIN_INSTANCE_ID__ = id }, captainInstanceId)
  console.log(`  Using captain_instance_id=${captainInstanceId}`)
  let p = 0, f = 0

  // === 列表页 ===

  // 1. 列表页加载
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)
    console.log('✅ SSL证书列表页加载'); p++
  } catch (e) { f++; console.log(`❌ SSL证书列表页加载: ${e.message}`) }

  // 2. 列表页列头验证
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    const required = ['证书名称', '使用情况', '创建时间', '操作']
    for (const col of required) {
      if (!headers.some(h => h.includes(col))) throw new Error(`Missing column: ${col}`)
    }
    // Old columns should be removed
    if (headers.some(h => h.includes('ID') && !h.includes('SSL'))) throw new Error('Old ID column still present')
    console.log('✅ 列表页列头正确（证书名称/使用情况/创建时间/操作）'); p++
  } catch (e) { f++; console.log(`❌ 列表页列头检查: ${e.message}`) }

  // 3. 使用情况渲染
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows > 0) {
      const usageTexts = await page.locator('.el-table__body-wrapper .el-table__row td:nth-child(2) .cell').allTextContents()
      const hasUsage = usageTexts.some(t => t.includes('系统使用中') || t.includes('站点正在使用') || t.includes('未使用'))
      if (!hasUsage) throw new Error('No usage status text found in rows')
      console.log(`✅ 使用情况渲染正常（${rows}行）`); p++
    } else {
      console.log('⚠️ 无证书数据，跳过使用情况测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 使用情况渲染: ${e.message}`) }

  // 4. 共享证书删除拦截
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    // Find a shared cert via API
    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const sharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) > 1)

    if (sharedCert) {
      // Click delete button on shared cert row
      const row = page.locator('.el-table__row').filter({ hasText: sharedCert.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()
      if (await deleteBtn.count() > 0) {
        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message').filter({ hasText: /多个租户组绑定|站点使用/ }).count()
        if (warningVisible === 0) throw new Error('Shared cert delete should show warning')
        console.log(`✅ 共享证书(id=${sharedCert.id})删除被阻止`); p++
      } else {
        console.log('⚠️ 共享证书行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无共享证书(binding_count>1)，跳过删除拦截测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 共享证书删除拦截: ${e.message}`) }

  // 5. 非共享证书可删除（弹出确认框）
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const nonSharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) <= 1 && !c.is_mgt_api_cert && (!c.websites || c.websites.length === 0))

    if (nonSharedCert) {
      const row = page.locator('.el-table__row').filter({ hasText: nonSharedCert.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()
      if (await deleteBtn.count() > 0) {
        await deleteBtn.click()
        await page.waitForTimeout(500)
        const confirmVisible = await page.locator('.el-message-box:visible').count()
        if (confirmVisible === 0) throw new Error('Non-shared cert delete should show confirm dialog')
        // Cancel the dialog
        await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click()
        console.log(`✅ 非共享证书(id=${nonSharedCert.id})可删除（弹出确认框）`); p++
      } else {
        console.log('⚠️ 非共享证书行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无非共享非系统证书，跳过删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 非共享证书删除: ${e.message}`) }

  // === 详情页 ===

  // 6. 详情页 KV 展示
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const rows = await getRows(page)
    if (rows > 0) {
      // Click first row's view button
      const viewBtn = page.locator('.el-table__row').first().locator('.el-icon-view').first()
      await viewBtn.click()
      await page.waitForTimeout(2000)

      const pageText = await page.locator('.el-card').first().textContent()
      const requiredFields = ['名称', '证书文件', '证书签名', '上传时间', '颁发者', '序列号', '有效期', '域名', '关联站点']
      for (const field of requiredFields) {
        if (!pageText.includes(field)) throw new Error(`Missing detail field: ${field}`)
      }
      console.log('✅ 详情页 KV 展示完整'); p++
    } else {
      console.log('⚠️ 无证书数据，跳过详情页测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 详情页 KV 展示: ${e.message}`) }

  // 7. 非共享证书详情页编辑图标可见
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const nonSharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) <= 1 && !c.is_mgt_api_cert && (!c.websites || c.websites.length === 0))

    if (nonSharedCert) {
      const row = page.locator('.el-table__row').filter({ hasText: nonSharedCert.name }).first()
      await row.locator('.el-icon-view').first().click()
      await page.waitForTimeout(2000)

      const editIcons = await page.locator('.el-icon-edit').count()
      if (editIcons < 2) throw new Error(`Non-shared cert should have 2 edit icons, found ${editIcons}`)
      console.log(`✅ 非共享证书详情页编辑图标可见（${editIcons}个）`); p++
    } else {
      console.log('⚠️ 无非共享非系统证书，跳过编辑图标测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 非共享证书编辑图标: ${e.message}`) }

  // 8. 共享证书详情页编辑图标置灰
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const sharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) > 1)

    if (sharedCert) {
      const row = page.locator('.el-table__row').filter({ hasText: sharedCert.name }).first()
      await row.locator('.el-icon-view').first().click()
      await page.waitForTimeout(2000)

      const editIcons = await page.locator('.el-icon-edit').count()
      if (editIcons > 0) {
        // Admin: edit icon should be blue (clickable), clicking shows confirmation dialog
        const firstIcon = page.locator('.el-icon-edit').first()
        const iconStyle = await firstIcon.getAttribute('style')
        const isBlue = iconStyle && (iconStyle.includes('#409EFF') || iconStyle.includes('rgb(64, 158, 255)'))
        if (!isBlue) throw new Error(`Admin on shared cert: edit icon should be blue, style=${iconStyle}`)
        await firstIcon.click()
        await page.waitForTimeout(500)
        const confirmBox = page.locator('.el-message-box')
        const hasConfirm = await confirmBox.isVisible().catch(() => false)
        if (!hasConfirm) throw new Error('Admin click on shared cert edit icon should show confirmation dialog')
        await page.locator('.el-message-box__btns .el-button').first().click().catch(() => {})
        await page.waitForTimeout(300)
        console.log(`✅ 共享证书详情页 admin 编辑图标蓝色+确认框`); p++
      } else {
        console.log(`✅ 共享证书详情页编辑图标已隐藏`); p++
      }
    } else {
      console.log('⚠️ 无共享证书，跳过编辑图标测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 共享证书编辑图标: ${e.message}`) }

  // 9. 详情页关联站点仅显示有权限站点（tenant_admin 验证）
  // Admin sees all sites, tenant_admin sees only bound sites — verified in tenant isolation test below

  // === 添加证书对话框 ===

  // 10. 添加证书对话框字段验证
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    await page.locator('button:has-text("添加SSL证书")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    const dialog = page.locator('.el-dialog:visible').first()

    const dialogText = await dialog.textContent()
    if (!dialogText.includes('证书名称')) throw new Error('Missing 证书名称')
    if (!dialogText.includes('是否含私钥')) throw new Error('Missing 是否含私钥')
    if (!dialogText.includes('证书文件')) throw new Error('Missing 证书文件')
    if (!dialogText.includes('证书密码')) throw new Error('Missing 证书密码')

    // Verify drag upload areas exist
    const uploadAreas = await dialog.locator('.el-upload-dragger').count()
    if (uploadAreas < 1) throw new Error('Missing drag upload area')

    // Close dialog
    await dialog.locator('.el-dialog__headerbtn').first().click()
    console.log('✅ 添加证书对话框字段完整（名称/私钥/文件/密码）'); p++
  } catch (e) { f++; console.log(`❌ 添加证书对话框: ${e.message}`) }

  // === 编辑功能 ===

  // 11. 非共享证书可编辑名称
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const nonSharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) <= 1 && !c.is_mgt_api_cert && (!c.websites || c.websites.length === 0))

    if (nonSharedCert) {
      const row = page.locator('.el-table__row').filter({ hasText: nonSharedCert.name }).first()
      await row.locator('.el-icon-view').first().click()
      await page.waitForTimeout(2000)

      // Click first edit icon (name)
      const editIcon = page.locator('.el-icon-edit').first()
      if (await editIcon.count() > 0) {
        await editIcon.click()
        await page.waitForTimeout(500)
        // Edit name dialog should appear
        const editDialog = page.locator('.el-dialog:visible').first()
        const dialogTitle = await editDialog.locator('.el-dialog__title').textContent().catch(() => '')
        if (!dialogTitle.includes('编辑名称')) throw new Error(`Expected 编辑名称 dialog, got: ${dialogTitle}`)
        await editDialog.locator('.el-dialog__headerbtn').first().click()
        console.log('✅ 非共享证书可编辑名称（弹出编辑对话框）'); p++
      } else {
        console.log('⚠️ 未找到编辑图标'); p++
      }
    } else {
      console.log('⚠️ 无非共享非系统证书，跳过编辑名称测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 编辑名称: ${e.message}`) }

  // 12. 非共享证书可编辑证书文件
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const nonSharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) <= 1 && !c.is_mgt_api_cert && (!c.websites || c.websites.length === 0))

    if (nonSharedCert) {
      const row = page.locator('.el-table__row').filter({ hasText: nonSharedCert.name }).first()
      await row.locator('.el-icon-view').first().click()
      await page.waitForTimeout(2000)

      // Click second edit icon (cert file)
      const editIcons = page.locator('.el-icon-edit')
      if (await editIcons.count() >= 2) {
        await editIcons.nth(1).click()
        await page.waitForTimeout(500)
        const editDialog = page.locator('.el-dialog:visible').first()
        const dialogTitle = await editDialog.locator('.el-dialog__title').textContent().catch(() => '')
        if (!dialogTitle.includes('编辑证书文件')) throw new Error(`Expected 编辑证书文件 dialog, got: ${dialogTitle}`)
        await editDialog.locator('.el-dialog__headerbtn').first().click()
        console.log('✅ 非共享证书可编辑证书文件（弹出编辑对话框）'); p++
      } else {
        console.log('⚠️ 未找到证书文件编辑图标'); p++
      }
    } else {
      console.log('⚠️ 无非共享非系统证书，跳过编辑文件测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 编辑证书文件: ${e.message}`) }

  // === 共享证书后端保护 ===

  // 13. 共享证书 certUpdate 返回 403
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const sharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) > 1)

    if (sharedCert) {
      const updateResp = await page.evaluate(async (certId) => {
        const r = await fetch('/api/captain/cert/update', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: certId, captain_instance_id: window.__E2E_CAPTAIN_INSTANCE_ID__, name: 'test-shared-edit' }),
          credentials: 'include',
        })
        return { status: r.status, body: await r.json() }
      }, sharedCert.id)

      if (updateResp.status !== 200 || updateResp.body?.err !== null) {
        throw new Error(`Admin certUpdate on shared cert: expected 200/null, got ${updateResp.status}: ${JSON.stringify(updateResp.body)}`)
      }
      console.log(`✅ 共享证书 admin certUpdate 返回 200（后端不拦截，由前端确认框代替）`); p++
    } else {
      console.log('⚠️ 无共享证书，跳过 certUpdate 保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 共享证书 certUpdate 保护: ${e.message}`) }

  // 14. 共享证书 certDelete 返回 403
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const certListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const sharedCert = (certListResp.data?.items || []).find(c => (c.binding_count ?? 0) > 1)

    if (sharedCert) {
      const deleteResp = await page.evaluate(async (certId) => {
        const r = await fetch('/api/captain/cert/delete', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id: certId, captain_instance_id: window.__E2E_CAPTAIN_INSTANCE_ID__ }),
          credentials: 'include',
        })
        return { status: r.status, body: await r.json() }
      }, sharedCert.id)

      if (deleteResp.status !== 403 && deleteResp.body?.err !== 'shared') {
        throw new Error(`Expected 403/shared, got ${deleteResp.status}: ${JSON.stringify(deleteResp.body)}`)
      }
      console.log(`✅ 共享证书 certDelete 返回 403/shared`); p++
    } else {
      console.log('⚠️ 无共享证书，跳过 certDelete 保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 共享证书 certDelete 保护: ${e.message}`) }

  // === 租户权限隔离 ===

  // 15. tenant_admin 只能看到本租户组绑定的证书
  try {
    // Get admin cert count
    const adminCertResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    })
    const adminCertCount = adminCertResp.data?.items?.length || 0

    // Login as tenant_admin
    await loginAs(page, 'tenant_admin')
    const tenantCookieHeader = await getAuthCookieHeader(page, 'tenant_admin')
    const tenantCaptainInstanceId = await getActiveWafId(page, tenantCookieHeader)
    await page.evaluate(id => { window.__E2E_CAPTAIN_INSTANCE_ID__ = id }, tenantCaptainInstanceId)
    console.log(`  tenant_admin using captain_instance_id=${tenantCaptainInstanceId}`)

    await navTo(page, '防护管理', 'SSL 证书')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const tenantCertResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/cert/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    })
    const tenantCertCount = tenantCertResp.data?.items?.length || 0

    if (tenantCertCount > adminCertCount) {
      throw new Error(`tenant_admin sees ${tenantCertCount} certs > admin ${adminCertCount}`)
    }
    console.log(`✅ tenant_admin 证书范围: ${tenantCertCount} ≤ admin ${adminCertCount}`); p++

    // Also verify detail page websites filtering for tenant_admin
    if (tenantCertCount > 0) {
      const firstCert = tenantCertResp.data.items[0]
      const detailResp = await page.evaluate(async (certId) => {
        const r = await fetch(`/api/captain/cert/detail?id=${certId}&captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}`, { credentials: 'include' })
        return r.json()
      }, firstCert.id)

      const websites = detailResp.data?.websites || []
      // Get tenant's bound site IDs
      const boundSitesResp = await page.evaluate(async () => {
        const r = await fetch(`/api/captain/site/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=1000`, { credentials: 'include' })
        return r.json()
      })
      const boundSiteIds = (boundSitesResp.data?.items || []).map(s => s.id)
      const allWebsitesBound = websites.every(w => boundSiteIds.includes(w.id))

      if (!allWebsitesBound && websites.length > 0) {
        throw new Error('Detail page shows websites not in tenant group scope')
      }
      console.log(`✅ tenant_admin 关联站点过滤正确（${websites.length}个站点）`); p++
    } else {
      console.log('⚠️ tenant_admin 无可见证书，跳过关联站点过滤测试'); p++
    }
  } catch (e) { f++; console.log(`❌ 租户权限隔离: ${e.message}`) }

  // Re-login as admin
  try {
    await loginAs(page, 'admin')
  } catch { /* non-fatal */ }

  console.log(`\n📊 SslCert: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
