// Integration: threat monitoring pages — verifies data loads
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForTableData, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })
  await loginAs(page)
  let p = 0, f = 0

  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows < 1) {
      const resp = await page.evaluate(async () => {
        const r = await fetch('/api/captain/detect-log/list', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ offset: 0, count: 10 }),
          credentials: 'include',
        })
        return r.json()
      })
      if (resp.data?.total < 1) throw new Error('No detect log data')
      console.log(`✅ 攻击检测日志 (API total: ${resp.data.total}, rows: ${rows})`); p++
    } else {
      console.log(`✅ 攻击检测日志 (${rows} rows)`); p++
    }

    // Verify highlighted source IP has color background
    const highlightedIp = await page.locator('.el-table__body-wrapper span[style*="background-color"]').count()
    if (highlightedIp > 0) {
      console.log(`✅ 源 IP 高亮渲染 (${highlightedIp} highlighted)`); p++
    } else {
      console.log('⚠️ 源 IP 高亮渲染: no highlighted IPs in current data'); p++
    }

    // Verify no 标记 column in detect log
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    if (headers.some(h => h.includes('标记'))) throw new Error('标记 column should be removed')
    console.log('✅ 攻击检测日志无标记列'); p++
  } catch (e) { f++; console.log(`❌ 攻击检测日志: ${e.message}`) }

  try {
    await navTo(page, '威胁监测', '频率控制日志')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content) throw new Error('Page empty')
    console.log('✅ 频率控制日志'); p++
  } catch (e) { f++; console.log(`❌ 频率控制日志: ${e.message}`) }

  try {
    await navTo(page, '威胁监测', '日志下载')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content) throw new Error('Page empty')
    console.log('✅ 日志下载'); p++
  } catch (e) { f++; console.log(`❌ 日志下载: ${e.message}`) }

  console.log(`\n📊 Monitoring: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
