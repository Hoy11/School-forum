// Integration: spec30b — Advanced settings (C1-C4) + Bug fixes (D1-D3) + UI/Backend (E1-E4)
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, waitForTableData, waitForWafSelector, launchOptions, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  const cookieHeader = await getAuthCookieHeader(page, 'admin')
  const captainInstanceId = await getActiveWafId(page, cookieHeader)
  console.log(`  Using captain_instance_id=${captainInstanceId}`)
  let p = 0, f = 0
  let rulePageReady = false

  async function gotoRulePage() {
    const visibleDialog = page.locator('.el-dialog:visible').first()
    if (await visibleDialog.count() > 0) {
      await visibleDialog.locator('.el-dialog__headerbtn').first().click().catch(() => {})
      await visibleDialog.waitFor({ state: 'hidden', timeout: 3000 }).catch(() => {})
    }
    const newBtn = page.locator('button:has-text("新建规则")').first()
    if (rulePageReady && await newBtn.isVisible().catch(() => false)) return

    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    await newBtn.waitFor({ state: 'visible', timeout: 10000 })
    rulePageReady = true
  }

  async function openNewDialog() {
    await page.locator('button:has-text("新建规则")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    return page.locator('.el-dialog:visible').first()
  }

  async function closeDialog(dialog) {
    if (!dialog) return
    try {
      await dialog.locator('.el-dialog__headerbtn').first().click()
      await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 3000 })
    } catch {
      await page.keyboard.press('Escape')
      await page.waitForTimeout(500)
    }
  }

  async function selectAction(dialog, actionLabel) {
    const modeFormItem = dialog.locator('.el-form-item').filter({ hasText: '模式' }).first()
    if (await modeFormItem.count() === 0) throw new Error('模式 form item not found')
    const actionSelect = modeFormItem.locator('.el-select').first()
    await actionSelect.click()
    const option = page.locator('.el-select-dropdown__item:visible').filter({ hasText: actionLabel }).first()
    await option.waitFor({ state: 'visible', timeout: 5000 })
    await option.click()
    await page.locator('.el-select-dropdown:visible').first().waitFor({ state: 'hidden', timeout: 3000 }).catch(() => {})
  }

  // ============================================================
  // C. 高级设置对齐雷池
  // ============================================================

  // T10: No intercept page config
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await selectAction(dialog, '拦截')
      const dialogText = await dialog.textContent()
      if (dialogText.includes('自定义拦截页面') || dialogText.includes('拦截页面')) {
        throw new Error('Intercept page config should NOT exist')
      }
      console.log('✅ C1 无拦截页面配置'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ C1 无拦截页面配置: ${e.message}`) }

  // T11: Decode method selector
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await dialog.locator('.el-collapse-item__header').first().click()
      await dialog.locator('.el-collapse-item__content:visible').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => {})
      const decodeFormItem = dialog.locator('.el-form-item').filter({ hasText: '检测前解码' }).first()
      if (await decodeFormItem.count() === 0) throw new Error('检测前解码 form item not found')
      const switchEl = decodeFormItem.locator('.el-switch').first()
      if (await switchEl.count() > 0) {
        const isChecked = await switchEl.evaluate(el => el.classList.contains('is-checked'))
        if (!isChecked) await switchEl.click()
        const methodSelect = decodeFormItem.locator('.el-select').first()
        if (await methodSelect.count() === 0) throw new Error('Decode method select not found')
        await methodSelect.click()
        await page.locator('.el-select-dropdown__item:visible').first().waitFor({ state: 'visible', timeout: 5000 })
        const methodOptions = await page.locator('.el-select-dropdown__item:visible').allTextContents()
        if (methodOptions.length < 4) throw new Error(`Expected ≥4 decode methods, got ${methodOptions.length}`)
        await page.keyboard.press('Escape')
      }
      console.log('✅ C2 解码方法选择器存在且含≥4种方法'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ C2 解码方法选择器: ${e.message}`) }

  // T12: "阻断状态码" only in deny mode
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await dialog.locator('.el-collapse-item__header').first().click()
      await dialog.locator('.el-collapse-item__content:visible').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => {})
      await selectAction(dialog, '拦截')
      let dialogText = await dialog.textContent()
      if (!dialogText.includes('阻断状态码')) throw new Error('Missing "阻断状态码" in deny mode')
      await selectAction(dialog, '放行')
      dialogText = await dialog.textContent()
      if (dialogText.includes('阻断状态码')) throw new Error('"阻断状态码" should NOT appear in allow mode')
      console.log('✅ C3 "阻断状态码"仅在拦截模式显示'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ C3 阻断状态码: ${e.message}`) }

  // T13: Log option descriptions
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await dialog.locator('.el-collapse-item__header').first().click()
      await dialog.locator('.el-collapse-item__content:visible').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => {})
      const dialogText = await dialog.textContent()
      if (!dialogText.includes('是否记录日志')) throw new Error('Missing 是否记录日志')
      if (!(dialogText.includes('持久记录') || dialogText.includes('仅记录') || dialogText.includes('不记录'))) throw new Error('Missing log descriptions')
      console.log('✅ C4 日志选项含描述文字'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ C4 日志选项描述: ${e.message}`) }

  // ============================================================
  // D. Bug 修复验证
  // ============================================================

  // T14: Bug #4 — Enable/disable single rule
  try {
    const ruleListResp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch(`/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    }, captainInstanceId)
    const rules = ruleListResp.data?.items || []
    const nonSharedRule = rules.find(r => (r.binding_count ?? 0) <= 1 && r.is_enabled === true)
    if (!nonSharedRule) { console.log('⚠️ 无非共享启用规则，跳过'); p++ }
    else {
      const disableResp = await page.evaluate(async ([ruleId, captainInstanceId]) => {
        const r = await fetch('/api/captain/policy-rule/enable', {
          method: 'PUT', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
          body: JSON.stringify({ captain_instance_id: captainInstanceId, ids: [Number(ruleId)], action: 'disable' }),
        })
        return r.json()
      }, [nonSharedRule.id, captainInstanceId])
      if (disableResp.err !== null) throw new Error(`Disable failed: ${disableResp.msg}`)

      const afterResp = await page.evaluate(async (captainInstanceId) => {
        const r = await fetch(`/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`, { credentials: 'include' })
        return r.json()
      }, captainInstanceId)
      const afterRules = afterResp.data?.items || []
      const afterRule = afterRules.find(r => r.id === nonSharedRule.id)
      if (afterRule && afterRule.is_enabled !== false) throw new Error('Rule should be disabled')

      let changedCount = 0
      for (const ar of afterRules) {
        const before = rules.find(o => o.id === ar.id)
        if (before && before.is_enabled !== ar.is_enabled) changedCount++
      }
      if (changedCount !== 1) throw new Error(`Expected 1 changed, got ${changedCount}`)

      await page.evaluate(async ([ruleId, captainInstanceId]) => {
        await fetch('/api/captain/policy-rule/enable', {
          method: 'PUT', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
          body: JSON.stringify({ captain_instance_id: captainInstanceId, ids: [Number(ruleId)], action: 'enable' }),
        })
      }, [nonSharedRule.id, captainInstanceId])
      console.log('✅ D1 Bug#4：禁用单条规则仅影响该规则'); p++
    }
  } catch (e) { f++; console.log(`❌ D1 Bug#4 启用/禁用单条: ${e.message}`) }

  // T15: Bug #5 — New rule condition editor blank
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      const condRows = dialog.locator('.ce-row')
      const rowCount = await condRows.count()
      if (rowCount > 3) throw new Error(`Has ${rowCount} rows — should be 1-2`)
      console.log('✅ D2 Bug#5：新建规则条件编辑器无残留数据'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ D2 Bug#5 条件编辑器残留: ${e.message}`) }

  // T16: Bug #6 — Pagination
  try {
    await gotoRulePage()
    const resp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch(`/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=20`, { credentials: 'include' })
      return r.json()
    }, captainInstanceId)
    const total = resp.data?.total || 0
    const items = resp.data?.items || []
    if (total === 0) throw new Error('No rules')
    if (total < items.length) throw new Error(`Total ${total} < items ${items.length}`)
    if (total > 20) {
      const p2 = await page.evaluate(async (captainInstanceId) => {
        const r = await fetch(`/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=20&count=20`, { credentials: 'include' })
        return r.json()
      }, captainInstanceId)
      const diff = Math.abs(p2.data?.total - total)
      if (diff > 2) throw new Error(`Page2 total ${p2.data?.total} differs from ${total} by ${diff} (>2 tolerance)`)
    }
    console.log(`✅ D3 Bug#6：分页正确(total=${total})`); p++
  } catch (e) { f++; console.log(`❌ D3 Bug#6 分页: ${e.message}`) }

  // ============================================================
  // E. UI 增强 + 后端校验
  // ============================================================

  // T17: Grid border mode
  try {
    await gotoRulePage()
    const hasBorder = await page.locator('.el-table--border').count()
    if (hasBorder === 0) throw new Error('No border mode')
    console.log('✅ E1 表格边框模式启用'); p++
  } catch (e) { f++; console.log(`❌ E1 表格边框: ${e.message}`) }

  // T18: Dialog label contains "模式"
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      const dialogText = await dialog.textContent()
      if (!dialogText.includes('模式')) throw new Error('Dialog should contain 模式 label')
      console.log('✅ E2 对话框含"模式"标签'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ E2 对话框标签: ${e.message}`) }

  // T19: Backend empty pattern validation
  try {
    const resp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch('/api/captain/policy-rule/create', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({
          captain_instance_id: captainInstanceId, action: 'deny', name: `e2e-empty-${Date.now()}`,
          comment: 'test', expire_time: 0, log_option: 'Non-Persistence',
          pattern: {}, is_enabled: true, websites: [],
        }),
      })
      return r.json()
    }, captainInstanceId)
    if (resp.err === null) throw new Error('Empty pattern should be rejected')
    console.log('✅ E3 后端空pattern校验拒绝'); p++
  } catch (e) { f++; console.log(`❌ E3 后端pattern校验: ${e.message}`) }

  // T20: Edit modify_module rule — verify format conversion via API (create + read back)
  try {
    const createResp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch('/api/captain/policy-rule/create', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({
          captain_instance_id: captainInstanceId, action: 'modify_module', name: `e2e-module-edit-${Date.now()}`,
          comment: 'e2e edit test', expire_time: 0, log_option: 'Non-Persistence',
          pattern: { $AND: [{ infix: ['urlpath', 'test'] }] },
          module_management: [{ key: 'sql_injection', enabled: true }],
          is_enabled: true, websites: [],
        }),
      })
      return r.json()
    }, captainInstanceId)
    if (createResp.err !== null) throw new Error(`Create failed: ${createResp.msg}`)
    const rule = createResp.data
    if (rule.action !== 'modify_module') throw new Error('Action should be modify_module')
    if (!rule.module_management || typeof rule.module_management !== 'object') throw new Error('module_management should be dict')
    if (!Array.isArray(rule.module_management.enabled)) throw new Error('module_management.enabled should be array')
    if (rule.module_management.enabled[0] !== 'sql_injection') throw new Error('module_management.enabled should contain sql_injection')
    console.log('✅ E4 检测模块控制规则创建+格式转换(dict)正确'); p++
    // Cleanup
    await page.evaluate(async ([id, captainInstanceId]) => {
      await fetch('/api/captain/policy-rule/delete', {
        method: 'DELETE', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({ captain_instance_id: captainInstanceId, id__in: [Number(id)] }),
      })
    }, [rule.id, captainInstanceId])
  } catch (e) { f++; console.log(`❌ E4 编辑检测模块控制回填: ${e.message}`) }

  console.log(`\n📊 Spec30b AdvancedSettings+Bugs+UI: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
