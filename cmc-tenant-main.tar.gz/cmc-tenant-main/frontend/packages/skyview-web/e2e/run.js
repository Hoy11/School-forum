#!/usr/bin/env node
// E2E Test Runner - runs all test suites sequentially
const { execSync } = require('child_process')
const path = require('path')

const TARGET_URL = process.env.TARGET_URL || 'http://localhost:3000'

const testSuites = [
  { name: 'Error Handling', file: 'errors.spec.js' },
  { name: 'WAF List Version', file: 'waf-list-version.spec.js' },
  { name: 'Transparent Proxy Site', file: 'transparent-proxy-site.spec.js' },
]

const e2eDir = __dirname
const SUMMARY_RE = /📊.*?:\s*(\d+)\s*passed,\s*(\d+)\s*failed/

function parseSuiteSummary(output) {
  const match = output.match(SUMMARY_RE)
  if (match) {
    return {
      passed: parseInt(match[1], 10),
      failed: parseInt(match[2], 10),
    }
  }

  const passed = (output.match(/✅/g) || []).length
  const failed = (output.match(/❌/g) || []).length
  if (passed > 0 || failed > 0) {
    return { passed, failed }
  }

  return null
}

function printSuiteHighlights(output) {
  for (const line of output.split('\n')) {
    if (line.includes('✅') || line.includes('❌') || line.includes('FAIL') || line.includes('Error') || line.includes('Browser')) console.log('  ' + line.trim())
  }
}

function runSuite(filePath, env) {
  let lastOutput = ''

  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const output = execSync(`node "${filePath}"`, {
        timeout: 180000,
        encoding: 'utf-8',
        stdio: ['pipe', 'pipe', 'pipe'],
        env,
      })
      lastOutput = output
      const summary = parseSuiteSummary(output)
      if (summary) return { ok: true, output, ...summary }
    } catch (e) {
      const output = [e.stdout, e.stderr, e.message].filter(Boolean).join('\n')
      lastOutput = output
      const summary = parseSuiteSummary(output)
      if (summary) return { ok: summary.failed === 0, output, ...summary }
    }

    if (attempt === 1) {
      console.log('  ↻ Retrying suite after incomplete output')
      if (lastOutput.trim()) console.log('  Last output (first 500 chars):', lastOutput.slice(0, 500))
    }
  }

  if (lastOutput.trim()) console.log('  Full output (first 1000 chars):', lastOutput.slice(0, 1000))
  return { ok: false, output: lastOutput, passed: 0, failed: 1 }
}

;(async () => {
  console.log('═══════════════════════════════════════════')
  console.log('  CMC Tenant E2E Test Suite')
  console.log(`  Target: ${TARGET_URL}`)
  console.log('═══════════════════════════════════════════\n')

  // Verify dev server is accessible
  try {
    const resp = await fetch(TARGET_URL, { signal: AbortSignal.timeout(5000) })
    if (!resp.ok) throw new Error(`Server returned ${resp.status}`)
    console.log('✓ Dev server is accessible\n')
  } catch (e) {
    console.error(`✗ Dev server not accessible at ${TARGET_URL}`)
    console.error('  Start with: cd frontend/packages/skyview-web && npm run dev')
    process.exit(1)
  }

  let totalPassed = 0
  let totalFailed = 0
  const results = []

  for (const suite of testSuites) {
    const filePath = path.join(e2eDir, suite.file)
    console.log(`\n▶ Running: ${suite.name}`)
    console.log('─'.repeat(40))

    const result = runSuite(filePath, { ...process.env, TARGET_URL })
    totalPassed += result.passed
    totalFailed += result.failed
    results.push({ name: suite.name, passed: result.passed, failed: result.failed })
    printSuiteHighlights(result.output)
  }

  console.log('\n═══════════════════════════════════════════')
  console.log('  E2E Test Summary')
  console.log('═══════════════════════════════════════════')
  for (const r of results) {
    const icon = r.failed === 0 ? '✓' : '✗'
    console.log(`  ${icon} ${r.name}: ${r.passed} passed, ${r.failed} failed`)
  }
  console.log('───────────────────────────────────────────')
  console.log(`  Total: ${totalPassed} passed, ${totalFailed} failed`)
  console.log('═══════════════════════════════════════════')

  process.exit(totalFailed > 0 ? 1 : 0)
})()
