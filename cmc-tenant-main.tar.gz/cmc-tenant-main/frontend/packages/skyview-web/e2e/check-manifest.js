#!/usr/bin/env node
// Validates that every E2E spec is registered in suites.js.

const fs = require('fs')
const path = require('path')
const suites = require('./suites')

const e2eDir = __dirname
const errors = []

function fail(message) {
  errors.push(message)
}

const specFiles = fs.readdirSync(e2eDir)
  .filter(file => file.endsWith('.spec.js'))
  .sort()

const registeredFiles = suites.map(suite => suite.file).sort()
const registeredSet = new Set(registeredFiles)
const diskSet = new Set(specFiles)

for (const file of specFiles) {
  if (!registeredSet.has(file)) fail(`Missing suite registration: ${file}`)
}

for (const file of registeredFiles) {
  if (!diskSet.has(file)) fail(`Registered suite file does not exist: ${file}`)
}

const duplicateFiles = registeredFiles.filter((file, index) => registeredFiles.indexOf(file) !== index)
for (const file of [...new Set(duplicateFiles)]) fail(`Duplicate suite registration: ${file}`)

for (const suite of suites) {
  if (!suite.file || typeof suite.file !== 'string') fail(`Suite has invalid file: ${JSON.stringify(suite)}`)
  if (!suite.name || typeof suite.name !== 'string') fail(`${suite.file}: missing name`)
  if (!Array.isArray(suite.layers) || suite.layers.length === 0) fail(`${suite.file}: missing layers`)
  if (!Array.isArray(suite.modules) || suite.modules.length === 0) fail(`${suite.file}: missing modules`)
  if (!Array.isArray(suite.tags) || suite.tags.length === 0) fail(`${suite.file}: missing tags`)
  if (!Number.isInteger(suite.group) || suite.group < 1) fail(`${suite.file}: invalid group`)
  if (suite.disabled && (!suite.disabledReason || typeof suite.disabledReason !== 'string')) {
    fail(`${suite.file}: disabled suite must provide disabledReason`)
  }

  for (const key of ['layers', 'modules', 'tags']) {
    const values = suite[key]
    if (!Array.isArray(values)) continue
    const invalid = values.filter(value => typeof value !== 'string' || value.trim() === '')
    if (invalid.length > 0) fail(`${suite.file}: invalid ${key}: ${JSON.stringify(invalid)}`)
  }

  const filePath = path.join(e2eDir, suite.file || '')
  if (suite.file && fs.existsSync(filePath)) {
    const content = fs.readFileSync(filePath, 'utf8')
    if (!content.includes('📊')) fail(`${suite.file}: missing summary line marker "📊"`)
  }
}

if (errors.length > 0) {
  console.error('E2E manifest check failed:')
  for (const error of errors) console.error(`  - ${error}`)
  process.exit(1)
}

console.log(`E2E manifest check passed: ${suites.length} registered suites, ${specFiles.length} files on disk`)
