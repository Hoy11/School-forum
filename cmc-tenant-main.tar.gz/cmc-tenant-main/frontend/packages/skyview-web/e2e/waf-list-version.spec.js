// E2E Test: WAF list version compatibility hint
const { chromium } = require('playwright')
const { loginAsRole, navigateToPage, launchOptions } = require('./helpers')

;(async () => {
  let browser
  let passed = 0
  let failed = 0

  try {
    browser = await chromium.launch(launchOptions())
  } catch (e) {
    console.log(`❌ Browser launch FAILED: ${e.message}`)
    console.log(`\n📊 WAF List Version: 0 passed, 1 failed`)
    process.exit(1)
  }

  try {
    const page = await browser.newPage()
    await loginAsRole(page, 'admin')

    await page.route('**/api/binding/waf/list**', (route) => {
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          err: null,
          msg: 'success',
          data: {
            total: 2,
            items: [
              {
                id: 1,
                tenant_group_id: 1,
                tenant_group_name: '默认组',
                captain_instance_id: 101,
                instance_name: 'baseline-waf',
                instance_host: '10.0.0.101',
                instance_status: 'HEALTHY',
                operation_mode: 'Software Reverse Proxy',
                version: '23.01.014_r6',
                created_at: '2026-06-01T00:00:00Z',
              },
              {
                id: 2,
                tenant_group_id: 1,
                tenant_group_name: '默认组',
                captain_instance_id: 102,
                instance_name: 'newer-waf',
                instance_host: '10.0.0.102',
                instance_status: 'HEALTHY',
                operation_mode: 'Hardware Transparent Proxy',
                version: '25.03.006',
                created_at: '2026-06-01T00:00:00Z',
              },
            ],
          },
        }),
      })
    })

    await navigateToPage(page, '/protection/wafs')
    await page.waitForSelector('.el-table__body-wrapper .el-table__row', { timeout: 10000 })

    const headers = await page.locator('.el-table__header-wrapper th').allTextContents()
    if (!headers.some(text => text.includes('版本'))) throw new Error('Version column header not found')

    const baselineRow = page.locator('.el-table__row').filter({ hasText: 'baseline-waf' })
    const newerRow = page.locator('.el-table__row').filter({ hasText: 'newer-waf' })
    if ((await baselineRow.count()) === 0) throw new Error('Baseline WAF row not found')
    if ((await newerRow.count()) === 0) throw new Error('Newer WAF row not found')
    if ((await baselineRow.locator('.el-icon-warning').count()) !== 0) {
      throw new Error('Baseline version should not show compatibility warning')
    }
    if ((await newerRow.locator('.el-icon-warning').count()) !== 1) {
      throw new Error('Non-baseline version should show one compatibility warning icon')
    }

    await newerRow.locator('.el-icon-warning').hover()
    await page.waitForSelector('.el-tooltip__popper:has-text("兼容性风险")', { timeout: 3000 })

    await page.close()
    passed++
    console.log('✅ Test 1: WAF version column and compatibility warning rendered')
  } catch (e) {
    failed++
    console.log(`❌ Test 1 FAILED: ${e.message}`)
  }

  console.log(`\n📊 WAF List Version: ${passed} passed, ${failed} failed`)
  await browser.close()
  process.exit(failed > 0 ? 1 : 0)
})()
