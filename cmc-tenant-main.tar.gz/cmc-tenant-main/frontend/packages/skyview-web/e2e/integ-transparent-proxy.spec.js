// Integration: transparent proxy WAF API paths and risk guard coverage.
// Uses real backend/Captain. Environment-specific cases are skipped when no
// usable transparent proxy WAF or test data is available.
const path = require('path')
const { chromium } = require('playwright')
const { launchOptions, getAuthCookieHeader } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'
const TP_MODE = 'Hardware Transparent Proxy'
const PASSWORD = 'Tenant@2024'

function headers(cookieHeader) {
  return { Cookie: cookieHeader }
}

function jsonHeaders(cookieHeader) {
  return { 'Content-Type': 'application/json', Cookie: cookieHeader }
}

function pageItems(data) {
  if (Array.isArray(data?.data)) return data.data
  if (Array.isArray(data?.data?.items)) return data.data.items
  return []
}

function dataArray(data) {
  return Array.isArray(data?.data) ? data.data : []
}

function isUsableWaf(waf) {
  if (!waf) return false
  if (waf.is_enabled === false) return false
  const status = String(waf.instance_status || waf.status || '').toUpperCase()
  if (!status) return true
  return status === 'HEALTHY' || status === 'UNHEALTHY' || status === 'ONLINE' || status === 'RUNNING'
}

function getInstanceID(waf) {
  return Number(waf.captain_instance_id || waf.id || waf.ID)
}

function getOperationMode(waf) {
  return waf.operation_mode || waf.mode || waf.Mode
}

function extractIPPort(site) {
  const addrs = Array.isArray(site.addrs) ? site.addrs : []
  for (const addr of addrs) {
    if (typeof addr === 'string' && addr.includes(':')) return addr
    if (addr?.ip_port) return addr.ip_port
    if (addr?.ip && addr?.port) return `${addr.ip}:${addr.port}`
  }
  if (site.ip && site.port) return `${site.ip}:${site.port}`
  return ''
}

function tpSitePayload(name, ipPort, captainInstanceId, workGroup) {
  return {
    captain_instance_id: captainInstanceId,
    is_enabled: true,
    name,
    interface: workGroup,
    operation_mode: TP_MODE,
    server_names: [`${name}.example.com`],
    url_paths: [{ op: 'pre', url_path: '/' }],
    addrs: [{ ip_port: ipPort, ssl: false, http2: false, sni: false, non_http: false }],
    ssl_cert: null,
    ssl_protocols: [],
    ssl_ciphers: '',
    policy_group: null,
    session_method: { type: 'off', param: '' },
    detector_ip_source: [],
    proxy_ip_list: [],
    proxy_ip_groups: [],
    access_log: { is_enabled: false, log_option: 'Drop', req_body: false, rsp_body: false },
    backend_config: {
      type: 'proxy',
      header_config: [],
      custom_config: { ignore_types: [], custom: {}, custom_web: [] },
      keepalive_config: 'default_keepalive_config',
      keepalive: 0,
      keepalive_timeout: 0,
      preserve_source_port: false,
    },
    deep_detection_config: { is_enabled: false },
    ntlm_enabled: false,
    asset_group: 1,
    remark: 'e2e transparent proxy conflict probe',
  }
}

async function apiJSON(page, method, urlPath, cookieHeader, body, timeout = 30000) {
  const opts = { headers: body ? jsonHeaders(cookieHeader) : headers(cookieHeader), timeout }
  if (body) opts.data = body
  const url = `${BACKEND_URL}${urlPath}`
  const resp = method === 'POST' ? await page.request.post(url, opts)
    : method === 'PUT' ? await page.request.put(url, opts)
      : method === 'DELETE' ? await page.request.delete(url, opts)
        : await page.request.get(url, opts)
  let data
  try {
    data = await resp.json()
  } catch {
    data = { err: 'parse_error', msg: await resp.text().catch(() => '') }
  }
  return { resp, data }
}

async function findTransparentProxyWaf(page, cookieHeader) {
  const list = await apiJSON(page, 'GET', '/api/binding/waf/list?offset=0&count=1000', cookieHeader)
  if (list.data.err === null) {
    const waf = pageItems(list.data).find(item => getOperationMode(item) === TP_MODE && isUsableWaf(item))
    if (waf) return waf
  }

  const groupsResp = await apiJSON(page, 'GET', '/api/tenant-group/list?offset=0&count=1000', cookieHeader)
  const groups = pageItems(groupsResp.data)
  for (const group of groups) {
    const available = await apiJSON(page, 'GET', `/api/binding/waf/available?tenant_group_id=${group.id}`, cookieHeader)
    if (available.data.err !== null) continue
    const waf = dataArray(available.data).find(item => getOperationMode(item) === TP_MODE && isUsableWaf(item))
    if (waf) return waf
  }
  return null
}

async function createTenantGroup(page, cookieHeader, suffix) {
  const username = `tp_e2e_${suffix}_${Date.now()}`
  const resp = await apiJSON(page, 'POST', '/api/tenant-group/create', cookieHeader, {
    name: `tp-e2e-${suffix}-${Date.now()}`,
    comment: 'temporary group for transparent proxy E2E',
    admin_username: username,
    admin_password: PASSWORD,
  })
  if (resp.data.err !== null) throw new Error(`create group ${suffix}: ${resp.data.msg || resp.data.err}`)
  return { id: resp.data.data.id, username, password: PASSWORD }
}

async function bindWaf(page, cookieHeader, tenantGroupID, captainInstanceID) {
  const resp = await apiJSON(page, 'POST', '/api/binding/waf/create', cookieHeader, {
    tenant_group_id: tenantGroupID,
    captain_instance_ids: [captainInstanceID],
  })
  if (resp.data.err !== null && !String(resp.data.msg || '').includes('已绑定')) {
    throw new Error(`bind WAF to group ${tenantGroupID}: ${resp.data.msg || resp.data.err}`)
  }
}

async function deleteWafBindings(page, cookieHeader, tenantGroupID) {
  const list = await apiJSON(page, 'GET', `/api/binding/waf/list?tenant_group_id=${tenantGroupID}&offset=0&count=1000`, cookieHeader)
  const ids = pageItems(list.data).map(item => item.id).filter(Boolean)
  if (ids.length > 0) {
    await apiJSON(page, 'DELETE', '/api/binding/waf/delete', cookieHeader, { ids }).catch(() => {})
  }
}

async function deleteSiteBindings(page, cookieHeader, tenantGroupID, captainInstanceID) {
  const list = await apiJSON(page, 'GET', `/api/binding/site/list?tenant_group_id=${tenantGroupID}&captain_instance_id=${captainInstanceID}&offset=0&count=1000`, cookieHeader)
  const ids = pageItems(list.data).map(item => item.id).filter(Boolean)
  if (ids.length > 0) {
    await apiJSON(page, 'DELETE', '/api/binding/site/delete', cookieHeader, { ids }).catch(() => {})
  }
}

async function deleteTenantGroup(page, cookieHeader, tenantGroupID) {
  if (tenantGroupID) {
    await apiJSON(page, 'DELETE', '/api/tenant-group/delete', cookieHeader, { ids: [tenantGroupID] }).catch(() => {})
  }
}

async function loginWithPassword(page, username, password) {
  const resp = await page.request.post(`${BACKEND_URL}/api/auth/login`, {
    data: { username, password },
  })
  const data = await resp.json()
  if (data.err !== null) throw new Error(`login ${username}: ${data.msg || data.err}`)
  return page.context().cookies().then(cookies => cookies.map(c => `${c.name}=${c.value}`).join('; '))
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  let passed = 0
  let failed = 0
  let skipped = 0

  let adminCookie
  try {
    adminCookie = await getAuthCookieHeader(page, 'admin')
    console.log('✅ Login (admin)'); passed++
  } catch (e) {
    console.log(`❌ Login (admin): ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  const tpWaf = await findTransparentProxyWaf(page, adminCookie)
  if (!tpWaf) {
    console.log('⚠️ 无可用透明代理 WAF，跳过透明代理真实集成测试')
    skipped++
    console.log(`\n📊 Transparent Proxy Integration: ${passed} passed, ${failed} failed, ${skipped} skipped`)
    await browser.close()
    process.exit(0)
  }

  const captainInstanceID = getInstanceID(tpWaf)
  console.log(`ℹ️ 使用透明代理 WAF: ${tpWaf.instance_name || tpWaf.name || captainInstanceID} (${captainInstanceID})`)

  // 1. Dynamic read path and work-group source.
  let workGroups = []
  try {
    const list = await apiJSON(page, 'GET', `/api/captain/site/list?captain_instance_id=${captainInstanceID}`, adminCookie)
    if (list.data.err !== null) throw new Error(`site list err=${list.data.err}, msg=${list.data.msg}`)
    if (!Array.isArray(list.data.data?.items)) throw new Error('site list should return paginated items')

    const wg = await apiJSON(page, 'GET', `/api/captain/site/aux/work-group-list?captain_instance_id=${captainInstanceID}`, adminCookie)
    if (wg.data.err !== null) throw new Error(`work-group err=${wg.data.err}, msg=${wg.data.msg}`)
    workGroups = Array.isArray(wg.data.data) ? wg.data.data : pageItems(wg.data)
    console.log('✅ API: transparent proxy site list and work-group list succeed'); passed++
  } catch (e) {
    failed++
    console.log(`❌ API: transparent proxy read paths: ${e.message}`)
  }

  // 2. Write path rejects mismatched operation_mode before proxying.
  try {
    const mismatch = await apiJSON(page, 'PUT', '/api/captain/site', adminCookie, {
      captain_instance_id: captainInstanceID,
      id: 1,
      operation_mode: 'Software Reverse Proxy',
    })
    if (mismatch.resp.status() !== 400) {
      throw new Error(`status=${mismatch.resp.status()}, body=${JSON.stringify(mismatch.data)}`)
    }
    if (!String(mismatch.data.msg || '').includes('不匹配')) {
      throw new Error(`missing mismatch message: ${JSON.stringify(mismatch.data)}`)
    }
    console.log('✅ API: mismatched transparent proxy operation_mode returns 400'); passed++
  } catch (e) {
    failed++
    console.log(`❌ API: mismatched operation_mode: ${e.message}`)
  }

  // 3. Binding path resolution for transparent proxy available/list APIs.
  try {
    const available = await apiJSON(page, 'GET', `/api/binding/site/available?tenant_group_id=1&captain_instance_id=${captainInstanceID}`, adminCookie)
    if (available.data.err !== null) throw new Error(`available err=${available.data.err}, msg=${available.data.msg}`)
    if (!Array.isArray(available.data.data)) throw new Error('available sites should be an array')

    const bindings = await apiJSON(page, 'GET', `/api/binding/site/list?tenant_group_id=1&captain_instance_id=${captainInstanceID}&offset=0&count=1000`, adminCookie)
    if (bindings.data.err !== null) throw new Error(`binding list err=${bindings.data.err}, msg=${bindings.data.msg}`)
    if (!Array.isArray(bindings.data.data?.items)) throw new Error('binding list should return paginated items')
    const named = bindings.data.data.items.filter(item => item.site_id).every(item => item.status === 'invalid' || typeof item.site_name === 'string')
    if (!named) throw new Error('binding list site names/status not enriched')
    console.log('✅ API: transparent proxy binding available/list succeed'); passed++
  } catch (e) {
    failed++
    console.log(`❌ API: transparent proxy binding paths: ${e.message}`)
  }

  // 4. addrs[].ip_port conflict guard. This needs an existing unbound TP site
  // and two temporary tenant groups; skip if the environment cannot provide them.
  let groupA = null
  let groupB = null
  try {
    const wgName = workGroups[0]?.name
    if (!wgName) {
      console.log('⚠️ 无透明代理工作组，跳过 addrs IP:Port 冲突测试'); skipped++
      throw new Error('__skip__')
    }

    const sites = await apiJSON(page, 'GET', `/api/captain/site/list?captain_instance_id=${captainInstanceID}`, adminCookie)
    const available = await apiJSON(page, 'GET', `/api/binding/site/available?tenant_group_id=1&captain_instance_id=${captainInstanceID}`, adminCookie)
    const availableIDs = new Set(dataArray(available.data).map(item => Number(item.site_id)))
    const target = pageItems(sites.data).find(site => availableIDs.has(Number(site.id || site.ID)) && extractIPPort(site))
    if (!target) {
      console.log('⚠️ 无未绑定且包含 addrs/ip_port 的透明代理站点，跳过 addrs IP:Port 冲突测试'); skipped++
      throw new Error('__skip__')
    }

    const ipPort = extractIPPort(target)
    const siteID = Number(target.id || target.ID)
    groupA = await createTenantGroup(page, adminCookie, 'a')
    groupB = await createTenantGroup(page, adminCookie, 'b')
    await bindWaf(page, adminCookie, groupA.id, captainInstanceID)
    await bindWaf(page, adminCookie, groupB.id, captainInstanceID)

    const bindSite = await apiJSON(page, 'POST', '/api/binding/site/create', adminCookie, {
      tenant_group_id: groupB.id,
      captain_instance_id: captainInstanceID,
      site_ids: [siteID],
    })
    if (bindSite.data.err !== null) throw new Error(`bind existing site: ${bindSite.data.msg || bindSite.data.err}`)

    const tenantCookie = await loginWithPassword(page, groupA.username, groupA.password)
    const create = await apiJSON(page, 'POST', '/api/captain/site', tenantCookie, tpSitePayload(
      `tp-conflict-${Date.now()}`,
      ipPort,
      captainInstanceID,
      wgName
    ))
    if (create.resp.status() === 429) {
      console.log('⚠️ WAF 写操作冷却中，跳过 addrs IP:Port 冲突测试'); skipped++
      throw new Error('__skip__')
    }
    if (create.resp.status() !== 403 || create.data.err !== 'risk_check') {
      throw new Error(`status=${create.resp.status()}, body=${JSON.stringify(create.data)}`)
    }
    console.log('✅ API: transparent proxy addrs IP:Port conflict returns 403'); passed++
  } catch (e) {
    if (e.message !== '__skip__') {
      failed++
      console.log(`❌ API: transparent proxy addrs IP:Port conflict: ${e.message}`)
    }
  } finally {
    if (groupB) await deleteSiteBindings(page, adminCookie, groupB.id, captainInstanceID)
    if (groupA) await deleteWafBindings(page, adminCookie, groupA.id)
    if (groupB) await deleteWafBindings(page, adminCookie, groupB.id)
    if (groupA) await deleteTenantGroup(page, adminCookie, groupA.id)
    if (groupB) await deleteTenantGroup(page, adminCookie, groupB.id)
  }

  console.log(`\n📊 Transparent Proxy Integration: ${passed} passed, ${failed} failed, ${skipped} skipped`)
  await browser.close()
  process.exit(failed > 0 ? 1 : 0)
})()
