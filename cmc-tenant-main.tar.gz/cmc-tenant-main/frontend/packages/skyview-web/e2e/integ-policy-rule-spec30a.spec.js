// Integration: spec30a — Action modes (A1-A6) + ConditionEditor (B1-B3)
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, waitForTableData, waitForWafSelector, launchOptions, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  const cookieHeader = await getAuthCookieHeader(page, 'admin')
  const captainInstanceId = await getActiveWafId(page, cookieHeader)
  console.log(`  Using captain_instance_id=${captainInstanceId}`)
  let p = 0, f = 0
  let rulePageReady = false

  async function gotoRulePage() {
    const visibleDialog = page.locator('.el-dialog:visible').first()
    if (await visibleDialog.count() > 0) {
      await visibleDialog.locator('.el-dialog__headerbtn').first().click().catch(() => {})
      await visibleDialog.waitFor({ state: 'hidden', timeout: 3000 }).catch(() => {})
    }
    const newBtn = page.locator('button:has-text("新建规则")').first()
    if (rulePageReady && await newBtn.isVisible().catch(() => false)) return

    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    await newBtn.waitFor({ state: 'visible', timeout: 10000 })
    rulePageReady = true
  }

  async function openNewDialog() {
    await page.locator('button:has-text("新建规则")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    return page.locator('.el-dialog:visible').first()
  }

  async function closeDialog(dialog) {
    if (!dialog) return
    try {
      await dialog.locator('.el-dialog__headerbtn').first().click()
      await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 3000 })
    } catch {
      await page.keyboard.press('Escape')
      await page.waitForTimeout(500)
    }
  }

  async function selectAction(dialog, actionLabel) {
    const modeFormItem = dialog.locator('.el-form-item').filter({ hasText: '模式' }).first()
    if (await modeFormItem.count() === 0) throw new Error('模式 form item not found')
    const actionSelect = modeFormItem.locator('.el-select').first()
    await actionSelect.click()
    const option = page.locator('.el-select-dropdown__item:visible').filter({ hasText: actionLabel }).first()
    await option.waitFor({ state: 'visible', timeout: 5000 })
    await option.click()
    await page.locator('.el-select-dropdown:visible').first().waitFor({ state: 'hidden', timeout: 3000 }).catch(() => {})
  }

  // ============================================================
  // A. 动作模式: 5种动作 + 检测模块控制 + 内置规则控制
  // ============================================================

  // T1: Action dropdown has 5 options
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      const modeFormItem = dialog.locator('.el-form-item').filter({ hasText: '模式' }).first()
      if (await modeFormItem.count() === 0) throw new Error('模式 form item not found')
      const actionSelect = modeFormItem.locator('.el-select').first()
      await actionSelect.click()
      await page.locator('.el-select-dropdown__item:visible').first().waitFor({ state: 'visible', timeout: 5000 })
      const options = await page.locator('.el-select-dropdown__item:visible').allTextContents()
      const required = ['拦截', '放行', '观察', '检测模块控制', '内置规则控制']
      for (const r of required) {
        if (!options.some(o => o.includes(r))) throw new Error(`Missing action option: ${r}`)
      }
      await page.keyboard.press('Escape')
      console.log('✅ A1 动作下拉含5种：拦截/放行/观察/检测模块控制/内置规则控制'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ A1 动作下拉5种选项: ${e.message}`) }

  // T2: Select 检测模块控制 → shows module action area + condition editor visible
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await selectAction(dialog, '检测模块控制')
      const dialogText = await dialog.textContent()
      const addBtn = dialog.locator('button:has-text("添加一个动作"), span:has-text("添加一个动作")').first()
      if (await addBtn.count() === 0) throw new Error('No "添加一个动作" button')
      if (!dialogText.includes('匹配条件')) throw new Error('Condition editor should be visible')
      console.log('✅ A2 检测模块控制：显示"添加一个动作"+条件编辑器可见'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ A2 检测模块控制UI: ${e.message}`) }

  // T3: Select 内置规则控制 → shows skynet rule dropdown with 开启/关闭
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await selectAction(dialog, '内置规则控制')
      const addBtn = dialog.locator('button:has-text("添加一个动作"), span:has-text("添加一个动作")').first()
      if (await addBtn.count() > 0) {
        await addBtn.click()
        await dialog.locator('.el-select:visible').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => {})
      }
      const dialogText = await dialog.textContent()
      if (!dialogText.includes('开启') || !dialogText.includes('关闭')) throw new Error('Skynet action should have 开启/关闭')
      if (!dialogText.includes('匹配条件')) throw new Error('Condition editor should be visible')
      console.log('✅ A3 内置规则控制：操作下拉含"开启/关闭"+条件编辑器可见'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ A3 内置规则控制UI: ${e.message}`) }

  // T4: Create modify_module rule via API (backend routing)
  try {
    const resp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch('/api/captain/policy-rule/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          captain_instance_id: captainInstanceId, action: 'modify_module', name: `e2e-module-${Date.now()}`,
          comment: 'e2e test', expire_time: 0, log_option: 'Non-Persistence',
          pattern: { $AND: [{ infix: ['urlpath', 'test'] }] },
          module_management: [{ key: 'sql_injection', enabled: true }],
          is_enabled: true, websites: [],
        }),
      })
      return r.json()
    }, captainInstanceId)
    if (resp.err !== null) throw new Error(`Create failed: ${resp.msg}`)
    const ruleId = resp.data?.id || resp.data
    console.log(`✅ A4 创建检测模块控制规则成功(id=${ruleId})`); p++
    // Cleanup
    if (ruleId) await page.evaluate(async ([id, captainInstanceId]) => {
      await fetch('/api/captain/policy-rule/delete', {
        method: 'DELETE', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({ captain_instance_id: captainInstanceId, id__in: [Number(id)] }),
      })
    }, [ruleId, captainInstanceId])
  } catch (e) { f++; console.log(`❌ A4 创建检测模块控制规则: ${e.message}`) }

  // T5: Create modify_skynet_rule via API
  try {
    const resp = await page.evaluate(async (captainInstanceId) => {
      const r = await fetch('/api/captain/policy-rule/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          captain_instance_id: captainInstanceId, action: 'modify_skynet_rule', name: `e2e-skynet-${Date.now()}`,
          comment: 'e2e test', expire_time: 0, log_option: 'Non-Persistence',
          pattern: { $AND: [{ infix: ['urlpath', 'test'] }] },
          skynet_rule_management: [{ key: '1', enabled: true }],
          is_enabled: true, websites: [],
        }),
      })
      return r.json()
    }, captainInstanceId)
    if (resp.err !== null) throw new Error(`Create failed: ${resp.msg}`)
    const ruleId = resp.data?.id || resp.data
    console.log(`✅ A5 创建内置规则控制规则成功(id=${ruleId})`); p++
    if (ruleId) await page.evaluate(async ([id, captainInstanceId]) => {
      await fetch('/api/captain/policy-rule/delete', {
        method: 'DELETE', headers: { 'Content-Type': 'application/json' }, credentials: 'include',
        body: JSON.stringify({ captain_instance_id: captainInstanceId, id__in: [Number(id)] }),
      })
    }, [ruleId, captainInstanceId])
  } catch (e) { f++; console.log(`❌ A5 创建内置规则控制规则: ${e.message}`) }

  // T6: Watch clearing — switch mode clears previous data
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await selectAction(dialog, '检测模块控制')
      const addBtn = dialog.locator('button:has-text("添加一个动作"), span:has-text("添加一个动作")').first()
      if (await addBtn.count() > 0) {
        await addBtn.click()
        await dialog.locator('.el-select:visible').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => {})
      }
      await selectAction(dialog, '内置规则控制')
      const dialogText = await dialog.textContent()
      const addBtn2 = dialog.locator('button:has-text("添加一个动作"), span:has-text("添加一个动作")').first()
      if (await addBtn2.count() === 0) throw new Error('Should show "添加一个动作" button after switching')
      console.log('✅ A6 切换动作模式：检测模块控制→内置规则控制，数据已清空'); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ A6 切换动作模式数据清空: ${e.message}`) }

  // ============================================================
  // B. ConditionEditor 增强 + 列头/标签
  // ============================================================

  // T7: Column header says "动作"
  try {
    await gotoRulePage()
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    if (!headers.some(h => h.includes('动作'))) throw new Error('Missing 动作 column header')
    console.log('✅ B1 列头包含"动作"'); p++
  } catch (e) { f++; console.log(`❌ B1 列头"动作": ${e.message}`) }

  // T8: 32 field types in condition editor
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      const fieldSelect = dialog.locator('.ce-row-fields .el-select').first()
      await fieldSelect.click()
      await page.locator('.el-select-dropdown__item:visible').first().waitFor({ state: 'visible', timeout: 5000 })
      const fieldOptions = await page.locator('.el-select-dropdown__item:visible').allTextContents()
      if (fieldOptions.length < 30) throw new Error(`Expected ≥30 field types, got ${fieldOptions.length}`)
      const requiredNew = ['Content-Length', 'Authorization', 'HTTP 请求体长度', 'HTTP 响应头']
      for (const rf of requiredNew) {
        if (!fieldOptions.some(o => o.includes(rf))) throw new Error(`Missing field: ${rf}`)
      }
      await page.keyboard.press('Escape')
      console.log(`✅ B2 条件编辑器字段类型≥30种(${fieldOptions.length})，含新增字段`); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ B2 字段类型补齐: ${e.message}`) }

  // T9: Attack type dropdown has ≥40 options + placeholder
  try {
    await gotoRulePage()
    const dialog = await openNewDialog()
    try {
      await dialog.locator('.el-collapse-item__header').first().click()
      await dialog.locator('.el-collapse-item__content:visible').first().waitFor({ state: 'visible', timeout: 5000 }).catch(() => {})
      const attackFormItem = dialog.locator('.el-form-item').filter({ hasText: '攻击类型' }).first()
      if (await attackFormItem.count() === 0) throw new Error('攻击类型 form item not found')
      const attackSelect = attackFormItem.locator('.el-select').first()
      const attackInput = attackSelect.locator('.el-input__inner').first()
      const placeholder = await attackInput.getAttribute('placeholder').catch(() => '')
      if (!placeholder.includes('攻击类型')) throw new Error(`Placeholder wrong: "${placeholder}"`)
      await attackSelect.click()
      await page.locator('.el-select-dropdown__item:visible').first().waitFor({ state: 'visible', timeout: 5000 })
      const attackOptions = await page.locator('.el-select-dropdown__item:visible').allTextContents()
      if (attackOptions.length < 40) throw new Error(`Expected ≥40, got ${attackOptions.length}`)
      const required = ['SQL 注入', 'XSS', 'CSRF', '威胁情报']
      for (const ra of required) {
        if (!attackOptions.some(o => o.includes(ra))) throw new Error(`Missing: ${ra}`)
      }
      await page.keyboard.press('Escape')
      console.log(`✅ B3 攻击类型≥40种(${attackOptions.length})+placeholder正确`); p++
    } finally { await closeDialog(dialog) }
  } catch (e) { f++; console.log(`❌ B3 攻击类型补齐: ${e.message}`) }

  console.log(`\n📊 Spec30a ActionModes+ConditionEditor: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
