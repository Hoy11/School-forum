// Integration test helpers — calls real backend, no mock
const fs = require('fs')
const path = require('path')

const TARGET_URL = process.env.TARGET_URL || 'http://localhost:3000'
const CREDENTIALS = {
  admin: { username: 'admin', password: 'Admin@2024' },
  tenant_admin: { username: 'test_admin', password: 'Tenant@2024' },
}
const AUTH_CACHE_DIR = process.env.E2E_AUTH_CACHE_DIR || path.join(__dirname, '.auth')

function integrationConfig() {
  if (process.env.PLAYWRIGHT_HEADLESS || process.env.CI) return {}
  return {
    proxy: { server: 'http://127.0.0.1:7890', bypass: 'localhost,127.0.0.1' },
  }
}

function launchOptions() {
  return { headless: true, slowMo: 0, ...integrationConfig() }
}

function isAuthCacheEnabled() {
  if (process.env.E2E_AUTH_CACHE === '0') return false
  const specFile = path.basename(process.argv[1] || '')
  return specFile !== 'integ-auth.spec.js'
}

function authCacheFile(role) {
  return path.join(AUTH_CACHE_DIR, `${role}.json`)
}

function readAuthCache(role) {
  try {
    const body = JSON.parse(fs.readFileSync(authCacheFile(role), 'utf8'))
    const cred = CREDENTIALS[role]
    if (!body || body.targetUrl !== TARGET_URL) return null
    if (!body.username || body.username !== cred.username) return null
    if (!Array.isArray(body.cookies) || body.cookies.length === 0) return null
    return body
  } catch {
    return null
  }
}

function writeAuthCache(role, cookies) {
  try {
    fs.mkdirSync(AUTH_CACHE_DIR, { recursive: true })
    const cred = CREDENTIALS[role]
    const file = authCacheFile(role)
    const tmpFile = `${file}.${process.pid}.tmp`
    fs.writeFileSync(tmpFile, JSON.stringify({
      targetUrl: TARGET_URL,
      role,
      username: cred.username,
      createdAt: new Date().toISOString(),
      cookies,
    }, null, 2))
    fs.renameSync(tmpFile, file)
  } catch {
    // Caching is an optimization; never fail a test because the cache cannot be written.
  }
}

async function clearAuthState(context) {
  await context.clearCookies().catch(() => {})
}

async function validateAuth(page, role) {
  try {
    const resp = await page.request.get(`${TARGET_URL}/api/auth/current`, { timeout: 5000 })
    if (!resp.ok()) return false
    const data = await resp.json()
    return data?.err === null && data?.data?.role === role
  } catch {
    return false
  }
}

async function applyCachedAuth(page, role) {
  if (!isAuthCacheEnabled()) return false
  const cache = readAuthCache(role)
  if (!cache) return false

  await clearAuthState(page.context())
  await page.context().addCookies(cache.cookies)
  const ok = await validateAuth(page, role)
  if (!ok) {
    await clearAuthState(page.context())
    return false
  }
  return true
}

async function getCookieHeader(page) {
  const cookies = await page.context().cookies()
  return cookies.map(c => `${c.name}=${c.value}`).join('; ')
}

async function getAuthCookieHeader(page, role = 'admin') {
  const cached = await applyCachedAuth(page, role)
  if (cached) return getCookieHeader(page)

  const cred = CREDENTIALS[role]
  await clearAuthState(page.context())
  const resp = await page.request.post(`${TARGET_URL}/api/auth/login`, {
    data: { username: cred.username, password: cred.password },
  })
  const data = await resp.json()
  if (data.err !== null) throw new Error(`Login failed: ${data.msg}`)
  const cookies = await page.context().cookies()
  writeAuthCache(role, cookies)
  return cookies.map(c => `${c.name}=${c.value}`).join('; ')
}

async function getActiveWafId(page, cookieHeader, options = {}) {
  const { requireSiteList = false } = options
  const resp = await page.request.get(`${TARGET_URL}/api/binding/waf/list?offset=0&count=1000`, {
    headers: { Cookie: cookieHeader },
  })
  const data = await resp.json()
  const items = data.data?.items || []
  const candidates = items.filter(w => {
    if (w.status && w.status !== 'active') return false
    return !!w.captain_instance_id && !!w.instance_name && !!w.instance_host
  })
  for (const waf of candidates) {
    if (!requireSiteList) return waf.captain_instance_id
    const siteResp = await page.request.get(`${TARGET_URL}/api/captain/site/list?captain_instance_id=${waf.captain_instance_id}`, {
      headers: { Cookie: cookieHeader },
    }).catch(() => null)
    if (!siteResp || !siteResp.ok()) continue
    const siteData = await siteResp.json().catch(() => null)
    if (siteData?.err === null) return waf.captain_instance_id
  }
  throw new Error('No active WAF binding available')
}

async function loginAs(page, role = 'admin') {
  const cred = CREDENTIALS[role]
  const cached = await applyCachedAuth(page, role)
  if (cached) {
    await page.goto(TARGET_URL, { waitUntil: 'domcontentloaded', timeout: 15000 })
    await page.locator('.layout').waitFor({ state: 'visible', timeout: 10000 }).catch(() => page.waitForTimeout(2000))
    await waitForLaunchLoaderGone(page)
    return page.url()
  }

  await clearAuthState(page.context())
  await page.goto(`${TARGET_URL}/login`, { waitUntil: 'domcontentloaded', timeout: 15000 })
  await page.locator('input[placeholder*="用户"]').first().fill(cred.username)
  await page.locator('input[type="password"]').first().fill(cred.password)
  await page.locator('button:has-text("登录")').first().click()
  // Wait for layout to appear (app loaded) instead of fixed timeout
  await page.locator('.layout').waitFor({ state: 'visible', timeout: 10000 }).catch(() => page.waitForTimeout(2000))
  await waitForLaunchLoaderGone(page)
  writeAuthCache(role, await page.context().cookies())
  return page.url()
}

async function waitForLaunchLoaderGone(page, timeout = 10000) {
  const loader = page.locator('#launch-loader')
  if (await loader.count() === 0) return
  await loader.first().waitFor({ state: 'detached', timeout }).catch(async () => {
    await page.evaluate(() => {
      document.querySelectorAll('#launch-loader').forEach(node => node.remove())
    }).catch(() => {})
  })
}

// Wait for page content to settle after navigation (table rows or content area)
async function waitForContent(page, timeout = 5000) {
  await Promise.race([
    page.locator('.el-table__body-wrapper .el-table__row').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
    page.locator('.layout__content').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
  ])
  await waitForLaunchLoaderGone(page)
}

// Wait for table to finish rendering (loading done, then rows or empty state)
async function waitForTableData(page, timeout = 8000) {
  // First, wait for loading mask to appear (Grid started fetching) or rows/empty to appear directly
  await Promise.race([
    page.locator('.el-table .el-loading-mask').first().waitFor({ state: 'visible', timeout: 3000 }).catch(() => {}),
    page.locator('.el-table__body-wrapper .el-table__row').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
    page.locator('.el-table__empty-block').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
    page.locator('.el-table__empty-text').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
  ])
  // Wait for loading mask to disappear if present
  const loading = page.locator('.el-table .el-loading-mask')
  if (await loading.count() > 0) {
    await loading.first().waitFor({ state: 'hidden', timeout }).catch(() => {})
  }
  // Wait for rows or empty state
  await Promise.race([
    page.locator('.el-table__body-wrapper .el-table__row').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
    page.locator('.el-table__empty-block').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
    page.locator('.el-table__empty-text').first().waitFor({ state: 'visible', timeout }).catch(() => {}),
  ])
  await waitForLaunchLoaderGone(page)
}

// Horizontal nav: click top-level group, then sidebar sub-item
async function navTo(page, groupName, menuItem) {
  const topItem = page.locator(`.el-menu--horizontal > .el-menu-item:has-text("${groupName}")`).first()
  await topItem.click()
  // Wait for sidebar to update
  await page.locator('.layout__sidebar .el-menu-item').first().waitFor({ state: 'visible', timeout: 3000 }).catch(() => {})
  const sideItem = page.locator(`.layout__sidebar .el-menu-item:has-text("${menuItem}")`).first()
  await sideItem.click({ force: true })
  await waitForContent(page)
}

async function getRows(page) {
  return page.locator('.el-table__body-wrapper .el-table__row').count()
}

// Get visible top-level menu texts
async function getTopMenuTexts(page) {
  return page.locator('.el-menu--horizontal > .el-menu-item').allTextContents()
}

// Wait for WAF selector to auto-select and become enabled (for 防护管理 sub-pages)
async function waitForWafSelector(page, timeout = 8000) {
  const select = page.locator('.el-select:not(.is-disabled)').first()
  await select.waitFor({ state: 'visible', timeout }).catch(() => {})
  // Wait until a WAF is actually auto-selected (input has a real value, not the initial "0")
  try {
    await page.waitForFunction(
      () => {
        const inp = document.querySelector('.el-select:not(.is-disabled) input')
        return inp && inp.value && inp.value !== '0' && inp.value.length > 0
      },
      { timeout: 8000 }
    )
  } catch { /* fall through */ }
  await page.waitForTimeout(300)
}

module.exports = {
  TARGET_URL, CREDENTIALS, integrationConfig, launchOptions, loginAs, getCookieHeader, getAuthCookieHeader, getActiveWafId, navTo, getRows, getTopMenuTexts, waitForContent, waitForTableData, waitForWafSelector, waitForLaunchLoaderGone,
}
