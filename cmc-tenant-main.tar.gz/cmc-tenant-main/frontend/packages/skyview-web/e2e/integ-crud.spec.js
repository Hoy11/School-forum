const { chromium } = require('playwright')
const path = require('path')
const { loginAs, navTo, getRows, waitForContent, waitForWafSelector, waitForTableData, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  let p = 0, f = 0

  // === 日志详情页 ===

  // 1. ACL log detail
  let clickedDetail = false
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows > 0) {
      const detailButton = page.locator('.el-table__body-wrapper .el-table__row button:has-text("详情"), .el-table__body-wrapper .el-table__row a:has-text("详情")').first()
      const detailCount = await detailButton.count()
      if (detailCount === 0) {
        console.log(`⚠️ No ACL log detail button (${rows} rows in list)`); p++
      } else {
        await detailButton.waitFor({ state: 'visible', timeout: 10000 }).catch(() => {})
        if (!await detailButton.isVisible().catch(() => false)) {
          console.log(`⚠️ ACL log detail button not visible (${rows} rows in list)`); p++
        } else {
          await detailButton.click().catch(async () => {
            await waitForTableData(page)
            await page.locator('.el-table__body-wrapper .el-table__row button:has-text("详情"), .el-table__body-wrapper .el-table__row a:has-text("详情")').first().click()
          })
          await waitForContent(page, 3000)
          const text = await page.locator('.layout__content').first().textContent()
          if (!text || text.length < 30) throw new Error('ACL detail empty')
          console.log(`✅ 频率控制日志详情 (${rows} rows in list)`); p++
          clickedDetail = true
        }
      }
    } else {
      console.log('⚠️ No ACL log rows'); p++
    }
  } catch (e) { f++; console.log(`❌ 频率控制日志详情: ${e.message}`) }
  if (clickedDetail) { await page.goBack().catch(() => {}); await waitForContent(page, 2000) }


  // === 防护管理 CRUD ===

  // 3. IP group list + new columns (包含IP, 备注)
  try {
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)
    // Verify new columns exist in table headers
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    if (!headers.some(h => h.includes('包含IP'))) throw new Error('Missing 包含IP column')
    if (!headers.some(h => h.includes('备注'))) throw new Error('Missing 备注 column')
    // Verify row data if rows exist
    if (rows > 0) {
      const firstRow = page.locator('.el-table__row').first()
      const cells = await firstRow.locator('.cell').allTextContents()
      // Should have at least 5 cells: ID, 名称, 包含IP, 备注, 操作
      if (cells.length < 5) throw new Error(`Only ${cells.length} columns, expected ≥5`)
    }
    console.log(`✅ IP 组页面 (${rows} rows, 包含IP+备注列)`); p++
  } catch (e) { f++; console.log(`❌ IP 组: ${e.message}`) }

  // 4. SSL cert list
  try {
    await navTo(page, '防护管理', 'SSL 证书')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content) throw new Error('Page empty')
    const rows = await getRows(page)
    console.log(`✅ SSL 证书页面 (${rows} rows)`); p++
  } catch (e) { f++; console.log(`❌ SSL 证书: ${e.message}`) }

  // 5. Custom rule list
  try {
    await navTo(page, '防护管理', '自定义规则')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content) throw new Error('Page empty')
    const rows = await getRows(page)
    console.log(`✅ 自定义规则页面 (${rows} rows)`); p++
  } catch (e) { f++; console.log(`❌ 自定义规则: ${e.message}`) }

  // 6. Detect log — no mark/标记 column (removed)
  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await page.waitForTimeout(1000)
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    const hasMark = headers.some(h => h.includes('标记'))
    if (hasMark) throw new Error('标记 column should be removed')
    console.log('✅ 检测日志无标记列'); p++
  } catch (e) { f++; console.log(`❌ 检测日志标记列: ${e.message}`) }

  // 7. Highlight IP CRUD — API-driven create/edit/delete + UI verification
  try {
    const testIP = `203.0.113.${Date.now() % 200 + 1}/32`

    // Clean up stale records from interrupted CI runs.
    const existingResp = await page.evaluate(async () => {
      const r = await fetch('/api/highlight-ip/list?offset=0&count=100', { credentials: 'include' })
      return r.json()
    })
    const staleIDs = (existingResp.data?.items || [])
      .filter(i => ['e2e-test', 'e2e-edited'].includes(i.comment))
      .map(i => i.id)
    if (staleIDs.length > 0) {
      const cleanupResp = await page.evaluate(async (ids) => {
        const r = await fetch('/api/highlight-ip/delete', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ids }),
          credentials: 'include',
        })
        return r.json()
      }, staleIDs)
      if (cleanupResp.err !== null) throw new Error(`Cleanup API failed: ${cleanupResp.msg}`)
    }

    // Create via API
    const createResp = await page.evaluate(async (ip) => {
      const r = await fetch('/api/highlight-ip/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ip, color: '#FF6600', comment: 'e2e-test' }),
        credentials: 'include',
      })
      return r.json()
    }, testIP)
    if (createResp.err !== null) throw new Error(`Create API failed: ${createResp.msg}`)

    // Verify in UI
    await navTo(page, '系统管理', '高亮 IP')
    await page.waitForTimeout(1000)
    const rowsAfterCreate = await getRows(page)
    const pageText = await page.locator('.layout__content').first().textContent()
    if (!pageText.includes('e2e-test')) throw new Error('Created entry not visible in list')

    // Verify color swatch
    const colorSwatch = await page.locator('.el-table__body-wrapper span[style*="background-color"]').count()
    if (colorSwatch < 1) throw new Error('No color swatch visible')

    // Edit color via API
    const editResp = await page.evaluate(async ({ id, ip }) => {
      const r = await fetch('/api/highlight-ip/update', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ip, color: '#00CC00', comment: 'e2e-edited' }),
        credentials: 'include',
      })
      return r.json()
    }, { id: createResp.data.id, ip: testIP })
    if (editResp.err !== null) throw new Error(`Edit API failed: ${editResp.msg}`)

    // Verify edit in UI
    await page.locator('.layout__content').first().waitFor({ state: 'visible', timeout: 3000 })
    const listResp = await page.evaluate(async () => {
      const r = await fetch('/api/highlight-ip/list?offset=0&count=100', { credentials: 'include' })
      return r.json()
    })
    const edited = listResp.data?.items?.find(i => i.comment === 'e2e-edited')
    if (!edited || edited.color !== '#00CC00') throw new Error('Edit not reflected in API')

    // Delete via API
    const delResp = await page.evaluate(async (id) => {
      const r = await fetch('/api/highlight-ip/delete', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: [id] }),
        credentials: 'include',
      })
      return r.json()
    }, createResp.data.id)
    if (delResp.err !== null) throw new Error(`Delete API failed: ${delResp.msg}`)

    console.log('✅ 高亮 IP CRUD (create/edit/delete)'); p++
  } catch (e) { f++; console.log(`❌ 高亮 IP CRUD: ${e.message}`) }

  // 7. Integration config (merged captain + SOC) — read & verify
  try {
    await navTo(page, '系统管理', '对接配置')
    await page.locator('.el-form-item:has-text("纵横地址") span').first().waitFor({ state: 'visible', timeout: 5000 })
    const captainResp = await page.evaluate(async () => {
      const r = await fetch('/api/system/captain', { credentials: 'include' })
      return r.json()
    })
    if (captainResp.err !== null) throw new Error(`Captain config API failed: ${captainResp.msg}`)
    const expectedHost = captainResp.data?.host || ''
    if (!expectedHost) throw new Error('Captain host empty')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content.includes(expectedHost)) throw new Error('Should show captain host')
    console.log('✅ 对接配置数据正确'); p++
  } catch (e) { f++; console.log(`❌ 对接配置: ${e.message}`) }

  // 8. Password config — read
  try {
    await navTo(page, '系统管理', '密码策略')
    // Wait for form to render with data
    await page.locator('.el-form-item:has-text("长度")').first().waitFor({ state: 'visible', timeout: 5000 })
    console.log('✅ 密码策略数据正确'); p++
  } catch (e) { f++; console.log(`❌ 密码策略: ${e.message}`) }

  // 9. Login security — read
  try {
    await navTo(page, '系统管理', '登录安全')
    const content = await page.locator('.layout__content').first().textContent()
    if (!content) throw new Error('Page empty')
    console.log('✅ 登录安全数据正确'); p++
  } catch (e) { f++; console.log(`❌ 登录安全: ${e.message}`) }

  console.log(`\n📊 Detail & CRUD: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
