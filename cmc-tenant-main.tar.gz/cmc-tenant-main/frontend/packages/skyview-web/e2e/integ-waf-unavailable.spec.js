// Integration: WAF selector unavailable guard — disabled/offline WAFs block writes
const { chromium } = require('playwright')
const { loginAsRole, navigateToPage, launchOptions } = require('./helpers')

const EMPTY_PAGE = { err: null, msg: 'success', data: { total: 0, items: [] } }

function wafFixture(overrides) {
  return {
    id: overrides.id || overrides.captain_instance_id || 1,
    tenant_group_id: 1,
    tenant_group_name: '默认组',
    captain_instance_id: overrides.captain_instance_id || overrides.id || 1,
    instance_name: overrides.instance_name,
    instance_host: overrides.instance_host || '10.0.0.1',
    instance_status: overrides.instance_status,
    is_enabled: overrides.is_enabled,
    operation_mode: 'Software Reverse Proxy',
    version: '23.01.014_r6',
    created_at: '2026-06-01T00:00:00Z',
  }
}

async function openIpGroupPage(browser, waf) {
  const page = await browser.newPage()
  await loginAsRole(page, 'admin')
  await page.unroute('**/api/binding/waf/list**').catch(() => {})

  let ipGroupListCalls = 0
  await page.route('**/api/binding/waf/list**', (route) => {
    route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        err: null,
        msg: 'success',
        data: { total: 1, items: [waf] },
      }),
    })
  })
  await page.route('**/api/captain/ip-group/list**', (route) => {
    ipGroupListCalls++
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify(EMPTY_PAGE) })
  })

  await navigateToPage(page, '/protection/ip-group')
  await page.waitForSelector('button:has-text("新建 IP 组")', { timeout: 10000 })
  return { page, getIpGroupListCalls: () => ipGroupListCalls }
}

async function buttonDisabled(page) {
  const button = page.locator('button:has-text("新建 IP 组")').first()
  return button.evaluate((el) => el.disabled || el.classList.contains('is-disabled'))
}

async function assertOperable(browser, status) {
  const name = `${status.toLowerCase()}-waf`
  const { page } = await openIpGroupPage(browser, wafFixture({
    captain_instance_id: status === 'HEALTHY' ? 101 : 102,
    instance_name: name,
    instance_status: status,
    is_enabled: true,
  }))

  if (await buttonDisabled(page)) throw new Error(`${status} WAF should allow creating IP groups`)
  const alertCount = await page.locator('.el-alert').filter({ hasText: '无法操作' }).count()
  if (alertCount !== 0) throw new Error(`${status} WAF should not show unavailable alert`)

  await page.locator('button:has-text("新建 IP 组")').first().click()
  await page.waitForSelector('.el-dialog:has-text("新建 IP 组")', { timeout: 3000 })
  await page.close()
}

async function assertBlocked(browser, waf, expectedMessage) {
  const { page, getIpGroupListCalls } = await openIpGroupPage(browser, waf)

  await page.waitForSelector(`.el-alert:has-text("${expectedMessage}")`, { timeout: 5000 })
  if (!(await buttonDisabled(page))) throw new Error(`${waf.instance_name} create button should be disabled`)

  await page.waitForTimeout(200)
  if (getIpGroupListCalls() !== 0) {
    throw new Error(`${waf.instance_name} should not request IP group list when WAF is unavailable`)
  }

  await page.close()
}

;(async () => {
  let browser
  let passed = 0
  let failed = 0

  try {
    browser = await chromium.launch(launchOptions())
  } catch (e) {
    console.log(`❌ Browser launch FAILED: ${e.message}`)
    console.log('\n📊 WAF Unavailable Guard: 0 passed, 1 failed')
    process.exit(1)
  }

  const tests = [
    {
      name: 'HEALTHY WAF remains editable',
      run: () => assertOperable(browser, 'HEALTHY'),
    },
    {
      name: 'UNHEALTHY WAF remains editable',
      run: () => assertOperable(browser, 'UNHEALTHY'),
    },
    {
      name: 'OFF LINE WAF blocks writes with offline message',
      run: () => assertBlocked(
        browser,
        wafFixture({ captain_instance_id: 201, instance_name: 'offline-waf', instance_status: 'OFF LINE', is_enabled: true }),
        'offline-waf 处于离线状态，无法操作'
      ),
    },
    {
      name: 'disabled WAF blocks writes with disabled message',
      run: () => assertBlocked(
        browser,
        wafFixture({ captain_instance_id: 202, instance_name: 'disabled-waf', instance_status: 'HEALTHY', is_enabled: false }),
        'disabled-waf 处于禁用状态，无法操作'
      ),
    },
    {
      name: 'unknown WAF status blocks writes with status message',
      run: () => assertBlocked(
        browser,
        wafFixture({ captain_instance_id: 203, instance_name: 'unknown-waf', instance_status: 'MAINTENANCE', is_enabled: true }),
        'unknown-waf 状态为 MAINTENANCE，无法操作'
      ),
    },
  ]

  for (const test of tests) {
    try {
      await test.run()
      passed++
      console.log(`✅ ${test.name}`)
    } catch (e) {
      failed++
      console.log(`❌ ${test.name}: ${e.message}`)
    }
  }

  await browser.close()
  console.log(`\n📊 WAF Unavailable Guard: ${passed} passed, ${failed} failed`)
  process.exit(failed > 0 ? 1 : 0)
})()
