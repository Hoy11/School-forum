// Integration: Audit Log - Request URL feature
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, launchOptions, waitForLaunchLoaderGone } = require(path.join(__dirname, 'integ-helpers'))

// 使用随机IP和带时间戳的备注，避免CI环境数据冲突
const TEST_IP = `192.168.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`
const TEST_COMMENT = `e2e-test-audit-url-${Date.now()}`

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  let passed = 0, failed = 0
  let test3Succeeded = false

  // 用例1: 登录并访问审计日志页面
  console.log('▶ Test 1: 登录并导航至审计日志页面')
  try {
    await loginAs(page)
    await navTo(page, '系统管理', '审计日志')
    await waitForLaunchLoaderGone(page)
    await page.locator('.el-table').first().waitFor({ state: 'visible', timeout: 5000 })
    await page.locator('th').first().waitFor({ state: 'visible', timeout: 5000 })
    console.log('✅ Test 1: 审计日志页面加载成功')
    passed++
  } catch (e) { failed++; console.log(`❌ Test 1: ${e.message}`) }

  // 用例2: 验证「请求路径」列存在
  console.log('▶ Test 2: 验证「请求路径」列存在')
  try {
    await navTo(page, '系统管理', '审计日志')
    await waitForLaunchLoaderGone(page)
    // 等待表头完全渲染
    await page.locator('.el-table__header-wrapper th').first().waitFor({ state: 'visible', timeout: 5000 })
    const allHeaders = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    const hasRequestUrlColumn = allHeaders.some(h => h.includes('请求路径'))
    if (!hasRequestUrlColumn) {
      throw new Error(`表格缺少「请求路径」列, 实际列头: ${allHeaders.join(', ')}`)
    }
    console.log('✅ Test 2: 「请求路径」列存在')
    passed++
  } catch (e) { failed++; console.log(`❌ Test 2: ${e.message}`) }

  // 用例3: 创建高亮IP产生审计日志
  console.log('▶ Test 3: 创建高亮IP产生审计日志')
  try {
    await navTo(page, '系统管理', '高亮 IP')
    await page.waitForTimeout(500)

    // 点击新建按钮
    await page.locator('button:has-text("新建")').first().click()
    await page.waitForTimeout(500)

    // 等待弹窗打开
    await page.locator('.el-dialog').first().waitFor({ state: 'visible', timeout: 3000 })

    // 填写IP（第一个输入框）
    await page.locator('.el-dialog .el-input__inner').first().fill(TEST_IP)

    // 填写备注（第三个输入框，第一个是IP，第二个是颜色选择器，第三个是备注）
    await page.locator('.el-dialog .el-input__inner').nth(2).fill(TEST_COMMENT)

    // 点击确定（footer区域的确定按钮）
    await page.locator('.el-dialog__footer button:has-text("确定")').first().click()

    // 验证创建成功：等待成功消息或表格刷新
    try {
      await page.locator('.el-message--success').first().waitFor({ state: 'visible', timeout: 3000 })
      console.log('✅ Test 3: 高亮IP创建成功')
    } catch (e) {
      // 如果没有toast，检查对话框是否关闭且表格中出现新数据
      await page.waitForTimeout(800)
      const dialogVisible = await page.locator('.el-dialog:visible').count()
      if (dialogVisible === 0) {
        console.log('✅ Test 3: 高亮IP创建成功（对话框关闭）')
      } else {
        const errorMsg = await page.locator('.el-form-item__error, .el-message--error').first().textContent().catch(() => '未知错误')
        throw new Error(`创建高亮IP失败: ${errorMsg}`)
      }
    }
    passed++
    test3Succeeded = true
  } catch (e) { failed++; console.log(`❌ Test 3: ${e.message}`) }

  // 用例4: 验证审计日志包含请求路径
  console.log('▶ Test 4: 验证审计日志包含请求路径')
  if (!test3Succeeded) {
    console.log('⚠️ Test 4: 跳过（依赖Test 3创建数据）')
  } else {
    try {
      await navTo(page, '系统管理', '审计日志')

      // 轮询等待审计日志写入（最长5秒）
      let firstRowUrl = ''
      let attempts = 0
      const maxAttempts = 10

      while (attempts < maxAttempts) {
        await page.reload()
        await page.locator('.el-table__row').first().waitFor({ state: 'visible', timeout: 5000 })
        await page.waitForTimeout(300)

        firstRowUrl = await page.locator('.el-table__row:first-child td:nth-child(3)').textContent() || ''

        // 检查是否为高亮IP创建的日志（操作列应包含"创建"）
        const firstRowAction = await page.locator('.el-table__row:first-child td:nth-child(2)').textContent() || ''
        const firstRowDetail = await page.locator('.el-table__row:first-child td:nth-child(5)').textContent() || ''

        if (firstRowUrl.trim() && firstRowUrl.trim() !== '—' &&
            (firstRowAction.includes('创建') || firstRowDetail.includes('高亮IP'))) {
          break
        }

        attempts++
        if (attempts < maxAttempts) {
          await page.waitForTimeout(500) // 等待后重试
        }
      }

      if (!firstRowUrl || firstRowUrl.trim() === '' || firstRowUrl.trim() === '—') {
        throw new Error('最新审计日志的 request_url 为空')
      }
      if (!firstRowUrl.includes('/api/')) {
        throw new Error(`请求路径格式不正确: ${firstRowUrl}`)
      }
      console.log(`✅ Test 4: 最新审计日志包含请求路径: ${firstRowUrl.trim()} (重试${attempts}次)`)
      passed++
    } catch (e) { failed++; console.log(`❌ Test 4: ${e.message}`) }
  }

  // 用例5: 验证详情弹窗展示请求路径
  console.log('▶ Test 5: 验证详情弹窗展示请求路径')
  try {
    // 确保在审计日志页面
    await navTo(page, '系统管理', '审计日志')
    await page.locator('.el-table__row').first().waitFor({ state: 'visible', timeout: 5000 })

    // 点击第一行的「查看」链接 - 先检查链接是否存在
    const detailLink = page.locator('.el-table__row:first-child .audit-log-detail-link, .el-table__row:first-child a:has-text("查看"), .el-table__row:first-child button:has-text("查看")').first()
    const linkCount = await detailLink.count()

    if (linkCount > 0 && await detailLink.isVisible()) {
      await detailLink.click()
      await page.waitForTimeout(300)

      // 验证弹窗打开
      await page.locator('.el-dialog').first().waitFor({ state: 'visible', timeout: 3000 })

      // 验证包含「请求路径」
      const dialogContent = await page.locator('.el-dialog').first().textContent()
      if (!dialogContent.includes('请求路径')) {
        throw new Error('详情弹窗缺少「请求路径」字段')
      }

      // 验证请求路径值不为空
      const requestUrlMatch = dialogContent.match(/请求路径[：:]\s*(\S+)/)
      if (!requestUrlMatch || !requestUrlMatch[1] || requestUrlMatch[1] === '—') {
        throw new Error('详情弹窗中请求路径值为空')
      }

      // 关闭弹窗
      await page.locator('.el-dialog__close, .el-dialog__headerbtn').first().click()
      await page.waitForTimeout(300)

      console.log('✅ Test 5: 详情弹窗展示请求路径')
      passed++
    } else {
      console.log('⚠️ Test 5: 跳过（未找到查看链接或请求体过短）')
      passed++ // 不视为失败
    }
  } catch (e) { failed++; console.log(`❌ Test 5: ${e.message}`) }

  // 用例6: 清理测试数据
  console.log('▶ Test 6: 清理测试数据')
  try {
    await navTo(page, '系统管理', '高亮 IP')
    await page.waitForTimeout(500)

    // 查找测试备注对应的删除按钮（使用备注匹配更可靠）
    const rows = await page.locator('.el-table__row').count()
    let found = false
    for (let i = 0; i < rows; i++) {
      const rowText = await page.locator(`.el-table__row:nth-child(${i + 1})`).textContent()
      if (rowText && rowText.includes(TEST_COMMENT)) {
        // 找到测试数据，点击删除
        await page.locator(`.el-table__row:nth-child(${i + 1}) button:has-text("删除"), .el-table__row:nth-child(${i + 1}) .el-button--danger`).first().click()
        await page.waitForTimeout(300)
        // 确认删除 - 等待确认对话框出现
        await page.locator('.el-message-box__btns button:has-text("确定"), .el-message-box button:has-text("确定")').first().waitFor({ state: 'visible', timeout: 3000 })
        await page.locator('.el-message-box__btns button:has-text("确定"), .el-message-box button:has-text("确定")').first().click()
        await page.waitForTimeout(500)
        console.log('✅ Test 6: 测试数据已清理')
        found = true
        break
      }
    }
    if (!found) {
      console.log('⚠️ Test 6: 未找到测试数据（可能已删除）')
    }
    passed++
  } catch (e) {
    console.log(`⚠️ Test 6: 清理数据失败或已不存在: ${e.message}`)
    passed++ // 清理失败不算用例失败
  }

  console.log(`\n📊 Audit Log URL Test: ${passed} passed, ${failed} failed`)
  await browser.close()
  process.exit(failed > 0 ? 1 : 0)
})()
