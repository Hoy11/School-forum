// Integration: custom rule write protection — runtime + shared + edit protection
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))
const { BACKEND_URL, login: apiLogin, sitePayload, cleanupSites } = require(path.join(__dirname, 'test-data'))

const BACKEND = TARGET_URL.replace(':3000', ':8080')
const TEST_PREFIX = `__e2e_wp_${Date.now()}`
const UI_PAGE_SIZE = 20

// API helpers (browser-context fetch with auto cookies)
async function apiGet(page, path) {
  return page.evaluate(async (p) => {
    const r = await fetch(p, { credentials: 'include' })
    return r.json()
  }, path)
}

async function apiPost(page, path, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return r.json()
  }, [path, body])
}

async function apiPut(page, path, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return r.json()
  }, [path, body])
}

async function apiDelete(page, path, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return r.json()
  }, [path, body])
}

function rulePayload(comment, websites, remoteAddr = '1.2.3.4') {
  return {
    is_global: false,
    is_enabled: true,
    action: 'deny',
    comment,
    risk_level: 0,
    pattern: { $AND: [{ remote_addr: { values: [remoteAddr], op: 'ipmatch' }, decode_methods: [] }] },
    websites,
    attack_type: -1,
    log_option: 'Persistence',
    cron_config: { type: 'all' },
    expire_time: '',
    is_expired: false,
  }
}

function cleanupUpdatePayload(rule, captainInstanceId) {
  return {
    captain_instance_id: captainInstanceId,
    id: rule.id,
    is_global: false,
    is_enabled: rule.is_enabled !== false,
    action: rule.action || 'deny',
    comment: rule.comment || `cleanup_rule_${rule.id}`,
    risk_level: rule.risk_level ?? 0,
    pattern: rule.pattern || { $AND: [{ remote_addr: { values: ['127.0.0.1'], op: 'ipmatch' }, decode_methods: [] }] },
    websites: [],
    attack_type: rule.attack_type ?? -1,
    log_option: rule.log_option || 'Persistence',
    cron_config: rule.cron_config || { type: 'all' },
    expire_time: rule.expire_time || '',
    is_expired: rule.is_expired || false,
  }
}

function moduleEndpointPayload(rule, captainInstanceId) {
  return {
    captain_instance_id: captainInstanceId,
    id: rule.id,
    is_global: false,
    is_enabled: rule.is_enabled !== false,
    action: 'modify_module',
    comment: rule.comment || `module_rule_${rule.id}`,
    risk_level: rule.risk_level ?? 0,
    pattern: rule.pattern || { $AND: [{ remote_addr: { values: ['127.0.0.1'], op: 'ipmatch' }, decode_methods: [] }] },
    websites: rule.websites || [],
    attack_type: rule.attack_type ?? -1,
    log_option: rule.log_option || 'Persistence',
    cron_config: rule.cron_config || { type: 'all' },
    expire_time: rule.expire_time || '',
    is_expired: rule.is_expired || false,
    module_management: rule.module_management || { disabled: [], enabled: [] },
  }
}

function skynetEndpointPayload(rule, captainInstanceId) {
  return {
    captain_instance_id: captainInstanceId,
    id: rule.id,
    is_global: false,
    is_enabled: rule.is_enabled !== false,
    action: 'modify_skynet_rule',
    comment: rule.comment || `skynet_rule_${rule.id}`,
    risk_level: rule.risk_level ?? 0,
    pattern: rule.pattern || { $AND: [{ remote_addr: { values: ['127.0.0.1'], op: 'ipmatch' }, decode_methods: [] }] },
    websites: rule.websites || [],
    attack_type: rule.attack_type ?? -1,
    log_option: rule.log_option || 'Persistence',
    cron_config: rule.cron_config || { type: 'all' },
    expire_time: rule.expire_time || '',
    is_expired: rule.is_expired || false,
    skynet_rule_management: rule.skynet_rule_management || { disabled: [], enabled: [] },
  }
}

function expectNotShared(resp, label) {
  if (resp.err === 'shared') throw new Error(`${label}: admin request was still blocked by shared protection`)
}

// Check if style contains gray color (handles both #ccc and rgb(204,204,204))
function isGrayColor(style) {
  if (!style) return false
  return style.includes('#ccc') || style.includes('rgb(204') || style.includes('rgb(204, 204, 204)')
}

// Explicitly select the correct WAF in the el-select dropdown if it differs from what's shown
async function selectWafIfNeeded(page, wafName) {
  if (!wafName) return
  const input = page.locator('.el-select:not(.is-disabled) input').first()
  const currentVal = await input.inputValue().catch(() => '')
  if (currentVal === wafName) return
  await page.locator('.el-select:not(.is-disabled)').first().click()
  await page.waitForTimeout(300)
  const option = page.locator('.el-select-dropdown__item').filter({ hasText: wafName }).first()
  if (await option.count() === 0) { await page.keyboard.press('Escape'); return }
  await option.click()
  await waitForTableData(page)
}

async function findVisibleSharedRuleRow(page, captainInstanceId) {
  const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=${UI_PAGE_SIZE}`)
  const rules = listResp.data?.items || []
  const sharedRules = rules.filter(r => (r.binding_count ?? 0) > 1)

  for (const rule of sharedRules) {
    const row = page.locator('.el-table__row').filter({ hasText: String(rule.id) }).first()
    if (await row.count() > 0) return { rule, row }
  }

  return { rule: null, row: null }
}

async function findRuleById(page, captainInstanceId, ruleId, label) {
  for (let attempt = 0; attempt < 5; attempt++) {
    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=10000`)
    const rules = listResp.data?.items || []
    const rule = rules.find(r => r.id === ruleId)
    if (rule) return rule
    await page.waitForTimeout(300)
  }
  throw new Error(`${label} not found in list`)
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  let p = 0, f = 0
  const createdSiteIds = []
  const createdRuleIds = []
  const ruleASearchKey = `${TEST_PREFIX}_ruleA`
  const ruleBSearchKey = `${TEST_PREFIX}_ruleB`

  // --- Seed: login as admin ---
  await loginAs(page, 'admin')

  let captainInstanceId
  let captainWafName = null
  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    captainInstanceId = await getActiveWafId(page, cookieHeader, { requireSiteList: true })
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)
    // Fetch WAF name so we can explicitly re-select it after any subsequent navTo
    const wafListResp = await apiGet(page, `/api/binding/waf/list?offset=0&count=1000`)
    const foundWaf = (wafListResp.data?.items || []).find(w => w.captain_instance_id === captainInstanceId)
    captainWafName = foundWaf?.instance_name || null
    await selectWafIfNeeded(page, captainWafName)
    console.log(`  Using captain_instance_id=${captainInstanceId} name=${captainWafName}`)
  } catch (e) {
    console.log(`❌ WAF selection: ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  // Find existing sites (reuse instead of creating new ones to avoid Captain API issues)
  let existingSiteId = null
  try {
    const siteResp = await apiGet(page, `/api/captain/site/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const sites = siteResp.data?.items || []
    if (sites.length > 0) {
      existingSiteId = sites[0].id
      console.log(`  Using existing site: id=${existingSiteId}`)
    }
  } catch { /* ignore */ }

  // --- Seed: create test sites only if no existing ones ---
  let testSiteId = existingSiteId
  if (!testSiteId) {
    try {
      const port1 = 25000 + Math.floor(Math.random() * 1000)
      const resp1 = await apiPost(page, '/api/captain/site', sitePayload(`${TEST_PREFIX}_site1`, port1, captainInstanceId))
      console.log(`  Site create response: err=${resp1.err}, data=${JSON.stringify(resp1.data)?.substring(0, 100)}`)
      if (resp1.err === null && resp1.data) {
        testSiteId = typeof resp1.data === 'object' ? resp1.data.id : resp1.data
        if (testSiteId) {
          createdSiteIds.push(testSiteId)
          await apiPost(page, '/api/binding/site/create', { tenant_group_id: 1, captain_instance_id: captainInstanceId, site_ids: [testSiteId] }).catch(() => {})
        }
      }
      console.log(`  Created test site: id=${testSiteId}`)
      p++
    } catch (e) { f++; console.log(`❌ 创建测试站点: ${e.message}`) }
  }

  // --- Seed: create Rule B as admin (API-only test, no binding needed) ---
  let ruleBId = null
  try {
    const resp = await apiPost(page, '/api/captain/policy-rule/create', {
      captain_instance_id: captainInstanceId,
      ...rulePayload(`${TEST_PREFIX}_ruleB_safe`, [], '5.6.7.8'),
    })
    console.log(`  Rule B create: err=${resp.err}, data=${JSON.stringify(resp.data)?.substring(0, 100)}`)
    if (resp.err === null && resp.data) {
      ruleBId = typeof resp.data === 'object' ? resp.data.id : resp.data
      if (ruleBId) createdRuleIds.push(ruleBId)
    }
    console.log(`  Rule B (safe): id=${ruleBId}`)
    p++
  } catch (e) { f++; console.log(`❌ 创建测试规则B: ${e.message}`) }

  // --- Seed: create Rule A and C as tenant_admin so binding_count=1 (required for adminConfirmEdit/Delete dialogs) ---
  let ruleAId = null
  let ruleCId = null
  try {
    await loginAs(page, 'tenant_admin')
    // Find a site visible to tenant_admin (needed for ruleA's websites=[])
    const tenantSiteResp = await apiGet(page, `/api/captain/site/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantSiteId = tenantSiteResp.data?.items?.[0]?.id || null
    // Rule A: with websites (in-use, binding_count=1 after creation as tenant)
    if (tenantSiteId) {
      const resp = await apiPost(page, '/api/captain/policy-rule/create', {
        captain_instance_id: captainInstanceId,
        ...rulePayload(`${TEST_PREFIX}_ruleA_inuse`, [tenantSiteId], '1.2.3.4'),
      })
      console.log(`  Rule A create: err=${resp.err}, data=${JSON.stringify(resp.data)?.substring(0, 100)}`)
      if (resp.err === null && resp.data) {
        ruleAId = typeof resp.data === 'object' ? resp.data.id : resp.data
        if (ruleAId) createdRuleIds.push(ruleAId)
      }
    }
    console.log(`  Rule A (in-use, tenant-owned): id=${ruleAId}`)
    // Rule C: no websites (not in-use, binding_count=1 after creation as tenant)
    const respC = await apiPost(page, '/api/captain/policy-rule/create', {
      captain_instance_id: captainInstanceId,
      ...rulePayload(`${TEST_PREFIX}_ruleC_unused`, [], '10.11.12.13'),
    })
    console.log(`  Rule C create: err=${respC.err}, data=${JSON.stringify(respC.data)?.substring(0, 100)}`)
    if (respC.err === null && respC.data) {
      ruleCId = typeof respC.data === 'object' ? respC.data.id : respC.data
      if (ruleCId) createdRuleIds.push(ruleCId)
    }
    console.log(`  Rule C (unused, tenant-owned): id=${ruleCId}`)
    p++
    await loginAs(page, 'admin')
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)
  } catch (e) { f++; console.log(`❌ 创建测试规则A/C: ${e.message}`); await loginAs(page, 'admin').catch(() => {}) }

  // ═══════════════════════════════════════════
  // Test 1: List injection — binding_count, site_names fields (admin)
  // NOTE: Must run BEFORE any delete operations so rules are still in the list
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const rules = listResp.data?.items || []
    if (rules.length === 0) throw new Error('No rules returned')

    const sample = rules[0]
    if (!('binding_count' in sample)) throw new Error('Missing binding_count field')
    if (!('site_names' in sample)) throw new Error('Missing site_names field')
    // admin also receives has_external_ref and shared_group_names (injectAdminRuleProtectionFields)
    if (!('has_external_ref' in sample)) throw new Error('Missing has_external_ref field for admin')
    if (!('shared_group_names' in sample)) throw new Error('Missing shared_group_names field for admin')

    // Verify Rule A has websites (in-use check)
    const ruleA = rules.find(r => r.id === ruleAId)
    if (ruleA && ruleA.websites && ruleA.websites.length === 0) {
      throw new Error('Rule A should have websites but has none')
    }
    console.log(`✅ [列表注入] binding_count, site_names, has_external_ref, shared_group_names 字段存在`); p++
  } catch (e) { f++; console.log(`❌ [列表注入] 保护字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 2: Backend — delete in-use rule returns in_use error
  // ═══════════════════════════════════════════
  try {
    if (!ruleAId) throw new Error('Rule A not created')
    const resp = await apiDelete(page, '/api/captain/policy-rule/delete', {
      captain_instance_id: captainInstanceId,
      id: ruleAId,
    })
    if (resp.err !== 'in_use') throw new Error(`Expected err=in_use, got err=${resp.err}, msg=${resp.msg}`)
    console.log(`✅ [后端] 删除使用中规则返回 in_use 错误`); p++
  } catch (e) { f++; console.log(`❌ [后端] 删除使用中规则: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 3: Backend — delete safe rule succeeds
  // ═══════════════════════════════════════════
  try {
    if (!ruleBId) throw new Error('Rule B not created')
    const resp = await apiDelete(page, '/api/captain/policy-rule/delete', {
      captain_instance_id: captainInstanceId,
      id: ruleBId,
    })
    if (resp.err !== null) throw new Error(`Expected success, got err=${resp.err}, msg=${resp.msg}`)
    const idx = createdRuleIds.indexOf(ruleBId)
    if (idx >= 0) createdRuleIds.splice(idx, 1)
    console.log(`✅ [后端] 删除无引用规则成功`); p++
  } catch (e) { f++; console.log(`❌ [后端] 删除无引用规则: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 4: Backend — admin edit shared rule succeeds (shared check bypassed for admin)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const rules = listResp.data?.items || []
    const sharedRule = rules.find(r => (r.binding_count ?? 0) > 1)
    if (sharedRule) {
      const resp = await apiPut(page, '/api/captain/policy-rule/update', {
        captain_instance_id: captainInstanceId,
        id: sharedRule.id,
        comment: sharedRule.comment || 'admin shared edit',
        is_enabled: sharedRule.is_enabled,
        action: sharedRule.action,
        risk_level: sharedRule.risk_level,
        pattern: sharedRule.pattern,
        websites: sharedRule.websites || [],
        attack_type: sharedRule.attack_type,
        log_option: sharedRule.log_option || 'Persistence',
        cron_config: sharedRule.cron_config || { type: 'all' },
        is_global: sharedRule.is_global ?? false,
        target: sharedRule.target || 'src_ip',
        is_expired: sharedRule.is_expired ?? false,
        expire_time: sharedRule.expire_time ?? '',
        delay: sharedRule.delay ?? 0,
        percentage: sharedRule.percentage ?? 100,
      })
      if (resp.err !== null) throw new Error(`Expected success, got err=${resp.err}, msg=${resp.msg}`)
      console.log(`✅ [后端] admin 编辑共享规则成功（shared 软限制由前端确认框承接）`); p++
    } else {
      console.log('⚠️ 无多租户共享规则，跳过后端测试：admin 编辑共享规则绕过后端 shared 拦截直接执行'); p++
    }
  } catch (e) { f++; console.log(`❌ [后端] admin 编辑共享规则: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 5: Backend — admin disable shared rule succeeds (shared check bypassed for admin)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const rules = listResp.data?.items || []
    const sharedRule = rules.find(r => (r.binding_count ?? 0) > 1)
    if (sharedRule) {
      const resp = await apiPut(page, '/api/captain/policy-rule/enable', {
        captain_instance_id: captainInstanceId,
        ids: [sharedRule.id],
        action: sharedRule.is_enabled ? 'disable' : 'enable',
      })
      if (resp.err !== null) throw new Error(`Expected success, got err=${resp.err}, msg=${resp.msg}`)
      // Restore original state
      await apiPut(page, '/api/captain/policy-rule/enable', {
        captain_instance_id: captainInstanceId,
        ids: [sharedRule.id],
        action: sharedRule.is_enabled ? 'enable' : 'disable',
      }).catch(() => {})
      console.log(`✅ [后端] admin 启禁共享规则成功（shared 软限制由前端确认框承接）`); p++
    } else {
      console.log('⚠️ 无多租户共享规则，跳过后端测试：admin 启禁共享规则绕过后端 shared 拦截直接执行'); p++
    }
  } catch (e) { f++; console.log(`❌ [后端] admin 启禁共享规则: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 6: API — in-use rule delete returns detailed error with site count
  // ═══════════════════════════════════════════
  try {
    if (!ruleAId) throw new Error('Rule A not created')
    const resp = await apiDelete(page, '/api/captain/policy-rule/delete', {
      captain_instance_id: captainInstanceId,
      id: ruleAId,
    })
    if (resp.err !== 'in_use') throw new Error(`Expected err=in_use, got err=${resp.err}`)
    if (!resp.msg || !resp.msg.includes('站点')) throw new Error(`msg should mention sites: ${resp.msg}`)
    console.log(`✅ [API] 删除使用中规则返回含站点数的详细错误 (msg=${resp.msg})`); p++
  } catch (e) { f++; console.log(`❌ [API] 删除使用中规则详细错误: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 7: API — in-use rule can still be enabled/disabled (in_use only blocks delete)
  // ═══════════════════════════════════════════
  try {
    if (!ruleAId) throw new Error('Rule A not created')
    // Disable should NOT be blocked by in_use protection
    const resp = await apiPut(page, '/api/captain/policy-rule/enable', {
      captain_instance_id: captainInstanceId,
      ids: [ruleAId],
      action: 'disable',
    })
    if (resp.err === 'in_use') throw new Error('Enable/disable should NOT be blocked by in_use')
    // Restore enabled state
    await apiPut(page, '/api/captain/policy-rule/enable', {
      captain_instance_id: captainInstanceId,
      ids: [ruleAId],
      action: 'enable',
    }).catch(() => {})
    console.log(`✅ [API] 使用中规则仍可启用/禁用（in_use 仅阻止删除）`); p++
  } catch (e) { f++; console.log(`❌ [API] 使用中规则启用/禁用: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 8: UI — shared rule enable/disable shows warning
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const { rule: sharedRule, row } = await findVisibleSharedRuleRow(page, captainInstanceId)

    if (sharedRule) {
      const dropdownTrigger = row.locator('.el-dropdown').first()
      if (await dropdownTrigger.count() > 0) {
        await dropdownTrigger.click()
        await page.waitForTimeout(300)

        const enableItem = page.locator('.el-dropdown-menu:visible .el-dropdown-menu__item:has-text("启用规则")').first()
        if (await enableItem.count() === 0) throw new Error(`Shared rule ${sharedRule.id} enable menu item not found`)
        const enableStyle = await enableItem.getAttribute('style')
        if (!isGrayColor(enableStyle)) throw new Error(`Enable item not grayed out, style=${enableStyle}`)

        await enableItem.click()
        await page.waitForTimeout(500)

        const warningVisible = await page.locator('.el-message').filter({ hasText: '多个租户组绑定' }).count()
        if (warningVisible === 0) throw new Error('No warning toast for shared enable')
        console.log(`✅ [UI] 启用/禁用共享规则显示警告提示`); p++
      } else {
        console.log(`⚠️ 共享规则 ${sharedRule.id} 行未找到更多按钮，跳过 UI 测试：non-admin 启禁共享规则显示 warning 提示`); p++
      }
    } else {
      console.log('⚠️ 当前页无共享规则，跳过 UI 测试：non-admin 启禁共享规则显示 warning 提示'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 启用/禁用共享规则: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 9: UI — shared rule edit opens read-only mode
  // ═══════════════════════════════════════════
  try {
    // Test 9 runs as tenant_admin (already switched in test 8; test 11 will re-login if needed)
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const { rule: sharedRule, row } = await findVisibleSharedRuleRow(page, captainInstanceId)

    if (sharedRule) {
      const editBtn = row.locator('.el-icon-edit').first()
      if (await editBtn.count() > 0) {
        await editBtn.click()
        await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })

        const dialog = page.locator('.el-dialog:visible').first()
        const title = await dialog.locator('.el-dialog__title').textContent()
        if (!title.includes('查看规则')) throw new Error(`Expected 查看规则 title, got: ${title}`)

        const disabledInputs = await dialog.locator('.el-select.is-disabled, .el-input.is-disabled, .el-textarea.is-disabled').count()
        const disabledSelects = await dialog.locator('.el-select .is-disabled').count()
        if (disabledInputs === 0 && disabledSelects === 0) throw new Error('No disabled form controls in read-only mode')

        const footerText = await dialog.locator('.el-dialog__footer').first().textContent()
        if (footerText.includes('确定')) throw new Error('确定 button should be hidden in read-only mode')

        await dialog.locator('.el-dialog__headerbtn').first().click()
        await page.locator('.el-dialog:visible').first().waitFor({ state: 'hidden', timeout: 5000 }).catch(() => {})
        console.log(`✅ [UI] 共享规则编辑以只读模式打开`); p++
      } else {
        console.log('⚠️ 共享规则行未找到编辑按钮'); p++
      }
    } else {
      console.log('⚠️ 当前页无共享规则，跳过 UI 测试：non-admin 编辑共享规则以只读模式打开表单'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 共享规则只读模式: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 10: UI — edit button is grayed for protected rules
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const { rule: sharedRule, row } = await findVisibleSharedRuleRow(page, captainInstanceId)

    if (sharedRule) {
      const editBtn = row.locator('.el-icon-edit').first()
      if (await editBtn.count() > 0) {
        const editStyle = await editBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (!isGrayColor(editStyle)) throw new Error(`Edit button not grayed, style=${editStyle}`)
        console.log(`✅ [UI] 编辑按钮置灰显示保护状态`); p++
      } else {
        console.log(`⚠️ 共享规则 ${sharedRule.id} 行未找到编辑按钮，跳过 UI 测试：共享规则编辑按钮显示置灰样式`); p++
      }
    } else {
      console.log('⚠️ 当前页无共享规则，跳过 UI 测试：共享规则编辑按钮显示置灰样式'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 编辑按钮样式: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 11: Tenant — protection fields + in-use delete blocked
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')

    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const tenantListResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantRules = tenantListResp.data?.items || []
    if (tenantRules.length > 0) {
      const sample = tenantRules[0]
      if (!('has_external_ref' in sample)) throw new Error('Missing has_external_ref field for tenant user')
      if (!('source' in sample)) throw new Error('Missing source field for tenant user')
      console.log(`✅ [租户] has_external_ref, source 字段注入正确`); p++
    } else {
      console.log('⚠️ 租户无可见规则，跳过字段检查'); p++
    }

    // Try deleting a tenant-owned in-use rule as tenant via API.
    // Do not reuse admin-seeded ruleAId here: public Captain data may map it to
    // a different tenant group, which makes this assertion depend on ambient data.
    const tenantSiteResp = await apiGet(page, `/api/captain/site/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantSites = tenantSiteResp.data?.items || []
    const tenantSiteId = tenantSites[0]?.id
    let tenantRuleId = null

    if (tenantSiteId) {
      const createResp = await apiPost(page, '/api/captain/policy-rule/create', {
        captain_instance_id: captainInstanceId,
        ...rulePayload(`${TEST_PREFIX}_tenant_inuse`, [tenantSiteId], '9.8.7.6'),
      })
      if (createResp.err !== null || !createResp.data) {
        throw new Error(`Failed to create tenant in-use rule: err=${createResp.err}, msg=${createResp.msg}`)
      }
      tenantRuleId = typeof createResp.data === 'object' ? createResp.data.id : createResp.data
      if (tenantRuleId) createdRuleIds.push(tenantRuleId)
    }

    if (tenantRuleId) {
      const resp = await apiDelete(page, '/api/captain/policy-rule/delete', {
        captain_instance_id: captainInstanceId,
        id: tenantRuleId,
      })
      if (resp.err === 'in_use' || resp.err === 'forbidden') {
        console.log(`✅ [租户] 删除使用中规则被阻止 (err=${resp.err})`); p++
      } else if (resp.err === null) {
        throw new Error('Tenant should not be able to delete in-use rule')
      } else {
        console.log(`⚠️ [租户] 删除使用中规则返回 err=${resp.err}, msg=${resp.msg}`); p++
      }
    } else {
      console.log('⚠️ 租户无可见站点，跳过使用中规则删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [租户] 使用中规则保护: ${e.message}`) }

  // Re-login as admin
  try { await loginAs(page, 'admin') } catch { /* non-fatal */ }

  // Helper: find row index on current page
  async function findRowIndex(comment) {
    return page.evaluate((c) => {
      const rows = document.querySelectorAll('.el-table__row')
      for (let i = 0; i < rows.length; i++) {
        if (rows[i].innerText.includes(c)) return i
      }
      return -1
    }, comment)
  }

  // Helper: find rule row across all pages — always searches from page 1
  async function findRuleRow(comment) {
    // First, go back to page 1 (navTo to the same route may not reset the Grid's currentPage)
    const prevBtn = page.locator('.el-pagination .btn-prev')
    for (let back = 0; back < 50; back++) {
      if (await prevBtn.count() === 0) break
      const prevDisabled = await prevBtn.evaluate(el => el.disabled || el.classList.contains('is-disabled')).catch(() => true)
      if (prevDisabled) break
      await prevBtn.click()
      await waitForTableData(page)
    }
    // Now search forward from page 1
    let idx = await findRowIndex(comment)
    if (idx >= 0) return page.locator('.el-table__row').nth(idx)
    const nextBtn = page.locator('.el-pagination .btn-next')
    for (let attempt = 0; attempt < 30; attempt++) {
      if (await nextBtn.count() === 0) break
      const disabled = await nextBtn.evaluate(el => el.disabled || el.classList.contains('is-disabled')).catch(() => true)
      if (disabled) break
      await nextBtn.click()
      await waitForTableData(page)
      idx = await findRowIndex(comment)
      if (idx >= 0) return page.locator('.el-table__row').nth(idx)
    }
    return null
  }

  // Helper: wait for el-message-box $confirm dialog
  async function expectConfirmDialog(label) {
    try {
      await page.locator('.el-message-box__wrapper').waitFor({ state: 'visible', timeout: 3000 })
    } catch {
      throw new Error(`Expected $confirm dialog for [${label}], but none appeared`)
    }
  }

  // ═══════════════════════════════════════════
  // Test 12: UI — admin edit in-use rule (Row 1) shows confirmation dialog with site names
  // ═══════════════════════════════════════════
  try {
    if (!ruleAId) throw new Error('Rule A not created')
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const ruleA = await findRuleById(page, captainInstanceId, ruleAId, 'Rule A')

    const row = await findRuleRow(ruleA.comment)
    if (!row) throw new Error(`Rule A (comment=${ruleA.comment}) not found in any page`)

    await row.locator('.el-icon-edit').first().click()
    await expectConfirmDialog('Row 1 edit')
    const msg = await page.locator('.el-message-box__message').first().textContent()
    if (!msg.includes('引用') && !msg.includes('站点')) throw new Error(`Unexpected confirm text: ${msg}`)
    await page.locator('.el-message-box__wrapper .el-button:not(.el-button--primary)').first().click()
    await page.waitForTimeout(300)
    console.log(`✅ [UI] admin 编辑"仅本租户站点在用"规则：弹确认框列出引用站点名`); p++
  } catch (e) { f++; console.log(`❌ [UI] admin 编辑使用中规则确认框: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 13: UI — admin disable in-use rule (Row 1) shows confirmation dialog
  // ═══════════════════════════════════════════
  try {
    if (!ruleAId) throw new Error('Rule A not created')
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const ruleA = await findRuleById(page, captainInstanceId, ruleAId, 'Rule A')

    const row = await findRuleRow(ruleA.comment)
    if (!row) throw new Error(`Rule A not found in any page`)

    await row.locator('.el-icon-more').first().click()
    await page.waitForTimeout(300)
    await page.locator('.el-dropdown-menu:visible .el-dropdown-menu__item').filter({ hasText: '禁用规则' }).first().click()
    await expectConfirmDialog('Row 1 disable')
    await page.locator('.el-message-box__wrapper .el-button:not(.el-button--primary)').first().click()
    await page.waitForTimeout(300)
    console.log(`✅ [UI] admin 禁用"仅本租户站点在用"规则：弹确认框而非直接执行`); p++
  } catch (e) { f++; console.log(`❌ [UI] admin 禁用使用中规则确认框: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 14: UI — admin edit unused rule (Row 3) shows confirmation dialog (防误操作)
  // ═══════════════════════════════════════════
  try {
    if (!ruleCId) throw new Error('Rule C not created')
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const ruleC = await findRuleById(page, captainInstanceId, ruleCId, 'Rule C')

    const row = await findRuleRow(ruleC.comment)
    if (!row) throw new Error(`Rule C (comment=${ruleC.comment}) not found in any page`)

    await row.locator('.el-icon-edit').first().click()
    await expectConfirmDialog('Row 3 edit')
    const msg = await page.locator('.el-message-box__message').first().textContent()
    if (!msg.includes('无站点引用')) throw new Error(`Unexpected confirm text: ${msg}`)
    await page.locator('.el-message-box__wrapper .el-button:not(.el-button--primary)').first().click()
    await page.waitForTimeout(300)
    console.log(`✅ [UI] admin 编辑"已绑定租户组但无站点引用"规则：弹确认框防误操作`); p++
  } catch (e) { f++; console.log(`❌ [UI] admin 编辑无引用规则确认框: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 15: UI — admin delete unused rule (Row 3) shows confirmation dialog, confirm deletes
  // ═══════════════════════════════════════════
  try {
    if (!ruleCId) throw new Error('Rule C not created')
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const ruleC = await findRuleById(page, captainInstanceId, ruleCId, 'Rule C')

    const row = await findRuleRow(ruleC.comment)
    if (!row) throw new Error(`Rule C not found in any page`)

    await row.locator('.el-icon-more').first().click()
    await page.waitForTimeout(300)
    await page.locator('.el-dropdown-menu:visible .el-dropdown-menu__item').filter({ hasText: '删除规则' }).first().click()
    await expectConfirmDialog('Row 3 delete')
    const msg = await page.locator('.el-message-box__message').first().textContent()
    if (!msg.includes('无站点引用')) throw new Error(`Unexpected confirm text: ${msg}`)
    // Confirm to actually delete (serves as cleanup)
    await page.locator('.el-message-box__wrapper .el-button--primary').first().click()
    await page.waitForTimeout(500)
    const idx = createdRuleIds.indexOf(ruleCId)
    if (idx >= 0) createdRuleIds.splice(idx, 1)
    ruleCId = null
    console.log(`✅ [UI] admin 删除"已绑定租户组但无站点引用"规则：确认框防误操作，确认后删除成功`); p++
  } catch (e) { f++; console.log(`❌ [UI] admin 删除无引用规则确认框: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 16: UI — admin delete shared+in_use rule shows toast warning (in_use 硬限制, Row 4+websites非空)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const rules = listResp.data?.items || []
    const target = rules.find(r => (r.binding_count ?? 0) > 1 && (r.websites?.length ?? 0) > 0)

    if (target) {
      console.log(`  [debug] Shared in-use rule: id=${target.id}, comment="${target.comment}", bc=${target.binding_count}, sites=${target.websites?.length}`)
      let row = await findRuleRow(target.comment || String(target.id))
      if (!row && target.comment) row = await findRuleRow(String(target.id))
      if (!row) throw new Error(`Row not found in any page (comment="${target.comment}", id=${target.id})`)
      await row.locator('.el-icon-more').first().click()
      await page.waitForTimeout(300)
      await page.locator('.el-dropdown-menu:visible .el-dropdown-menu__item').filter({ hasText: '删除规则' }).first().click()
      await page.waitForTimeout(500)

      // Must be toast, NOT $confirm dialog
      const msgBoxVisible = await page.locator('.el-message-box__wrapper').isVisible()
      if (msgBoxVisible) {
        await page.locator('.el-message-box__wrapper .el-button:not(.el-button--primary)').first().click()
        throw new Error('Expected toast (in_use 硬限制), but got $confirm dialog')
      }
      const toastVisible = await page.locator('.el-message').filter({ hasText: '站点' }).count()
      if (toastVisible === 0) throw new Error('Expected in_use toast warning')
      console.log(`✅ [UI] admin 删除共享+使用中规则显示 toast 警告（in_use 硬限制，无确认框）`); p++
    } else {
      console.log('⚠️ 无多租户共享且有站点在用的规则，跳过 UI 测试：admin 删除时触发 in_use toast 而非确认框'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] admin 删除共享+使用中规则: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 17: UI — admin delete shared unused rule shows confirmation dialog (Row 4, websites空)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const rules = listResp.data?.items || []
    const target = rules.find(r => (r.binding_count ?? 0) > 1 && (r.websites?.length ?? 0) === 0)

    if (target) {
      const row = await findRuleRow(target.comment || String(target.id))
      if (!row) throw new Error('Row not found in any page')
      await row.locator('.el-icon-more').first().click()
      await page.waitForTimeout(300)
      await page.locator('.el-dropdown-menu:visible .el-dropdown-menu__item').filter({ hasText: '删除规则' }).first().click()
      await expectConfirmDialog('Row 4 delete (no sites)')
      const msg = await page.locator('.el-message-box__message').first().textContent()
      if (!msg.includes('共享') && !msg.includes('租户组')) throw new Error(`Unexpected confirm text: ${msg}`)
      await page.locator('.el-message-box__wrapper .el-button:not(.el-button--primary)').first().click()
      await page.waitForTimeout(300)
      console.log(`✅ [UI] admin 删除共享无引用规则弹确认框（Row 4，列出 shared_group_names）`); p++
    } else {
      console.log('⚠️ 无多租户共享且当前无站点引用的规则，跳过 UI 测试：admin 删除时弹共享确认框（含租户组名）'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] admin 删除共享无引用规则确认框: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 18: UI — admin edit has_external_ref rule shows confirmation dialog (Row 2)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '自定义规则')
    await waitForWafSelector(page)
    await selectWafIfNeeded(page, captainWafName)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const rules = listResp.data?.items || []
    const target = rules.find(r => r.has_external_ref === true)

    if (target) {
      const row = await findRuleRow(target.comment || String(target.id))
      if (!row) throw new Error('Row not found in any page')
      await row.locator('.el-icon-edit').first().click()
      await expectConfirmDialog('Row 2 edit (external ref)')
      const msg = await page.locator('.el-message-box__message').first().textContent()
      if (!msg.includes('租户组') && !msg.includes('引用')) throw new Error(`Unexpected confirm text: ${msg}`)
      await page.locator('.el-message-box__wrapper .el-button:not(.el-button--primary)').first().click()
      await page.waitForTimeout(300)
      console.log(`✅ [UI] admin 编辑外部引用规则弹确认框（Row 2，列出 shared_group_names）`); p++
    } else {
      console.log('⚠️ 无"含外部租户组站点引用"的规则，跳过 UI 测试：admin 编辑时弹确认框列出外部租户组名'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] admin 编辑外部引用规则确认框: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 19: Backend — admin delete shared+in_use rule returns in_use (硬限制不因 admin 而豁免)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const rules = listResp.data?.items || []
    const target = rules.find(r => (r.binding_count ?? 0) > 1 && (r.websites?.length ?? 0) > 0)

    if (target) {
      const resp = await apiDelete(page, '/api/captain/policy-rule/delete', {
        captain_instance_id: captainInstanceId,
        id: target.id,
      })
      if (resp.err !== 'in_use') throw new Error(`Expected err=in_use (hard block for admin too), got err=${resp.err}`)
      console.log(`✅ [后端] admin 删除共享+使用中规则返回 in_use（硬限制，Row 4+in_use）`); p++
    } else {
      console.log('⚠️ 无多租户共享且有站点在用的规则，跳过后端测试：admin 删除返回 in_use（in_use 硬限制对 admin 也生效）'); p++
    }
  } catch (e) { f++; console.log(`❌ [后端] admin 删除共享+使用中规则: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 20: Backend — module endpoints keep non-admin shared block, admin bypasses it
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'admin')
    const adminListResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const adminRules = adminListResp.data?.items || []
    const adminModuleRule = adminRules.find(r => (r.binding_count ?? 0) > 1 && r.action === 'modify_module')

    await loginAs(page, 'tenant_admin')
    const tenantListResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantRules = tenantListResp.data?.items || []
    const tenantModuleRule = tenantRules.find(r => (r.binding_count ?? 0) > 1 && r.action === 'modify_module')

    if (adminModuleRule && tenantModuleRule) {
      const tenantPayload = moduleEndpointPayload(tenantModuleRule, captainInstanceId)
      const tenantPost = await apiPost(page, '/api/captain/policy-rule/module', tenantPayload)
      if (tenantPost.err !== 'shared') throw new Error(`tenant_admin POST module expected shared, got err=${tenantPost.err}`)
      const tenantPut = await apiPut(page, '/api/captain/policy-rule/module', tenantPayload)
      if (tenantPut.err !== 'shared') throw new Error(`tenant_admin PUT module expected shared, got err=${tenantPut.err}`)

      await loginAs(page, 'admin')
      const adminPayload = moduleEndpointPayload(adminModuleRule, captainInstanceId)
      const adminPost = await apiPost(page, '/api/captain/policy-rule/module', adminPayload)
      expectNotShared(adminPost, 'admin POST module')
      const adminPut = await apiPut(page, '/api/captain/policy-rule/module', adminPayload)
      expectNotShared(adminPut, 'admin PUT module')
      console.log(`✅ [后端] module POST/PUT：tenant_admin 返回 shared，admin 不再被 shared 硬拦截`); p++
    } else {
      console.log('⚠️ 无多租户共享的检测模块控制规则，跳过后端测试：module POST/PUT admin shared 绕过与 non-admin 拦截'); p++
    }
  } catch (e) { f++; console.log(`❌ [后端] module shared 保护分级: ${e.message}`) }
  try { await loginAs(page, 'admin') } catch { /* non-fatal */ }

  // ═══════════════════════════════════════════
  // Test 21: Backend — skynet endpoint keeps non-admin shared block, admin bypasses it
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'admin')
    const adminListResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const adminRules = adminListResp.data?.items || []
    const adminSkynetRule = adminRules.find(r => (r.binding_count ?? 0) > 1 && r.action === 'modify_skynet_rule')

    await loginAs(page, 'tenant_admin')
    const tenantListResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantRules = tenantListResp.data?.items || []
    const tenantSkynetRule = tenantRules.find(r => (r.binding_count ?? 0) > 1 && r.action === 'modify_skynet_rule')

    if (adminSkynetRule && tenantSkynetRule) {
      const tenantPayload = skynetEndpointPayload(tenantSkynetRule, captainInstanceId)
      const tenantResp = await apiPut(page, '/api/captain/policy-rule/skynet-rule', tenantPayload)
      if (tenantResp.err !== 'shared') throw new Error(`tenant_admin skynet expected shared, got err=${tenantResp.err}`)

      await loginAs(page, 'admin')
      const adminPayload = skynetEndpointPayload(adminSkynetRule, captainInstanceId)
      const adminResp = await apiPut(page, '/api/captain/policy-rule/skynet-rule', adminPayload)
      expectNotShared(adminResp, 'admin skynet')
      console.log(`✅ [后端] skynet PUT：tenant_admin 返回 shared，admin 不再被 shared 硬拦截`); p++
    } else {
      console.log('⚠️ 无多租户共享的内置规则控制规则，跳过后端测试：skynet PUT admin shared 绕过与 non-admin 拦截'); p++
    }
  } catch (e) { f++; console.log(`❌ [后端] skynet shared 保护分级: ${e.message}`) }
  try { await loginAs(page, 'admin') } catch { /* non-fatal */ }

  // ═══════════════════════════════════════════
  // Cleanup
  // ═══════════════════════════════════════════
  try {
    for (const ruleId of Array.from(new Set(createdRuleIds))) {
      const deleteResp = await apiDelete(page, '/api/captain/policy-rule/delete', {
        captain_instance_id: captainInstanceId,
        id: ruleId,
      }).catch(() => null)

      if (deleteResp?.err === 'in_use') {
        const listResp = await apiGet(page, `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}&offset=0&count=10000`).catch(() => null)
        const rules = listResp?.data?.items || []
        const rule = rules.find(r => r.id === ruleId)
        if (rule) {
          await apiPut(page, '/api/captain/policy-rule/update', cleanupUpdatePayload(rule, captainInstanceId)).catch(() => {})
          await apiDelete(page, '/api/captain/policy-rule/delete', {
            captain_instance_id: captainInstanceId,
            id: ruleId,
          }).catch(() => {})
        }
      }
    }

    if (createdSiteIds.length > 0) {
      const cookieHeader = await apiLogin(page)
      await cleanupSites(page, cookieHeader, createdSiteIds, captainInstanceId)
    }
    console.log('✅ 清理测试数据')
  } catch (e) { f++; console.log(`❌ 清理测试数据: ${e.message}`) }

  console.log(`\n📊 RuleWriteProtection: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
