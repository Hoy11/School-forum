// Integration: Block page write protection — in_use + shared + source injection
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND = TARGET_URL.replace(':3000', ':8080')

// API helpers (browser-context fetch with auto cookies)
async function apiGet(page, urlPath) {
  return page.evaluate(async (p) => {
    const r = await fetch(p, { credentials: 'include' })
    return r.json()
  }, urlPath)
}

async function apiDelete(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return { status: r.status, body: await r.json() }
  }, [urlPath, body])
}

async function apiPut(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return { status: r.status, body: await r.json() }
  }, [urlPath, body])
}

async function waitForBlockPageUnused(page, captainInstanceId, nameHash, timeoutMs = 12000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=1000`)
    const bp = (listResp.data?.items || []).find(b => b.name === nameHash)
    if (!bp || (bp.policy_group_used_count ?? 0) === 0) return true
    await page.waitForTimeout(500)
  }
  return false
}

// Delete a BP using the two-step confirm_token flow (handles shared BPs for admin).
async function adminDeleteBP(page, captainInstanceId, nameHash) {
  const probe = await apiDelete(page, '/api/captain/block-page/delete', { name: nameHash, captain_instance_id: captainInstanceId })
  if (probe.body?.err === 'shared') {
    const token = probe.body?.confirm_token
    if (!token) throw new Error('No confirm_token in shared error response')
    const confirm = await apiDelete(page, `/api/captain/block-page/delete?confirm_token=${encodeURIComponent(token)}`, { name: nameHash, captain_instance_id: captainInstanceId })
    if (confirm.body?.err) throw new Error(`Delete with token failed: err=${confirm.body.err}`)
    return confirm
  }
  if (probe.body?.err) throw new Error(`Delete failed: err=${probe.body.err}`)
  return probe
}

// Check if style contains gray color (#ccc or rgb(204,...))
function isGrayColor(style) {
  if (!style) return false
  return style.includes('#ccc') || style.includes('rgb(204') || style.includes('rgb(204, 204, 204)')
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  let p = 0, f = 0, s = 0
  let captainInstanceId

  // --- Seed: login as admin ---
  await loginAs(page, 'admin')

  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    captainInstanceId = await getActiveWafId(page, cookieHeader)
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)
    console.log(`  Using captain_instance_id=${captainInstanceId}`)
  } catch (e) {
    console.log(`❌ WAF selection: ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  // --- Fixture: admin upload BP → used_count=0, binding_count=0, tenant_admin invisible ---
  let fixtureBPHash = null
  try {
    const ts = Date.now()
    const uploadResp = await page.evaluate(async ({ cid, ts }) => {
      const fd = new FormData()
      fd.append('file', new Blob(['<html><body>E2E fixture</body></html>'], { type: 'text/html' }), `e2e_fixture_${ts}.html`)
      fd.append('captain_instance_id', String(cid))
      const r = await fetch(`/api/captain/block-page/upload?captain_instance_id=${cid}`, { method: 'POST', body: fd, credentials: 'include' })
      return { status: r.status, body: await r.json() }
    }, { cid: captainInstanceId, ts })
    if (uploadResp.status >= 300) throw new Error(`Fixture upload failed: ${JSON.stringify(uploadResp.body)}`)
    fixtureBPHash = uploadResp.body?.data?.path
    if (!fixtureBPHash) throw new Error('No path in upload response')
    console.log(`  [fixture] uploaded BP hash=${fixtureBPHash.substring(0,8)}...`)
  } catch (e) { console.log(`⚠️ Fixture upload failed: ${e.message}`) }

  // --- Shared Fixture: tenant_admin upload + policy reconcile → binding_count > 1 ---
  // BP deduplication is by content hash. tenant_admin upload creates TG1 binding (binding_count=1).
  // Policy reconcile creates additional bindings for other TGs using that policy → binding_count>1.
  let sharedFixtureBPHash = null
  let sharedFixtureReady = false
  let reconcilePolicy = null
  let reconcilePolicyOriginalPath = null
  try {
    // Step 1: tenant_admin uploads fixture BP → TG1 binding
    await loginAs(page, 'tenant_admin')
    const sharedHTML = '<html><body>E2E shared fixture block page</body></html>'
    const sharedUploadResp = await page.evaluate(async ({ cid, html }) => {
      const fd = new FormData()
      fd.append('file', new Blob([html], { type: 'text/html' }), `e2e_shared_${Date.now()}.html`)
      fd.append('captain_instance_id', String(cid))
      const r = await fetch(`/api/captain/block-page/upload?captain_instance_id=${cid}`, { method: 'POST', body: fd, credentials: 'include' })
      return { status: r.status, body: await r.json() }
    }, { cid: captainInstanceId, html: sharedHTML })
    if (sharedUploadResp.status >= 300) throw new Error(`tenant_admin upload failed: status=${sharedUploadResp.status}`)
    sharedFixtureBPHash = sharedUploadResp.body?.data?.path
    if (!sharedFixtureBPHash) throw new Error('No path in upload response')

    // Step 2: Admin temporarily updates a policy to use fixture BP → reconcile creates TG2+ bindings
    await loginAs(page, 'admin')
    const policiesResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = policiesResp.data?.items || []
    // Find a policy that has a forbidden_page_config.path (so reconcile is meaningful)
    reconcilePolicy = policies.find(pol => pol.forbidden_page_config?.path)
    if (reconcilePolicy) {
      reconcilePolicyOriginalPath = reconcilePolicy.forbidden_page_config.path
      const updateBody = { ...reconcilePolicy, captain_instance_id: captainInstanceId,
        forbidden_page_config: { ...reconcilePolicy.forbidden_page_config, path: sharedFixtureBPHash } }
      const updateResp = await apiPut(page, '/api/captain/policy/update', updateBody)
      if (updateResp.status >= 300 || updateResp.body?.err !== null) {
        reconcilePolicy = null
        reconcilePolicyOriginalPath = null
      } else {
        // Step 3: Poll until binding_count > 1 (reconcile runs async)
        for (let i = 0; i < 20; i++) {
          await page.waitForTimeout(500)
          const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
          const bp = (listResp.data?.items || []).find(b => b.name === sharedFixtureBPHash)
          if (bp && (bp.binding_count ?? 0) > 1) { sharedFixtureReady = true; break }
        }
      }
    }
    // Verify actual binding_count
    const checkResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const sharedBP = (checkResp.data?.items || []).find(b => b.name === sharedFixtureBPHash)
    const bc = sharedBP?.binding_count ?? 0
    console.log(`  [shared fixture] hash=${sharedFixtureBPHash.substring(0,8)}... binding_count=${bc}`)
    sharedFixtureReady = bc > 1
    if (!sharedFixtureReady) console.log('  [shared fixture] binding_count=1 only — shared-specific tests will skip')
  } catch (e) {
    console.log(`⚠️ Shared fixture setup failed: ${e.message}`)
    sharedFixtureBPHash = null
    sharedFixtureReady = false
    reconcilePolicy = null
  }

  // ═══════════════════════════════════════════
  // Test 1: List injection — binding_count + policy_group_used_count + shared_group_names fields (admin)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    if (items.length === 0) throw new Error('No block pages returned')

    const sample = items[0]
    if (!('binding_count' in sample)) throw new Error('Missing binding_count field')
    if (!('policy_group_used_count' in sample)) throw new Error('Missing policy_group_used_count field')
    if (!('shared_group_names' in sample)) throw new Error('Missing shared_group_names field for admin')
    // Verify shared items have non-empty shared_group_names
    const sharedItem = items.find(i => (i.binding_count ?? 0) > 1)
    if (sharedItem && (!Array.isArray(sharedItem.shared_group_names) || sharedItem.shared_group_names.length === 0)) {
      throw new Error(`shared_group_names should be non-empty for shared BP (binding_count=${sharedItem.binding_count})`)
    }
    console.log(`✅ [列表注入] binding_count, policy_group_used_count, shared_group_names 字段存在`); p++
  } catch (e) { f++; console.log(`❌ [列表注入] 保护字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 2: List injection — admin has no source field (source only for non-admin)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    if (items.length === 0) throw new Error('No block pages returned')

    const sample = items[0]
    // source is only injected for non-admin users — admin should NEVER have it
    if ('source' in sample) throw new Error(`Admin should NOT have source field, got source=${sample.source}`)
    console.log(`✅ [列表注入] admin 无 source 字段（source 仅注入 non-admin）`); p++
  } catch (e) { f++; console.log(`❌ [列表注入] source 字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 3: Runtime protection — in_use delete returns err=in_use
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseBP = items.find(bp => (bp.policy_group_used_count ?? 0) > 0)

    if (inUseBP) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: inUseBP.name,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Expected err=in_use, got err=${resp.body?.err}, status=${resp.status}`)
      console.log(`✅ [运行时保护] 删除使用中拦截页面返回 in_use 错误`); p++
    } else {
      console.log('⚠️ 无使用中拦截页面(policy_group_used_count>0)，跳过运行时保护测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [运行时保护] 删除使用中拦截页面: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 4: Runtime protection — error message contains policy group count
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseBP = items.find(bp => (bp.policy_group_used_count ?? 0) > 0)

    if (inUseBP) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: inUseBP.name,
        captain_instance_id: captainInstanceId,
      })
      if (!resp.body?.msg || !resp.body.msg.includes('防护策略')) throw new Error(`msg should mention 防护策略: ${resp.body?.msg}`)
      console.log(`✅ [运行时保护] 错误消息包含引用数 (msg=${resp.body.msg})`); p++
    } else {
      console.log('⚠️ 无使用中拦截页面，跳过错误消息测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [运行时保护] 错误消息: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 5: Admin shared — backend returns err=shared + confirm_token (P1-1: admin no longer bypasses)
  //   Step 1: no token → expect err=shared with confirm_token in response
  //   Step 2: with token → expect success (fixture deleted as part of verification)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedNotInUse = sharedFixtureReady
      ? items.find(bp => bp.name === sharedFixtureBPHash && (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)
      : null

    if (sharedNotInUse) {
      // Step 1: admin DELETE without token → backend must return err=shared + confirm_token (P1-1 fix)
      const probe = await apiDelete(page, '/api/captain/block-page/delete', {
        name: sharedNotInUse.name, captain_instance_id: captainInstanceId,
      })
      if (probe.body?.err !== 'shared') throw new Error(`Expected err=shared (no token), got err=${probe.body?.err}, status=${probe.status}`)
      const confirmToken = probe.body?.confirm_token
      if (!confirmToken) throw new Error(`Expected confirm_token in err=shared response, got: ${JSON.stringify(probe.body)}`)
      // Token verified — fixture preserved for Tests 10/19/20; teardown will complete the delete
      console.log(`✅ [共享保护 P1] admin 无 token 删除共享拦截页面返回 err=shared + confirm_token（后端拦截生效）`); p++
    } else {
      console.log('⚠️ shared fixture 未达到 binding_count>1，跳过 admin 共享保护 P1 测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [共享保护 P1] admin 删除共享拦截页面: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 6: Non-admin shared protection — tenant_admin delete shared BP returns err=shared
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')
    await page.waitForTimeout(500)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedNotInUse = sharedFixtureReady
      ? items.find(bp => bp.name === sharedFixtureBPHash && (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)
      : null

    if (sharedNotInUse) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: sharedNotInUse.name, captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'shared') throw new Error(`Expected err=shared for non-admin, got err=${resp.body?.err}`)
      if (!resp.body?.msg || !resp.body.msg.includes('共享')) throw new Error(`msg should mention 共享: ${resp.body?.msg}`)
      // Non-admin also receives confirm_token (backend unified flow), but shouldn't use it
      console.log(`✅ [non-admin 共享] tenant_admin 删除共享拦截页面返回 shared (msg="${resp.body.msg}")`); p++
    } else {
      console.log('⚠️ shared fixture 未达到 binding_count>1，跳过 non-admin 共享保护测试'); s++
    }

    await loginAs(page, 'admin')
    await page.waitForTimeout(500)
  } catch (e) { f++; console.log(`❌ [non-admin 共享] tenant_admin 删除共享拦截页面: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 7: Priority — in_use + shared both true → in_use takes priority
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const bothProtected = items.find(bp => (bp.policy_group_used_count ?? 0) > 0 && (bp.binding_count ?? 0) > 1)

    if (bothProtected) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: bothProtected.name,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Expected err=in_use (priority), got err=${resp.body?.err}`)
      console.log(`✅ [优先级] in_use + shared 同时满足时优先返回 in_use`); p++
    } else {
      console.log('⚠️ 无同时 in_use+shared 的拦截页面，跳过优先级测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [优先级] in_use 优先: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 8: Ownership — non-owner tenant group delete returns err=forbidden
  // ═══════════════════════════════════════════
  try {
    // Fetch admin-visible BPs BEFORE switching to tenant_admin session
    const adminListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const adminItems = adminListResp.data?.items || []

    // Switch to tenant_admin — backend filters list to this TG only
    await loginAs(page, 'tenant_admin')

    const tenantListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantItems = tenantListResp.data?.items || []

    // Items visible to admin but NOT to tenant_admin are non-owned resources
    // Prefer fixture BP (admin upload, no mapping → never visible to tenant_admin)
    const tenantNames = new Set(tenantItems.map(i => i.name))
    const notOwned = fixtureBPHash
      ? adminItems.find(i => i.name === fixtureBPHash && !tenantNames.has(i.name))
      : adminItems.find(i => !tenantNames.has(i.name))

    if (notOwned) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: notOwned.name,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'forbidden') throw new Error(`Expected err=forbidden, got err=${resp.body?.err}`)
      console.log(`✅ [所有权] 非本组资源删除返回 forbidden`); p++
    } else {
      console.log('⚠️ 无非本组拦截页面，跳过所有权测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [所有权] 非本组资源: ${e.message}`) }

  // Re-login as admin for remaining tests
  await loginAs(page, 'admin')

  // ═══════════════════════════════════════════
  // Test 9: UI — in-use block page delete button grayed + tooltip
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseBP = items.find(bp => (bp.policy_group_used_count ?? 0) > 0)

    if (inUseBP) {
      const row = page.locator('.el-table__row').filter({ hasText: inUseBP.comment || inUseBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (!isGrayColor(btnStyle)) throw new Error(`In-use BP delete button not grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message').filter({ hasText: '防护策略使用' }).count()
        if (warningVisible === 0) throw new Error('No warning toast for in-use BP delete')
        console.log(`✅ [UI] 使用中拦截页面删除按钮置灰+警告提示`); p++
      } else {
        console.log('⚠️ 使用中拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无使用中拦截页面，跳过UI使用中删除测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [UI] 使用中拦截页面删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 10: UI — admin shared-only BP delete button NOT grayed, shows confirm dialog
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedBP = sharedFixtureReady
      ? items.find(bp => bp.name === sharedFixtureBPHash && (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)
      : null

    if (sharedBP) {
      const row = page.locator('.el-table__row').filter({ hasText: sharedBP.comment || sharedBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (isGrayColor(btnStyle)) throw new Error(`Admin shared-only BP button should NOT be grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        // Admin should see confirm dialog (not warning toast) for shared BP
        const confirmVisible = await page.locator('.el-message-box:visible').count()
        if (confirmVisible > 0) {
          const confirmText = await page.locator('.el-message-box:visible').textContent()
          if (!confirmText.includes('共享')) throw new Error(`Confirm dialog should mention 共享: "${confirmText}"`)
          await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click()
          console.log(`✅ [UI] admin 共享拦截页面删除按钮深色+弹确认框（含共享组名）`); p++
        } else {
          console.log('⚠️ admin 共享拦截页面点击删除未弹出确认框'); s++
        }
      } else {
        console.log('⚠️ 共享拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无纯共享拦截页面，跳过 admin UI 共享删除测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [UI] admin 共享拦截页面删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 11: UI — admin normal block page delete shows confirm dialog (anti-misoperation)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const normalBP = fixtureBPHash
      ? items.find(bp => bp.name === fixtureBPHash)
      : items.find(bp => (bp.binding_count ?? 0) <= 1 && (bp.policy_group_used_count ?? 0) === 0)

    if (normalBP) {
      const row = page.locator('.el-table__row').filter({ hasText: normalBP.comment || normalBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (isGrayColor(btnStyle)) throw new Error(`Admin normal BP delete button should NOT be grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        // Admin should see confirm dialog listing tenant group info
        const confirmVisible = await page.locator('.el-message-box:visible').count()
        if (confirmVisible > 0) {
          const confirmText = await page.locator('.el-message-box:visible').textContent()
          if (!confirmText.includes('租户组')) throw new Error(`Confirm dialog should mention 租户组: "${confirmText}"`)
          // Cancel (non-destructive — fixture shared with Tests 8/20b)
          await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click()
          console.log(`✅ [UI] admin 正常拦截页面删除：弹确认框（含"租户组"），取消后不删`); p++
        } else {
          console.log('⚠️ admin 正常拦截页面点击删除未弹出确认框'); s++
        }
      } else {
        console.log('⚠️ 正常拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无可删除拦截页面，跳过 admin UI 正常删除测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [UI] admin 正常拦截页面删除: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 12: UI — admin in_use BP delete click shows warning toast (in_use hard block for all roles)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    // Only in_use BP (not shared) — shared-only is now a confirm dialog for admin (Test 10)
    const inUseBP = items.find(bp => (bp.policy_group_used_count ?? 0) > 0)

    if (inUseBP) {
      const row = page.locator('.el-table__row').filter({ hasText: inUseBP.comment || inUseBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message--warning').filter({ hasText: '防护策略使用' }).count()
        if (warningVisible === 0) throw new Error('No warning toast for in-use BP delete click')
        console.log(`✅ [UI] admin 使用中拦截页面点击删除显示 warning toast（in_use 硬限制）`); p++
      } else {
        console.log('⚠️ 使用中拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无使用中拦截页面，跳过 in_use warning toast 测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [UI] in_use warning toast: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 13: Tenant — source field injection for tenant_admin
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')

    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const tenantListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantItems = tenantListResp.data?.items || []
    if (tenantItems.length > 0) {
      const sample = tenantItems[0]
      if (!('source' in sample)) throw new Error('Missing source field for tenant user')
      console.log(`✅ [租户] source 字段注入正确 (source=${sample.source})`); p++
    } else {
      console.log('⚠️ 租户无可见拦截页面，跳过 source 字段检查'); s++
    }
  } catch (e) { f++; console.log(`❌ [租户] source 字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 14: Tenant — visible scope fewer than admin
  // ═══════════════════════════════════════════
  try {
    const tenantListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=1000`)
    const tenantCount = tenantListResp.data?.items?.length || 0

    // Re-login as admin to compare
    await loginAs(page, 'admin')
    const adminListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=1000`)
    const adminCount = adminListResp.data?.items?.length || 0

    if (tenantCount > adminCount) {
      throw new Error(`tenant_admin sees ${tenantCount} block pages > admin ${adminCount}`)
    }
    console.log(`✅ [租户] 拦截页面范围: tenant_admin ${tenantCount} ≤ admin ${adminCount}`); p++
  } catch (e) { f++; console.log(`❌ [租户] 可见范围: ${e.message}`) }

  // Re-login as admin
  try { await loginAs(page, 'admin') } catch { /* non-fatal */ }

  // ═══════════════════════════════════════════
  // Test 15: Admin list — shared_group_names is array for all items
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    if (items.length === 0) throw new Error('No block pages returned')

    let allHaveField = 0
    for (const item of items) {
      if (Array.isArray(item.shared_group_names)) allHaveField++
    }
    if (allHaveField !== items.length) throw new Error(`Only ${allHaveField}/${items.length} items have shared_group_names array`)
    console.log(`✅ [admin 列表] 所有 ${items.length} 条均含 shared_group_names 数组`); p++
  } catch (e) { f++; console.log(`❌ [admin 列表] shared_group_names: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 16: Admin delete shared+in_use BP returns in_use (hard block for admin too)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedInUse = items.find(bp => (bp.policy_group_used_count ?? 0) > 0 && (bp.binding_count ?? 0) > 1)

    if (sharedInUse) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: sharedInUse.name,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Admin should still get in_use for shared+in_use BP, got err=${resp.body?.err}`)
      console.log(`✅ [admin 硬限制] admin 删除共享+使用中拦截页面返回 in_use（硬限制不豁免）`); p++
    } else {
      console.log('⚠️ 无共享+使用中拦截页面，跳过 admin in_use 硬限制测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [admin 硬限制] shared+in_use: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 17: Admin delete in_use-only BP returns in_use (hard block)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseOnly = items.find(bp => (bp.policy_group_used_count ?? 0) > 0 && (bp.binding_count ?? 0) <= 1)

    if (inUseOnly) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: inUseOnly.name,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'in_use') throw new Error(`Expected err=in_use for in-use BP, got err=${resp.body?.err}`)
      console.log(`✅ [admin 硬限制] admin 删除使用中拦截页面返回 in_use`); p++
    } else {
      console.log('⚠️ 无使用中单绑定拦截页面，跳过 admin in_use-only 硬限制测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [admin 硬限制] in_use-only: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 18: UI — admin in_use BP delete button grayed + toast warning (in_use hard block)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const inUseBP = items.find(bp => (bp.policy_group_used_count ?? 0) > 0)

    if (inUseBP) {
      const row = page.locator('.el-table__row').filter({ hasText: inUseBP.comment || inUseBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (!isGrayColor(btnStyle)) throw new Error(`Admin in-use BP delete button should be grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message').filter({ hasText: '防护策略使用' }).count()
        if (warningVisible === 0) throw new Error('Admin should see in_use toast warning')
        console.log(`✅ [admin UI] admin 使用中拦截页面删除按钮置灰+toast 警告`); p++
      } else {
        console.log('⚠️ 使用中拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无使用中拦截页面，跳过 admin UI in_use 测试'); s++
    }
  } catch (e) { f++; console.log(`❌ [admin UI] in_use 删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 19: Non-admin UI — shared BP delete button grayed + toast warning
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')
    await page.waitForTimeout(500)

    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedBP = sharedFixtureReady
      ? items.find(bp => bp.name === sharedFixtureBPHash && (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)
      : null

    if (sharedBP) {
      const row = page.locator('.el-table__row').filter({ hasText: sharedBP.comment || sharedBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (!isGrayColor(btnStyle)) throw new Error(`Non-admin shared BP button should be grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message').filter({ hasText: '共享' }).count()
        if (warningVisible === 0) throw new Error('Non-admin should see shared toast warning')
        console.log(`✅ [non-admin UI] tenant_admin 共享拦截页面删除按钮置灰+toast 警告`); p++
      } else {
        console.log('⚠️ 共享拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ tenant_admin 无可见共享拦截页面，跳过 non-admin UI 共享测试'); s++
    }

    // Re-login as admin for summary
    await loginAs(page, 'admin')
    await page.waitForTimeout(500)
  } catch (e) { f++; console.log(`❌ [non-admin UI] shared 删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 20: Non-admin delete shared BP → backend returns err=shared (shared still enforced)
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')
    await page.waitForTimeout(500)

    const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const items = listResp.data?.items || []
    const sharedNotInUse = sharedFixtureReady
      ? items.find(bp => bp.name === sharedFixtureBPHash && (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)
      : null

    if (sharedNotInUse) {
      const resp = await apiDelete(page, '/api/captain/block-page/delete', {
        name: sharedNotInUse.name, captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'shared') throw new Error(`Non-admin should get err=shared, got err=${resp.body?.err}`)
      console.log(`✅ [non-admin 后端] tenant_admin 删除共享拦截页面返回 err=shared（non-admin 无 confirm_token 绕过途径）`); p++
    } else {
      console.log('⚠️ tenant_admin 无可见共享拦截页面，跳过 non-admin 后端 shared 验证'); s++
    }

    // Re-login as admin
    await loginAs(page, 'admin')
    await page.waitForTimeout(500)
  } catch (e) { f++; console.log(`❌ [non-admin 后端] shared 保护: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 20b: Download — tenant_admin unauthorized download returns 403/forbidden
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'admin')
    await page.waitForTimeout(500)

    // Use fixture BP (no mapping → not owned by tenant_admin), or scan for non-owned
    let nonOwnedName = fixtureBPHash
    if (!nonOwnedName) {
      const adminListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
      const adminItems = adminListResp.data?.items || []
      await loginAs(page, 'tenant_admin')
      await page.waitForTimeout(500)
      const tenantListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
      const tenantNames = new Set((tenantListResp.data?.items || []).map(i => i.name))
      nonOwnedName = (adminItems.find(bp => !tenantNames.has(bp.name)) || {}).name
    }

    if (nonOwnedName) {
      // tenant_admin attempts to download
      await loginAs(page, 'tenant_admin')
      await page.waitForTimeout(500)
      const dlResp = await page.evaluate(async ({ name, cid }) => {
        const r = await fetch(`/api/captain/block-page/download?name=${encodeURIComponent(name)}&captain_instance_id=${cid}`, { credentials: 'include' })
        return { status: r.status, body: await r.json() }
      }, { name: nonOwnedName, cid: captainInstanceId })
      if (dlResp.status !== 403 || dlResp.body?.err !== 'forbidden') {
        throw new Error(`Expected 403/forbidden for unauthorized download, got ${dlResp.status}/${dlResp.body?.err}`)
      }
      console.log(`✅ [下载越权] tenant_admin 对非本组拦截页面下载返回 403/forbidden`); p++
    } else {
      console.log('⚠️ 无非本组拦截页面，跳过下载越权测试'); s++
    }

    // Re-login as admin
    await loginAs(page, 'admin')
    await page.waitForTimeout(500)
  } catch (e) { f++; console.log(`❌ [下载越权] tenant_admin 越权下载: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 21: Admin upload — no mapping written (tenant_admin cannot see it immediately)
  // ═══════════════════════════════════════════
  let newBPHash = null
  try {
    await loginAs(page, 'admin')
    const ts = Date.now()
    const fileName = `e2e_reconcile_${ts}.html`
    const htmlContent = '<html><body>E2E reconcile test page</body></html>'

    const uploadResp = await page.evaluate(async ({ cid, content, name }) => {
      const formData = new FormData()
      const blob = new Blob([content], { type: 'text/html' })
      formData.append('file', blob, name)
      formData.append('captain_instance_id', String(cid))
      const r = await fetch(`/api/captain/block-page/upload?captain_instance_id=${cid}`, {
        method: 'POST',
        body: formData,
        credentials: 'include',
      })
      return { status: r.status, body: await r.json() }
    }, { cid: captainInstanceId, content: htmlContent, name: fileName })

    if (uploadResp.status >= 300) throw new Error(`Upload failed status=${uploadResp.status}: ${JSON.stringify(uploadResp.body)}`)
    newBPHash = uploadResp.body?.data?.path
    if (!newBPHash) throw new Error(`No path in upload response: ${JSON.stringify(uploadResp.body)}`)
    console.log(`  [admin 上传] 新拦截页面 hash=${newBPHash.substring(0, 8)}...`)

    // Switch to tenant_admin — should NOT see new BP (admin upload writes no mapping)
    await loginAs(page, 'tenant_admin')
    const tenantListResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const foundNew = (tenantListResp.data?.items || []).find(bp => bp.name === newBPHash)
    if (foundNew) throw new Error(`Admin upload should not write mapping — tenant_admin should not see new BP`)
    console.log(`✅ [admin 上传] admin 上传后 tenant_admin 不可见（无 mapping 写入）`); p++

    await loginAs(page, 'admin')
  } catch (e) { f++; console.log(`❌ [admin 上传] 无 mapping: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 22: PolicyUpdate → reconcileBlockPageMappings adds/removes mapping
  // ═══════════════════════════════════════════
  try {
    if (!newBPHash) {
      console.log('⚠️ [reconcile] Test 21 未产生新拦截页面，跳过 reconcile 测试'); s++
    } else {
      await loginAs(page, 'admin')

      // 1. Dynamically find a policy with forbidden_page_config.path (not hardcoded to id=25)
      const policiesResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
      const policies = policiesResp.data?.items || []
      const targetPolicy = policies.find(p => p.forbidden_page_config?.path)
      if (!targetPolicy) throw new Error('No policy with forbidden_page_config.path found')
      const policyId = targetPolicy.id

      // Fetch full detail for the PUT body
      const policyDetailResp = await apiGet(page, `/api/captain/policy/detail?captain_instance_id=${captainInstanceId}&id=${policyId}`)
      const originalPolicy = policyDetailResp.data
      if (!originalPolicy) throw new Error(`Failed to fetch policy ${policyId} detail`)
      const originalPath = originalPolicy.forbidden_page_config?.path || ''
      console.log(`  [reconcile] 使用 policy id=${policyId}, originalPath=${originalPath.substring(0, 8)}...`)

      // 2. Update policy to use new block page → triggers reconcileBlockPageMappings async
      const putBody = { ...originalPolicy, captain_instance_id: captainInstanceId,
        forbidden_page_config: { ...originalPolicy.forbidden_page_config, path: newBPHash } }
      const updateResp = await page.evaluate(async ([body]) => {
        const r = await fetch('/api/captain/policy/update', {
          method: 'PUT', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body), credentials: 'include',
        })
        return { status: r.status, body: await r.json() }
      }, [putBody])
      if (updateResp.status >= 300) throw new Error(`PolicyUpdate failed: ${JSON.stringify(updateResp.body)}`)

      // 3. Poll tenant_admin list until new BP appears (max 10s, 500ms intervals)
      let newBPVisible = false
      for (let i = 0; i < 20; i++) {
        await page.waitForTimeout(500)
        await loginAs(page, 'tenant_admin')
        const pollList = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
        if ((pollList.data?.items || []).find(bp => bp.name === newBPHash)) {
          newBPVisible = true
          break
        }
        await loginAs(page, 'admin') // switch back for next iteration
      }
      if (!newBPVisible) throw new Error(`After PolicyUpdate+reconcile, tenant_admin should see new BP (polled 10s)`)
      console.log(`✅ [reconcile] PolicyUpdate 后 reconcile 新增 mapping（tenant_admin 可见新拦截页面）`); p++

      // 4. Restore policy to original path → triggers reconcile again
      await loginAs(page, 'admin')
      const restoreBody = { ...originalPolicy, captain_instance_id: captainInstanceId,
        forbidden_page_config: { ...originalPolicy.forbidden_page_config, path: originalPath } }
      await page.evaluate(async ([body]) => {
        await fetch('/api/captain/policy/update', {
          method: 'PUT', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body), credentials: 'include',
        })
      }, [restoreBody])

      // 5. Poll until new BP disappears from tenant_admin view
      let newBPRemoved = false
      for (let i = 0; i < 20; i++) {
        await page.waitForTimeout(500)
        await loginAs(page, 'tenant_admin')
        const pollList = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
        if (!(pollList.data?.items || []).find(bp => bp.name === newBPHash)) {
          newBPRemoved = true
          break
        }
        await loginAs(page, 'admin')
      }
      if (!newBPRemoved) throw new Error(`After restore, reconcile should remove mapping — tenant_admin should not see new BP (polled 10s)`)
      console.log(`✅ [reconcile] 还原 policy 后 reconcile 删除 mapping（tenant_admin 不再可见新拦截页面）`); p++

      // 6. Cleanup: admin deletes new BP
      await loginAs(page, 'admin')
      await apiDelete(page, '/api/captain/block-page/delete', { name: newBPHash, captain_instance_id: captainInstanceId })
      console.log(`  [reconcile] 清理新拦截页面 ${newBPHash.substring(0, 8)}...`)
    }
  } catch (e) {
    f++; console.log(`❌ [reconcile] PolicyUpdate 同步: ${e.message}`)
    // Cleanup on failure
    if (newBPHash) {
      await loginAs(page, 'admin').catch(() => {})
      await apiDelete(page, '/api/captain/block-page/delete', { name: newBPHash, captain_instance_id: captainInstanceId }).catch(() => {})
    }
  }

  // ═══════════════════════════════════════════
  // Teardown: restore policy + delete shared fixture (also verifies full token-based delete flow)
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'admin')
    // Restore reconcile policy to original forbidden page path
    if (reconcilePolicy && reconcilePolicyOriginalPath) {
      const restoreBody = { ...reconcilePolicy, captain_instance_id: captainInstanceId,
        forbidden_page_config: { ...reconcilePolicy.forbidden_page_config, path: reconcilePolicyOriginalPath } }
      const restoreResp = await apiPut(page, '/api/captain/policy/update', restoreBody)
      if (restoreResp.status >= 300 || restoreResp.body?.err !== null) {
        throw new Error(`Restore policy failed: status=${restoreResp.status}, err=${restoreResp.body?.err}, msg=${restoreResp.body?.msg}`)
      }
      await page.waitForTimeout(2000) // allow reconcile to remove fixture BP bindings
    }
    // Delete shared fixture BP with token flow (proves admin CAN delete shared BP with confirm_token)
    if (sharedFixtureBPHash) {
      const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
      const bp = (listResp.data?.items || []).find(b => b.name === sharedFixtureBPHash)
      if (bp) {
        if (await waitForBlockPageUnused(page, captainInstanceId, sharedFixtureBPHash)) {
          await adminDeleteBP(page, captainInstanceId, sharedFixtureBPHash)
          console.log(`  [teardown] 清理 shared fixture BP ${sharedFixtureBPHash.substring(0,8)}... 成功`)
        } else {
          console.log(`⚠️ shared fixture BP ${sharedFixtureBPHash.substring(0,8)}... 仍被策略引用，跳过删除避免破坏策略引用`)
        }
      }
    }
    // Also delete non-shared fixture BP if it still exists
    if (fixtureBPHash) {
      const listResp = await apiGet(page, `/api/captain/block-page/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
      const bp = (listResp.data?.items || []).find(b => b.name === fixtureBPHash)
      if (bp) {
        await adminDeleteBP(page, captainInstanceId, fixtureBPHash)
        console.log(`  [teardown] 清理 fixture BP ${fixtureBPHash.substring(0,8)}... 成功`)
      }
    }
  } catch (e) { console.log(`⚠️ Teardown failed: ${e.message}`) }

  console.log(`\n📊 BlockPageWriteProtection: ${p} passed, ${f} failed, ${s} skipped`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
