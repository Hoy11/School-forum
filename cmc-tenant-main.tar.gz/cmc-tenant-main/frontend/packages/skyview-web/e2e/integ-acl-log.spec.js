// E2E Test: ACL log page 1:1 replicate Captain-2 — view-only, expand rows, 4 fixed columns
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForTableData, launchOptions, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

async function waitForDropdownOptions(page) {
  const dropdown = page.locator('.el-select-dropdown:not([style*="display: none"])').last()
  await dropdown.locator('.el-select-dropdown__item').first()
    .waitFor({ state: 'visible', timeout: 10000 })
  return dropdown
}

async function addFilter(page, label) {
  const addBtn = page.locator('.condition-filter button:has-text("添加筛选")')
  await addBtn.waitFor({ state: 'visible', timeout: 10000 })
  await addBtn.click()
  const item = page.locator('.condition-filter__item').last()
  await item.locator('.el-select .el-input__inner').first().click()
  const dropdown = await waitForDropdownOptions(page)
  await dropdown.locator('.el-select-dropdown__item').filter({ hasText: label }).first().click()
  return item
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()

  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  // Capture ACL log API response for field verification
  let aclApiResponse = null
  page.on('response', async resp => {
    const url = resp.url()
    if (url.includes('/api/captain/acl-log/list')) {
      try { aclApiResponse = await resp.json() } catch {}
    }
  })

  await loginAs(page, 'admin')
  const cookieHeader = await getAuthCookieHeader(page, 'admin')
  const captainInstanceId = await getActiveWafId(page, cookieHeader)
  let p = 0, f = 0

  // ---- Test 1: ACL log page loads ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)
    console.log('✅ ACL log page loads'); p++
  } catch (e) { f++; console.log(`❌ ACL log page loads: ${e.message}`) }

  // ---- Test 1.5: Dynamic WAF filter loads and submits log_id condition ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    const filterItem = await addFilter(page, '日志来源')
    const valueSelect = filterItem.locator('.condition-filter__sub-item .el-select').first()
    await valueSelect.locator('.el-input__inner').click()
    const dropdown = await waitForDropdownOptions(page)
    const optionCount = await dropdown.locator('.el-select-dropdown__item:visible').count()
    if (optionCount < 1) throw new Error('WAF log source dropdown has no options')
    await dropdown.locator('.el-select-dropdown__item:visible').first().click()
    await page.keyboard.press('Escape')

    const reqPromise = page.waitForRequest(req => {
      if (req.method() !== 'POST' || !req.url().includes('/api/captain/acl-log/list')) return false
      try {
        return (JSON.parse(req.postData() || '{}').conditions || []).some(cond => cond.target === 'log_id')
      } catch { return false }
    }, { timeout: 10000 })
    await page.locator('.condition-filter button:has-text("搜索")').click()
    const body = JSON.parse((await reqPromise).postData() || '{}')
    const logID = (body.conditions || []).find(cond => cond.target === 'log_id')
    if (logID?.items?.[0]?.oper !== 'in') throw new Error(`log_id should use in operator: ${JSON.stringify(logID)}`)
    if (!Array.isArray(logID.items[0].value) || logID.items[0].value.length < 1) throw new Error(`log_id value missing: ${JSON.stringify(logID)}`)

    console.log(`✅ ACL dynamic WAF filter submits log_id (${optionCount} option(s))`); p++
  } catch (e) { f++; console.log(`❌ ACL dynamic WAF filter: ${e.message}`) }

  // ---- Test 2: Correct 4 fixed columns displayed ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    const headers = await page.locator('.el-table__header-wrapper th').allTextContents()
    const headerText = headers.map(h => h.trim()).filter(Boolean)

    // Check that 4 required columns are present
    const expectedHeaders = ['日志来源', '日志内容', '关联的规则', '时间']
    const missing = expectedHeaders.filter(h => !headerText.some(th => th.includes(h)))
    if (missing.length > 0) throw new Error(`Missing columns: ${missing.join(', ')}`)

    // Check that old columns are NOT present
    const oldHeaders = ['匹配目标', '执行次数', '操作']
    const found = oldHeaders.filter(h => headerText.some(th => th.includes(h)))
    if (found.length > 0) throw new Error(`Old columns should not exist: ${found.join(', ')}`)

    console.log(`✅ 4 fixed columns correct: ${headerText.join(', ')}`); p++
  } catch (e) { f++; console.log(`❌ 4 fixed columns: ${e.message}`) }

  // ---- Test 3: No column settings button ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    const columnBtn = page.locator('button:has-text("列设置")')
    if (await columnBtn.count() > 0) throw new Error('Column settings button should not exist')

    console.log('✅ No column settings button'); p++
  } catch (e) { f++; console.log(`❌ No column settings: ${e.message}`) }

  // ---- Test 4: Download button present, no destructive action buttons ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    // Download button should exist (disabled when no rows selected)
    const downloadBtn = page.locator('.layout__content button:has-text("下载选中日志")').first()
    if (await downloadBtn.count() === 0) throw new Error('Download button not found')

    // Should NOT have other action buttons
    const actionArea = page.locator('.layout__content').first()
    const forbiddenButtons = ['标记', 'SOC', '删除', '编辑']
    for (const label of forbiddenButtons) {
      const btn = actionArea.locator(`button:has-text("${label}")`)
      if (await btn.count() > 0) throw new Error(`Should not have action button: ${label}`)
    }

    // No "详情" link/button in table rows
    const detailBtn = page.locator('.el-table__body-wrapper .el-button:has-text("详情")')
    if (await detailBtn.count() > 0) throw new Error('Should not have detail button in rows')

    console.log('✅ Download button present, no destructive action buttons'); p++
  } catch (e) { f++; console.log(`❌ Action buttons check: ${e.message}`) }

  // ---- Test 5: Expand rows available ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No ACL log rows, skipping expand test'); p++
    } else {
      // Check expand icon exists
      const expandIcon = page.locator('.el-table__expand-icon').first()
      if (await expandIcon.count() === 0) throw new Error('Expand icon not found in table')

      console.log('✅ Expand rows available'); p++
    }
  } catch (e) { f++; console.log(`❌ Expand rows: ${e.message}`) }

  // ---- Test 6: Expand row shows IP details ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No ACL log rows, skipping expand detail test'); p++
    } else {
      // Click expand icon on first row
      const expandIcon = page.locator('.el-table__expand-icon').first()
      await expandIcon.click()
      await page.waitForTimeout(2000)

      // Check for expand content area (title text)
      const expandContent = page.locator('.el-table__expanded-cell')
      if (await expandContent.count() === 0) throw new Error('Expand content not rendered after click')

      // Check for sort radio buttons (el-radio with border, not el-radio-button)
      const radioButtons = page.locator('.acl-expand-radio .el-radio.is-bordered')
      const hasSort = await radioButtons.count()
      if (hasSort < 2) throw new Error('Sort radio buttons not found in expand area')

      console.log('✅ Expand row shows IP details with sort'); p++
    }
  } catch (e) { f++; console.log(`❌ Expand row details: ${e.message}`) }

  // ---- Test 7: No detail page route ----
  try {
    // Navigate directly to old detail route - should not exist or redirect
    await page.goto(`${TARGET_URL}/threat/acl-log/detail?id=1&captain_instance_id=${captainInstanceId}`, { waitUntil: 'domcontentloaded', timeout: 8000 }).catch(() => {})
    await page.waitForTimeout(1000)

    // Should not render the old detail page content
    const detailPageHeader = page.locator('.el-page-header')
    const currentUrl = page.url()

    // If it rendered a page header with "频率控制日志详情", the old route still exists
    if (await detailPageHeader.count() > 0 && currentUrl.includes('/threat/acl-log/detail')) {
      const detailContent = page.locator('.el-form-item__label')
      if (await detailContent.count() > 0) throw new Error('Old detail page route should not exist')
    }

    console.log('✅ No detail page route'); p++
  } catch (e) { f++; console.log(`❌ No detail page route: ${e.message}`) }

  // Re-login as admin after URL navigation broke page state
  await loginAs(page, 'admin')

  // ---- Test 8: Auto-refresh component visible ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    const refreshArea = page.locator('text=最后更新').or(page.locator('.el-icon-refresh'))
    if (await refreshArea.count() === 0) throw new Error('Auto-refresh component not found')

    console.log('✅ Auto-refresh component visible'); p++
  } catch (e) { f++; console.log(`❌ Auto-refresh: ${e.message}`) }

  // ---- Test 9: API returns correct data structure ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    if (aclApiResponse && aclApiResponse.data && aclApiResponse.data.items && aclApiResponse.data.items.length > 0) {
      const item = aclApiResponse.data.items[0]
      const requiredFields = ['id', 'timestamp', 'acl_rule_target', 'count', 'waf_name', 'waf_id', 'origin_id']
      const missing = requiredFields.filter(fld => item[fld] === undefined)
      if (missing.length > 0) throw new Error(`API response missing fields: ${missing.join(', ')}`)

      if (item.acl_rule_template !== null && item.acl_rule_template !== undefined) {
        const templateFields = ['name', 'match_method', 'action', 'dry_run', 'status']
        const missingTemplate = templateFields.filter(fld => item.acl_rule_template[fld] === undefined)
        if (missingTemplate.length > 0) throw new Error(`acl_rule_template missing fields: ${missingTemplate.join(', ')}`)
      }

      console.log(`✅ API returns correct data structure (${aclApiResponse.data.items.length} items)`); p++
    } else {
      console.log('⏭️  No ACL log data from API, skipping structure check'); p++
    }
  } catch (e) { f++; console.log(`❌ API data structure: ${e.message}`) }

  // ---- Test 10: Expand triggers correct API calls ----
  try {
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No ACL log rows, skipping expand API test'); p++
    } else {
      let detailCalled = false
      let srcIpCalled = false

      page.on('response', async resp => {
        const url = resp.url()
        if (url.includes('/api/captain/acl-log/detail')) detailCalled = true
        if (url.includes('/api/captain/acl-log/src-ip-detail')) srcIpCalled = true
      })

      // Click expand on first non-deleted row
      const expandIcon = page.locator('.el-table__expand-icon').first()
      await expandIcon.click()
      await page.waitForTimeout(3000)

      if (!detailCalled) throw new Error('Expand did not trigger acl-log/detail API call')
      // src-ip-detail may fail on 21 version, so just log
      if (!srcIpCalled) {
        console.log('  (src-ip-detail not called — may be 21 version or API error)')
      }

      console.log(`✅ Expand triggers correct API calls (detail=${detailCalled}, src-ip=${srcIpCalled})`); p++
    }
  } catch (e) { f++; console.log(`❌ Expand API calls: ${e.message}`) }

  // ---- Test 11: Tenant user can view and download ----
  try {
    await loginAs(page, 'tenant_admin')
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)

    // Download button should exist
    const downloadBtn = page.locator('.layout__content button:has-text("下载选中日志")').first()
    if (await downloadBtn.count() === 0) throw new Error('Download button not found for tenant')

    // Should NOT have other action buttons
    const actionArea = page.locator('.layout__content').first()
    const forbiddenButtons = ['标记', 'SOC', '删除', '编辑']
    for (const label of forbiddenButtons) {
      const btn = actionArea.locator(`button:has-text("${label}")`)
      if (await btn.count() > 0) throw new Error(`Tenant should not have action button: ${label}`)
    }

    console.log('✅ Tenant user: can download, no destructive buttons'); p++
  } catch (e) { f++; console.log(`❌ Tenant action buttons: ${e.message}`) }

  // ---- Test 12: Log content column renders formatted text ----
  try {
    await loginAs(page, 'admin')
    await navTo(page, '威胁监测', '频率控制日志')
    await waitForTableData(page)
    const rows = await getRows(page)

    if (rows < 1) {
      console.log('⏭️  No ACL log rows, skipping log content test'); p++
    } else {
      // Check that log content column has formatted text (contains "触发访问控制规则限制")
      const logContentCells = page.locator('.el-table__body-wrapper td')
      const allText = await logContentCells.allTextContents()
      const hasFormattedContent = allText.some(t => t.includes('触发访问控制规则限制'))

      if (!hasFormattedContent) throw new Error('Log content column does not show formatted text')
      console.log('✅ Log content column renders formatted text'); p++
    }
  } catch (e) { f++; console.log(`❌ Log content formatted: ${e.message}`) }

  console.log(`\n📊 ACL Log 1:1 Replicate: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
