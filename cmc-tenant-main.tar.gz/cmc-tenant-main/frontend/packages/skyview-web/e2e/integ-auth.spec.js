// Integration Test: Authentication — real backend
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, launchOptions } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  let passed = 0, failed = 0

  // Test 1: Login page renders
  try {
    const page = await browser.newPage()
    await page.goto(`${TARGET_URL}/login`, { waitUntil: 'domcontentloaded', timeout: 15000 })
    await page.locator('input[placeholder*="用户"]').first().waitFor({ state: 'visible', timeout: 5000 })
    if (!await page.locator('input[placeholder*="用户"]').isVisible()) throw new Error('Username input missing')
    if (!await page.locator('input[type="password"]').isVisible()) throw new Error('Password input missing')
    if (!await page.locator('button:has-text("登录")').isVisible()) throw new Error('Login button missing')
    console.log('✅ Test 1: Login page renders')
    passed++; await page.close()
  } catch (e) { failed++; console.log(`❌ Test 1 FAILED: ${e.message}`) }

  // Test 2: Admin login succeeds
  try {
    const page = await browser.newPage()
    const url = await loginAs(page, 'admin')
    if (url.includes('/login')) throw new Error('Still on login page after login')
    console.log('✅ Test 2: Admin login succeeds')
    passed++; await page.close()
  } catch (e) { failed++; console.log(`❌ Test 2 FAILED: ${e.message}`) }

  // Test 3: Dashboard renders with top nav
  try {
    const page = await browser.newPage()
    await loginAs(page, 'admin')
    const topNav = page.locator('.top-nav__bar').first()
    if (!await topNav.isVisible()) throw new Error('Top nav not visible')
    const username = page.locator('.top-nav__username')
    if (!await username.isVisible()) throw new Error('Username not visible')
    console.log('✅ Test 3: Dashboard renders with top nav')
    passed++; await page.close()
  } catch (e) { failed++; console.log(`❌ Test 3 FAILED: ${e.message}`) }

  // Test 4: Logout API clears token cookie
  try {
    const page = await browser.newPage()
    await loginAs(page, 'admin')
    // Verify token cookie exists
    const cookiesBefore = await page.context().cookies()
    const hasTokenBefore = cookiesBefore.some(c => c.name === 'token')
    if (!hasTokenBefore) throw new Error('No token cookie before logout')
    // Call logout API (same as frontend does)
    const logoutResp = await page.evaluate(async () => {
      const r = await fetch('/api/auth/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'include' })
      return { status: r.status, body: await r.json() }
    })
    if (logoutResp.status !== 200) throw new Error(`Logout API returned ${logoutResp.status}`)
    // Verify token cookie is cleared by server (maxAge=-1)
    const cookiesAfter = await page.context().cookies()
    const tokenCookie = cookiesAfter.find(c => c.name === 'token')
    if (tokenCookie && tokenCookie.value !== '') throw new Error('Token cookie still has value after logout')
    console.log('✅ Test 4: Logout API clears token cookie')
    passed++; await page.close()
  } catch (e) { failed++; console.log(`❌ Test 4 FAILED: ${e.message}`) }

  // Test 5: Invalid password stays on login
  try {
    const page = await browser.newPage()
    await page.goto(`${TARGET_URL}/login`, { waitUntil: 'domcontentloaded', timeout: 15000 })
    await page.locator('input[placeholder*="用户"]').first().fill('admin')
    await page.locator('input[type="password"]').first().fill('wrongpassword')
    await page.locator('button:has-text("登录")').first().click()
    await page.waitForTimeout(2000)
    if (!page.url().includes('/login')) throw new Error('Should stay on login with wrong password')
    console.log('✅ Test 5: Invalid password stays on login')
    passed++; await page.close()
  } catch (e) { failed++; console.log(`❌ Test 5 FAILED: ${e.message}`) }

  // Test 6: Auth current returns user info
  try {
    const page = await browser.newPage()
    await loginAs(page, 'admin')
    const resp = await page.evaluate(async () => {
      const r = await fetch('/api/auth/current', { credentials: 'include' })
      return r.json()
    })
    if (resp.err !== null) throw new Error(`Auth current failed: ${resp.msg}`)
    if (resp.data.role !== 'admin') throw new Error(`Expected admin, got ${resp.data.role}`)
    console.log('✅ Test 6: /api/auth/current returns user')
    passed++; await page.close()
  } catch (e) { failed++; console.log(`❌ Test 6 FAILED: ${e.message}`) }

  console.log(`\n📊 Integration Auth: ${passed} passed, ${failed} failed`)
  await browser.close()
  process.exit(failed > 0 ? 1 : 0)
})()
