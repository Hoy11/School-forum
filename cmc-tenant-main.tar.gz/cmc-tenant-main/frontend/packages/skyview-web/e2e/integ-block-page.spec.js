// Integration: Block Page (拦截页面) — list/upload/download/delete/shared+runtime protection
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  const adminCookieHeader = await getAuthCookieHeader(page, 'admin')
  const captainInstanceId = await getActiveWafId(page, adminCookieHeader)
  await page.evaluate(id => { window.__E2E_CAPTAIN_INSTANCE_ID__ = id }, captainInstanceId)
  console.log(`  Using captain_instance_id=${captainInstanceId}`)
  let p = 0, f = 0, s = 0

  // --- Fixture: admin upload BP → used_count=0, binding_count=0, tenant_admin invisible ---
  let fixtureBPHash = null
  try {
    const ts = Date.now()
    const uploadResp = await page.evaluate(async ({ cid, ts }) => {
      const fd = new FormData()
      fd.append('file', new Blob(['<html><body>E2E fixture</body></html>'], { type: 'text/html' }), `e2e_fixture_${ts}.html`)
      fd.append('captain_instance_id', String(cid))
      const r = await fetch(`/api/captain/block-page/upload?captain_instance_id=${cid}`, { method: 'POST', body: fd, credentials: 'include' })
      return { status: r.status, body: await r.json() }
    }, { cid: captainInstanceId, ts })
    if (uploadResp.status >= 300) throw new Error(`Fixture upload failed: ${JSON.stringify(uploadResp.body)}`)
    fixtureBPHash = uploadResp.body?.data?.path
    if (!fixtureBPHash) throw new Error('No path in upload response')
    console.log(`  [fixture] uploaded BP hash=${fixtureBPHash.substring(0,8)}...`)
  } catch (e) { console.log(`⚠️ Fixture upload failed: ${e.message}`) }

  // === 列表页 ===

  // 1. 列表页加载
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)
    console.log('✅ 拦截页面列表页加载'); p++
  } catch (e) { f++; console.log(`❌ 拦截页面列表页加载: ${e.message}`) }

  // 2. 列表页列头验证
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    const required = ['文件名称', '使用情况', '创建时间', '操作']
    for (const col of required) {
      if (!headers.some(h => h.includes(col))) throw new Error(`Missing column: ${col}`)
    }
    console.log('✅ 列表页列头正确（文件名称/使用情况/创建时间/操作）'); p++
  } catch (e) { f++; console.log(`❌ 列表页列头检查: ${e.message}`) }

  // 3. 使用情况渲染
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows > 0) {
      const usageTexts = await page.locator('.el-table__body-wrapper .el-table__row td:nth-child(2) .cell').allTextContents()
      const hasUsage = usageTexts.some(t => t.includes('防护策略中使用') || t.includes('未使用'))
      if (!hasUsage) throw new Error('No usage status text found in rows')
      console.log(`✅ 使用情况渲染正常（${rows}行）`); p++
    } else {
      console.log('⚠️ 无拦截页面数据，跳过使用情况测试'); s++
    }
  } catch (e) { f++; console.log(`❌ 使用情况渲染: ${e.message}`) }

  // === 添加拦截页面对话框 ===

  // 4. 添加拦截页面对话框字段验证
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    await page.locator('button:has-text("添加拦截页面")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })
    const dialog = page.locator('.el-dialog:visible').first()

    const dialogText = await dialog.textContent()
    if (!dialogText.includes('拦截页面名称')) throw new Error('Missing 拦截页面名称')
    if (!dialogText.includes('拦截页面') && !dialogText.includes('点击上传')) throw new Error('Missing upload area')

    const uploadAreas = await dialog.locator('.el-upload-dragger').count()
    if (uploadAreas < 1) throw new Error('Missing drag upload area')

    await dialog.locator('.el-dialog__headerbtn').first().click()
    console.log('✅ 添加拦截页面对话框字段完整（名称+拖拽上传）'); p++
  } catch (e) { f++; console.log(`❌ 添加拦截页面对话框: ${e.message}`) }

  // 4a. 上传非 .html 文件提交后被后端拦截
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    await page.locator('button:has-text("添加拦截页面")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })

    const uploadInput = page.locator('.el-dialog:visible input[type="file"]')
    await uploadInput.setInputFiles({ name: 'test.txt', mimeType: 'text/plain', buffer: Buffer.from('not html') })
    await page.locator('.el-dialog:visible button:has-text("确定")').click()

    const msgVisible = await page.locator('.el-message').filter({ hasText: '.html 格式' })
      .waitFor({ state: 'visible', timeout: 3000 }).then(() => true).catch(() => false)
    if (!msgVisible) throw new Error('Non-.html file should trigger backend warning')

    console.log('✅ 非.html文件上传提交后被后端拦截'); p++
  } catch (e) { f++; console.log(`❌ 非.html文件后端拦截: ${e.message}`) }
  finally {
    await page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click({ timeout: 3000 }).catch(() => {})
    await page.locator('.el-dialog:visible').waitFor({ state: 'hidden', timeout: 3000 }).catch(() => {})
  }

  // 4b. 上传超大 .html 文件被前端大小限制拦截
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    await page.locator('button:has-text("添加拦截页面")').first().click()
    await page.locator('.el-dialog:visible').first().waitFor({ state: 'visible', timeout: 5000 })

    const uploadInput = page.locator('.el-dialog:visible input[type="file"]')
    await uploadInput.setInputFiles({
      name: 'large.html',
      mimeType: 'text/html',
      buffer: Buffer.alloc(129 * 1024, 'a'),
    })

    const msgVisible = await page.locator('.el-message').filter({ hasText: '自定义拦截页面最大为' })
      .waitFor({ state: 'visible', timeout: 3000 }).then(() => true).catch(() => false)
    if (!msgVisible) throw new Error('Large .html file should trigger size warning')

    console.log('✅ 超大.html文件被前端大小限制拦截'); p++
  } catch (e) { f++; console.log(`❌ 超大.html文件前端拦截: ${e.message}`) }
  finally {
    await page.locator('.el-dialog:visible .el-dialog__headerbtn').first().click({ timeout: 3000 }).catch(() => {})
    await page.locator('.el-dialog:visible').waitFor({ state: 'hidden', timeout: 3000 }).catch(() => {})
  }

  // 4c. 后端直接上传非 .html 文件返回 400/invalid_format（.htm 也拒绝，与雷池一致）
  try {
    const resp = await page.evaluate(async () => {
      const results = []
      for (const filename of ['test.txt', 'test.htm']) {
        const fd = new FormData()
        fd.append('file', new Blob(['not html'], { type: 'text/plain' }), filename)
        fd.append('captain_instance_id', String(window.__E2E_CAPTAIN_INSTANCE_ID__))
        const r = await fetch(`/api/captain/block-page/upload?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}`, {
          method: 'POST', body: fd, credentials: 'include',
        })
        results.push({ filename, status: r.status, body: await r.json() })
      }
      return results
    })

    for (const item of resp) {
      if (item.status !== 400 || item.body?.err !== 'invalid_format') {
        throw new Error(`${item.filename}: expected 400/invalid_format, got ${item.status}: ${JSON.stringify(item.body)}`)
      }
    }
    console.log('✅ 非.html文件后端API返回400/invalid_format（含.htm）'); p++
  } catch (e) { f++; console.log(`❌ 非.html文件后端API拦截: ${e.message}`) }

  // 4d. 后端直接上传超大 .html 文件返回 400/file_too_large
  try {
    const resp = await page.evaluate(async () => {
      const fd = new FormData()
      fd.append('file', new Blob(['a'.repeat(129 * 1024)], { type: 'text/html' }), 'large.html')
      fd.append('captain_instance_id', String(window.__E2E_CAPTAIN_INSTANCE_ID__))
      const r = await fetch(`/api/captain/block-page/upload?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}`, {
        method: 'POST', body: fd, credentials: 'include',
      })
      return { status: r.status, body: await r.json() }
    })

    if (resp.status !== 400 || resp.body?.err !== 'file_too_large') {
      throw new Error(`Expected 400/file_too_large, got ${resp.status}: ${JSON.stringify(resp.body)}`)
    }
    console.log('✅ 超大.html文件后端API返回400/file_too_large'); p++
  } catch (e) { f++; console.log(`❌ 超大.html文件后端API拦截: ${e.message}`) }

  // === 删除保护 ===

  // 5. 共享拦截页面删除行为（admin: 确认框; non-admin 后端拦截）
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const bpListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const sharedBP = (bpListResp.data?.items || []).find(bp => (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)
    const sharedAnyBP = !sharedBP ? (bpListResp.data?.items || []).find(bp => (bp.binding_count ?? 0) > 1) : null

    if (sharedBP) {
      const rowFilter = sharedBP.comment || sharedBP.name
      const row = page.locator('.el-table__row').filter({ hasText: rowFilter }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        await deleteBtn.click()
        await page.waitForTimeout(500)
        // Admin: shared-only BP → confirm dialog (not warning toast)
        const confirmVisible = await page.locator('.el-message-box:visible').count()
        if (confirmVisible > 0) {
          const confirmText = await page.locator('.el-message-box:visible').textContent()
          if (confirmText.includes('共享')) {
            await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click()
            console.log(`✅ admin 共享拦截页面(id=${sharedBP.id})弹确认框（含"共享"）`); p++
          } else {
            console.log(`⚠️ admin 共享拦截页面确认框未含"共享"文本`); s++
          }
        } else {
          console.log(`⚠️ admin 共享拦截页面未弹确认框 (可能$message已显示)`); s++
        }
      } else {
        console.log('⚠️ 共享拦截页面行未找到删除按钮'); s++
      }
    } else if (sharedAnyBP) {
      // Shared + in_use: in_use takes priority per spec 24-3 check order — still hard block for admin
      const row = page.locator('.el-table__row').filter({ hasText: sharedAnyBP.comment || sharedAnyBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()
      if (await deleteBtn.count() > 0) {
        await deleteBtn.click()
        await page.waitForTimeout(500)
        const inUseWarning = await page.locator('.el-message').filter({ hasText: '防护策略使用' }).count()
        if (inUseWarning === 0) throw new Error('Shared+in_use BP delete should show in_use warning')
        console.log(`✅ 共享+使用中拦截页面(id=${sharedAnyBP.id})删除被阻止(in_use优先，admin也拦截)`); p++
      } else {
        console.log('⚠️ 共享+使用中拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无共享拦截页面(binding_count>1)，跳过删除拦截测试'); s++
    }
  } catch (e) { f++; console.log(`❌ 共享拦截页面删除拦截: ${e.message}`) }

  // 6. 使用中拦截页面删除 UI 拦截（admin 仅判断 policy_group_used_count > 0，不依赖 binding_count）
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const bpListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const inUseBP = (bpListResp.data?.items || []).find(bp => (bp.policy_group_used_count ?? 0) > 0)

    if (inUseBP) {
      const row = page.locator('.el-table__row').filter({ hasText: inUseBP.comment || inUseBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()
      if (await deleteBtn.count() > 0) {
        await deleteBtn.click()
        await page.waitForTimeout(500)
        const msgCount = await page.locator('.el-message').filter({ hasText: '防护策略使用' }).count()
        if (msgCount === 0) throw new Error(`In-use BP(id=${inUseBP.id}) delete click should show toast warning`)
        console.log(`✅ 使用中拦截页面(id=${inUseBP.id})删除被阻止`); p++
      } else {
        console.log('⚠️ 使用中拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无使用中拦截页面(policy_group_used_count>0)，跳过删除拦截测试'); s++
    }
  } catch (e) { f++; console.log(`❌ 使用中拦截页面删除拦截: ${e.message}`) }

  // 7. 非共享未使用拦截页面可删除（弹出确认框）
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const bpListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const deletableBP = fixtureBPHash
      ? (bpListResp.data?.items || []).find(bp => bp.name === fixtureBPHash)
      : (bpListResp.data?.items || []).find(bp => (bp.binding_count ?? 0) <= 1 && (bp.policy_group_used_count ?? 0) === 0)

    if (deletableBP) {
      const row = page.locator('.el-table__row').filter({ hasText: deletableBP.comment || deletableBP.name }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()
      if (await deleteBtn.count() > 0) {
        await deleteBtn.click()
        await page.waitForTimeout(500)
        const confirmVisible = await page.locator('.el-message-box:visible').count()
        if (confirmVisible === 0) throw new Error('Deletable block page should show confirm dialog')
        await page.locator('.el-message-box:visible .el-button:has-text("取消")').first().click()
        console.log(`✅ 可删除拦截页面(id=${deletableBP.id})弹出确认框`); p++
      } else {
        console.log('⚠️ 可删除拦截页面行未找到删除按钮'); s++
      }
    } else {
      console.log('⚠️ 无可删除拦截页面，跳过删除确认测试'); s++
    }
  } catch (e) { f++; console.log(`❌ 可删除拦截页面确认框: ${e.message}`) }

  // 8a. 下载按钮存在 + admin 下载成功验证
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows > 0) {
      const downloadBtns = await page.locator('.el-table__row .el-icon-download').count()
      if (downloadBtns === 0) throw new Error('No download buttons found in table rows')

      // Verify admin download actually succeeds (200 + non-empty response)
      const bpListResp = await page.evaluate(async () => {
        const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
        return r.json()
      })
      const firstBP = (bpListResp.data?.items || [])[0]
      if (firstBP) {
        const dlResp = await page.evaluate(async ({ name, cid }) => {
          const r = await fetch(`/api/captain/block-page/download?name=${encodeURIComponent(name)}&captain_instance_id=${cid}`, { credentials: 'include' })
          return { status: r.status, bodyLength: (await r.arrayBuffer()).byteLength }
        }, { name: firstBP.name, cid: captainInstanceId })
        if (dlResp.status !== 200) throw new Error(`Download returned ${dlResp.status}`)
        if (dlResp.bodyLength === 0) throw new Error('Download response body is empty')
        console.log(`✅ 下载按钮存在（${downloadBtns}个），admin 下载成功 (${dlResp.bodyLength} bytes)`); p++
      } else {
        console.log('⚠️ 无拦截页面数据，跳过下载验证'); s++
      }
    } else {
      console.log('⚠️ 无拦截页面数据，跳过下载按钮测试'); s++
    }
  } catch (e) { f++; console.log(`❌ 下载按钮: ${e.message}`) }

  // === 后端共享保护 ===

  // 9. Admin 删除 shared-only BP — P1-1 修复后后端返回 err=shared + confirm_token（不再直接成功）
  try {
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const bpListResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    })
    const sharedNotInUse = (bpListResp.data?.items || []).find(bp => (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)
    const sharedAny = (bpListResp.data?.items || []).find(bp => (bp.binding_count ?? 0) > 1)

    if (sharedNotInUse) {
      // P1-1: admin DELETE without confirm_token → must return err=shared + confirm_token
      const deleteResp = await page.evaluate(async ({ bpName }) => {
        const r = await fetch('/api/captain/block-page/delete', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: bpName, captain_instance_id: window.__E2E_CAPTAIN_INSTANCE_ID__ }),
          credentials: 'include',
        })
        return { status: r.status, body: await r.json() }
      }, { bpName: sharedNotInUse.name })

      if (deleteResp.body?.err !== 'shared') {
        throw new Error(`Admin without token should get err=shared (P1-1), got err=${deleteResp.body?.err}`)
      }
      if (!deleteResp.body?.confirm_token) {
        throw new Error(`err=shared response should include confirm_token, got: ${JSON.stringify(deleteResp.body)}`)
      }
      console.log('✅ admin 无 token 删除 shared-only 拦截页面返回 err=shared + confirm_token（P1 后端拦截生效）'); p++
    } else if (sharedAny) {
      // Shared + in_use — in_use hard block still applies to admin
      const deleteResp = await page.evaluate(async ({ bpName }) => {
        const r = await fetch('/api/captain/block-page/delete', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: bpName, captain_instance_id: window.__E2E_CAPTAIN_INSTANCE_ID__ }),
          credentials: 'include',
        })
        return { status: r.status, body: await r.json() }
      }, { bpName: sharedAny.name })

      if (deleteResp.body?.err !== 'in_use') {
        throw new Error(`Shared+in_use should return in_use for admin too, got err=${deleteResp.body?.err}`)
      }
      console.log('✅ admin 删除 shared+in_use 拦截页面返回 in_use（硬限制不豁免）'); p++
    } else {
      console.log('⚠️ 无共享拦截页面，跳过 blockPageDelete 保护测试'); s++
    }
  } catch (e) { f++; console.log(`❌ 共享拦截页面 blockPageDelete 保护: ${e.message}`) }

  // 9b. Non-admin (tenant_admin) 删除 shared BP 仍返回 err=shared
  try {
    await loginAs(page, 'tenant_admin')
    await page.waitForTimeout(500)
    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const tenantBPResp = await page.evaluate(async (cid) => {
      const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${cid}&offset=0&count=100`, { credentials: 'include' })
      return r.json()
    }, captainInstanceId)
    const sharedBP = (tenantBPResp.data?.items || []).find(bp => (bp.binding_count ?? 0) > 1 && (bp.policy_group_used_count ?? 0) === 0)

    if (sharedBP) {
      const deleteResp = await page.evaluate(async ({ bpName, cid }) => {
        const r = await fetch('/api/captain/block-page/delete', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: bpName, captain_instance_id: cid }),
          credentials: 'include',
        })
        return { status: r.status, body: await r.json() }
      }, { bpName: sharedBP.name, cid: captainInstanceId })

      if (deleteResp.body?.err !== 'shared') {
        throw new Error(`Non-admin should get err=shared, got err=${deleteResp.body?.err}`)
      }
      console.log('✅ tenant_admin 删除共享拦截页面返回 err=shared（non-admin 仍受 shared 保护）'); p++
    } else {
      console.log('⚠️ tenant_admin 无可见共享拦截页面，跳过 non-admin shared 保护测试'); s++
    }

    // Re-login as admin
    await loginAs(page, 'admin')
    await page.waitForTimeout(500)
  } catch (e) { f++; console.log(`❌ non-admin 共享拦截页面 blockPageDelete 保护: ${e.message}`) }

  // === 租户权限隔离 ===

  // 10. tenant_admin 只能看到本租户组绑定的拦截页面
  try {
    // Re-set captainInstanceId after re-login as admin (page navigation clears window vars)
    await page.evaluate(id => { window.__E2E_CAPTAIN_INSTANCE_ID__ = id }, captainInstanceId)
    const adminBPResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    })
    const adminBPCount = adminBPResp.data?.items?.length || 0

    await loginAs(page, 'tenant_admin')
    const tenantCookieHeader = await getAuthCookieHeader(page, 'tenant_admin')
    const tenantCaptainInstanceId = await getActiveWafId(page, tenantCookieHeader)
    await page.evaluate(id => { window.__E2E_CAPTAIN_INSTANCE_ID__ = id }, tenantCaptainInstanceId)
    console.log(`  tenant_admin using captain_instance_id=${tenantCaptainInstanceId}`)

    await navTo(page, '防护管理', '拦截页面')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const tenantBPResp = await page.evaluate(async () => {
      const r = await fetch(`/api/captain/block-page/list?captain_instance_id=${window.__E2E_CAPTAIN_INSTANCE_ID__}&offset=0&count=1000`, { credentials: 'include' })
      return r.json()
    })
    const tenantBPCount = tenantBPResp.data?.items?.length || 0

    if (tenantBPCount > adminBPCount) {
      throw new Error(`tenant_admin sees ${tenantBPCount} block pages > admin ${adminBPCount}`)
    }
    console.log(`✅ tenant_admin 拦截页面范围: ${tenantBPCount} ≤ admin ${adminBPCount}`); p++
  } catch (e) { f++; console.log(`❌ 租户权限隔离: ${e.message}`) }

  // Re-login as admin
  try {
    await loginAs(page, 'admin')
  } catch { /* non-fatal */ }

  console.log(`\n📊 BlockPage: ${p} passed, ${f} failed, ${s} skipped`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
