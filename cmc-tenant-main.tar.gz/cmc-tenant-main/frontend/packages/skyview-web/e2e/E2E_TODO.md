# E2E TODO

## 消除条件跳过

原则：关键 E2E 不应因为共享 Captain 环境缺少数据而长期 `skip` 后仍计入通过。下面这些 `⚠️` 项需要逐步改造成确定性测试：

- 测试前自动准备所需 fixture，或使用专用的 E2E 租户组 / WAF / 资源命名空间。
- 如果 fixture 准备失败，应让测试失败，而不是继续计入 passed。
- 只有第三方环境临时不可用、且有明确人工验证步骤时，才允许临时豁免。

### 证书写保护

- `integ-cert-write-protection.spec.js`
  - ~~`⚠️ UI 当前页无"系统使用中"证书行，跳过UI系统证书删除测试`~~ — 已修复：`waitForWafSelector` 增加 `inp.value !== '0'` 判断，避免在 WAF 初始化值 "0" 时提前返回导致空表格。
  - `⚠️ 无使用中非共享非系统证书，跳过编辑测试`（Test 6）
    - 需要准备一个非系统、非共享、被站点引用的证书。
    - 验证编辑受使用中保护，返回预期错误。
  - `⚠️ 无外部引用证书(has_external_ref=true)，跳过测试`（Test 9）
    - 需要准备一个 `has_external_ref=true` 的非系统证书。
    - 验证编辑/删除保护逻辑。
  - ~~`⚠️ 租户无可见系统证书，跳过删除测试`~~ — 已修复：`filterCertResponseForTenant` 现在对租户透出系统证书，Test 14 中租户删除系统证书已可正常验证。
  - `⚠️ 无非保护证书，跳过admin删除测试`（Test 17）
    - 需要准备一个 admin 可直接删除的证书（非系统、非共享、不在使用中，且有 binding 记录）。
    - 验证 admin 删除非保护证书 API 返回 `err: null`。
  - `⚠️ 无共享+无引用+非系统证书，跳过admin删除按钮测试`（Test 18）
    - 需要准备一个 `binding_count > 1`、`websites=[]`、非系统的证书。
    - 验证 admin 列表页该证书删除按钮为蓝色可点击（而非置灰），点击后弹确认框。

### IP 组写保护

- `integ-ip-group-write-protection.spec.js`
  - `⚠️ 无纯共享IP组，跳过错误消息测试`
    - 需要准备 `binding_count>1` 且未被策略引用的共享 IP 组。
    - 验证共享保护错误消息。
  - `⚠️ 没有 has_external_ref=true 且 binding_count<=1 的IP组，跳过编辑保护测试`
    - 需要准备非共享、外部引用 IP 组。
    - 验证编辑返回 `has_external_ref`。
  - `⚠️ 没有 source=created 的IP组，跳过编辑绕过测试`
    - 需要由 E2E 流程创建一个 IP 组，使其 `source=created`。
    - 验证租户自建资源不会被外部引用保护误拦截。
  - `⚠️ 无 has_external_ref=true 的非共享IP组，跳过UI编辑按钮测试`
    - 复用非共享、外部引用 IP 组 fixture。
    - 验证 UI 编辑按钮置灰与提示。
  - `⚠️ 无可删除IP组，跳过UI正常删除测试`
    - 需要准备非共享、未使用、非外部引用的 IP 组。
    - 验证正常删除确认流程。

### 自定义规则匹配条件

- `integ-policy-rule.spec.js`
  - `⚠️ 匹配条件中无"IP 组"选项，跳过`
    - 需要确保测试环境具备可见 IP 组，且自定义规则匹配条件下拉中出现 `IP 组`。
    - 如果产品预期必须支持 IP 组匹配，该项应改为强断言失败。

### 拦截页面写保护

> 已通过 admin upload fixture BP（`binding_count=0`, `used_count=0`）覆盖 4 个 skip：
> - ~~`⚠️ 无非本组拦截页面，跳过所有权测试`~~ → ✅ fixture BP admin 可见/tenant_admin 不可见
> - ~~`⚠️ admin UI: 无可删除拦截页面，跳过正常删除确认框测试`~~ → ✅ fixture BP `binding_count=0, used_count=0`
> - ~~`⚠️ 无非本组拦截页面，跳过下载越权测试`~~ → ✅ fixture BP name 直接用于下载 403 验证
>
> 剩余 3 个 skip 均因缺少 **多 TG 共享（`binding_count>1`）且无策略引用（`used_count=0`）** 的拦截页面。
> 需要 DB 直连写入 `captain_block_page_bindings` 表多 TG 映射才能覆盖，API 层无法创建。

- `integ-block-page-write-protection.spec.js`
  - `⚠️ 无纯共享拦截页面，跳过 admin UI 共享删除测试`（Test 10）
    - 需要 `binding_count>1` 且 `policy_group_used_count=0`。
    - 验证 admin 删除共享 BP 弹确认框列出 shared_group_names。
  - `⚠️ tenant_admin 无可见共享拦截页面，跳过 non-admin UI 共享测试`（Test 19）
    - 需要 tenant_admin 可见的 `binding_count>1` 且 `used_count=0` 的 BP。
  - `⚠️ tenant_admin 无可见共享拦截页面，跳过 non-admin 后端 shared 验证`（Test 20）
    - 同上，验证 non-admin 删除 shared BP 返回 err=shared。

### 拦截页面功能

> 已通过 fixture BP 覆盖 1 个 skip：
> - ~~`⚠️ 无可删除拦截页面，跳过删除确认测试`~~ → ✅ fixture BP 弹确认框

- `integ-block-page.spec.js`
  - `⚠️ 无使用中拦截页面(policy_group_used_count>0 && binding_count>=1)，跳过删除拦截测试`（Test 6）
    - 需要 `used_count>0` 且 `binding_count>=1`（排除历史 reconcile 残留的 `binding_count=0` 垃圾数据）。
  - `⚠️ tenant_admin 无可见共享拦截页面，跳过 non-admin shared 保护测试`（Test 9b）
    - 需要 tenant_admin 可见的 `binding_count>1` 且 `used_count=0` 的 BP。

### 管理员映射同步

- `integ-admin-mapping-sync.spec.js`
  - 当前已在 `e2e/suites.js` 中临时标记 `disabled: true`，不会被 `--all`、`--layer critical/nightly`、impact selection 自动执行。
  - 下线原因：
    - 后端 resync 目前依赖频率限制，多个 E2E / 自测共用同一套 Captain 与 Redis 时容易互相污染。
    - 用例 V19-V29 会受到历史 rate limit key 和共享 WAF 状态影响，失败结果不能稳定反映产品缺陷。
  - 后端重构目标：
    - 去掉 resync 的频率限制语义，不再通过“等待一段时间后再允许同步”控制并发。
    - 改为 WAF 维度全局锁：同一时间同一个 `captain_instance_id` 只允许一个映射同步进程工作。
    - 如果一次同步覆盖多个 WAF，需要按确定顺序获取所有相关 WAF 锁，避免死锁。
    - 同一 WAF 已有同步进行中时，应返回稳定的冲突响应，例如 `409 conflict` / `resync_in_progress`，而不是随机 429。
    - 锁必须在成功、失败、panic/异常退出时释放，并设置合理 TTL 防止进程崩溃后永久占锁。
    - 响应里应包含当前冲突的 `captain_instance_id` / task 信息，便于 CI 与人工排查。
  - E2E 恢复条件：
    - 恢复 `integ-admin-mapping-sync.spec.js` 自动执行前，先补充锁并发语义测试：同 WAF 并发只允许一个任务成功，另一个返回冲突。
    - 补充不同 WAF 并发同步互不阻塞的测试。
    - V19-V29 不再清理 `resync:rate:*`，也不再依赖共享环境里的历史限流状态。
    - 恢复后移除 `disabled: true` / `disabledReason`，并把 mapping-sync impact 重新挂回该 suite。

### 自定义规则写保护

- `integ-rule-write-protection.spec.js`
  - `⚠️ 无多租户共享且当前无站点引用的规则，跳过 UI 测试：admin 删除时弹共享确认框（含租户组名）`
    - 需要准备 `binding_count>1` 且 `websites=[]` 的共享规则。
    - 验证 admin 删除时弹确认框列出共享的租户组名，确认后执行删除。
    - 构造方式：绑定 0617 到多个租户组，然后将该规则从所有站点解绑。
  - `⚠️ 无"含外部租户组站点引用"的规则，跳过 UI 测试：admin 编辑时弹确认框列出外部租户组名`
    - 需要准备 `has_external_ref=true` 的规则（`binding_count=1`，但引用的站点已迁移到其他租户组）。
    - 验证 admin 编辑时弹确认框列出外部租户组名，确认后执行编辑。
    - 构造方式：将规则绑定的站点跨租户组迁移（站点从 TG_A 重新绑定到 TG_B），使规则 websites 中的站点不属于映射表中的 tenant_group_id。

## 建议改造顺序

1. 先补 IP 组与拦截页面 fixture，因为它们 skip 数量最多，且覆盖删除保护、共享保护、所有权保护等关键路径。
2. 再补证书 fixture，优先覆盖 `has_external_ref` 与系统证书删除保护。
3. 最后处理自定义规则下拉与 V26 限流问题，分别确认是产品缺陷、环境数据缺失，还是测试准备不足。
