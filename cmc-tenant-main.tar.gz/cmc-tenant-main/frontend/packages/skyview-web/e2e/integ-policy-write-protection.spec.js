// Integration: Policy write protection — is_default + in_use + shared + has_external_ref
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForContent, waitForTableData, waitForWafSelector, launchOptions, CREDENTIALS, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

// API helpers (browser-context fetch with auto cookies)
async function apiGet(page, urlPath) {
  return page.evaluate(async (p) => {
    const r = await fetch(p, { credentials: 'include' })
    return r.json()
  }, urlPath)
}

async function apiPut(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return { status: r.status, body: await r.json() }
  }, [urlPath, body])
}

async function apiDelete(page, urlPath, body) {
  return page.evaluate(async ([p, b]) => {
    const r = await fetch(p, { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b), credentials: 'include' })
    return { status: r.status, body: await r.json() }
  }, [urlPath, body])
}

// Check if style contains gray color (#ccc or rgb(204,...))
function isGrayColor(style) {
  if (!style) return false
  return style.includes('#ccc') || style.includes('rgb(204') || style.includes('rgb(204, 204, 204)')
}

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  let p = 0, f = 0
  let captainInstanceId

  // --- Seed: login as admin ---
  await loginAs(page, 'admin')

  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    captainInstanceId = await getActiveWafId(page, cookieHeader)
    await navTo(page, '防护管理', '攻击检测引擎')
    await waitForWafSelector(page)
    await waitForTableData(page)
    console.log(`  Using captain_instance_id=${captainInstanceId}`)
  } catch (e) {
    console.log(`❌ WAF selection: ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  // ═══════════════════════════════════════════
  // Test 1: List injection — protection fields
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    if (policies.length === 0) throw new Error('No policies returned')

    const sample = policies[0]
    const requiredFields = ['binding_count', 'site_count', 'is_default']
    const missing = requiredFields.filter(k => !(k in sample))
    if (missing.length > 0) throw new Error(`Missing fields: ${missing.join(', ')}`)

    // Admin should also get shared_group_names / referenced_site_names when applicable
    const sharedPolicy = policies.find(p => (p.binding_count ?? 0) > 1)
    if (sharedPolicy && !('shared_group_names' in sharedPolicy))
      console.log('  ⚠️ shared policy missing shared_group_names (may be empty array)')

    console.log(`✅ [列表注入] binding_count, site_count, is_default 字段存在`); p++
  } catch (e) { f++; console.log(`❌ [列表注入] 保护字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 2: Detail injection — protection fields + admin-specific
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    if (policies.length === 0) throw new Error('No policies available')

    const firstPolicy = policies[0]
    const detailResp = await apiGet(page, `/api/captain/policy/detail?id=${firstPolicy.id}&captain_instance_id=${captainInstanceId}`)
    const detail = detailResp.data
    if (!detail) throw new Error('No detail data returned')

    const requiredFields = ['binding_count', 'site_count', 'source', 'is_default', 'has_external_ref']
    const missing = requiredFields.filter(k => !(k in detail))
    if (missing.length > 0) throw new Error(`Missing fields in detail: ${missing.join(', ')}`)

    // Admin-specific: shared_group_names / referenced_site_names
    const adminOnlyFields = []
    if ((detail.binding_count ?? 0) > 1 && !('shared_group_names' in detail))
      adminOnlyFields.push('shared_group_names')
    if ((detail.site_count ?? 0) > 0 && !('referenced_site_names' in detail))
      adminOnlyFields.push('referenced_site_names')

    console.log(`✅ [详情注入] 保护字段完整，binding_count=${detail.binding_count}, site_count=${detail.site_count}, is_default=${detail.is_default}${adminOnlyFields.length ? ` (缺少admin字段: ${adminOnlyFields.join(',')})` : ''}`); p++
  } catch (e) { f++; console.log(`❌ [详情注入] 保护字段: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 3: is_default delete blocked (hard limit for ALL users including admin)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const defaultPolicy = policies.find(p => p.is_default === true)

    if (defaultPolicy) {
      const resp = await apiDelete(page, '/api/captain/policy/delete', {
        id: defaultPolicy.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err !== 'system_default') throw new Error(`Expected err=system_default, got err=${resp.body?.err}, status=${resp.status}`)
      if (!resp.body?.msg || !resp.body.msg.includes('默认防护策略模板')) throw new Error(`msg should mention default template: ${resp.body?.msg}`)
      console.log(`✅ [is_default] Admin删除默认策略返回 system_default 错误`); p++
    } else {
      console.log('⚠️ 无默认策略(is_default=true)，跳过删除硬限制测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [is_default] 删除硬限制: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 4: is_default edit NOT blocked by backend (frontend-only info prompt)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const defaultPolicy = policies.find(p => p.is_default === true)

    if (defaultPolicy) {
      const resp = await apiPut(page, '/api/captain/policy/update', {
        id: defaultPolicy.id,
        captain_instance_id: captainInstanceId,
        comment: defaultPolicy.comment || '',
      })
      // Backend should NOT return system_default for update — it only shows $message.info on frontend
      if (resp.body?.err === 'system_default') throw new Error('Backend should NOT block is_default edit (frontend-only info prompt)')
      // The update may succeed or fail with other errors, but not system_default
      console.log(`✅ [is_default] Admin编辑默认策略后端不拦截（err=${resp.body?.err}）`); p++
    } else {
      console.log('⚠️ 无默认策略，跳过编辑不拦截测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [is_default] 编辑不拦截: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 5: in_use delete — admin NOT blocked (soft limit, frontend confirmation dialog)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const inUsePolicy = policies.find(p => (p.site_count ?? 0) > 0 && !p.is_default)

    if (inUsePolicy) {
      const resp = await apiDelete(page, '/api/captain/policy/delete', {
        id: inUsePolicy.id,
        captain_instance_id: captainInstanceId,
      })
      // CMC backend does NOT block admin for in_use (soft limit via frontend confirmation dialog)
      // The request goes through to Captain, which may return its own error
      if (resp.body?.err === 'in_use') throw new Error('Admin should NOT be blocked by CMC in_use (soft limit)')
      // Captain may block with its own error, or succeed — either is fine for this test
      console.log(`✅ [in_use] Admin删除使用中策略不被CMC拦截（err=${resp.body?.err}，软限制由前端确认框处理）`); p++
    } else {
      console.log('⚠️ 无使用中非默认策略(site_count>0)，跳过 in_use 保护测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [in_use] Admin删除保护: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 6: shared delete — admin NOT blocked (soft limit, frontend confirmation dialog)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const sharedAny = policies.find(p => (p.binding_count ?? 0) > 1 && !p.is_default)

    if (sharedAny) {
      const resp = await apiDelete(page, '/api/captain/policy/delete', {
        id: sharedAny.id,
        captain_instance_id: captainInstanceId,
      })
      // CMC backend does NOT block admin for shared (soft limit via frontend confirmation dialog)
      if (resp.body?.err === 'shared') throw new Error('Admin should NOT be blocked by CMC shared (soft limit)')
      // The request goes through to Captain, which may return its own error
      console.log(`✅ [shared] Admin删除共享策略不被CMC拦截（err=${resp.body?.err}，软限制由前端确认框处理）`); p++
    } else {
      console.log('⚠️ 无共享策略(binding_count>1)，跳过共享删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [shared] Admin删除保护: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 7: shared edit — admin NOT blocked (soft limit, frontend confirmation dialog)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const sharedPolicy = policies.find(p => (p.binding_count ?? 0) > 1 && !p.is_default)

    if (sharedPolicy) {
      const resp = await apiPut(page, '/api/captain/policy/update', {
        id: sharedPolicy.id,
        captain_instance_id: captainInstanceId,
        comment: 'test-shared-edit',
      })
      // CMC backend does NOT block admin for shared (soft limit via frontend confirmation dialog)
      if (resp.body?.err === 'shared') throw new Error('Admin should NOT be blocked by CMC shared (soft limit)')
      console.log(`✅ [shared] Admin编辑共享策略不被CMC拦截（err=${resp.body?.err}，软限制由前端确认框处理）`); p++
    } else {
      console.log('⚠️ 无共享策略(binding_count>1)，跳过共享编辑测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [shared] Admin编辑保护: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 8: Admin delete shared+in_use policy — CMC does NOT block (soft limits)
  // ═══════════════════════════════════════════
  try {
    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const sharedAndInUse = policies.find(p => (p.binding_count ?? 0) > 1 && (p.site_count ?? 0) > 0 && !p.is_default)

    if (sharedAndInUse) {
      const resp = await apiDelete(page, '/api/captain/policy/delete', {
        id: sharedAndInUse.id,
        captain_instance_id: captainInstanceId,
      })
      // Admin: both in_use and shared are soft limits — CMC does not block
      if (resp.body?.err === 'in_use' || resp.body?.err === 'shared') throw new Error('Admin should NOT be blocked by CMC in_use/shared (soft limits)')
      console.log(`✅ [优先级] Admin删除共享+使用中策略不被CMC拦截（err=${resp.body?.err}，均为软限制）`); p++
    } else {
      console.log('⚠️ 无共享+使用中策略，跳过优先级测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [优先级] Admin删除优先级: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 10: UI — is_default delete button grayed + warning toast
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '攻击检测引擎')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const defaultPolicy = policies.find(p => p.is_default === true)

    if (defaultPolicy) {
      const row = page.locator('.el-table__row').filter({ hasText: String(defaultPolicy.id || defaultPolicy.name) }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (!isGrayColor(btnStyle)) throw new Error(`Default policy delete button not grayed, style=${btnStyle}`)

        await deleteBtn.click()
        await page.waitForTimeout(500)
        const warningVisible = await page.locator('.el-message').filter({ hasText: '默认防护策略模板' }).count()
        if (warningVisible === 0) throw new Error('No warning toast for default policy delete')
        console.log(`✅ [UI] 默认策略删除按钮置灰+警告提示`); p++
      } else {
        console.log('⚠️ 默认策略行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无默认策略，跳过UI默认策略删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 默认策略删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 11: UI — in_use policy delete button NOT grayed for admin (soft limit = confirmation dialog)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '攻击检测引擎')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const inUsePolicy = policies.find(p => (p.site_count ?? 0) > 0 && !p.is_default)

    if (inUsePolicy) {
      const row = page.locator('.el-table__row').filter({ hasText: String(inUsePolicy.id || inUsePolicy.name) }).first()
      const deleteBtn = row.locator('.el-icon-delete').first()

      if (await deleteBtn.count() > 0) {
        const btnStyle = await deleteBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        // Admin in_use is a soft limit — button should NOT be grayed (confirmation dialog instead)
        if (isGrayColor(btnStyle)) throw new Error(`Admin in_use delete button should NOT be grayed (soft limit), style=${btnStyle}`)
        console.log(`✅ [UI] Admin使用中策略删除按钮不置灰（软限制=确认框）`); p++
      } else {
        console.log('⚠️ 使用中策略行未找到删除按钮'); p++
      }
    } else {
      console.log('⚠️ 无使用中非默认策略，跳过UI使用中删除测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] Admin使用中策略删除按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 12: UI — shared policy detail button navigable (read-only viewing allowed)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '攻击检测引擎')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const sharedPolicy = policies.find(p => (p.binding_count ?? 0) > 1 && !p.is_default)

    if (sharedPolicy) {
      const row = page.locator('.el-table__row').filter({ hasText: String(sharedPolicy.id || sharedPolicy.name) }).first()
      const detailBtn = row.locator('.el-icon-document').first()

      if (await detailBtn.count() > 0) {
        // Detail button should NOT be grayed (read-only viewing is always allowed)
        const btnStyle = await detailBtn.evaluate(el => {
          const btn = el.closest('button')
          return btn ? btn.getAttribute('style') : ''
        })
        if (isGrayColor(btnStyle)) throw new Error(`Detail button should NOT be grayed (read-only viewing allowed), style=${btnStyle}`)

        // Click should navigate to detail page (not show warning)
        await detailBtn.click()
        await page.waitForTimeout(2000)

        // Verify we're on the detail page (URL should contain 'policy' and 'detail')
        const url = page.url()
        if (!url.includes('policy') || !url.includes('detail')) throw new Error(`Clicking detail button did not navigate to detail page, URL=${url}`)

        // No alert banner for admin (isEditProtected returns false for admin)
        console.log(`✅ [UI] 共享策略详情按钮可点击导航（允许只读查看）`); p++

        // Navigate back for next test
        await page.goBack()
        await waitForTableData(page)
      } else {
        console.log('⚠️ 共享策略行未找到详情按钮'); p++
      }
    } else {
      console.log('⚠️ 无共享策略，跳过UI详情按钮测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 共享策略详情按钮: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 13: UI — detail page: admin edit icons NOT grayed (soft limit)
  // ═══════════════════════════════════════════
  try {
    await navTo(page, '防护管理', '攻击检测引擎')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const listResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const policies = listResp.data?.items || []
    const sharedPolicy = policies.find(p => (p.binding_count ?? 0) > 1 && !p.is_default)

    if (sharedPolicy) {
      const row = page.locator('.el-table__row').filter({ hasText: String(sharedPolicy.id || sharedPolicy.name) }).first()
      const detailBtn = row.locator('.el-icon-document').first()

      if (await detailBtn.count() > 0) {
        await detailBtn.click()
        await page.waitForTimeout(2000)

        // Admin: edit icons should NOT be grayed (soft limit = confirmation dialog)
        const editBtns = await page.locator('.el-icon-edit').count()
        if (editBtns > 0) {
          const firstEditBtn = page.locator('.el-icon-edit').first()
          const iconStyle = await firstEditBtn.getAttribute('style')
          if (isGrayColor(iconStyle)) throw new Error(`Admin shared policy detail edit icon should NOT be grayed (soft limit), style=${iconStyle}`)
          console.log(`✅ [UI] Admin详情页共享策略编辑图标不置灰（软限制=确认框）`); p++
        } else {
          console.log('✅ [UI] 共享策略详情页无编辑按钮（已隐藏）'); p++
        }
      } else {
        console.log('⚠️ 共享策略行未找到详情按钮'); p++
      }
    } else {
      console.log('⚠️ 无共享策略，跳过详情页编辑图标测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [UI] 详情页编辑图标: ${e.message}`) }

  // ═══════════════════════════════════════════
  // Test 14: Tenant — protection fields injected
  // ═══════════════════════════════════════════
  try {
    await loginAs(page, 'tenant_admin')

    await navTo(page, '防护管理', '攻击检测引擎')
    await waitForWafSelector(page)
    await waitForTableData(page)

    const tenantListResp = await apiGet(page, `/api/captain/policy/list?captain_instance_id=${captainInstanceId}&offset=0&count=100`)
    const tenantPolicies = tenantListResp.data?.items || []
    if (tenantPolicies.length > 0) {
      const sample = tenantPolicies[0]
      if (!('source' in sample)) throw new Error('Missing source field for tenant user')
      if (!('has_external_ref' in sample)) throw new Error('Missing has_external_ref field for tenant user')
      if (!('is_default' in sample)) throw new Error('Missing is_default field for tenant user')
      console.log(`✅ [租户] source, has_external_ref, is_default 字段注入正确`); p++
    } else {
      console.log('⚠️ 租户无可见策略，跳过字段检查'); p++
    }

    // ═══════════════════════════════════════════
    // Test 15: Tenant — delete is_default blocked
    // ═══════════════════════════════════════════
    const defaultPolicy = tenantPolicies.find(p => p.is_default === true)
    if (defaultPolicy) {
      const resp = await apiDelete(page, '/api/captain/policy/delete', {
        id: defaultPolicy.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err === 'system_default' || resp.body?.err === 'forbidden') {
        console.log(`✅ [租户] 删除默认策略被阻止 (err=${resp.body?.err})`); p++
      } else if (resp.body?.err === null) {
        throw new Error('Tenant should not be able to delete default policy')
      } else {
        console.log(`⚠️ [租户] 删除默认策略返回 err=${resp.body?.err}`); p++
      }
    } else {
      console.log('⚠️ 租户无可见默认策略，跳过删除测试'); p++
    }

    // ═══════════════════════════════════════════
    // Test 16: Tenant — delete in_use blocked
    // ═══════════════════════════════════════════
    const inUsePolicy = tenantPolicies.find(p => (p.site_count ?? 0) > 0 && !p.is_default)
    if (inUsePolicy) {
      const resp = await apiDelete(page, '/api/captain/policy/delete', {
        id: inUsePolicy.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err === 'in_use' || resp.body?.err === 'forbidden') {
        console.log(`✅ [租户] 删除使用中策略被阻止 (err=${resp.body?.err})`); p++
      } else if (resp.body?.err === null) {
        throw new Error('Tenant should not be able to delete in-use policy')
      } else {
        console.log(`⚠️ [租户] 删除使用中策略返回 err=${resp.body?.err}`); p++
      }
    } else {
      console.log('⚠️ 租户无可见使用中策略，跳过删除测试'); p++
    }

    // ═══════════════════════════════════════════
    // Test 17: Tenant — delete shared blocked
    // Note: if the shared policy is also in_use, CMC checks in_use first, so err=in_use is valid
    // ═══════════════════════════════════════════
    const sharedPolicy = tenantPolicies.find(p => (p.binding_count ?? 0) > 1 && !p.is_default)
    if (sharedPolicy) {
      const resp = await apiDelete(page, '/api/captain/policy/delete', {
        id: sharedPolicy.id,
        captain_instance_id: captainInstanceId,
      })
      if (resp.body?.err === 'shared' || resp.body?.err === 'in_use' || resp.body?.err === 'forbidden') {
        console.log(`✅ [租户] 删除共享策略被阻止 (err=${resp.body?.err})`); p++
      } else if (resp.body?.err === null) {
        throw new Error('Tenant should not be able to delete shared policy')
      } else {
        console.log(`⚠️ [租户] 删除共享策略返回 err=${resp.body?.err}`); p++
      }
    } else {
      console.log('⚠️ 租户无可见共享策略，跳过删除测试'); p++
    }

    // ═══════════════════════════════════════════
    // Test 18: Tenant — edit shared blocked
    // ═══════════════════════════════════════════
    if (sharedPolicy) {
      const resp = await apiPut(page, '/api/captain/policy/update', {
        id: sharedPolicy.id,
        captain_instance_id: captainInstanceId,
        comment: 'test-tenant-shared-edit',
      })
      if (resp.body?.err === 'shared' || resp.body?.err === 'forbidden') {
        console.log(`✅ [租户] 编辑共享策略被阻止 (err=${resp.body?.err})`); p++
      } else if (resp.body?.err === null) {
        throw new Error('Tenant should not be able to edit shared policy')
      } else {
        console.log(`⚠️ [租户] 编辑共享策略返回 err=${resp.body?.err}`); p++
      }
    } else {
      console.log('⚠️ 租户无可见共享策略，跳过编辑测试'); p++
    }

    // ═══════════════════════════════════════════
    // Test 18: Tenant — edit has_external_ref blocked
    // Note: a policy can be both shared AND has_external_ref (e.g., __e2e_wp_shared).
    // If shared check runs first, err=shared; if has_external_ref check runs first (binding_count<=1),
    // err=has_external_ref. Both are valid protection errors.
    // ═══════════════════════════════════════════
    const extRefPolicy = tenantPolicies.find(p => p.has_external_ref === true && !p.is_default)
    if (extRefPolicy) {
      const resp = await apiPut(page, '/api/captain/policy/update', {
        id: extRefPolicy.id,
        captain_instance_id: captainInstanceId,
        comment: 'test-tenant-extref-edit',
      })
      if (resp.body?.err === 'has_external_ref' || resp.body?.err === 'shared' || resp.body?.err === 'forbidden') {
        console.log(`✅ [租户] 编辑外部引用策略被阻止 (err=${resp.body?.err})`); p++
      } else if (resp.body?.err === null) {
        throw new Error('Tenant should not be able to edit policy with external references')
      } else {
        console.log(`⚠️ [租户] 编辑外部引用策略返回 err=${resp.body?.err}`); p++
      }
    } else {
      console.log('⚠️ 租户无可见外部引用策略(has_external_ref=true)，跳过编辑测试'); p++
    }
  } catch (e) { f++; console.log(`❌ [租户] 保护测试: ${e.message}`) }

  // Re-login as admin
  try { await loginAs(page, 'admin') } catch { /* non-fatal */ }

  console.log(`\n📊 PolicyWriteProtection: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
