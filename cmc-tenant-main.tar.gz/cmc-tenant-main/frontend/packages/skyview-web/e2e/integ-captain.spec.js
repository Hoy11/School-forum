// Integration Test: Captain-connected pages — real backend + real Captain
const path = require('path')
const { chromium } = require('playwright')
const { TARGET_URL, loginAs, navTo, getRows, waitForTableData, waitForWafSelector, launchOptions, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))
const { ensureSites, cleanupSites, login: apiLogin } = require(path.join(__dirname, 'test-data'))

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  page.on('response', resp => {
    const url = resp.url()
    if (url.includes('/api/') && resp.status() >= 400)
      console.log(`  API ${resp.status()}: ${url.substring(url.indexOf('/api/'))}`)
  })

  await loginAs(page, 'admin')
  let p = 0, f = 0

  // Seed test data: ensure at least 2 sites exist
  let seedSiteIds = []
  try {
    const cookieHeader = await apiLogin(page)
    const captainInstanceId = await getActiveWafId(page, cookieHeader, { requireSiteList: true })
    seedSiteIds = await ensureSites(page, cookieHeader, captainInstanceId, 2)
    if (seedSiteIds.length > 0) console.log(`  Seeded ${seedSiteIds.length} sites`)
  } catch (e) { console.log(`  Seed warning: ${e.message}`) }

  try {
    await navTo(page, '系统管理', '对接配置')
    await page.locator('.el-form-item:has-text("纵横地址") span').first().waitFor({ state: 'visible', timeout: 5000 })
    const content = await page.locator('.layout__content').first().textContent()
    if (!content.includes('10.2.102.76')) throw new Error('Should show captain host')
    console.log('✅ Integration config shows host'); p++
  } catch (e) { f++; console.log(`❌ Integration config: ${e.message}`) }

  try {
    await navTo(page, '防护管理', 'WAF 列表')
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows < 1) throw new Error('No WAF instances')
    console.log(`✅ WAF list: ${rows} instances`); p++
  } catch (e) { f++; console.log(`❌ WAF list: ${e.message}`) }

  try {
    await navTo(page, '防护管理', '站点管理')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows < 1) throw new Error('No sites')
    // Verify WAF selector has no duplicate options (by value)
    const wafSelect = page.locator('.el-select').first()
    await wafSelect.click()
    await page.waitForTimeout(500)
    const options = await page.locator('.el-select-dropdown__item').allTextContents()
    const optionValues = await page.locator('.el-select-dropdown__item').evaluateAll(els => els.map(el => el.getAttribute('id') || el.textContent))
    // Dedup check: no two options should have the same text
    const uniqueTexts = new Set(options.map(o => o.trim()))
    if (uniqueTexts.size !== options.length) throw new Error(`Duplicate WAF options: ${options.length} total, ${uniqueTexts.size} unique`)
    // Close dropdown
    await wafSelect.click()
    await page.waitForTimeout(300)
    console.log(`✅ Site management: ${rows} rows, WAF selector deduped (${uniqueTexts.size} unique)`); p++
  } catch (e) { f++; console.log(`❌ Site management: ${e.message}`) }

  try {
    await navTo(page, '防护管理', 'IP 组')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)
    // Verify new columns
    const headers = await page.locator('.el-table__header-wrapper th .cell').allTextContents()
    if (!headers.some(h => h.includes('包含IP'))) throw new Error('Missing 包含IP column')
    if (!headers.some(h => h.includes('备注'))) throw new Error('Missing 备注 column')
    console.log(`✅ IP Group: ${rows} rows, 包含IP+备注列`); p++
  } catch (e) { f++; console.log(`❌ IP Group: ${e.message}`) }

  try {
    await navTo(page, '防护管理', '攻击检测引擎')
    await waitForWafSelector(page)
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows < 1) throw new Error('No policies')
    console.log(`✅ Policy: ${rows} rows`); p++
  } catch (e) { f++; console.log(`❌ Policy: ${e.message}`) }

  try {
    await navTo(page, '威胁监测', '攻击检测日志')
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows < 1) {
      const resp = await page.evaluate(async () => {
        const r = await fetch('/api/captain/detect-log/list', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ offset: 0, count: 10 }), credentials: 'include',
        })
        return r.json()
      })
      if (resp.data?.total < 1) throw new Error('No detect log data')
      console.log(`✅ Detect log (API: ${resp.data.total}, table: ${rows})`); p++
    } else {
      console.log(`✅ Detect log: ${rows} rows`); p++
    }
  } catch (e) { f++; console.log(`❌ Detect log: ${e.message}`) }

  try {
    await navTo(page, '租户管理', '租户组')
    await waitForTableData(page)
    const rows = await getRows(page)
    console.log(`✅ Tenant group: ${rows} rows`); p++
  } catch (e) { f++; console.log(`❌ Tenant group: ${e.message}`) }

  try {
    await navTo(page, '租户管理', 'WAF 绑定')
    await waitForTableData(page)
    const rows = await getRows(page)
    console.log(`✅ WAF binding: ${rows} rows`); p++
  } catch (e) { f++; console.log(`❌ WAF binding: ${e.message}`) }

  // Site binding page: verify sync button exists
  try {
    await navTo(page, '租户管理', '站点绑定')
    await page.waitForTimeout(1500)
    await waitForTableData(page)
    const rows = await getRows(page)
    if (rows > 0) {
      const syncBtn = page.locator('.el-table__row').first().locator('button:has-text("同步")')
      if (await syncBtn.count() === 0) throw new Error('No sync button in action column')
      // Click sync, expect confirmation dialog
      await syncBtn.first().click()
      await page.waitForTimeout(500)
      const confirmDialog = page.locator('.el-message-box')
      if (await confirmDialog.count() === 0) throw new Error('No confirmation dialog')
      const dialogText = await confirmDialog.locator('.el-message-box__message').textContent()
      if (!dialogText.includes('同步')) throw new Error(`Unexpected dialog text: ${dialogText}`)
      // Cancel instead of confirming (don't actually resync)
      await confirmDialog.locator('button:has-text("取消")').first().click()
      await page.waitForTimeout(300)
      console.log(`✅ Site binding: ${rows} rows, sync button works`); p++
    } else {
      // Verify sync button exists via page content even without rows
      const pageContent = await page.locator('.layout__content').first().textContent()
      if (!pageContent.includes('绑定站点')) throw new Error('Page not loaded properly')
      console.log('✅ Site binding: page loads, sync column present (no rows)'); p++
    }
  } catch (e) { f++; console.log(`❌ Site binding sync: ${e.message}`) }

  // No cleanup: seed data persists for other tests

  console.log(`\n📊 Captain Integration: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
