// Integration: backend API — hits :8080 directly, verifies response format
const path = require('path')
const { chromium } = require('playwright')
const { launchOptions, getAuthCookieHeader, getActiveWafId } = require(path.join(__dirname, 'integ-helpers'))

const BACKEND_URL = process.env.BACKEND_URL || 'http://localhost:8080'

;(async () => {
  const browser = await chromium.launch(launchOptions())
  const page = await browser.newPage()
  let p = 0, f = 0

  // --- Login ---
  let cookies
  try {
    const cookieHeader = await getAuthCookieHeader(page, 'admin')
    cookies = await page.context().cookies()
    if (!cookies.some(c => c.name === 'token')) throw new Error('No token cookie')
    if (!cookieHeader.includes('token=')) throw new Error('No token cookie header')
    console.log('✅ Login'); p++
  } catch (e) { f++; console.log(`❌ Login: ${e.message}`) }

  const headers = { Cookie: cookies.map(c => `${c.name}=${c.value}`).join('; ') }
  let captainInstanceId
  try {
    captainInstanceId = await getActiveWafId(page, headers.Cookie, { requireSiteList: true })
    console.log(`  Using captain_instance_id=${captainInstanceId}`)
  } catch (e) {
    f++
    console.log(`❌ WAF selection: ${e.message}`)
    await browser.close()
    process.exit(1)
  }

  // --- Helper ---
  async function testApi(name, method, path, body, checks, customHeaders = headers) {
    try {
      const opts = { headers: { ...customHeaders } }
      if (body) { opts.data = body; opts.headers['Content-Type'] = 'application/json' }
      const resp = method === 'POST' ? await page.request.post(`${BACKEND_URL}${path}`, opts)
                                   : await page.request.get(`${BACKEND_URL}${path}`, opts)
      const data = await resp.json()
      for (const [field, expected] of Object.entries(checks)) {
        const actual = field.split('.').reduce((o, k) => o?.[k], data)
        if (typeof expected === 'function') {
          if (!expected(actual)) throw new Error(`${field}=${JSON.stringify(actual)}, check failed`)
        } else if (actual !== expected) {
          throw new Error(`${field}=${JSON.stringify(actual)}, expected ${JSON.stringify(expected)}`)
        }
      }
      console.log(`✅ ${name}`); p++
      return data
    } catch (e) { f++; console.log(`❌ ${name}: ${e.message}`) }
  }

  async function testTenantLogIDExclusion() {
    try {
      const cookieHeader = await getAuthCookieHeader(page, 'tenant_admin')
      const tenantHeaders = { Cookie: cookieHeader }
      const wafResp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?offset=0&count=100`, { headers: tenantHeaders })
      const wafData = await wafResp.json()
      if (wafData.err !== null) throw new Error(`WAF binding list failed: ${wafData.msg}`)

      const wafID = wafData.data?.items?.[0]?.captain_instance_id
      if (!wafID) {
        console.log('⚠️ Tenant log_id exclusion skipped: no bound WAF'); p++
        return
      }

      const resp = await page.request.post(`${BACKEND_URL}/api/captain/detect-log/list`, {
        headers: { ...tenantHeaders, 'Content-Type': 'application/json' },
        data: {
          offset: 0,
          count: 20,
          conditions: [
            { target: 'log_id', items: [{ oper: 'not_in', value: String(wafID) }] },
          ],
        },
      })
      const data = await resp.json()
      if (data.err !== null) throw new Error(`detect log query failed: ${data.msg}`)
      const leaked = (data.data?.items || []).filter(item => String(item.log_id) === String(wafID))
      if (leaked.length > 0) throw new Error(`excluded log_id ${wafID} appeared in ${leaked.length} rows`)

      console.log(`✅ Tenant detect log_id exclusion (${wafID})`); p++
    } catch (e) { f++; console.log(`❌ Tenant detect log_id exclusion: ${e.message}`) }
  }

  async function testTenantWebsiteNameFilter() {
    try {
      const cookieHeader = await getAuthCookieHeader(page, 'tenant_admin')
      const tenantHeaders = { Cookie: cookieHeader }
      const wafResp = await page.request.get(`${BACKEND_URL}/api/binding/waf/list?offset=0&count=100`, { headers: tenantHeaders })
      const wafData = await wafResp.json()
      if (wafData.err !== null) throw new Error(`WAF binding list failed: ${wafData.msg}`)
      if ((wafData.data?.items || []).length === 0) {
        console.log('⚠️ Tenant website_name filter skipped: no bound WAF'); p++
        return
      }

      const resp = await page.request.post(`${BACKEND_URL}/api/captain/detect-log/list`, {
        headers: { ...tenantHeaders, 'Content-Type': 'application/json' },
        data: {
          offset: 0,
          count: 5,
          conditions: [
            { target: 'website_name', items: [{ oper: 'contains', value: '' }] },
          ],
        },
      })
      const data = await resp.json()
      if (data.err !== null) throw new Error(`detect log query failed: ${data.msg}`)
      if (!Array.isArray(data.data?.items)) throw new Error('data.items should be an array')

      console.log('✅ Tenant detect website_name filter'); p++
    } catch (e) { f++; console.log(`❌ Tenant detect website_name filter: ${e.message}`) }
  }

  // --- Detect log: offset→target_page conversion + msg:"success" + paginated data ---
  await testApi('Detect log list', 'POST', '/api/captain/detect-log/list',
    { offset: 0, count: 10 },
    { 'err': null, 'msg': 'success', 'data.total': v => v >= 0, 'data.items': v => Array.isArray(v) }
  )

  // --- Detect log: filter operators exposed by CMC must be accepted by Captain BasicFilter ---
  await testApi('Detect log list with exact scalar filters', 'POST', '/api/captain/detect-log/list',
    {
      offset: 0,
      count: 10,
      conditions: [
        { target: 'status_code', items: [{ oper: 'exact', value: '200' }] },
        { target: 'src_port', items: [{ oper: 'not_exact', value: '0' }] },
      ],
    },
    { 'err': null, 'msg': 'success', 'data.items': v => Array.isArray(v) }
  )

  await testTenantWebsiteNameFilter()

  // --- Detect log website_name rewrite path: unmatched name should become empty result, not proxy error ---
  await testApi('Detect log website_name filter', 'POST', '/api/captain/detect-log/list',
    {
      offset: 0,
      count: 10,
      conditions: [{ target: 'website_name', items: [{ oper: 'contains', value: '__cmc_e2e_no_such_site__' }] }],
    },
    { 'err': null, 'msg': 'success', 'data.total': v => v === 0, 'data.items': v => Array.isArray(v) && v.length === 0 }
  )

  // --- Detect log: rule_id filter used by policy-rule deep links is accepted ---
  await testApi('Detect log list with rule_id filter', 'POST', '/api/captain/detect-log/list',
    {
      offset: 0,
      count: 5,
      conditions: [
        { target: 'rule_id', items: [{ oper: 'exact', value: '0' }] },
      ],
    },
    { 'err': null, 'msg': 'success', 'data.items': v => Array.isArray(v) }
  )

  // --- ACL log: conditions removed + msg:"success" ---
  await testApi('ACL log list', 'POST', '/api/captain/acl-log/list',
    { offset: 0, count: 10 },
    { 'err': null, 'msg': 'success' }
  )

  // --- ACL log: CMC conditions are converted to Captain BasicFilter fields ---
  await testApi('ACL log list with BasicFilter conditions', 'POST', '/api/captain/acl-log/list',
    {
      offset: 0,
      count: 10,
      conditions: [
        { target: 'log_id', items: [{ oper: 'in', value: ['1'] }] },
        { target: 'target', items: [{ oper: 'like', value: '127' }] },
        { target: 'timestamp_tsrange', items: [{ oper: 'range', value: '0-4102444800' }] },
      ],
    },
    { 'err': null, 'msg': 'success' }
  )

  await testTenantLogIDExclusion()

  // --- Bot log (record): conditions removed + msg:"success" ---
  await testApi('Bot log record list', 'POST', '/api/captain/bot-log/record/list',
    { offset: 0, count: 10 },
    { 'err': null, 'msg': 'success' }
  )

  // --- Bot log (result) ---
  await testApi('Bot log result list', 'POST', '/api/captain/bot-log/result/list',
    { offset: 0, count: 10 },
    { 'err': null, 'msg': 'success' }
  )

  // --- Site list: wrapListAsPage format ---
  await testApi('Site list', 'GET', `/api/captain/site/list?captain_instance_id=${captainInstanceId}`, null,
    { 'err': null, 'msg': 'success', 'data.items': v => Array.isArray(v) }
  )

  // --- IP group list ---
  await testApi('IP group list', 'GET', `/api/captain/ip-group/list?captain_instance_id=${captainInstanceId}`, null,
    { 'err': null, 'msg': 'success' }
  )

  // --- SSL cert list ---
  await testApi('Cert list', 'GET', `/api/captain/cert/list?captain_instance_id=${captainInstanceId}`, null,
    { 'err': null, 'msg': 'success' }
  )

  // --- Policy list ---
  await testApi('Policy list', 'GET', `/api/captain/policy/list?captain_instance_id=${captainInstanceId}`, null,
    { 'err': null, 'msg': 'success' }
  )

  // --- Policy rule list (already paginated from Captain) ---
  await testApi('Policy rule list', 'GET', `/api/captain/policy-rule/list?captain_instance_id=${captainInstanceId}`, null,
    { 'err': null, 'msg': 'success' }
  )

  // --- Mark flag list ---
  await testApi('Mark flag list', 'GET', '/api/captain/mark_flag', null,
    { 'err': null, 'msg': v => v === 'success' || v === null }
  )

  // --- Tenant detect log: requested site_uuid outside allowed set should intersect to empty result ---
  try {
    const tenantCookie = await getAuthCookieHeader(page, 'tenant_admin')
    await testApi('Tenant detect log site_uuid intersection', 'POST', '/api/captain/detect-log/list',
      {
        offset: 0,
        count: 10,
        conditions: [{ target: 'site_uuid', items: [{ oper: 'exact', value: '999999999' }] }],
      },
      { 'err': null, 'msg': 'success', 'data.total': v => v === 0, 'data.items': v => Array.isArray(v) && v.length === 0 },
      { Cookie: tenantCookie }
    )
  } catch (e) { f++; console.log(`❌ Tenant detect log site_uuid intersection: ${e.message}`) }

  console.log(`\n📊 Backend API: ${p} passed, ${f} failed`)
  await browser.close()
  process.exit(f > 0 ? 1 : 0)
})()
