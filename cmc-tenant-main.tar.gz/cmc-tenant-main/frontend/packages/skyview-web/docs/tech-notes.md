# 前端技术要点

开发过程中发现的技术要点和踩坑记录，供后续开发参考。

## vue-class-component

### 箭头函数类属性 vs 方法定义 — this 绑定差异

```typescript
// ❌ 错误：箭头函数类属性
fetchData = (offset, count, conditions) => {
  if (!this.wafId) return empty   // this 是构造时闭包捕获的 _this，非 Vue 响应式代理
  return siteList(this.wafId, offset, count, conditions)  // _this.wafId 永远是初始值 0
}

// ✅ 正确：方法定义
fetchData(offset, count, conditions) {
  if (!this.wafId) return empty   // this 正确绑定到 Vue 响应式实例
  return siteList(this.wafId, offset, count, conditions)  // 能读到 computed/mixin 的更新值
}
```

**原因**：vue-class-component 将箭头函数类属性放入 `data()`，闭包捕获的 `_this` 是构造时的原始对象，Vue 响应式更新不会反映到 `_this` 上。方法放入 `methods`，调用时 `this` 绑定到 Vue 代理实例。

**适用场景**：任何需要读取响应式数据（computed、mixin 数据、data）的函数，如果作为 prop 传给子组件（如 Grid 的 `fetchData`），必须用方法定义。

### Mixins 中不能用 @Watch 装饰器

```typescript
// ❌ 错误：Vue.extend() 中 @Watch 编译报 TS2304
export const MyMixin = Vue.extend({
  @Watch('someProp')   // 语法错误
  onPropChange() { ... }
})

// ✅ 正确：使用 watch 对象
export const MyMixin = Vue.extend({
  watch: {
    someProp() { ... }
  }
})

// ✅ 正确：在使用 mixin 的 @Component 类中写 @Watch
@Component
export default class MyPage extends Mixins(MyMixin) {
  @Watch('someProp')
  onPropChange() { ... }
}
```

## Captain API 代理

### 响应格式差异

| 来源 | 格式 |
|---|---|
| Captain API | `{"err": null, "msg": null, "data": [...]}` 或 `{"err": null, "msg": "", "data": {...}}` |
| 前端期望 | `{"err": null, "msg": "success", "data": {"total": N, "items": [...]}}` |

后端 `wrapCaptainResp()` 补全 `msg: null` / `msg: ""` → `msg: "success"`；`wrapListAsPage()` 将裸数组包装为分页格式。

`policy-rule/list` 已返回分页格式，不需要 `wrapListAsPage`。

### captain_instance_id 传参

后端 `getInstanceID(c)` 从 `c.Query("captain_instance_id")` 取值。前端必须将其作为**独立 query 参数**传递，不能放在 conditions JSON 里。

### 日志 API 分页参数差异

Captain 日志 API 分页方式不同，后端负责统一转换，前端始终使用 `listQuery`（`{offset, count}`）：

| API | Captain 分页参数 | 后端处理 |
|---|---|---|
| detect_log | `target_page` + `count` | `convertOffsetToTargetPage()` 自动转换 |
| acl_log / bot_log | `offset` + `count` | 直接透传 |

前端 `listQuery` 发送的 `conditions` 字段不被 Captain 日志 API 识别，后端自动删除。

### 日志 API 不走 WAF 实例代理

日志查询使用 Captain-2 管理接口，不需要 `Proxy` 头（`captain_instance_id`）：
- 防护管理（站点/IP组/SSL/策略/规则）：需要 `InstanceID` → 设置 Proxy 头
- 日志查看（detect_log/acl_log/bot_log）：不需要 InstanceID，Captain 直接返回全量日志

租户过滤由后端通过 `InjectLogFilter` / `InjectDetectLogSiteFilter` 注入 `log_id` / `site_uuid` 条件实现。

## 组件时序

### WAF 选择器 + Grid 数据加载

防护子页面通过 `WafSelectorMixin` 获取 `wafId`。加载时序：

1. Mixin `created` 异步加载 WAF 列表 → 设置 `selectedWafId` 和 `wafReady`
2. Grid `mounted` 调用 `loadData()` → 此时 `wafId` 可能仍为 0 → guard 返回空
3. Mixin 异步完成后，`$nextTick(() => grid.loadData())` 触发数据加载
4. `@Watch('wafReady')` 作为双保险，确保 Grid 重新加载数据

**关键**：`fetchData` 必须是方法而非箭头函数属性（见上文），否则 guard 中的 `this.wafId` 读不到更新值。
