import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class ResizeBox extends Vue {
  @Prop({ default: '300px' }) initialWidth!: string
  @Prop({ default: 200 }) minWidth!: number
  @Prop({ default: 800 }) maxWidth!: number

  width = this.initialWidth
  resizing = false
  startX = 0
  startWidth = 0

  startResize(e: MouseEvent) {
    this.resizing = true
    this.startX = e.clientX
    this.startWidth = parseInt(this.width, 10)
    document.addEventListener('mousemove', this.onResize)
    document.addEventListener('mouseup', this.stopResize)
  }

  onResize(e: MouseEvent) {
    if (!this.resizing) return
    const diff = e.clientX - this.startX
    const newWidth = Math.min(this.maxWidth, Math.max(this.minWidth, this.startWidth + diff))
    this.width = newWidth + 'px'
  }

  stopResize() {
    this.resizing = false
    document.removeEventListener('mousemove', this.onResize)
    document.removeEventListener('mouseup', this.stopResize)
  }

  render(h: any) {
    return (
      <div class="resize-box" style={{ width: this.width }}>
        {this.$slots.default}
        <div class="resize-box__handle" on-mousedown={this.startResize} />
      </div>
    )
  }
}
