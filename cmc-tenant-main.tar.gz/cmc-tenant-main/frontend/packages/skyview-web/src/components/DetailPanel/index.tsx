import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class DetailPanel extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: '详情' }) title!: string
  @Prop({ default: '600px' }) width!: string

  render(h: any) {
    return (
      <el-drawer
        title={this.title}
        visible={this.visible}
        size={this.width}
        on-close={() => this.$emit('close')}
      >
        {this.$slots.default}
      </el-drawer>
    )
  }
}
