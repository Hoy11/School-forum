// @ts-nocheck
import { Component, Vue, Watch } from 'vue-property-decorator'
import TopNav, { MenuItem } from './TopNav'
import { logout } from '@/api/auth'
import { isAdmin, isTenantAdmin } from '@/permission'
import { RouteName } from '@/router/names'

@Component({ components: { TopNav } })
export default class Wrapper extends Vue {
  activeGroupTitle = ''

  get username(): string {
    return this.$store.state.user.currentUser?.username || ''
  }

  get menuItems(): MenuItem[] {
    const items: MenuItem[] = [
      {
        title: '威胁监测',
        children: [
          { title: '攻击检测日志', route: RouteName.detectLog },
          { title: '频率控制日志', route: RouteName.aclLog },
          { title: '日志下载', route: RouteName.logDownload },
        ]
      },
      {
        title: '防护管理',
        children: [
          { title: 'WAF 列表', route: RouteName.wafList },
          { title: '站点管理', route: RouteName.siteManagement },
          { title: 'IP 组', route: RouteName.ipGroup },
          { title: 'SSL 证书', route: RouteName.sslCert },
          { title: '拦截页面', route: RouteName.blockPage },
          { title: '攻击检测引擎', route: RouteName.policy },
          { title: '自定义规则', route: RouteName.policyRule },
        ]
      },
    ]

    if (isAdmin()) {
      items.push({
        title: '租户管理',
        children: [
          { title: '租户组', route: RouteName.tenantGroupList },
          { title: '全局用户', route: RouteName.userList },
          { title: 'WAF 绑定', route: RouteName.wafBinding },
          { title: '站点绑定', route: RouteName.siteBinding },
        ]
      })
    }

    if (isTenantAdmin()) {
      items.push({
        title: '组内管理',
        children: [
          { title: '组内用户', route: RouteName.tenantUserList },
        ]
      })
    }

    if (isAdmin()) {
      items.push({
        title: '系统管理',
        children: [
          { title: '对接配置', route: RouteName.integrationConfig }, // 合并原 SOC 配置 + 纵横配置
          { title: '高亮 IP', route: RouteName.highlightIp },
          { title: '审计日志', route: RouteName.auditLog },
          { title: '密码策略', route: RouteName.passwordConfig },
          { title: '登录安全', route: RouteName.loginSecurity },
        ]
      })
    }

    items.push({
      title: '个人设置',
      children: [
        { title: '修改密码', route: RouteName.changePassword },
        { title: '用户信息', route: RouteName.userInfo },
        { title: 'API Token', route: RouteName.apiToken },
      ]
    })

    return items
  }

  get activeGroup(): MenuItem | undefined {
    return this.menuItems.find(g => g.title === this.activeGroupTitle)
  }

  @Watch('$route', { immediate: true })
  onRouteChange() {
    for (const group of this.menuItems) {
      if (group.children?.some(c => c.route === this.$route.name)) {
        this.activeGroupTitle = group.title
        return
      }
    }
    if (!this.activeGroupTitle && this.menuItems.length) {
      this.activeGroupTitle = this.menuItems[0].title
    }
  }

  handleSelectGroup(title: string) {
    this.activeGroupTitle = title
    const group = this.menuItems.find(g => g.title === title)
    if (group?.children?.length) {
      const target = group.children.find(c => c.route === this.$route.name)
        ? this.$route.name as string
        : group.children[0].route!
      if (target !== this.$route.name) {
        this.$router.push({ name: target })
      }
    }
  }

  handleLogout() {
    logout().catch(() => {})
    this.$store.commit('user/clearUser')
    this.$store.commit('tenant/clearTenant')
    this.$router.push('/login')
  }

  render(h: any) {
    return (
      <div class="layout">
        <TopNav
          menuGroups={this.menuItems}
          activeTopIndex={this.activeGroupTitle}
          username={this.username}
          on-select-group={this.handleSelectGroup}
          on-logout={this.handleLogout}
        />
        <div class="layout__body">
          {this.activeGroup?.children?.length && (
            <div class="layout__sidebar">
              <el-menu
                default-active={String(this.$route.name)}
                on-select={(route: string) => { if (this.$route.name !== route) this.$router.push({ name: route }) }}
              >
                {this.activeGroup!.children!.map(item => (
                  <el-menu-item index={item.route!}>{item.title}</el-menu-item>
                ))}
              </el-menu>
            </div>
          )}
          <div class="layout__content">
            <router-view />
          </div>
        </div>
      </div>
    )
  }
}
