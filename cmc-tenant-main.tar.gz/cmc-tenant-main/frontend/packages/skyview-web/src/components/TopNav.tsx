// @ts-nocheck
import { Component, Vue, Prop } from 'vue-property-decorator'

export interface MenuItem {
  title: string
  icon?: string
  children?: MenuItem[]
  route?: string
}

@Component
export default class TopNav extends Vue {
  @Prop() menuGroups!: MenuItem[]
  @Prop() activeTopIndex!: string
  @Prop() username!: string

  render(h: any) {
    return (
      <div class="top-nav__bar">
        <div class="top-nav__logo">CMC 多租户管理平台</div>
        <el-menu
          mode="horizontal"
          default-active={this.activeTopIndex}
          on-select={(index: string) => this.$emit('select-group', index)}
        >
          {this.menuGroups.map((group) => (
            <el-menu-item index={group.title}>{group.title}</el-menu-item>
          ))}
        </el-menu>
        <div class="top-nav__user">
          <el-dropdown on-command={(cmd: string) => { if (cmd === 'logout') this.$emit('logout') }}>
            <span class="top-nav__username">
              {this.username} <i class="el-icon-arrow-down el-icon--right" />
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="logout">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    )
  }
}
