import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class HighlightTag extends Vue {
  @Prop({ default: false }) isHighlighted!: boolean
  @Prop({ default: '' }) comment!: string

  render(h: any) {
    if (!this.isHighlighted) return null
    return (
      <el-tooltip content={this.comment} placement="top">
        <el-tag type="warning" size="mini" style="margin-left: 4px">
          标记
        </el-tag>
      </el-tooltip>
    )
  }
}
