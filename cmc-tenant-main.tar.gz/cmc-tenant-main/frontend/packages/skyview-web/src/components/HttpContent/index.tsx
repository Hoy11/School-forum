import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class HttpContent extends Vue {
  @Prop({ default: '' }) content!: string
  @Prop({ default: '请求' }) label!: string

  get formattedContent(): string {
    try {
      return JSON.stringify(JSON.parse(this.content), null, 2)
    } catch {
      return this.content
    }
  }

  render(h: any) {
    return (
      <div class="http-content">
        <div class="http-content__label">{this.label}</div>
        <pre class="http-content__body">{this.formattedContent}</pre>
      </div>
    )
  }
}
