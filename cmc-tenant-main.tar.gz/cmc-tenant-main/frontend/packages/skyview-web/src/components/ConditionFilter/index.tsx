// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Condition, ConditionItem, FilterFieldOption, Oper } from '@/types/common'
import { markFlagGet } from '@/api/log/flag'

const TEXT_OPERATORS: { label: string; value: Oper }[] = [
  { label: '包含', value: 'like' },
  { label: '精确', value: '=' },
]

function defaultOperForField(field?: FilterFieldOption): Oper {
  if (field?.defaultOper) return field.defaultOper
  const type = field?.type || 'text'
  switch (type) {
    case 'text': return 'like'
    case 'number': return '='
    case 'choice': return '='
    case 'multi_choice': return 'in'
    case 'time': return 'before'
    case 'time_range': return 'range'
    case 'flag': return 'in'
    default: return '='
  }
}

function defaultValueForType(type: string): any {
  switch (type) {
    case 'multi_choice': return []
    case 'flag': return []
    case 'time_range': return null
    default: return ''
  }
}

function createItem(field?: FilterFieldOption): ConditionItem {
  return { oper: defaultOperForField(field), value: defaultValueForType(field?.type || 'text') }
}

@Component
export default class ConditionFilter extends Vue {
  @Prop({ default: () => [] }) conditions!: Condition[]
  @Prop({ default: () => [] }) fields!: FilterFieldOption[]

  flagChoices: { label: string; value: string }[] = []
  flagLoaded = false

  @Watch('conditions')
  onConditionsChange(conds: Condition[]) {
    conds.forEach(c => {
      if (c.target === 'flag' && !this.flagLoaded) this.loadFlagChoices()
    })
  }

  async loadFlagChoices() {
    if (this.flagLoaded) return
    try {
      const resp = await markFlagGet()
      if (resp.err === null && Array.isArray(resp.data)) {
        this.flagChoices = resp.data.map(f => {
          if (typeof f === 'string') return { label: f, value: f }
          return { label: f.name || String(f.value), value: String(f.value) }
        })
      }
    } catch { /* ignore */ }
    this.flagLoaded = true
  }

  getFieldConfig(target: string): FilterFieldOption | undefined {
    return this.fields.find(f => f.value === target)
  }

  addCondition() {
    if (!this.canAddCondition()) return
    this.$emit('change', [...this.conditions, { target: '', items: [createItem()] }])
  }

  isConditionComplete(cond: Condition): boolean {
    return !!cond.target && this.hasActiveValue(cond)
  }

  canAddCondition(): boolean {
    if (this.conditions.length === 0) return true
    if (!this.conditions.every(cond => this.isConditionComplete(cond))) return false
    const usedFields = new Set(this.conditions.map(c => c.target).filter(Boolean))
    return usedFields.size < this.fields.length
  }

  removeCondition(index: number) {
    this.$emit('change', this.conditions.filter((_, i) => i !== index))
  }

  addItem(index: number) {
    const field = this.getFieldConfig(this.conditions[index].target)
    if (!field) return
    const newConditions = this.conditions.map((c, i) =>
      i === index ? { ...c, items: [...c.items, createItem(field)] } : c
    )
    this.$emit('change', newConditions)
  }

  removeItem(groupIndex: number, itemIndex: number) {
    const group = this.conditions[groupIndex]
    if (group.items.length <= 1) {
      this.removeCondition(groupIndex)
      return
    }
    const newConditions = this.conditions.map((c, i) =>
      i === groupIndex ? { ...c, items: c.items.filter((_, j) => j !== itemIndex) } : c
    )
    this.$emit('change', newConditions)
  }

  updateCondition(index: number, field: string, value: unknown) {
    const newConditions = this.conditions.map((c, i) =>
      i === index ? { ...c, [field]: value } : c
    )
    this.$emit('change', newConditions)
  }

  updateItem(groupIndex: number, itemIndex: number, field: string, value: unknown) {
    const newConditions = this.conditions.map((c, i) => {
      if (i !== groupIndex) return c
      const newItems = c.items.map((item, j) =>
        j === itemIndex ? { ...item, [field]: value } : item
      )
      return { ...c, items: newItems }
    })
    this.$emit('change', newConditions)
  }

  handleFieldChange(index: number, target: string) {
    const field = this.getFieldConfig(target)
    if (!field) return
    const newConditions = this.conditions.map((c, i) =>
      i === index ? { target, items: [createItem(field)] } : c
    )
    this.$emit('change', newConditions)
    if (target === 'flag') this.loadFlagChoices()
  }

  handleOperChange(groupIndex: number, itemIndex: number, oper: Oper) {
    const newConditions = this.conditions.map((c, i) => {
      if (i !== groupIndex) return c
      const newItems = c.items.map((item, j) => {
        if (j !== itemIndex) return item
        // Convert value type when switching between single/multi value operators
        let newValue = item.value
        const isMultiOper = oper === 'in' || oper === 'not in'
        const wasMultiOper = item.oper === 'in' || item.oper === 'not in'
        if (isMultiOper && !wasMultiOper) {
          // Switching to multi: convert single value to array
          if (item.value !== '' && item.value !== null && item.value !== undefined) {
            newValue = [item.value]
          } else {
            newValue = []
          }
        } else if (!isMultiOper && wasMultiOper) {
          // Switching from multi: take first element
          if (Array.isArray(item.value) && item.value.length > 0) {
            newValue = item.value[0]
          } else {
            newValue = ''
          }
        }
        return { ...item, oper, value: newValue }
      })
      return { ...c, items: newItems }
    })
    this.$emit('change', newConditions)
  }

  handleValueChange(groupIndex: number, itemIndex: number, value: any) {
    this.updateItem(groupIndex, itemIndex, 'value', value)
  }

  handleTimeRangeChange(groupIndex: number, itemIndex: number, dates: Date[] | null) {
    if (!dates || dates.length < 2) {
      this.updateItem(groupIndex, itemIndex, 'value', null)
      return
    }
    const start = Math.floor(dates[0].getTime() / 1000)
    const end = Math.floor(dates[1].getTime() / 1000)
    this.updateItem(groupIndex, itemIndex, 'value', `${start}-${end}`)
  }

  getChoicesForField(target: string): { label: string; value: string }[] {
    if (target === 'flag') return this.flagChoices
    const field = this.getFieldConfig(target)
    return field?.choices || []
  }

  hasActiveValue(cond: Condition): boolean {
    return cond.items.some(item => {
      if (item.value === '' || item.value === null || item.value === undefined) return false
      if (Array.isArray(item.value) && item.value.length === 0) return false
      return true
    })
  }

  canAddItem(cond: Condition): boolean {
    if (!cond.target) return false
    const field = this.getFieldConfig(cond.target)
    return ['text', 'number'].includes(field?.type || 'text')
  }

  renderValueInput(h: any, cond: Condition, item: ConditionItem, gi: number, ii: number) {
    const field = this.getFieldConfig(cond.target)
    if (!field) return <el-input size="small" placeholder="值" />

    const type = field.type || 'text'
    switch (type) {
      case 'text':
        return (
          <el-input
            value={item.value}
            on-input={(v: string) => this.handleValueChange(gi, ii, v)}
            placeholder={field.placeholder || field.label}
            size="small"
            style="width: 160px"
          />
        )
      case 'number':
        return (
          <el-input
            value={item.value}
            on-input={(v: string) => this.handleValueChange(gi, ii, v)}
            placeholder={field.placeholder || field.label}
            size="small"
            style="width: 140px"
          />
        )
      case 'choice':
        return (
          <el-select
            value={item.value}
            on-input={(v: string) => this.handleValueChange(gi, ii, v)}
            placeholder={field.label}
            size="small"
            style="width: 120px"
          >
            {this.getChoicesForField(cond.target).map(opt => (
              <el-option label={opt.label} value={opt.value} />
            ))}
          </el-select>
        )
      case 'multi_choice': {
        // For in/not in operators, use multi-select; for =/!=/< /> use single-select
        const isArrayOper = item.oper === 'in' || item.oper === 'not in'
        return (
          <el-select
            value={isArrayOper ? (item.value || []) : (item.value || '')}
            on-input={(v: string[]) => this.handleValueChange(gi, ii, v)}
            placeholder={field.placeholder || field.label}
            size="small"
            multiple={isArrayOper}
            collapse-tags={isArrayOper}
            collapse-tags-limit={isArrayOper ? 1 : undefined}
            style="width: 200px"
          >
            {this.getChoicesForField(cond.target).map(opt => (
              <el-option label={opt.label} value={opt.value} />
            ))}
          </el-select>
        )
      }
      case 'time_range':
        return (
          <el-date-picker
            type="datetimerange"
            size="small"
            style="width: 360px"
            on-change={(dates: any) => this.handleTimeRangeChange(gi, ii, dates)}
            start-placeholder="开始时间"
            end-placeholder="结束时间"
          />
        )
      case 'flag':
        return (
          <el-select
            value={item.value}
            on-input={(v: string[]) => this.handleValueChange(gi, ii, v)}
            placeholder="标记"
            size="small"
            multiple
            collapse-tags
            style="width: 160px"
          >
            {this.flagChoices.map(opt => (
              <el-option label={opt.label} value={opt.value} />
            ))}
          </el-select>
        )
      default:
        return <el-input size="small" placeholder="值" />
    }
  }

  renderOperator(h: any, cond: Condition, item: ConditionItem, gi: number, ii: number) {
    const field = this.getFieldConfig(cond.target)
    if (!field) return null

    const operators = field.operators || ((field.type || 'text') === 'text' ? TEXT_OPERATORS : null)
    if (!operators || operators.length === 0) return null

    return (
      <el-select
        value={item.oper}
        on-input={(v: Oper) => this.handleOperChange(gi, ii, v)}
        size="small"
        style="width: 112px"
      >
        {operators.map(opt => (
          <el-option label={opt.label} value={opt.value} />
        ))}
      </el-select>
    )
  }

  renderItem(h: any, cond: Condition, item: ConditionItem, gi: number, ii: number) {
    return (
      <span class="condition-filter__sub-item">
        {this.renderOperator(h, cond, item, gi, ii)}
        {this.renderValueInput(h, cond, item, gi, ii)}
        {cond.items.length > 1 && (
          <i class="el-icon-close condition-filter__item-remove" on-click={() => this.removeItem(gi, ii)} />
        )}
      </span>
    )
  }

  handleSearch() {
    const valid = this.conditions.filter(c => c.target && this.hasActiveValue(c))
    this.$emit('search', valid)
  }

  render(h: any) {
    return (
      <div class="condition-filter">
        <div class="condition-filter__items">
          {this.conditions.map((cond, gi) => {
            const active = this.hasActiveValue(cond)
            return (
              <div class={['condition-filter__item', active && 'condition-filter__item--active']}>
                <el-select
                  value={cond.target}
                  on-input={(v: string) => this.handleFieldChange(gi, v)}
                  placeholder="字段"
                  size="small"
                  style="width: 132px"
                >
                  {this.fields
                    .filter(opt => !this.conditions.some((c, i) => i !== gi && c.target === opt.value))
                    .map(opt => (
                    <el-option label={opt.label} value={opt.value} />
                  ))}
                </el-select>
                {cond.items.map((item, ii) => this.renderItem(h, cond, item, gi, ii))}
                {this.canAddItem(cond) && (
                  <i class="el-icon-plus condition-filter__add-item" on-click={() => this.addItem(gi)} />
                )}
                <i class="el-icon-close condition-filter__remove" on-click={() => this.removeCondition(gi)} />
              </div>
            )
          })}
        </div>
        <div class="condition-filter__actions">
          <el-button type="text" icon="el-icon-plus" disabled={!this.canAddCondition()} on-click={this.addCondition} style="color: #0B71BB">
            添加筛选
          </el-button>
          <el-button type="primary" size="small" on-click={this.handleSearch}>
            搜索
          </el-button>
        </div>
      </div>
    )
  }
}
