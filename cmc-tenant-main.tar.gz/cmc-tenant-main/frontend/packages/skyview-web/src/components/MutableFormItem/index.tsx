import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class MutableFormItem extends Vue {
  @Prop({ required: true }) title!: string
  @Prop({ default: 24 }) span!: number

  render(h: any) {
    return (
      <el-col span={this.span} class="mutable-form-item">
        <div class="mutable-form-item__label">{this.title}</div>
        <div class="mutable-form-item__value">{this.$slots.default || '-'}</div>
      </el-col>
    )
  }
}
