import { Component, Prop, Vue, Watch } from 'vue-property-decorator'

function pad2(n: number): string {
  return String(n).padStart(2, '0')
}

function formatTime(d: Date): string {
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`
}

@Component
export default class LastUpdateTime extends Vue {
  @Prop({ default: 0 }) time!: number
  @Prop({ default: false }) immediate!: boolean

  autoRefresh = this.immediate
  countdown = 30
  interval: number | null = null

  get formattedTime(): string {
    if (!this.time) return '-'
    return formatTime(new Date(this.time * 1000))
  }

  @Watch('immediate')
  onImmediateChange(v: boolean) {
    this.autoRefresh = v
    this.toggleTimer()
  }

  @Watch('time')
  onTimeChange() {
    this.countdown = 30
  }

  mounted() {
    this.toggleTimer()
  }

  beforeDestroy() {
    this.clearTimer()
  }

  toggleTimer() {
    this.clearTimer()
    if (this.autoRefresh) {
      this.countdown = 30
      this.interval = window.setInterval(() => {
        this.countdown--
        if (this.countdown <= 0) {
          this.$emit('refresh')
          this.countdown = 30
        }
      }, 1000)
    }
  }

  clearTimer() {
    if (this.interval) {
      clearInterval(this.interval)
      this.interval = null
    }
  }

  handleToggle(v: boolean) {
    this.autoRefresh = v
    this.$emit(v ? 'start' : 'stop')
    this.toggleTimer()
  }

  handleRefresh() {
    this.countdown = 30
    this.$emit('refresh')
  }

  render(h: any) {
    return (
      <div style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: #909399">
        <span>最后更新: {this.formattedTime}</span>
        {this.autoRefresh && <span>{this.countdown}s</span>}
        <el-button type="text" size="mini" icon="el-icon-refresh" on-click={this.handleRefresh} />
        <el-switch value={this.autoRefresh} on-change={this.handleToggle} width={40} />
      </div>
    )
  }
}
