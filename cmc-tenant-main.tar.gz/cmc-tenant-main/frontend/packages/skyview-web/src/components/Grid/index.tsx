import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Condition, PageResult, ApiResponse } from '@/types/common'

export interface ColumnDef {
  key: string
  title: string
  width?: number
  minWidth?: number
  showOverflowTooltip?: boolean
  render?: (h: any, row: any) => any
  renderHeader?: (h: any) => any
}

@Component
export default class Grid extends Vue {
  @Prop({ required: true }) columns!: ColumnDef[]
  @Prop({ required: true }) fetchData!: (offset: number, count: number, conditions: Condition[]) => Promise<ApiResponse<PageResult<any>>>
  @Prop({ default: 'id' }) rowKey!: string
  @Prop({ default: false }) selectable!: boolean
  @Prop({ default: () => [] }) defaultConditions!: Condition[]
  @Prop({ default: null }) expandRender!: ((h: any, row: any) => any) | null
  @Prop({ default: null }) expandChange!: ((row: any, expandedRows: any[]) => void) | null
  @Prop({ default: true }) border!: boolean

  data: any[] = []
  total = 0
  currentPage = 1
  pageSize = 20
  loading = false
  conditions: Condition[] = []

  created() {
    this.conditions = [...this.defaultConditions]
  }

  mounted() {
    this.loadData()
  }

  @Watch('defaultConditions')
  onDefaultConditionsChange(val: Condition[]) {
    this.conditions = [...val]
    this.currentPage = 1
    this.loadData()
  }

  get offset(): number {
    return (this.currentPage - 1) * this.pageSize
  }

  async loadData() {
    this.loading = true
    try {
      const resp = await this.fetchData(this.offset, this.pageSize, this.conditions)
      if (resp.err === null) {
        this.data = resp.data.items
        this.total = resp.data.total
      }
    } finally {
      this.loading = false
    }
  }

  handlePageChange(page: number) {
    this.currentPage = page
    this.loadData()
  }

  handleSizeChange(size: number) {
    this.pageSize = size
    this.currentPage = 1
    this.loadData()
  }

  handleConditionsChange(conditions: Condition[]) {
    this.conditions = conditions
    this.currentPage = 1
    this.loadData()
  }

  renderCell(h: any, row: any, col: ColumnDef) {
    if (col.render) {
      return col.render(h, row)
    }
    return row[col.key]
  }

  handleExpandChange(row: any, expandedRows: any[]) {
    if (this.expandChange) this.expandChange(row, expandedRows)
    this.$emit('expand-change', row, expandedRows)
  }

  render(h: any) {
    const tableColumns: any[] = []

    if (this.expandRender) {
      tableColumns.push(
        h('el-table-column', {
          props: { type: 'expand' },
          scopedSlots: {
            default: ({ row }: { row: any }) => this.expandRender!(h, row)
          }
        })
      )
    }

    this.columns.forEach((col) => {
      const scopedSlots: any = {
        default: ({ row }: { row: any }) => this.renderCell(h, row, col)
      }
      if (col.renderHeader) {
        scopedSlots.header = () => col.renderHeader!(h)
      }
      tableColumns.push(
        h('el-table-column', {
          props: { prop: col.key, label: col.title, 'min-width': col.minWidth || col.width, 'show-overflow-tooltip': col.showOverflowTooltip },
          scopedSlots,
        })
      )
    })

    return h('div', { class: 'grid' }, [
      h('el-table', {
        directives: [{ name: 'loading', value: this.loading }],
        props: {
          data: this.data,
          rowKey: this.rowKey,
          border: this.border,
        },
        style: { width: '100%' },
        on: {
          'selection-change': (rows: any[]) => this.$emit('selection-change', rows),
          'expand-change': this.handleExpandChange,
        },
      }, [
        this.selectable ? h('el-table-column', { props: { type: 'selection', width: 55 } }) : null,
        ...tableColumns,
      ].filter(Boolean)),
      h('el-pagination', {
        props: {
          currentPage: this.currentPage,
          pageSize: this.pageSize,
          total: this.total,
          layout: 'total, sizes, prev, pager, next, jumper',
        },
        on: {
          'current-change': this.handlePageChange,
          'size-change': this.handleSizeChange,
        },
      }),
    ])
  }
}
