// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class FieldEditDialog extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: '' }) title!: string
  @Prop({ default: false }) loading!: boolean
  @Prop({ default: '600px' }) width!: string

  render(h: any) {
    return (
      <el-dialog title={this.title} visible={this.visible}
        width={this.width} top="5vh" close-on-click-modal={false} destroy-on-close
        on-close={() => this.$emit('close')}>
        {this.$slots.default}
        <div slot="footer">
          <el-button on-click={() => this.$emit('close')}>取消</el-button>
          <el-button type="primary" loading={this.loading}
            on-click={() => this.$emit('submit')}>确定</el-button>
        </div>
      </el-dialog>
    )
  }
}
