// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class EditableRow extends Vue {
  @Prop({ required: true }) label!: string
  @Prop({ default: false }) editable!: boolean
  @Prop({ default: 'inline' }) mode!: 'inline' | 'dialog'
  @Prop() submitFn!: (value: any) => Promise<void>
  @Prop() value!: any
  @Prop({ default: '140px' }) labelWidth!: string

  editing = false
  editValue: any = null
  saving = false

  startEdit() {
    if (this.mode === 'dialog') {
      this.$emit('edit-click')
      return
    }
    this.editValue = this.value != null ? JSON.parse(JSON.stringify(this.value)) : this.value
    this.editing = true
  }

  handleCancel() {
    this.editing = false
    this.editValue = null
  }

  async handleSave() {
    if (!this.submitFn) { this.editing = false; return }
    this.saving = true
    try {
      await this.submitFn(this.editValue)
      this.editing = false
      this.editValue = null
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.saving = false
    }
  }

  handleInput(v: any) {
    this.editValue = v
  }

  render(h: any) {
    return (
      <div class="editable-row" style="display:flex;border-bottom:1px solid #ebeef5;padding:8px 12px">
        <span style={`width:${this.labelWidth};color:#909399;flex-shrink:0;font-size:13px`}>{this.label}</span>
        <span style="flex:1;font-size:13px;word-break:break-all">
          {this.editing
            ? this.$scopedSlots.edit?.({ value: this.editValue, input: this.handleInput })
            : (this.$slots.default || this.$scopedSlots.default?.() || this.value ?? '-')}
        </span>
        {this.editable && !this.editing && (
          <el-button type="text" icon="el-icon-edit" style="margin-left:8px;flex-shrink:0"
            on-click={this.startEdit} />
        )}
        {this.editing && (
          <span style="display:inline-flex;gap:4px;margin-left:8px;flex-shrink:0">
            <el-button size="mini" type="primary" on-click={this.handleSave} loading={this.saving}>确定</el-button>
            <el-button size="mini" on-click={this.handleCancel}>取消</el-button>
          </span>
        )}
      </div>
    )
  }
}
