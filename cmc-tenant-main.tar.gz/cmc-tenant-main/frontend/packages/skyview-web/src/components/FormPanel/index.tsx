import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class FormPanel extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: '编辑' }) title!: string
  @Prop({ default: false }) loading!: boolean

  render(h: any) {
    return (
      <el-dialog
        title={this.title}
        visible={this.visible}
        on-close={() => this.$emit('cancel')}
      >
        {this.$slots.default}
        <div slot="footer">
          <el-button on-click={() => this.$emit('cancel')}>取消</el-button>
          <el-button type="primary" loading={this.loading} on-click={() => this.$emit('submit')}>确定</el-button>
        </div>
      </el-dialog>
    )
  }
}
