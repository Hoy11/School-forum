// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { ipGroupList } from '@/api/captain-ip-group'
import { IPGroup } from '@/types/ip-group'

interface ConditionNode {
  type: 'condition'
  match: string
  field: string
  value: string
  fromValue: string
  toValue: string
  decode_methods: string[]
}

interface ConditionGroup {
  type: 'group'
  logic: '$AND' | '$OR'
  children: ConditionItem[]
}

type ConditionItem = ConditionNode | ConditionGroup

// Operator sets matching SafeLine/Captain-2 API (h=str, g=cidr, m=num)
const STR_METHODS = ['infix', 'notinfix', 'str', 'notstr', 're', 'notre']
const CIDR_METHODS = ['cidr', 'notcidr', ...STR_METHODS]
const NUM_METHODS = ['lt', 'le', 'eq', 'ne', 'gt', 'ge']

const MATCH_OPTIONS = [
  // str_type (h)
  { label: '包含', value: 'infix' },
  { label: '不包含', value: 'notinfix' },
  { label: '等于', value: 'str' },
  { label: '不等于', value: 'notstr' },
  { label: '正则匹配', value: 're' },
  { label: '正则不匹配', value: 'notre' },
  // cidr_type (g)
  { label: '属于网段', value: 'cidr' },
  { label: '不属于网段', value: 'notcidr' },
  // region_type
  { label: '来自地区', value: 'fromregion' },
  { label: '不是来自地区', value: 'notfromregion' },
  // ip_group_type
  { label: '属于 IP 组', value: 'ingroup' },
  { label: '不属于 IP 组', value: 'notingroup' },
  // CMC-specific
  { label: '范围', value: 'range' },
  // numeric_type (m)
  { label: '小于', value: 'lt' },
  { label: '小于等于', value: 'le' },
  { label: '等于', value: 'eq' },
  { label: '不等于', value: 'ne' },
  { label: '大于', value: 'gt' },
  { label: '大于等于', value: 'ge' },
]

const FIELD_OPTIONS = [
  { label: 'URI', value: 'urlpath' },
  { label: '解码后路径', value: 'decoded_path' },
  { label: 'Query', value: 'decoded_query' },
  { label: 'GET 参数', value: 'query' },
  { label: 'Method', value: 'method' },
  { label: 'Host', value: 'host' },
  { label: '完整 Cookie', value: 'raw_cookie' },
  { label: 'Cookie 参数', value: 'cookie' },
  { label: 'User Agent', value: 'user_agent' },
  { label: 'Referer', value: 'referer' },
  { label: 'Content-Type', value: 'content_type' },
  { label: 'Content-Length', value: 'content_length' },
  { label: '用户 IP', value: 'remote_addr' },
  { label: 'X-Forwarded-For', value: 'x_forwarded_for' },
  { label: 'Origin', value: 'origin' },
  { label: 'Accept-Language', value: 'accept_language' },
  { label: 'Authorization', value: 'authorization' },
  { label: 'Session', value: 'session' },
  { label: '完整 HTTP header', value: 'request_header' },
  { label: 'HTTP 请求头', value: 'custom_header' },
  { label: 'HTTP 请求头长度', value: 'request_header_length' },
  { label: 'HTTP 请求体长度', value: 'request_body_length' },
  { label: 'POST 参数', value: 'form' },
  { label: '请求体中任意 key 长度', value: 'form_keys_len' },
  { label: '请求体中任意 val 长度', value: 'form_vals_len' },
  { label: '请求体中 key 数量', value: 'form_keys_count' },
  { label: '完整 Body', value: 'request_body' },
  { label: '上传的文件名', value: 'file_name' },
  { label: 'HTTP 状态码', value: 'response_status' },
  { label: 'HTTP 响应头', value: 'response_header' },
  { label: '完整 HTTP 响应头', value: 'response_header_raw' },
  { label: '响应内容', value: 'response_body' },
]

const FIELD_MATCH_MAP: Record<string, string[]> = {
  // str + h
  urlpath: STR_METHODS,
  decoded_path: STR_METHODS,
  decoded_query: STR_METHODS,
  method: STR_METHODS,
  host: STR_METHODS,
  raw_cookie: STR_METHODS,
  user_agent: STR_METHODS,
  referer: STR_METHODS,
  content_type: STR_METHODS,
  content_length: NUM_METHODS,
  x_forwarded_for: STR_METHODS,
  origin: STR_METHODS,
  accept_language: STR_METHODS,
  authorization: STR_METHODS,
  session: STR_METHODS,
  request_header: STR_METHODS,
  custom_header: STR_METHODS,
  request_header_length: NUM_METHODS,
  request_body_length: NUM_METHODS,
  form: STR_METHODS,
  form_keys_len: NUM_METHODS,
  form_vals_len: NUM_METHODS,
  form_keys_count: NUM_METHODS,
  request_body: STR_METHODS,
  file_name: STR_METHODS,
  response_status: STR_METHODS,
  response_header: STR_METHODS,
  response_header_raw: STR_METHODS,
  response_body: STR_METHODS,
  // str + g + region + ip_group (IP)
  remote_addr: [...CIDR_METHODS, 'fromregion', 'notfromregion', 'ingroup', 'notingroup', 'range'],
  // kv + h
  query: STR_METHODS,
  cookie: STR_METHODS,
}

function availableMatches(field: string): string[] {
  if (!field) return []
  return FIELD_MATCH_MAP[field] || STR_METHODS
}

function createCondition(): ConditionNode {
  return { type: 'condition', match: '', field: '', value: '', fromValue: '', toValue: '', decode_methods: [] }
}

function createGroup(): ConditionGroup {
  return { type: 'group', logic: '$AND', children: [createCondition()] }
}

function patternToItems(pattern: any): { items: ConditionItem[], logic: string } {
  if (!pattern || typeof pattern !== 'object') return { items: [], logic: '$AND' }

  const keys = Object.keys(pattern)
  if (keys.length === 0) return { items: [], logic: '$AND' }

  const logicKey = keys.find(k => k === '$AND' || k === '$OR') || '$AND'
  const arr = pattern[logicKey]
  if (!Array.isArray(arr)) return { items: [], logic: '$AND' }

  return {
    items: arr.map((item: any) => {
      if (item.$AND || item.$OR) {
        const subLogic = item.$AND ? '$AND' : '$OR'
        const subArr = item[subLogic] || []
        return {
          type: 'group',
          logic: subLogic,
          children: subArr.map(parseConditionNode),
        } as ConditionGroup
      }
      return parseConditionNode(item)
    }),
    logic: logicKey,
  }
}

function parseConditionNode(item: any): ConditionNode {
  const matchType = [...STR_METHODS, ...CIDR_METHODS, ...NUM_METHODS, 'ingroup', 'notingroup', 'fromregion', 'notfromregion', 'range'].find(m => item[m]) || 'infix'
  const matchObj = item[matchType] || {}
  const field = Object.keys(matchObj)[0] || 'remote_addr'
  const rawVal = matchObj[field]

  let value = ''
  let fromValue = ''
  let toValue = ''
  if (matchType === 'range' && rawVal && typeof rawVal === 'object') {
    fromValue = String(rawVal.from ?? '')
    toValue = String(rawVal.to ?? '')
  } else {
    value = String(rawVal ?? '')
  }

  return {
    type: 'condition',
    match: matchType,
    field,
    value,
    fromValue,
    toValue,
    decode_methods: item.decode_methods || [],
  }
}

function itemsToPattern(items: ConditionItem[], logic: string): any {
  if (items.length === 0) return { [logic]: [] }
  const converted = items.map(itemToPatternEntry)
  return { [logic]: converted }
}

function itemToPatternEntry(item: ConditionItem): any {
  if (item.type === 'group') {
    return { [item.logic]: item.children.map(itemToPatternEntry) }
  }
  const node = item as ConditionNode
  let val: any = node.value
  if (node.match === 'range') {
    val = { from: Number(node.fromValue) || 0, to: Number(node.toValue) || 0 }
  }
  return {
    [node.match]: { [node.field]: val },
    decode_methods: node.decode_methods || [],
  }
}

@Component
export default class ConditionEditor extends Vue {
  @Prop({ default: null }) value!: Record<string, unknown> | null
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: false }) disabled!: boolean

  items: ConditionItem[] = [createCondition()]
  logic: '$AND' | '$OR' = '$AND'
  ipGroups: IPGroup[] = []
  _selfEmitting = false

  @Watch('value', { immediate: true })
  onValueChange(val: any) {
    if (this._selfEmitting) return
    if (val && Object.keys(val).length > 0) {
      const result = patternToItems(val)
      this.items = result.items
      this.logic = result.logic as '$AND' | '$OR'
    } else {
      this.items = [createCondition()]
      this.logic = '$AND'
    }
  }

  @Watch('captainInstanceId', { immediate: true })
  onInstanceChange(id: number) {
    if (id) this.loadIPGroups()
  }

  async loadIPGroups() {
    try {
      const resp = await ipGroupList(this.captainInstanceId, 0, 1000)
      if (resp.err === null) {
        this.ipGroups = resp.data?.items || []
      }
    } catch { /* ignore */ }
  }

  get pattern(): Record<string, unknown> {
    return itemsToPattern(this.items, this.logic)
  }

  addCondition() {
    this.items = [...this.items, createCondition()]
    this.emitChange()
  }

  nestCondition(index: number) {
    const items = [...this.items]
    const condition = items[index] as ConditionNode
    const group: ConditionGroup = {
      type: 'group',
      logic: '$AND',
      children: [condition, createCondition()]
    }
    items[index] = group
    this.items = items
    this.emitChange()
  }

  removeItem(index: number) {
    this.items = this.items.filter((_, i) => i !== index)
    this.emitChange()
  }

  updateItem(index: number, patch: Partial<ConditionNode | ConditionGroup>) {
    const items = [...this.items]
    const item = { ...items[index], ...patch }
    if (item.type === 'condition') {
      const available = availableMatches(item.field)
      if (!item.field || !item.match || !available.includes(item.match)) {
        item.match = available[0] || ''
        item.value = ''
      }
    }
    items[index] = item
    this.items = items
    this.emitChange()
  }

  addGroupChild(gIndex: number) {
    const items = [...this.items]
    const group = items[gIndex] as ConditionGroup
    items[gIndex] = { ...group, children: [...group.children, createCondition()] }
    this.items = items
    this.emitChange()
  }

  removeGroupChild(gIndex: number, cIndex: number) {
    const items = [...this.items]
    const group = { ...(items[gIndex] as ConditionGroup) }
    group.children = group.children.filter((_, i) => i !== cIndex)
    // 子组只剩1个条件时，自动取消嵌套 — 提升到顶层
    if (group.children.length <= 1) {
      items[gIndex] = group.children[0] || createCondition()
    } else {
      items[gIndex] = group
    }
    this.items = items
    this.emitChange()
  }

  updateGroupChild(gIndex: number, cIndex: number, patch: Partial<ConditionNode>) {
    const items = [...this.items]
    const group = { ...(items[gIndex] as ConditionGroup) }
    const child = { ...group.children[cIndex], ...patch } as ConditionNode
    const available = availableMatches(child.field)
    if (!child.field || !child.match || !available.includes(child.match)) {
      child.match = available[0] || ''
      child.value = ''
    }
    group.children = group.children.map((c, i) => i === cIndex ? child : c)
    items[gIndex] = group
    this.items = items
    this.emitChange()
  }

  updateGroupLogic(gIndex: number, logic: string) {
    const items = [...this.items]
    items[gIndex] = { ...(items[gIndex] as ConditionGroup), logic }
    this.items = items
    this.emitChange()
  }

  /** Validate all conditions, return first error message or null */
  validate(): string | null {
    const checkItem = (item: ConditionItem): string | null => {
      if (item.type === 'group') {
        if (item.children.length === 0) return '条件组不能为空'
        for (const child of item.children) {
          const err = checkItem(child)
          if (err) return err
        }
        return null
      }
      const node = item as ConditionNode
      if (!node.field) return '请选择字段'
      if (!node.match) return '请选择操作符'
      if (!node.value && node.match !== 'range') {
        if (node.match === 'ingroup') return '请选择 IP 组'
        return '匹配值不能为空'
      }
      if (node.match === 'range') {
        if (!node.fromValue || !node.toValue) return '范围起止值不能为空'
        if (isNaN(Number(node.fromValue)) || isNaN(Number(node.toValue))) return '范围起止值必须为数字'
        if (Number(node.fromValue) > Number(node.toValue)) return '范围起始值不能大于结束值'
      }
      return null
    }
    if (this.items.length === 0) return '请添加至少一个匹配条件'
    for (const item of this.items) {
      const err = checkItem(item)
      if (err) return err
    }
    return null
  }

  emitChange() {
    this._selfEmitting = true
    this.$emit('input', this.pattern)
    this.$emit('change', this.pattern)
    this.$nextTick(() => { this._selfEmitting = false })
  }

  getAvailableMatches(field: string) {
    return MATCH_OPTIONS.filter(o => availableMatches(field).includes(o.value))
  }

  renderConditionRow(h: any, item: ConditionNode, index: number, isGroup: boolean, gIndex?: number) {
    const updateFn = isGroup
      ? (patch: Partial<ConditionNode>) => this.updateGroupChild(gIndex!, index, patch)
      : (patch: Partial<ConditionNode>) => this.updateItem(index, patch)
    const removeFn = isGroup
      ? () => this.removeGroupChild(gIndex!, index)
      : () => this.removeItem(index)

    const isRange = item.match === 'range'
    const isIngroup = item.match === 'ingroup'
    const availableMatches = this.getAvailableMatches(item.field)

    return (
      <div class="ce-row">
        <div class="ce-row-fields">
          <el-select v-model={item.field} size="small" style="width: 128px; flex-shrink: 0" placeholder="请选择" clearable disabled={this.disabled} on-change={(v: string) => updateFn({ field: v })}>
            {FIELD_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
          </el-select>
          <el-select v-model={item.match} size="small" style="width: 120px; flex-shrink: 0" placeholder="请选择" clearable disabled={this.disabled} on-change={(v: string) => updateFn({ match: v, value: '', fromValue: '', toValue: '' })}>
            {availableMatches.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
          </el-select>
          {isRange ? (
            <span style="display: flex; align-items: center; gap: 4px">
              <el-input v-model={item.fromValue} size="small" style="width: 80px" placeholder="from" disabled={this.disabled} on-input={(v: string) => updateFn({ fromValue: v })} />
              <span>-</span>
              <el-input v-model={item.toValue} size="small" style="width: 80px" placeholder="to" disabled={this.disabled} on-input={(v: string) => updateFn({ toValue: v })} />
            </span>
          ) : isIngroup ? (
            <el-select v-model={item.value} size="small" style="flex: 1" placeholder="选择 IP 组" disabled={this.disabled} on-change={(v: string) => updateFn({ value: v })}>
              {this.ipGroups.map(g => <el-option key={g.id} label={g.name} value={String(g.id)} />)}
            </el-select>
          ) : (
            <el-input v-model={item.value} size="small" style="flex: 1; min-width: 60px" placeholder="参数值" disabled={this.disabled} on-input={(v: string) => updateFn({ value: v })} />
          )}
        </div>
        <div class="ce-row-actions">
          {!isGroup && !this.disabled && (
            <i class="ce-action-icon ce-add-pattern-icon el-icon-plus" title="嵌套" on-click={() => this.nestCondition(index)} />
          )}
          {!this.disabled && (
            <i class="ce-action-icon ce-delete-icon el-icon-close" title="删除" on-click={removeFn} />
          )}
        </div>
      </div>
    )
  }

  renderGroup(h: any, item: ConditionGroup, gIndex: number) {
    const hasLogic = item.children.length >= 2

    const childrenRows = item.children.map((child, cIndex) => {
      return <div key={cIndex}>{this.renderConditionRow(h, child as ConditionNode, cIndex, true, gIndex)}</div>
    })

    const addBtn = !this.disabled && (
      <div class="ce-add-btn">
        <el-button size="mini" icon="el-icon-plus" on-click={() => this.addGroupChild(gIndex)}>添加条件</el-button>
      </div>
    )

    if (!hasLogic) {
      return (
        <div class="ce-group">
          {childrenRows}
          {addBtn}
        </div>
      )
    }

    // 嵌套组：AND/OR 在左侧列，条件在右侧列，与顶层一样左右分列（对齐雷池）
    // addBtn 在 ce-wrapper 外面，不参与 AND/OR 居中计算
    return (
      <div class="ce-group">
        <div class="ce-wrapper">
          <div class="ce-logic-col">
            <el-select size="small" style="width: 80px" value={item.logic} disabled={this.disabled}
              on-change={(v: string) => this.updateGroupLogic(gIndex, v)}>
              <el-option label="$AND" value="$AND" />
              <el-option label="$OR" value="$OR" />
            </el-select>
          </div>
          <div class="ce-conditions-col">
            {childrenRows}
          </div>
        </div>
        {addBtn}
      </div>
    )
  }

  render(h: any) {
    const hasLogic = this.items.length >= 2

    // 条件行列表
    const conditionRows = this.items.map((item, index) => {
      if (item.type === 'group') {
        return <div key={index}>{this.renderGroup(h, item as ConditionGroup, index)}</div>
      }
      return <div key={index}>{this.renderConditionRow(h, item as ConditionNode, index, false)}</div>
    })

    // 添加条件按钮
    const addBtn = !this.disabled && (
      <div class="ce-add-btn">
        <el-button size="small" icon="el-icon-plus" on-click={this.addCondition}>添加条件</el-button>
      </div>
    )

    // 仅 1 个条件时：不显示左侧逻辑列，无虚线
    if (!hasLogic) {
      return (
        <div>
          {conditionRows}
          {addBtn}
        </div>
      )
    }

    // ≥2 个条件时：左右分列 + 虚线连接
    return (
      <div class="ce-wrapper">
        <div class="ce-logic-col">
          <el-select size="small" style="width: 80px" value={this.logic} disabled={this.disabled}
            on-change={(v: string) => { this.logic = v; this.emitChange() }}>
            <el-option label="$AND" value="$AND" />
            <el-option label="$OR" value="$OR" />
          </el-select>
        </div>
        <div class="ce-conditions-col">
          {conditionRows}
          {addBtn}
        </div>
      </div>
    )
  }
}
