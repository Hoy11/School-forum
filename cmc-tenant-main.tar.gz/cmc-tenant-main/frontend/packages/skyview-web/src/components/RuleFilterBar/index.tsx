// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Condition, ConditionItem, FilterFieldOption, Oper } from '@/types/common'

// Operator sets per field type — matching Raycher QuickFilter exactly
const ID_OPERATORS: { label: string; value: Oper }[] = [
  { label: '等于', value: '=' },
  { label: '不等于', value: '!=' },
  { label: '小于', value: '<' },
  { label: '大于', value: '>' },
]

const TEXT_OPERATORS: { label: string; value: Oper }[] = [
  { label: '包含', value: 'like' },
  { label: '不包含', value: 'not like' },
]

const CHOICE_OPERATORS: { label: string; value: Oper }[] = [
  { label: '等于', value: '=' },
  { label: '不等于', value: '!=' },
]

const DENY_CODE_OPERATORS: { label: string; value: Oper }[] = [
  { label: '等于', value: '=' },
  { label: '不等于', value: '!=' },
  { label: '小于', value: '<' },
  { label: '大于', value: '>' },
  { label: '等于一系列值（逗号分隔）', value: 'in' },
  { label: '不等于一系列值（逗号分隔）', value: 'not in' },
]

const TIME_RANGE_OPERATORS: { label: string; value: Oper }[] = [
  { label: '早于', value: 'before' },
  { label: '晚于', value: 'after' },
  { label: '范围', value: 'range' },
]

function defaultOperForType(type: string): Oper {
  switch (type) {
    case 'text': return 'like'
    case 'choice': return '='
    case 'multi_choice': return '='
    case 'time': return 'before'
    case 'time_range': return 'range'
    default: return '='
  }
}

function operatorsForField(field: FilterFieldOption): { label: string; value: Oper }[] {
  if (field.operators && field.operators.length > 0) return field.operators
  switch (field.type) {
    case 'text': return TEXT_OPERATORS
    case 'choice': return CHOICE_OPERATORS
    case 'multi_choice': return CHOICE_OPERATORS
    case 'time': return TIME_RANGE_OPERATORS
    case 'time_range': return TIME_RANGE_OPERATORS
    default: return []
  }
}

function createItem(type?: string, field?: FilterFieldOption): ConditionItem {
  const ops = operatorsForField(field || { label: '', value: '', type: type || 'text' })
  const oper = ops.length > 0 ? ops[0].value : defaultOperForType(type || 'text')
  return { oper, value: type === 'multi_choice' ? [] : (type === 'time_range' || type === 'time' ? null : '') }
}

interface FieldState {
  items: ConditionItem[]
  visible: boolean  // popover visible state
}

@Component
export default class RuleFilterBar extends Vue {
  @Prop({ default: () => [] }) defaultFields!: FilterFieldOption[]
  @Prop({ default: () => [] }) optionalFields!: FilterFieldOption[]
  @Prop({ default: () => [] }) conditions!: Condition[]

  activeFields: string[] = []
  fieldStates: Record<string, FieldState> = {}
  showConfig = false

  created() {
    this.resetFieldStates(this.conditions)
  }

  @Watch('conditions', { deep: true })
  onConditionsChange(conditions: Condition[]) {
    this.resetFieldStates(conditions)
  }

  resetFieldStates(conditions: Condition[] = []) {
    this.activeFields = this.defaultFields.map(f => f.value)
    const states: Record<string, FieldState> = {}
    for (const f of [...this.defaultFields, ...this.optionalFields]) {
      states[f.value] = { items: [createItem(f.type, f)], visible: false }
    }
    for (const condition of conditions || []) {
      const field = [...this.defaultFields, ...this.optionalFields].find(f => f.value === condition.target)
      if (!field) continue
      if (!this.activeFields.includes(field.value)) this.activeFields.push(field.value)
      states[field.value] = {
        items: condition.items?.length ? condition.items.map(item => ({ ...item })) : [createItem(field.type, field)],
        visible: false,
      }
    }
    this.fieldStates = states
  }

  get allFieldsMap(): Record<string, FilterFieldOption> {
    const map: Record<string, FilterFieldOption> = {}
    for (const f of this.defaultFields) map[f.value] = f
    for (const f of this.optionalFields) map[f.value] = f
    return map
  }

  getField(value: string): FilterFieldOption | undefined {
    return this.allFieldsMap[value]
  }

  // Check if a field has any active (non-empty) value
  hasActiveValue(fieldValue: string): boolean {
    const state = this.fieldStates[fieldValue]
    if (!state) return false
    return state.items.some(item => {
      if (item.value === '' || item.value === null || item.value === undefined) return false
      if (Array.isArray(item.value) && item.value.length === 0) return false
      return true
    })
  }

  // Get display label for the value on the tag
  getValueLabel(fieldValue: string): string {
    const state = this.fieldStates[fieldValue]
    const field = this.getField(fieldValue)
    if (!state || !field || !state.items?.[0]) return ''

    const item = state.items[0]
    if (item.value === '' || item.value === null || item.value === undefined) return ''

    switch (field.type) {
      case 'text':
        return String(item.value)
      case 'choice': {
        // Handle both single value and array value (for in/not in operators)
        if (Array.isArray(item.value)) {
          if (item.value.length === 0) return ''
          const labels = (item.value as string[]).map(v => {
            const choice = field.choices?.find(c => c.value === String(v))
            return choice ? choice.label : String(v)
          })
          return labels.join(', ')
        }
        const choice = field.choices?.find(c => c.value === String(item.value))
        return choice ? choice.label : String(item.value)
      }
      case 'multi_choice': {
        if (!Array.isArray(item.value) || item.value.length === 0) return ''
        const labels = (item.value as string[]).map(v => {
          const choice = field.choices?.find(c => c.value === String(v))
          return choice ? choice.label : String(v)
        })
        if (labels.length <= 2) return labels.join(', ')
        return labels[0] + ` +${labels.length - 1}`
      }
      case 'time':
      case 'time_range': {
        if (typeof item.value !== 'string') return ''
        if (item.oper === 'range') {
          const tParts = item.value.split('-')
          if (tParts.length < 2 || !tParts[0] || !tParts[1]) return ''
          const sd = new Date(parseInt(tParts[0], 10) * 1000)
          const ed = new Date(parseInt(tParts[1], 10) * 1000)
          const fmt = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
          return `${fmt(sd)} ~ ${fmt(ed)}`
        } else {
          const ts = parseInt(item.value, 10)
          if (isNaN(ts)) return ''
          const d = new Date(ts * 1000)
          return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
        }
      }
      default:
        return ''
    }
  }

  buildConditions(): Condition[] {
    const conditions: Condition[] = []
    for (const fieldValue of this.activeFields) {
      const state = this.fieldStates[fieldValue]
      if (!state || !this.hasActiveValue(fieldValue)) continue
      conditions.push({ target: fieldValue, items: state.items.filter(i => i.value !== '' && i.value !== null && i.value !== undefined) })
    }
    return conditions
  }

  emitSearch() {
    this.$emit('search', this.buildConditions())
  }

  // Clear all values for a field (back to "全部")
  clearField(fieldValue: string) {
    const field = this.getField(fieldValue)
    if (!field) return
    this.fieldStates[fieldValue].items = [createItem(field.type, field)]
    this.fieldStates[fieldValue].visible = false
    this.emitSearch()
  }

  // Confirm popover: close and emit search
  confirmPopover(fieldValue: string) {
    this.fieldStates[fieldValue].visible = false
    this.emitSearch()
  }

  // Cancel popover: close without emitting
  cancelPopover(fieldValue: string) {
    this.fieldStates[fieldValue].visible = false
  }

  // Update field operator at given index
  updateOper(fieldValue: string, index: number, oper: Oper) {
    const items = [...this.fieldStates[fieldValue].items]
    items[index] = { ...items[index], oper }
    this.fieldStates[fieldValue].items = items
  }

  // Update field value at given index
  updateVal(fieldValue: string, index: number, value: any) {
    const items = [...this.fieldStates[fieldValue].items]
    items[index] = { ...items[index], value }
    this.fieldStates[fieldValue].items = items
  }

  // Add a new item row
  addItem(fieldValue: string) {
    const field = this.getField(fieldValue)
    if (!field) return
    const state = this.fieldStates[fieldValue]
    state.items = [...state.items, createItem(field.type, field)]
  }

  // Remove an item row
  removeItem(fieldValue: string, index: number) {
    const state = this.fieldStates[fieldValue]
    if (state.items.length <= 1) return
    state.items = state.items.filter((_, i) => i !== index)
  }

  isFieldChecked(value: string): boolean {
    return this.activeFields.includes(value)
  }

  toggleField(value: string) {
    if (this.isFieldChecked(value)) {
      this.activeFields = this.activeFields.filter(f => f !== value)
      const field = this.getField(value)
      if (field) {
        this.fieldStates[value] = { items: [createItem(field.type, field)], visible: false }
      }
      this.showConfig = false
      this.emitSearch()
    } else {
      this.activeFields = [...this.activeFields, value]
      this.showConfig = false
    }
  }

  handleClickOutside(e: MouseEvent) {
    const target = e.target as HTMLElement
    if (!target?.closest?.('.rule-filter-bar')) {
      this.showConfig = false
    }
  }

  mounted() {
    document.addEventListener('click', this.handleClickOutside)
  }

  beforeDestroy() {
    document.removeEventListener('click', this.handleClickOutside)
  }

  // Render the popover content for a field — matches Raycher QuickFilter popover layout
  renderPopoverContent(h: any, fieldValue: string) {
    const field = this.getField(fieldValue)
    if (!field) return null
    const state = this.fieldStates[fieldValue]
    if (!state) return null

    const ops = operatorsForField(field)
    const showOperator = ops.length > 0

    const rows = state.items.map((item: ConditionItem, ii: number) => {
      const isLastItem = ii === state.items.length - 1

      let inputArea = null

      switch (field.type) {
        case 'text':
          inputArea = (
            <div style="display: flex; align-items: center; gap: 8px; width: 320px; margin-bottom: 8px;">
              {showOperator && (
                <el-select
                  value={item.oper}
                  on-input={(v: Oper) => this.updateOper(fieldValue, ii, v)}
                  size="small"
                  style="width: 80px"
                >
                  {ops.map((op: any) => <el-option key={op.value} label={op.label} value={op.value} />)}
                </el-select>
              )}
              <el-input
                value={item.value || ''}
                on-input={(v: string) => this.updateVal(fieldValue, ii, v)}
                placeholder={field.placeholder || field.label}
                size="small"
                style="flex: 1"
                on-keyup={(e: KeyboardEvent) => { if (e.key === 'Enter') this.confirmPopover(fieldValue) }}
              />
              {state.items.length > 1 && (
                <i class="el-icon-close" style="color: #909399; cursor: pointer; font-size: 14px; flex-shrink: 0"
                  on-click={() => this.removeItem(fieldValue, ii)} />
              )}
            </div>
          )
          break

        case 'choice': {
          // For in/not in operators, use multi-select; otherwise single-select
          const choiceIsMulti = item.oper === 'in' || item.oper === 'not in'
          inputArea = (
            <div style="display: flex; align-items: center; gap: 8px; width: 320px; margin-bottom: 8px;">
              {showOperator && (
                <el-select
                  value={item.oper}
                  on-input={(v: Oper) => { this.updateOper(fieldValue, ii, v); if (v === 'in' || v === 'not in') this.updateVal(fieldValue, ii, []) }}
                  size="small"
                  style="width: 80px"
                >
                  {ops.map((op: any) => <el-option key={op.value} label={op.label} value={op.value} />)}
                </el-select>
              )}
              <el-select
                value={choiceIsMulti ? (item.value || []) : (item.value || '')}
                on-input={(v: any) => this.updateVal(fieldValue, ii, v)}
                placeholder={field.placeholder || '请选择'}
                size="small"
                multiple={choiceIsMulti}
                {...(choiceIsMulti ? { collapseTags: true, collapseTagsLimit: 1 } : {})}
                style="flex: 1"
              >
                {(field.choices || []).map((opt: any) => <el-option key={opt.value} label={opt.label} value={opt.value} />)}
              </el-select>
            </div>
          )
          break
        }

        case 'multi_choice': {
          // For in/not in operators, use multi-select; for =/!= use single-select
          const multiIsArray = item.oper === 'in' || item.oper === 'not in' || item.oper === '<' || item.oper === '>'
          inputArea = (
            <div style="display: flex; align-items: center; gap: 8px; width: 320px; margin-bottom: 8px;">
              {showOperator && (
                <el-select
                  value={item.oper}
                  on-input={(v: Oper) => { this.updateOper(fieldValue, ii, v); if (v === 'in' || v === 'not in') this.updateVal(fieldValue, ii, []) }}
                  size="small"
                  style="width: 80px"
                >
                  {ops.map((op: any) => <el-option key={op.value} label={op.label} value={op.value} />)}
                </el-select>
              )}
              <el-select
                value={multiIsArray ? (item.value || []) : (item.value || '')}
                on-input={(v: any) => this.updateVal(fieldValue, ii, v)}
                placeholder={field.placeholder || '请选择'}
                size="small"
                multiple={multiIsArray}
                {...(multiIsArray ? { collapseTags: true, collapseTagsLimit: 1 } : {})}
                style="flex: 1"
              >
                {(field.choices || []).map((opt: any) => <el-option key={opt.value} label={opt.label} value={opt.value} />)}
              </el-select>
            </div>
          )
          break
        }

        case 'time':
        case 'time_range': {
          // time: single date picker (before/after mode)
          // time_range: operator decides if range or single date
          const isSingleTime = field.type === 'time' || item.oper === 'before' || item.oper === 'after' || item.oper === '='
          const isRange = !isSingleTime && item.oper === 'range'
          const singleDate = item.value
            ? (isRange ? this.parseTimeRangeStart(String(item.value)) : this.parseSingleTime(String(item.value)))
            : null

          inputArea = (
            <div style="width: 320px; margin-bottom: 8px;">
              <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                {showOperator && (
                  <el-select
                    value={item.oper}
                    on-input={(v: Oper) => { this.updateOper(fieldValue, ii, v); if (v !== 'range') this.updateVal(fieldValue, ii, null) }}
                    size="small"
                    style="width: 80px"
                  >
                    {ops.map((op: any) => <el-option key={op.value} label={op.label} value={op.value} />)}
                  </el-select>
                )}
              </div>
              {isRange ? (
                <div style="display: flex; align-items: center; gap: 8px;">
                  <el-date-picker
                    type="datetime"
                    size="small"
                    style="flex: 1"
                    value={item.value ? this.parseTimeRangeStart(String(item.value)) : null}
                    on-input={(v: Date) => this.handleTimePartChange(fieldValue, ii, 'start', v)}
                    placeholder="开始时间"
                  />
                  <span style="color: #909399; font-size: 12px">-</span>
                  <el-date-picker
                    type="datetime"
                    size="small"
                    style="flex: 1"
                    value={item.value ? this.parseTimeRangeEnd(String(item.value)) : null}
                    on-input={(v: Date) => this.handleTimePartChange(fieldValue, ii, 'end', v)}
                    placeholder="结束时间"
                  />
                </div>
              ) : (
                <el-date-picker
                  type="datetime"
                  size="small"
                  style="width: 100%"
                  value={singleDate}
                  on-input={(v: Date) => this.handleSingleTimeChange(fieldValue, ii, v)}
                  placeholder={item.oper === 'before' ? '早于此时间' : (item.oper === 'after' ? '晚于此时间' : '选择时间')}
                />
              )}
            </div>
          )
          break
        }

        default:
          inputArea = (
            <div style="width: 320px; margin-bottom: 8px;">
              <el-input value="" size="small" disabled />
            </div>
          )
      }

      return [
        inputArea,
        isLastItem && (
          <el-button type="text" size="mini" on-click={() => this.addItem(fieldValue)} style="margin-bottom: 8px; color: #0b71bb; padding: 0;">
            + 添加
          </el-button>
        ),
      ]
    })

    const footer = (
      <div style={{
        display: 'flex',
        justifyContent: 'flex-end',
        gap: '8px',
        paddingTop: '8px',
        marginTop: '4px',
        borderTop: '1px solid #e9e9e9',
      }}>
        <el-button size="small" on-click={() => this.cancelPopover(fieldValue)}>取消</el-button>
        <el-button size="small" type="primary" on-click={() => this.confirmPopover(fieldValue)}>确定</el-button>
      </div>
    )

    return <div style="min-width: 340px; padding: 12px;">{rows}{footer}</div>
  }

  // Parse start time from "start-end" string
  parseTimeRangeStart(s: string): Date | null {
    const parts = s.split('-')
    if (parts.length < 1 || !parts[0]) return null
    const ts = parseInt(parts[0], 10) * 1000
    if (isNaN(ts)) return null
    return new Date(ts)
  }

  // Parse end time from "start-end" string
  parseTimeRangeEnd(s: string): Date | null {
    const parts = s.split('-')
    if (parts.length < 2 || !parts[1]) return null
    const ts = parseInt(parts[1], 10) * 1000
    if (isNaN(ts)) return null
    return new Date(ts)
  }

  // Parse single timestamp string
  parseSingleTime(s: string): Date | null {
    if (!s || s.startsWith('-') || s.endsWith('-')) return null
    const ts = parseInt(s, 10) * 1000
    if (isNaN(ts)) return null
    return new Date(ts)
  }

  // Handle individual date picker change for time range
  handleTimePartChange(fieldValue: string, index: number, part: 'start' | 'end', date: Date | null) {
    const state = this.fieldStates[fieldValue]
    const item = state.items[index]
    const current = typeof item.value === 'string' ? item.value : ''
    const parts = current.split('-')
    let startTs = parts[0] || ''
    let endTs = parts[1] || ''

    if (date) {
      const ts = String(Math.floor(date.getTime() / 1000))
      if (part === 'start') startTs = ts
      else endTs = ts
    } else {
      if (part === 'start') startTs = ''
      else endTs = ''
    }

    const newVal = startTs && endTs ? `${startTs}-${endTs}` : (startTs ? `${startTs}-` : (endTs ? `-${endTs}` : ''))
    this.updateVal(fieldValue, index, newVal || null)
  }

  // Handle single date picker change (before/after mode)
  handleSingleTimeChange(fieldValue: string, index: number, date: Date | null) {
    const ts = date ? String(Math.floor(date.getTime() / 1000)) : null
    this.updateVal(fieldValue, index, ts)
  }

  render(h: any) {
    return (
      <div class="rule-filter-bar" style={{ display: 'inline-flex', alignItems: 'center', gap: '0', flexWrap: 'wrap', flex: '1', minWidth: 0 }}>
        {this.activeFields.map((fieldValue: string) => {
          const field = this.getField(fieldValue)
          if (!field) return null
          const state = this.fieldStates[fieldValue]
          if (!state) return null
          const active = this.hasActiveValue(fieldValue)
          const valueLabel = this.getValueLabel(fieldValue)

          // Build display value text
          let displayText = '全部'
          if (active) {
            displayText = valueLabel || '已设置'
          }

          return (
            <el-popover
              key={fieldValue}
              placement="bottom"
              trigger="click"
              v-model={state.visible}
              popper-class="rule-filter-popper"
            >
              <div slot="reference" class="condition-filter__tag" style={{
                display: 'inline-flex',
                alignItems: 'center',
                height: '24px',
                minWidth: '105px',
                padding: '0 14px',
                marginRight: '14px',
                borderRadius: '4px',
                background: '#EEF1F5',
                cursor: 'pointer',
                userSelect: 'none',
                whiteSpace: 'nowrap',
              }}>
                <span style={{ color: active ? '#0b71bb' : '#999', fontSize: '12px' }}>
                  {field.label}：
                </span>
                <span style={{ color: active ? '#0b71bb' : '#999', fontSize: '12px' }}>
                  {displayText}
                </span>
                {active && (
                  <i class="el-icon-close condition-filter__tag-clear" style={{
                    color: '#999',
                    fontSize: '12px',
                    marginLeft: '4px',
                    cursor: 'pointer',
                  }} on-click={(e: MouseEvent) => { e.stopPropagation(); this.clearField(fieldValue) }} />
                )}
                <i class="el-icon-arrow-down condition-filter__tag-arrow" style={{ color: '#999', fontSize: '12px', marginLeft: '4px' }} />
              </div>
              {this.renderPopoverContent(h, fieldValue)}
            </el-popover>
          )
        })}

        {/* 三点按钮 — 添加更多筛选字段 */}
        <el-popover
          placement="bottom"
          trigger="click"
          v-model={this.showConfig}
          popper-class="rule-filter-popper"
        >
          <div slot="reference" class="condition-filter__add-btn" style={{
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            width: '40px',
            height: '24px',
            borderRadius: '4px',
            background: '#EEF1F5',
            cursor: 'pointer',
            marginRight: '14px',
          }}>
            <span style={{ width: '4px', height: '4px', borderRadius: '50%', background: '#333', margin: '0 2px' }} />
            <span style={{ width: '4px', height: '4px', borderRadius: '50%', background: '#333', margin: '0 2px' }} />
            <span style={{ width: '4px', height: '4px', borderRadius: '50%', background: '#333', margin: '0 2px' }} />
          </div>
          <div class="condition-filter__add-menu" style={{ maxHeight: '240px', overflowY: 'auto' }}>
            {this.optionalFields
              .filter((f: FilterFieldOption) => !this.isFieldChecked(f.value))
              .map((field: FilterFieldOption) => (
                <div class="condition-filter__add-menu-item"
                  style={{
                    padding: '6px 14px',
                    fontSize: '12px',
                    color: '#333',
                    cursor: 'pointer',
                    whiteSpace: 'nowrap',
                  }}
                  on-click={() => this.toggleField(field.value)}
                >
                  {field.label}
                </div>
              ))}
            {this.optionalFields.filter((f: FilterFieldOption) => !this.isFieldChecked(f.value)).length === 0 && (
              <div style={{ padding: '6px 14px', fontSize: '12px', color: '#999' }}>已全部添加</div>
            )}
          </div>
        </el-popover>
      </div>
    )
  }
}
