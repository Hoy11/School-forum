import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class ConfirmDialog extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: '确认' }) title!: string
  @Prop({ default: '确定要执行此操作吗？' }) message!: string
  @Prop({ default: false }) loading!: boolean

  render(h: any) {
    return (
      <el-dialog
        title={this.title}
        visible={this.visible}
        width="400px"
        on-close={() => this.$emit('cancel')}
      >
        <p>{this.message}</p>
        <div slot="footer">
          <el-button on-click={() => this.$emit('cancel')}>取消</el-button>
          <el-button type="danger" loading={this.loading} on-click={() => this.$emit('confirm')}>
            确定
          </el-button>
        </div>
      </el-dialog>
    )
  }
}
