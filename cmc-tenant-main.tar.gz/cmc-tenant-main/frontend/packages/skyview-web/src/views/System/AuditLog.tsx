// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import { auditList } from '@/api/system'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'

@Component({ components: { Grid, ConditionFilter } })
export default class AuditLog extends Vue {
  filterConditions: Condition[] = []

  detailDialogVisible = false

  activeLog: any = null

  filterFields = [
    { label: '用户名', value: 'username', type: 'text', operators: [{ label: '等于', value: '=' }] },
    { label: '操作', value: 'action', type: 'text', operators: [
      { label: '包含', value: 'like' },
      { label: '不包含', value: 'not like' },
    ] },
    { label: '结果', value: 'result', type: 'choice', operators: [
      { label: '等于', value: '=' },
      { label: '不等于', value: '!=' },
    ], choices: [
      { label: '成功', value: 'success' },
      { label: '失败', value: 'failed' },
    ] },
  ]

  private truncateDetail(text: string, max = 80): string {
    if (!text) return ''
    return text.length > max ? text.slice(0, max) + '...' : text
  }

  private resultLabel(result: string): string {
    if (result === 'success') return '成功'
    if (result === 'failed') return '失败'
    return '未知'
  }

  private resultColor(result: string): string {
    if (result === 'success') return '#67c23a'
    if (result === 'failed') return '#f56c6c'
    return '#909399'
  }

  openDetail(row: any) {
    this.activeLog = row
    this.detailDialogVisible = true
  }

  columns: ColumnDef[] = [
    { key: 'username', title: '用户', width: 100 },
    { key: 'action', title: '操作', width: 100, render: (h: any, row: any) => row.action || '—' },
    { key: 'request_url', title: '请求路径', width: 180, render: (h: any, row: any) => row.request_url || '—' },
    {
      key: 'result',
      title: '结果',
      width: 90,
      render: (h: any, row: any) => (
        <span style={{ color: this.resultColor(row.result), fontWeight: 500 }}>
          {this.resultLabel(row.result)}
        </span>
      ),
    },
    {
      key: 'detail',
      title: '请求体',
      minWidth: 280,
      render: (h: any, row: any) => {
        const text = row.detail || ''
        const short = this.truncateDetail(text)
        const showLink = text && text.length > 80
        const children = [h('span', short || '—')]
        if (showLink) {
          children.push(
            h('button', {
              attrs: { type: 'button' },
              class: 'audit-log-detail-link',
              style: {
                marginLeft: '8px',
                padding: '0',
                border: 'none',
                background: 'transparent',
                color: '#409eff',
                cursor: 'pointer',
              },
              domProps: {
                textContent: '查看',
                onclick: () => this.openDetail(row),
              },
            }),
          )
        }
        return h('span', children)
      },
    },
    { key: 'ip', title: 'IP', width: 130 },
    {
      key: 'created_at',
      title: '时间',
      width: 160,
      render: (h: any, row: any) => {
        if (!row.created_at) return '—'
        const d = new Date(row.created_at)
        if (Number.isNaN(d.getTime())) return row.created_at
        return d.toLocaleString()
      },
    },
  ]

  fetchData = (offset: number, count: number, conditions: Condition[]) => auditList(offset, count, conditions)

  handleFilterSearch(conditions: Condition[]) {
    this.filterConditions = conditions
  }

  render(h: any) {
    return (
      <div class="audit-log-page">
        <ConditionFilter
          conditions={this.filterConditions}
          fields={this.filterFields}
          on-change={(c: Condition[]) => {
            this.filterConditions = c
          }}
          on-search={this.handleFilterSearch}
        />
        <Grid
          columns={this.columns}
          fetchData={this.fetchData}
          defaultConditions={this.filterConditions}
        />
        <el-dialog
          title="请求体详情"
          visible={this.detailDialogVisible}
          width="60%"
          onClose={() => {
            this.detailDialogVisible = false
            this.activeLog = null
          }}
        >
          <div style="margin-bottom: 12px;">
            <div><strong>请求路径：</strong>{this.activeLog?.request_url || '—'}</div>
            <div><strong>摘要：</strong>{this.activeLog?.summary || '—'}</div>
            <div><strong>结果：</strong>{this.resultLabel(this.activeLog?.result)}</div>
            {this.activeLog?.error_message && <div><strong>失败原因：</strong>{this.activeLog.error_message}</div>}
          </div>
          <pre style="max-height: 60vh; overflow: auto; white-space: pre-wrap;">
            {this.activeLog?.detail || '（无请求体）'}
          </pre>
        </el-dialog>
      </div>
    )
  }
}
