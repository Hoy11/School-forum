// @ts-nocheck
// 合并原 SocConfig 和 CaptainConfig：上方只读纵横配置，下方可编辑 SOC 配置
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { captainConfigGet, socList, socCreate, socUpdate, socDelete, socTest } from '@/api/system'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { SocConfig } from '@/types/soc'

@Component({ components: { Grid } })
export default class IntegrationConfig extends Vue {
  // 纵横配置
  captainHost = ''
  captainApiToken = ''
  captainSource = ''
  captainLoading = false

  // SOC 配置
  showForm = false
  editingItem: SocConfig | null = null
  form = { name: '', brokers: '', topic: '', username: '', password: '', sasl_mechanism: 'PLAIN', is_enabled: true }

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'name', title: '名称' },
    { key: 'brokers', title: 'Kafka Brokers', render: (h: any, row: SocConfig) => row.brokers || row.endpoint || '—' },
    { key: 'topic', title: 'Topic', render: (h: any, row: SocConfig) => row.topic || row.api_key || '—' },
    { key: 'is_enabled', title: '状态', render: (h: any, row: SocConfig) => row.is_enabled ? '启用' : '禁用' },
  ]

  fetchData = (offset: number, count: number, conditions: Condition[]) => socList(offset, count, conditions)

  async created() {
    this.captainLoading = true
    try {
      const resp = await captainConfigGet()
      if (resp.err === null) {
        this.captainHost = resp.data.host || ''
        this.captainApiToken = resp.data.api_token || ''
        this.captainSource = resp.data.source || ''
      }
    } finally {
      this.captainLoading = false
    }
  }

  handleEdit(row: SocConfig) {
    this.editingItem = row
    this.form = {
      name: row.name,
      brokers: row.brokers || row.endpoint || '',
      topic: row.topic || row.api_key || '',
      username: row.username || '',
      password: '',
      sasl_mechanism: row.sasl_mechanism || 'PLAIN',
      is_enabled: row.is_enabled
    }
    this.showForm = true
  }

  async handleSubmit() {
    if (!this.form.name || !this.form.brokers || !this.form.topic) {
      this.$message.error('名称、Brokers、Topic 必填')
      return
    }
    try {
      if (this.editingItem) {
        const resp = await socUpdate({ id: this.editingItem.id, ...this.form })
        if (resp.err !== null) throw new Error(resp.msg || '更新失败')
        this.$message.success('SOC Kafka 配置已更新')
      } else {
        const resp = await socCreate(this.form)
        if (resp.err !== null) throw new Error(resp.msg || '创建失败')
        this.$message.success('SOC Kafka 配置已创建')
      }
      this.showForm = false;
      (this.$refs.grid as any).loadData()
    } catch (e) {
      this.$message.error(e?.message || '保存失败')
    }
  }

  async handleTest(row: SocConfig) {
    const resp = await socTest(row.id)
    if (resp.err !== null) {
      this.$message.error(resp.msg || 'Kafka 连通性测试失败')
      return
    }
    this.$message.success('Kafka 连通性测试成功')
  }

  async handleDelete(row: SocConfig) {
    await this.$confirm('确定删除？', '提示', { type: 'warning' })
    const resp = await socDelete(row.id)
    if (resp.err !== null) {
      this.$message.error(resp.msg || '删除失败')
      return
    }
    (this.$refs.grid as any).loadData()
  }

  render(h: any) {
    return (
      <div>
        {/* 纵横配置 - 只读 */}
        <el-card>
          <div slot="header">纵横配置</div>
          <div v-loading={this.captainLoading}>
            <el-alert type="info" description="纵横地址与 Token 通过配置文件或环境变量 CAPTAIN_HOST / CAPTAIN_API_TOKEN 管理" show-icon closable={false} style="margin-bottom: 16px" />
            <el-form label-width="120px" style="max-width: 600px">
              <el-form-item label="配置来源">
                <el-tag size="small">{this.captainSource === 'config' ? '配置文件/环境变量' : '数据库'}</el-tag>
              </el-form-item>
              <el-form-item label="纵横地址">
                <span style="line-height: 40px">{this.captainHost}</span>
              </el-form-item>
              <el-form-item label="API Token">
                <span style="line-height: 40px">{this.captainApiToken}</span>
              </el-form-item>
            </el-form>
          </div>
        </el-card>

        {/* SOC 配置 - 可编辑 */}
        <el-card style="margin-top: 20px">
          <div slot="header">SOC Kafka 配置</div>
          <el-button type="primary" style="margin-bottom: 16px" on-click={() => { this.editingItem = null; this.form = { name: '', brokers: '', topic: '', username: '', password: '', sasl_mechanism: 'PLAIN', is_enabled: true }; this.showForm = true }}>新建 SOC</el-button>
          <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 250, render: (h: any, row: SocConfig) => (
            <span>
              <el-button type="text" on-click={() => this.handleEdit(row)}>编辑</el-button>
              <el-button type="text" on-click={() => this.handleTest(row)}>测试</el-button>
              <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>删除</el-button>
            </span>
          )}]} fetchData={this.fetchData} />
        </el-card>

        <el-dialog title={this.editingItem ? '编辑 SOC Kafka' : '新建 SOC Kafka'} visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="120px">
            <el-form-item label="名称"><el-input v-model={this.form.name} /></el-form-item>
            <el-form-item label="Brokers"><el-input v-model={this.form.brokers} placeholder="多个地址用英文逗号分隔，如 10.0.0.1:9092,10.0.0.2:9092" /></el-form-item>
            <el-form-item label="Topic"><el-input v-model={this.form.topic} /></el-form-item>
            <el-form-item label="用户名"><el-input v-model={this.form.username} /></el-form-item>
            <el-form-item label="密码"><el-input v-model={this.form.password} type="password" /></el-form-item>
            <el-form-item label="启用"><el-switch v-model={this.form.is_enabled} /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
