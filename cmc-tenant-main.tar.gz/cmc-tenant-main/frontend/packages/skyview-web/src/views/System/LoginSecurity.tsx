// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { loginSecurityGet, loginSecurityUpdate } from '@/api/system'
import { LoginSecurityConfig } from '@/types/system'

@Component
export default class LoginSecurity extends Vue {
  form: LoginSecurityConfig = { max_retry: 5, lock_minutes: 30, retry_window: 300, single_sign_on: false }
  loading = false
  saving = false

  async created() {
    this.loading = true
    try {
      const resp = await loginSecurityGet()
      if (resp.err === null) this.form = resp.data
    } finally {
      this.loading = false
    }
  }

  async handleSave() {
    this.saving = true
    try {
      const resp = await loginSecurityUpdate(this.form)
      if (resp.err !== null) {
        this.$message.error(resp.msg || '保存失败')
        return
      }
      this.$message.success('保存成功')
    } finally {
      this.saving = false
    }
  }

  render(h: any) {
    return (
      <div v-loading={this.loading}>
        <h3>登录安全</h3>
        <el-form label-width="140px" style="max-width: 600px">
          <el-form-item label="最大重试次数"><el-input-number v-model={this.form.max_retry} min={1} /></el-form-item>
          <el-form-item label="锁定时间(分钟)"><el-input-number v-model={this.form.lock_minutes} min={1} /></el-form-item>
          <el-form-item label="重试窗口(秒)"><el-input-number v-model={this.form.retry_window} min={60} /></el-form-item>
          <el-form-item label="单点登录"><el-switch v-model={this.form.single_sign_on} /></el-form-item>
          <el-form-item><el-button type="primary" loading={this.saving} on-click={this.handleSave}>保存</el-button></el-form-item>
        </el-form>
      </div>
    )
  }
}
