// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { highlightIPList, highlightIPCreate, highlightIPUpdate, highlightIPDelete } from '@/api/highlight-ip'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { HighlightIP } from '@/types/highlight-ip'
import { isAdmin } from '@/permission'

@Component({ components: { Grid } })
export default class HighlightIp extends Vue {
  showForm = false
  editingItem: HighlightIP | null = null
  form = { ip: '', color: '#FF0000', comment: '' }

  get readOnly(): boolean { return !isAdmin() }

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'ip', title: 'IP/CIDR' },
    { key: 'color', title: '颜色', width: 100, render: (h: any, row: HighlightIP) => (
      <span style={`display:inline-block;width:20px;height:20px;background-color:${row.color};border-radius:4px;vertical-align:middle;border:1px solid #ddd`} />
    )},
    { key: 'comment', title: '备注' },
  ]

  fetchData(offset: number, count: number, conditions: Condition[]) {
    return highlightIPList(offset, count, conditions)
  }

  toHex(val: string): string {
    if (!val) return '#FF0000'
    if (val.startsWith('#')) return val
    const m = val.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/)
    if (m) {
      const r = parseInt(m[1]).toString(16).padStart(2, '0')
      const g = parseInt(m[2]).toString(16).padStart(2, '0')
      const b = parseInt(m[3]).toString(16).padStart(2, '0')
      return `#${r}${g}${b}`
    }
    return val
  }

  handleColorChange(val: string) {
    const color = this.toHex(val)
    this.form = { ...this.form, color }
  }

  async handleSubmit() {
    try {
      let resp
      if (this.editingItem) {
        resp = await highlightIPUpdate({ id: this.editingItem.id, ip: this.form.ip, color: this.form.color, comment: this.form.comment })
      } else {
        resp = await highlightIPCreate({ ip: this.form.ip, color: this.form.color, comment: this.form.comment })
      }
      if (resp.err !== null) {
        this.$message.error(resp.msg || '操作失败')
        return
      }
      this.showForm = false;
      (this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    }
  }

  async handleDelete(row: HighlightIP) {
    await this.$confirm('确定删除？', '提示', { type: 'warning' })
    await highlightIPDelete({ ids: [row.id] });
    (this.$refs.grid as any).loadData()
  }

  render(h: any) {
    return (
      <div>
        {!this.readOnly && <el-button type="primary" style="margin-bottom: 16px" on-click={() => { this.editingItem = null; this.form = { ip: '', color: '#FF0000', comment: '' }; this.showForm = true }}>新建高亮 IP</el-button>}
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 150, render: (h: any, row: HighlightIP) => (
          this.readOnly ? <span>-</span> :
          <span>
            <el-button type="text" on-click={() => { this.editingItem = row; this.form = { ip: row.ip, color: row.color || '#FF0000', comment: row.comment }; this.showForm = true }}>编辑</el-button>
            <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>删除</el-button>
          </span>
        )}]} fetchData={this.fetchData} />
        <el-dialog title={this.editingItem ? '编辑高亮 IP' : '新建高亮 IP'} visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="80px">
            <el-form-item label="IP/CIDR"><el-input v-model={this.form.ip} placeholder="如: 192.168.1.0/24" /></el-form-item>
            <el-form-item label="颜色"><el-color-picker value={this.form.color} on-active-change={this.handleColorChange} on-change={this.handleColorChange} size="small" /></el-form-item>
            <el-form-item label="备注"><el-input v-model={this.form.comment} /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
