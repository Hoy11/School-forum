// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { passwordConfigGet, passwordConfigUpdate } from '@/api/system'
import { PasswordConfig } from '@/types/system'

@Component
export default class PasswordConfigView extends Vue {
  form: PasswordConfig = { min_length: 8, has_upper: false, has_lower: false, has_num: false, has_symbol: false, is_forced: false, update_days: 90 }
  loading = false
  saving = false

  async created() {
    this.loading = true
    try {
      const resp = await passwordConfigGet()
      if (resp.err === null) this.form = resp.data
    } finally {
      this.loading = false
    }
  }

  async handleSave() {
    this.saving = true
    try {
      const resp = await passwordConfigUpdate(this.form)
      if (resp.err !== null) {
        this.$message.error(resp.msg || '保存失败')
        return
      }
      this.$message.success('保存成功')
    } finally {
      this.saving = false
    }
  }

  render(h: any) {
    return (
      <div v-loading={this.loading}>
        <h3>密码策略</h3>
        <el-form label-width="120px" style="max-width: 600px">
          <el-form-item label="最小长度"><el-input-number v-model={this.form.min_length} min={6} max={32} /></el-form-item>
          <el-form-item label="需要大写"><el-switch v-model={this.form.has_upper} /></el-form-item>
          <el-form-item label="需要小写"><el-switch v-model={this.form.has_lower} /></el-form-item>
          <el-form-item label="需要数字"><el-switch v-model={this.form.has_num} /></el-form-item>
          <el-form-item label="需要符号"><el-switch v-model={this.form.has_symbol} /></el-form-item>
          <el-form-item label="强制更新"><el-switch v-model={this.form.is_forced} /></el-form-item>
          <el-form-item label="更新周期(天)"><el-input-number v-model={this.form.update_days} min={1} /></el-form-item>
          <el-form-item><el-button type="primary" loading={this.saving} on-click={this.handleSave}>保存</el-button></el-form-item>
        </el-form>
      </div>
    )
  }
}
