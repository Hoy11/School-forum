// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { siteBindingList, siteBindingCreate, siteBindingDelete, siteBindingAvailable, wafBindingList, siteBindingResync } from '@/api/binding'
import { tenantGroupList } from '@/api/tenant-group'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { SiteBindingWithInfo, WafBindingWithInfo, AvailableSite, TenantGroup } from '@/types/tenant'

@Component({ components: { Grid } })
export default class SiteBinding extends Vue {
  showForm = false
  statusFilter: 'all' | 'active' | 'invalid' = 'all'
  availableWafs: WafBindingWithInfo[] = []
  availableSites: AvailableSite[] = []
  tenantGroups: TenantGroup[] = []
  form = { tenant_group_id: undefined as number | undefined, captain_instance_id: undefined as number | undefined, site_ids: [] as number[] }

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'tenant_group_name', title: '租户组' },
    { key: 'instance_name', title: 'WAF 名称', minWidth: 160, render: (h: any, row: SiteBindingWithInfo) => row.instance_name || '-' },
    { key: 'site_name', title: '站点名称', minWidth: 220, render: (h: any, row: SiteBindingWithInfo) => this.renderSiteName(h, row) },
    { key: 'status', title: '状态', width: 110, render: (h: any, row: SiteBindingWithInfo) => this.renderStatusTag(h, row) },
  ]

  isInvalidSite(row: SiteBindingWithInfo) {
    return row.status === 'invalid'
  }

  isUnknownSite(row: SiteBindingWithInfo) {
    return row.status === 'unknown'
  }

  filterRows(rows: SiteBindingWithInfo[]) {
    if (this.statusFilter === 'all') return rows
    return rows.filter(row => this.statusFilter === 'invalid' ? this.isInvalidSite(row) : row.status === 'active')
  }

  async fetchData(offset: number, count: number, conditions: Condition[]) {
    if (this.statusFilter === 'all') return siteBindingList(offset, count, conditions)
    const resp = await siteBindingList(0, 10000, conditions)
    if (resp.err === null) {
      const items = this.filterRows(resp.data.items)
      resp.data = { total: items.length, items: items.slice(offset, offset + count) }
    }
    return resp
  }

  renderSiteName(h: any, row: SiteBindingWithInfo) {
    if (this.isUnknownSite(row)) {
      return (
        <span>
          <span style="color:#909399">暂时无法确认站点状态</span>
          <span style="color:#C0C4CC;margin-left:6px">ID: {row.site_id}</span>
        </span>
      )
    }
    if (!this.isInvalidSite(row)) return row.site_name || '-'
    return (
      <span>
        <span style="color:#909399">站点不存在或已删除</span>
        <span style="color:#C0C4CC;margin-left:6px">ID: {row.site_id}</span>
      </span>
    )
  }

  renderStatusTag(h: any, row: SiteBindingWithInfo) {
    if (this.isInvalidSite(row)) {
      return (
        <el-tooltip content="纵横中不存在该站点，可能已被删除或重新添加" placement="top">
          <el-tag type="danger" size="mini">已失效</el-tag>
        </el-tooltip>
      )
    }
    if (this.isUnknownSite(row)) {
      return (
        <el-tooltip content="暂时无法从纵横确认该站点状态，请稍后重试" placement="top">
          <el-tag type="warning" size="mini">状态未知</el-tag>
        </el-tooltip>
      )
    }
    return <el-tag type="success" size="mini">有效</el-tag>
  }

  handleStatusFilterChange() {
    const grid = this.$refs.grid as any
    if (!grid) return
    grid.currentPage = 1
    grid.loadData()
  }

  setStatusFilter(status: 'all' | 'active' | 'invalid') {
    if (this.statusFilter === status) return
    this.statusFilter = status
    this.$nextTick(() => this.handleStatusFilterChange())
  }

  renderFilterButton(h: any, status: 'all' | 'active' | 'invalid', label: string) {
    const active = this.statusFilter === status
    return h('button', {
      attrs: { type: 'button' },
      class: `el-button el-button--small${active ? ' el-button--primary' : ''}`,
      on: { click: () => this.setStatusFilter(status) },
    }, [h('span', [label])])
  }

  async handleCreate() {
    this.form = { tenant_group_id: undefined, captain_instance_id: undefined, site_ids: [] }
    this.availableSites = []
    const resp = await tenantGroupList(0, 1000)
    if (resp.err === null) this.tenantGroups = resp.data.items
    this.showForm = true
  }

  async handleTenantGroupChange(groupId: number) {
    this.form.captain_instance_id = undefined
    this.form.site_ids = []
    this.availableSites = []
    this.availableWafs = []
    if (!groupId) return
    const resp = await wafBindingList(0, 1000, [{ target: 'tenant_group_id', items: [{ oper: '=', value: groupId }] }])
    if (resp.err === null) this.availableWafs = resp.data.items.filter(
      (w, i, arr) => arr.findIndex(x => x.captain_instance_id === w.captain_instance_id) === i
    )
  }

  async handleWafChange(wafId: number) {
    this.form.site_ids = []
    this.availableSites = []
    if (!this.form.tenant_group_id || !wafId) return
    const resp = await siteBindingAvailable(this.form.tenant_group_id, wafId)
    if (resp.err === null) this.availableSites = resp.data
  }

  async handleDelete(row: SiteBindingWithInfo) {
    const message = this.isInvalidSite(row)
      ? '该绑定对应的纵横站点已不存在，解绑只会清理 CMC 本地绑定关系，不会影响纵横。'
      : this.isUnknownSite(row)
        ? '暂时无法确认该站点在纵横上的状态，解绑只会清理 CMC 本地绑定关系，不会删除纵横上的站点。'
        : '确定解绑该站点？解绑只会清理 CMC 本地绑定关系，不会删除纵横上的站点。'
    await this.$confirm(message, '提示', { type: 'warning' })
    await siteBindingDelete(row.id);
    (this.$refs.grid as any).loadData()
  }

  async handleResync(row: SiteBindingWithInfo) {
    await this.$confirm('确定同步该站点关联的资源？', '提示', { type: 'info' })
    try {
      const resp = await siteBindingResync(row.id)
      if (resp.err !== null) {
        this.$message.error(resp.msg || '同步失败')
        return
      }
      this.$message.success(`同步完成，已同步 ${resp.data && resp.data.synced ? resp.data.synced : 0} 个站点`)
    } catch (e: any) {
      this.$message.error((e && e.message) || '同步失败')
    }
  }

  async handleSubmit() {
    await siteBindingCreate({ tenant_group_id: this.form.tenant_group_id!, captain_instance_id: this.form.captain_instance_id!, site_ids: this.form.site_ids })
    this.showForm = false;
    (this.$refs.grid as any).loadData()
  }

  render(h: any) {
    return (
      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
          <el-button type="primary" on-click={this.handleCreate}>绑定站点</el-button>
          <div class="el-button-group">
            {this.renderFilterButton(h, 'all', '全部')}
            {this.renderFilterButton(h, 'active', '有效')}
            {this.renderFilterButton(h, 'invalid', '已失效')}
          </div>
        </div>
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 140, render: (h: any, row: SiteBindingWithInfo) => (
          <span>
            <el-button type="text" disabled={this.isInvalidSite(row)} on-click={() => this.handleResync(row)}>同步</el-button>
            <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>{this.isInvalidSite(row) ? '清理绑定' : '解绑'}</el-button>
          </span>
        )}]} fetchData={(offset: number, count: number, conditions: Condition[]) => this.fetchData(offset, count, conditions)} />
        <el-dialog title="绑定站点" visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="120px">
            <el-form-item label="租户组">
              <el-select v-model={this.form.tenant_group_id} placeholder="选择租户组" on-change={this.handleTenantGroupChange}>
                {this.tenantGroups.map(g => <el-option label={g.name} value={g.id} />)}
              </el-select>
            </el-form-item>
            <el-form-item label="WAF 实例">
              <el-select v-model={this.form.captain_instance_id} placeholder="选择 WAF" disabled={!this.form.tenant_group_id} on-change={this.handleWafChange}>
                {this.availableWafs.map(w => <el-option label={`${w.instance_name} (${w.instance_host})`} value={w.captain_instance_id} />)}
              </el-select>
            </el-form-item>
            <el-form-item label="站点">
              <el-select v-model={this.form.site_ids} multiple placeholder="选择站点" disabled={!this.form.captain_instance_id} style="width: 100%">
                {this.availableSites.map(s => <el-option label={`${s.site_name} (${s.server_names ? s.server_names.join(', ') : ''})`} value={s.site_id} />)}
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleSubmit} disabled={!this.form.tenant_group_id || !this.form.captain_instance_id || this.form.site_ids.length === 0}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
