// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import { userList, userCreate, userUpdate, userEnable, userDisable, userCredential, userUnlock, userDelete } from '@/api/user'
import { tenantGroupList } from '@/api/tenant-group'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { User, Role } from '@/types/users'
import { TenantGroup } from '@/types/tenant'

@Component({ components: { Grid, ConditionFilter } })
export default class UserList extends Vue {
  showForm = false
  editingItem: User | null = null
  form = { username: '', password: '', role: 'tenant' as Role, tenant_group_id: undefined as number | undefined, remark: '' }
  tenantGroups: TenantGroup[] = []
  filterConditions: Condition[] = []

  filterFields = [
    { label: '用户名', value: 'username', type: 'text', operators: [{ label: '等于', value: '=' }] },
    { label: '角色', value: 'role', type: 'choice', operators: [
      { label: '等于', value: '=' },
      { label: '不等于', value: '!=' },
    ], choices: [
      { label: '管理员', value: 'admin' },
      { label: '租户管理员', value: 'tenant_admin' },
      { label: '租户用户', value: 'tenant' },
    ] },
    { label: '启用状态', value: 'is_enabled', type: 'choice', operators: [
      { label: '等于', value: '=' },
      { label: '不等于', value: '!=' },
    ], choices: [
      { label: '启用', value: 'true' },
      { label: '禁用', value: 'false' },
    ] },
  ]

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'username', title: '用户名' },
    { key: 'role', title: '角色' },
    { key: 'tenant_group_name', title: '租户组' },
    { key: 'is_enabled', title: '状态', render: (h: any, row: User) => row.is_enabled ? '启用' : '禁用' },
  ]

  fetchData = (offset: number, count: number, conditions: Condition[]) => userList(offset, count, conditions)

  async handleCreate() {
    this.editingItem = null
    this.form = { username: '', password: '', role: 'tenant', tenant_group_id: undefined, remark: '' }
    const resp = await tenantGroupList(0, 1000)
    if (resp.err === null) this.tenantGroups = resp.data.items
    this.showForm = true
  }

  handleRoleChange(role: Role) {
    if (role === 'admin') this.form.tenant_group_id = undefined
  }

  async handleEdit(row: User) {
    this.editingItem = row
    this.form = { username: row.username, password: '', role: row.role, tenant_group_id: row.tenant_group_id ?? undefined, remark: row.remark }
    const resp = await tenantGroupList(0, 1000)
    if (resp.err === null) this.tenantGroups = resp.data.items
    this.showForm = true
  }

  async handleSubmit() {
    if (this.form.role !== 'admin' && !this.form.tenant_group_id) {
      this.$message.warning('请选择租户组')
      return
    }
    if (this.editingItem) {
      await userUpdate({ id: this.editingItem.id, role: this.form.role, tenant_group_id: this.form.tenant_group_id, remark: this.form.remark })
    } else {
      await userCreate(this.form)
    }
    this.showForm = false;
    (this.$refs.grid as any).loadData()
  }

  async handleToggle(row: User) {
    row.is_enabled ? await userDisable(row.id) : await userEnable(row.id);
    (this.$refs.grid as any).loadData()
  }

  async handleCredential(row: User) {
    const resp = await userCredential(row.id)
    if (resp.err === null) {
      this.$alert(`新密码: ${resp.data.password}`, '凭据', { type: 'info' })
    }
  }

  async handleUnlock(row: User) {
    await userUnlock(row.id)
    this.$message.success('已解锁')
  }

  async handleDelete(row: User) {
    await this.$confirm('确定删除？', '提示', { type: 'warning' })
    await userDelete(row.id);
    (this.$refs.grid as any).loadData()
  }

  handleFilterSearch(conditions: Condition[]) {
    this.filterConditions = conditions
  }

  render(h: any) {
    return (
      <div>
        <ConditionFilter conditions={this.filterConditions} fields={this.filterFields} on-change={(c: Condition[]) => { this.filterConditions = c }} on-search={this.handleFilterSearch} />
        <el-button type="primary" style="margin-bottom: 16px" on-click={this.handleCreate}>新建用户</el-button>
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 250, render: (h: any, row: User) => (
          <span>
            <el-button type="text" on-click={() => this.handleEdit(row)}>编辑</el-button>
            <el-button type="text" on-click={() => this.handleToggle(row)}>{row.is_enabled ? '禁用' : '启用'}</el-button>
            <el-button type="text" on-click={() => this.handleCredential(row)}>重置密码</el-button>
            <el-button type="text" on-click={() => this.handleUnlock(row)}>解锁</el-button>
            <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>删除</el-button>
          </span>
        )}]} fetchData={this.fetchData} defaultConditions={this.filterConditions} />
        <el-dialog title={this.editingItem ? '编辑用户' : '新建用户'} visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="100px">
            {!this.editingItem && <el-form-item label="用户名"><el-input v-model={this.form.username} /></el-form-item>}
            {!this.editingItem && <el-form-item label="密码"><el-input v-model={this.form.password} type="password" /></el-form-item>}
            <el-form-item label="角色">
              <el-select v-model={this.form.role} on-change={this.handleRoleChange} disabled={!!this.editingItem?.role_locked}>
                <el-option label="管理员" value="admin" />
                <el-option label="租户管理员" value="tenant_admin" />
                <el-option label="普通租户" value="tenant" />
              </el-select>
              {this.editingItem?.role_locked && <span style="color:#999;font-size:12px;margin-left:8px">角色已锁定，不可修改</span>}
            </el-form-item>
            {this.form.role !== 'admin' && <el-form-item label="租户组">
              <el-select v-model={this.form.tenant_group_id} placeholder="选择租户组">
                {this.tenantGroups.map(g => <el-option label={g.name} value={g.id} />)}
              </el-select>
            </el-form-item>}
            <el-form-item label="备注"><el-input v-model={this.form.remark} /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
