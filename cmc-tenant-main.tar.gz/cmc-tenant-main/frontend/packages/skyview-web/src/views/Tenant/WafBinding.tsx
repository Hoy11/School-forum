// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { wafBindingList, wafBindingCreate, wafBindingDelete, wafBindingAvailable } from '@/api/binding'
import { tenantGroupList } from '@/api/tenant-group'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { WafBindingWithInfo, AvailableWaf, TenantGroup } from '@/types/tenant'

@Component({ components: { Grid } })
export default class WafBinding extends Vue {
  showForm = false
  statusFilter: 'all' | 'active' | 'invalid' = 'all'
  availableWafs: AvailableWaf[] = []
  tenantGroups: TenantGroup[] = []
  form = { tenant_group_id: undefined as number | undefined, captain_instance_ids: [] as number[] }

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'tenant_group_name', title: '租户组' },
    { key: 'instance_name', title: 'WAF 名称', minWidth: 180, render: (h: any, row: WafBindingWithInfo) => this.renderWafName(h, row) },
    { key: 'instance_host', title: '地址', minWidth: 160, render: (h: any, row: WafBindingWithInfo) => row.instance_host || '-' },
    { key: 'instance_status', title: '状态', width: 110, render: (h: any, row: WafBindingWithInfo) => this.renderStatusTag(h, row) },
  ]

  isInvalidWaf(row: WafBindingWithInfo) {
    return row.status === 'invalid'
  }

  isUnknownWaf(row: WafBindingWithInfo) {
    return row.status === 'unknown' || (!row.status && !row.instance_name && !row.instance_host && !row.operation_mode && !row.version)
  }

  filterRows(rows: WafBindingWithInfo[]) {
    if (this.statusFilter === 'all') return rows
    return rows.filter(row => this.statusFilter === 'invalid' ? this.isInvalidWaf(row) : row.status === 'active')
  }

  async fetchData(offset: number, count: number, conditions: Condition[]) {
    if (this.statusFilter === 'all') return wafBindingList(offset, count, conditions)
    const resp = await wafBindingList(0, 10000, conditions)
    if (resp.err === null) {
      const items = this.filterRows(resp.data.items)
      resp.data = { total: items.length, items: items.slice(offset, offset + count) }
    }
    return resp
  }

  renderWafName(h: any, row: WafBindingWithInfo) {
    if (this.isUnknownWaf(row)) {
      return (
        <span>
          <span style="color:#909399">暂时无法确认 WAF 状态</span>
          <span style="color:#C0C4CC;margin-left:6px">ID: {row.captain_instance_id}</span>
        </span>
      )
    }
    if (!this.isInvalidWaf(row)) return row.instance_name || '-'
    return (
      <span>
        <span style="color:#909399">纵横中不存在该 WAF</span>
        <span style="color:#C0C4CC;margin-left:6px">ID: {row.captain_instance_id}</span>
      </span>
    )
  }

  renderStatusTag(h: any, row: WafBindingWithInfo) {
    if (this.isInvalidWaf(row)) {
      return (
        <el-tooltip content="纵横中不存在该 WAF，可能已被删除或重新添加" placement="top">
          <el-tag type="danger" size="mini">已失效</el-tag>
        </el-tooltip>
      )
    }
    if (this.isUnknownWaf(row)) {
      return (
        <el-tooltip content="暂时无法从纵横确认该 WAF 状态，请稍后重试" placement="top">
          <el-tag type="warning" size="mini">状态未知</el-tag>
        </el-tooltip>
      )
    }
    const status = row.instance_status || 'UNKNOWN'
    const type = status === 'ONLINE' ? 'success' : status === 'OFFLINE' ? 'info' : 'warning'
    return <el-tag type={type} size="mini">{status}</el-tag>
  }

  handleStatusFilterChange() {
    const grid = this.$refs.grid as any
    if (!grid) return
    grid.currentPage = 1
    grid.loadData()
  }

  setStatusFilter(status: 'all' | 'active' | 'invalid') {
    if (this.statusFilter === status) return
    this.statusFilter = status
    this.$nextTick(() => this.handleStatusFilterChange())
  }

  renderFilterButton(h: any, status: 'all' | 'active' | 'invalid', label: string) {
    const active = this.statusFilter === status
    return h('button', {
      attrs: { type: 'button' },
      class: `el-button el-button--small${active ? ' el-button--primary' : ''}`,
      on: { click: () => this.setStatusFilter(status) },
    }, [h('span', [label])])
  }

  async handleCreate() {
    this.form = { tenant_group_id: undefined, captain_instance_ids: [] }
    this.availableWafs = []
    const resp = await tenantGroupList(0, 1000)
    if (resp.err === null) this.tenantGroups = resp.data.items
    this.showForm = true
  }

  async handleTenantGroupChange(groupId: number) {
    this.form.captain_instance_ids = []
    this.availableWafs = []
    if (!groupId) return
    const resp = await wafBindingAvailable(groupId)
    if (resp.err === null) this.availableWafs = resp.data
  }

  async handleDelete(row: WafBindingWithInfo) {
    const message = this.isInvalidWaf(row)
      ? '该绑定对应的纵横 WAF 已不存在，解绑只会清理 CMC 本地绑定关系，不会影响纵横。'
      : this.isUnknownWaf(row)
        ? '暂时无法确认该 WAF 在纵横上的状态，解绑只会清理 CMC 本地绑定关系，不会删除纵横上的 WAF。'
        : '确定解绑该 WAF？解绑只会清理 CMC 本地绑定关系，不会删除纵横上的 WAF。'
    await this.$confirm(message, '提示', { type: 'warning' })
    try {
      await wafBindingDelete(row.id)
      ;(this.$refs.grid as any).loadData()
    } catch (e) {
      this.$alert(e.message || '解绑失败', '无法解绑', { type: 'warning' })
    }
  }

  async handleSubmit() {
    await wafBindingCreate({ tenant_group_id: this.form.tenant_group_id!, captain_instance_ids: this.form.captain_instance_ids })
    this.showForm = false;
    (this.$refs.grid as any).loadData()
  }

  render(h: any) {
    return (
      <div>
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
          <el-button type="primary" on-click={this.handleCreate}>绑定 WAF</el-button>
          <div class="el-button-group">
            {this.renderFilterButton(h, 'all', '全部')}
            {this.renderFilterButton(h, 'active', '有效')}
            {this.renderFilterButton(h, 'invalid', '已失效')}
          </div>
        </div>
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 100, render: (h: any, row: WafBindingWithInfo) => (
          <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>解绑</el-button>
        )}]} fetchData={(offset: number, count: number, conditions: Condition[]) => this.fetchData(offset, count, conditions)} />
        <el-dialog title="绑定 WAF" visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="120px">
            <el-form-item label="租户组">
              <el-select v-model={this.form.tenant_group_id} placeholder="选择租户组" on-change={this.handleTenantGroupChange}>
                {this.tenantGroups.map(g => <el-option label={g.name} value={g.id} />)}
              </el-select>
            </el-form-item>
            <el-form-item label="WAF 实例">
              <el-select v-model={this.form.captain_instance_ids} multiple placeholder="选择 WAF" disabled={!this.form.tenant_group_id} style="width: 100%">
                {this.availableWafs.map(w => <el-option label={`${w.instance_name} (${w.instance_host})`} value={w.captain_instance_id} />)}
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleSubmit} disabled={!this.form.tenant_group_id || this.form.captain_instance_ids.length === 0}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
