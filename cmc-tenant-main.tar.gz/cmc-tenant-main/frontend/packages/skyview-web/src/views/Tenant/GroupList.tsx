// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { tenantGroupList, tenantGroupCreate, tenantGroupUpdate, tenantGroupDelete } from '@/api/tenant-group'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { TenantGroup } from '@/types/tenant'

@Component({ components: { Grid } })
export default class GroupList extends Vue {
  showForm = false
  editingItem: TenantGroup | null = null
  form = { name: '', comment: '', admin_username: '', admin_password: '' }
  submitting = false

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'name', title: '名称' },
    { key: 'admin_username', title: '管理员' },
    { key: 'comment', title: '备注' },
    { key: 'created_at', title: '创建时间' },
  ]

  fetchData = (offset: number, count: number, conditions: Condition[]) => tenantGroupList(offset, count, conditions)

  handleCreate() {
    this.editingItem = null
    this.form = { name: '', comment: '', admin_username: '', admin_password: '' }
    this.showForm = true
  }

  handleEdit(row: TenantGroup) {
    this.editingItem = row
    this.form = { name: row.name, comment: row.comment, admin_username: '', admin_password: '' }
    this.showForm = true
  }

  async handleSubmit() {
    if (!this.form.name.trim()) {
      this.$message.warning('请输入租户组名称')
      return
    }
    if (!this.editingItem && !this.form.admin_username.trim()) {
      this.$message.warning('请输入管理员用户名')
      return
    }
    if (!this.editingItem && !this.form.admin_password) {
      this.$message.warning('请输入管理员密码')
      return
    }

    this.submitting = true
    try {
      if (this.editingItem) {
        await tenantGroupUpdate({ id: this.editingItem.id, name: this.form.name, comment: this.form.comment })
      } else {
        await tenantGroupCreate(this.form)
      }
      this.showForm = false;
      (this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.submitting = false
    }
  }

  async handleDelete(row: TenantGroup) {
    await this.$confirm('确定删除？', '提示', { type: 'warning' })
    try {
      await tenantGroupDelete(row.id);
      (this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '删除失败')
    }
  }

  render(h: any) {
    return (
      <div>
        <div style="margin-bottom: 16px">
          <el-button type="primary" on-click={this.handleCreate}>新建租户组</el-button>
        </div>
        <Grid ref="grid" columns={this.columns} fetchData={this.fetchData}
          columns={[...this.columns, { key: 'actions', title: '操作', width: 150, render: (h: any, row: TenantGroup) => (
            <span>
              <el-button type="text" on-click={() => this.handleEdit(row)}>编辑</el-button>
              <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>删除</el-button>
            </span>
          )}]}
        />
        <el-dialog title={this.editingItem ? '编辑租户组' : '新建租户组'} visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="100px">
            <el-form-item label="名称"><el-input v-model={this.form.name} /></el-form-item>
            <el-form-item label="备注"><el-input v-model={this.form.comment} type="textarea" /></el-form-item>
            {!this.editingItem && <div><el-form-item label="管理员用户名"><el-input v-model={this.form.admin_username} /></el-form-item>
            <el-form-item label="管理员密码"><el-input v-model={this.form.admin_password} type="password" /></el-form-item></div>}
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" loading={this.submitting} on-click={this.handleSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
