// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import { tenantUserList, tenantUserCreate, tenantUserEnable, tenantUserDisable, tenantUserCredential, tenantUserUnlock, tenantUserDelete } from '@/api/tenant-user'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { User } from '@/types/users'

@Component({ components: { Grid, ConditionFilter } })
export default class TenantUserList extends Vue {
  showForm = false
  form = { username: '', password: '', remark: '' }
  filterConditions: Condition[] = []

  filterFields = [
    { label: '用户名', value: 'username', type: 'text', operators: [{ label: '等于', value: '=' }] },
    { label: '启用状态', value: 'is_enabled', type: 'choice', operators: [
      { label: '等于', value: '=' },
      { label: '不等于', value: '!=' },
    ], choices: [
      { label: '启用', value: 'true' },
      { label: '禁用', value: 'false' },
    ] },
  ]

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'username', title: '用户名' },
    { key: 'is_enabled', title: '状态', render: (h: any, row: User) => row.is_enabled ? '启用' : '禁用' },
    { key: 'remark', title: '备注' },
  ]

  fetchData = (offset: number, count: number, conditions: Condition[]) => tenantUserList(offset, count, conditions)

  async handleSubmit() {
    await tenantUserCreate(this.form)
    this.showForm = false;
    (this.$refs.grid as any).loadData()
  }

  async handleDelete(row: User) {
    await this.$confirm('确定删除？', '提示', { type: 'warning' })
    await tenantUserDelete(row.id);
    (this.$refs.grid as any).loadData()
  }

  async handleUnlock(row: User) {
    await tenantUserUnlock(row.id)
    this.$message.success('已解锁')
  }

  handleFilterSearch(conditions: Condition[]) {
    this.filterConditions = conditions
  }

  render(h: any) {
    return (
      <div>
        <ConditionFilter conditions={this.filterConditions} fields={this.filterFields} on-change={(c: Condition[]) => { this.filterConditions = c }} on-search={this.handleFilterSearch} />
        <el-button type="primary" style="margin-bottom: 16px" on-click={() => { this.form = { username: '', password: '', remark: '' }; this.showForm = true }}>新建用户</el-button>
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 200, render: (h: any, row: User) => (
          <span>
            <el-button type="text" on-click={async () => { row.is_enabled ? await tenantUserDisable(row.id) : await tenantUserEnable(row.id); (this.$refs.grid as any).loadData() }}>{row.is_enabled ? '禁用' : '启用'}</el-button>
            <el-button type="text" on-click={async () => { const r = await tenantUserCredential(row.id); if (r.err === null) this.$alert(`新密码: ${r.data.password}`) }}>重置密码</el-button>
            <el-button type="text" on-click={() => this.handleUnlock(row)}>解锁</el-button>
            <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>删除</el-button>
          </span>
        )}]} fetchData={this.fetchData} defaultConditions={this.filterConditions} />
        <el-dialog title="新建组内用户" visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="80px">
            <el-form-item label="用户名"><el-input v-model={this.form.username} /></el-form-item>
            <el-form-item label="密码"><el-input v-model={this.form.password} type="password" /></el-form-item>
            <el-form-item label="备注"><el-input v-model={this.form.remark} /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
