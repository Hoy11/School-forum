// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { botResultDetail } from '@/api/log/bot'
import { BotLogDetail } from '@/types/bot'
import HttpContent from '@/components/HttpContent'

@Component({ components: { HttpContent } })
export default class BotResultDetailPage extends Vue {
  get logId(): string { return String(this.$route.query.id || '') }

  detail: BotLogDetail | null = null
  loading = false

  created() { this.loadData() }

  async loadData() {
    this.loading = true
    try {
      const resp = await botResultDetail(this.logId)
      if (resp.err === null) this.detail = resp.data
    } finally {
      this.loading = false
    }
  }

  render(h: any) {
    const rows: [string, any][] = this.detail ? [
      ['ID', this.detail.id],
      ['源 IP', this.detail.src_ip],
      ['目标 IP', this.detail.dest_ip],
      ['目标端口', this.detail.dest_port],
      ['站点名称', this.detail.website_name],
      ['Bot 配置', this.detail.bot_config_name],
      ['验证模式', this.detail.verify_mode?.translation],
      ['国家/省份', `${this.detail.country ?? ''} ${this.detail.province ?? ''}`.trim()],
      ['时间', this.detail.timestamp],
    ] : []
    return (
      <div v-loading={this.loading}>
        <el-page-header on-back={() => this.$router.back()} content="Bot 结果详情" />
        {this.detail && (
          <el-card style="margin-top: 16px">
            <div slot="header"><span>基本信息</span></div>
            <div style="display:grid;grid-template-columns:1fr 1fr;border:1px solid #EBEEF5">
              {rows.map(([label, value]) => (
                <div style="display:flex;border-bottom:1px solid #EBEEF5;padding:12px 16px;line-height:24px">
                  <div style="width:100px;flex-shrink:0;color:#909399;font-size:14px">{label}</div>
                  <div style="flex:1;font-size:14px">{value}</div>
                </div>
              ))}
            </div>
          </el-card>
        )}
      </div>
    )
  }
}
