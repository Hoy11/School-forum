// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { detectLogDetail } from '@/api/log'
import { socReport } from '@/api/soc'
import { DetectLogDetail } from '@/types/detect'
import { RouteName } from '@/router/names'
import { riskLevelToType } from '@/utils/detectLogHelper'
import HttpContent from '@/components/HttpContent'
import MutableFormItem from '@/components/MutableFormItem'
import { basicInfoFields, detectInfoFields, splitInHalf, DetailField } from './detailFields'

@Component({ components: { HttpContent, MutableFormItem } })
export default class DetectLogDetailPage extends Vue {
  get logId(): string { return String(this.$route.query.id || '') }

  detail: DetectLogDetail | null = null
  loading = false
  reporting = false

  created() { this.loadData() }

  async loadData() {
    this.loading = true
    try {
      const resp = await detectLogDetail(this.logId)
      if (resp.err === null) this.detail = resp.data
    } finally {
      this.loading = false
    }
  }

  async handleSocReport() {
    if (this.reporting) return
    this.reporting = true
    try {
      await socReport({ log_type: 'detect', log_id: this.logId })
      this.$message.success('SOC 上报成功')
    } catch (e: any) {
      const msg = e?.message || 'SOC 上报失败'
      if (msg.includes('无可用 SOC 配置')) {
        try {
          await this.$confirm('当前未配置可用 SOC，是否前往系统集成页面配置？', 'SOC 未配置', {
            confirmButtonText: '去配置',
            cancelButtonText: '取消',
            type: 'warning',
          })
          this.$router.push({ name: RouteName.integrationConfig })
        } catch { /* cancel */ }
        return
      }
      this.$message.error(msg)
    } finally {
      this.reporting = false
    }
  }

  getRawValue(field: DetailField): string {
    if (!this.detail) return '-'
    const value = field.getValue ? field.getValue(this.detail) : this.detail[field.key!]
    return value ?? '-'
  }

  render(h: any) {
    if (!this.detail) {
      return <div v-loading={this.loading}><el-page-header on-back={() => this.$router.back()} content="检测日志详情" /></div>
    }

    const [basicLeft, basicRight] = splitInHalf(basicInfoFields)
    const [detectLeft, detectRight] = splitInHalf(detectInfoFields)
    const hasReq = !!(this.detail.req_header || this.detail.req_body)
    const hasRsp = !!(this.detail.rsp_header || this.detail.resp_header || this.detail.rsp_body || this.detail.resp_body)

    const renderVal = (f: DetailField) => {
      if (f.key === 'risk_level' && this.detail!.risk_level_num) {
        return <el-tag type={riskLevelToType(this.detail!.risk_level_num)} size="mini" effect="dark">{this.getRawValue(f)}</el-tag>
      }
      return this.getRawValue(f)
    }

    return (
      <div v-loading={this.loading}>
        <el-page-header on-back={() => this.$router.back()} content="检测日志详情" />
        <div style="margin-top: 16px">
          <el-card>
            <div slot="header" style="display: flex; justify-content: space-between">
              <span>基本信息</span>
              <el-button type="primary" size="small" loading={this.reporting} on-click={this.handleSocReport}>SOC 上报</el-button>
            </div>
            <el-row gutter={16}>
              <el-col span={12}>
                {basicLeft.map(f => <MutableFormItem title={f.label} span={24}>{renderVal(f)}</MutableFormItem>)}
              </el-col>
              <el-col span={12}>
                {basicRight.map(f => <MutableFormItem title={f.label} span={24}>{renderVal(f)}</MutableFormItem>)}
              </el-col>
            </el-row>
          </el-card>

          <el-card style="margin-top: 16px">
            <div slot="header"><span>攻击检测信息</span></div>
            <el-row gutter={16}>
              <el-col span={12}>
                {detectLeft.map(f => <MutableFormItem title={f.label} span={24}>{renderVal(f)}</MutableFormItem>)}
              </el-col>
              <el-col span={12}>
                {detectRight.map(f => <MutableFormItem title={f.label} span={24}>{renderVal(f)}</MutableFormItem>)}
              </el-col>
            </el-row>
          </el-card>

          {(hasReq || hasRsp) && (
            <el-card style="margin-top: 16px">
              <div slot="header"><span>HTTP 内容</span></div>
              <el-row gutter={16}>
                {hasReq && (
                  <el-col span={hasRsp ? 12 : 24}>
                    <HttpContent content={this.detail.req_header} label="请求头" />
                    <div style="margin-top: 12px"><HttpContent content={this.detail.req_body} label="请求体" /></div>
                  </el-col>
                )}
                {hasRsp && (
                  <el-col span={hasReq ? 12 : 24}>
                    <HttpContent content={this.detail.rsp_header || this.detail.resp_header} label="响应头" />
                    <div style="margin-top: 12px"><HttpContent content={this.detail.rsp_body || this.detail.resp_body} label="响应体" /></div>
                  </el-col>
                )}
              </el-row>
            </el-card>
          )}
        </div>
      </div>
    )
  }
}
