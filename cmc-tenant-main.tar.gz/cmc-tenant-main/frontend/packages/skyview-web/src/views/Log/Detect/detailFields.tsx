import { DetectLogDetail } from '@/types/detect'
import { formatTimestamp, formatTimestampMs, formatMicroseconds, riskLevelToType, translateEffective, formatDecodePath, formatGeo, formatHostPort } from '@/utils/detectLogHelper'

export interface DetailField {
  key?: string
  label: string
  getValue?: (row: DetectLogDetail) => string
}

export const basicInfoFields: DetailField[] = [
  { key: 'website_name', label: '防护站点名称' },
  { key: 'website', label: 'URL 地址' },
  { key: 'event_id', label: 'Event ID' },
  { key: 'http_host_port', label: 'Host 端口', getValue: (r) => formatHostPort(r.http_host_port) },
  { key: 'src_ip', label: '源 IP' },
  { key: 'socket_ip', label: 'Socket IP' },
  { key: 'method', label: '请求方法' },
  { key: 'src_port', label: '源端口' },
  { key: 'req_start_time', label: '请求开始时间', getValue: (r) => formatTimestampMs(r.req_start_time) },
  { key: 'country', label: '地理位置', getValue: (r) => formatGeo(r.country, r.province) },
  { key: 'status_code', label: '响应码', getValue: (r) => String(r.status_code ?? '-') },
  { key: 'req_detect_time', label: '请求检测时长', getValue: (r) => formatMicroseconds(r.req_detect_time) },
  { key: 'rsp_start_time', label: '响应开始时间', getValue: (r) => formatTimestampMs(r.rsp_start_time) },
  { key: 'session', label: 'Session' },
  { key: 'dst_ip', label: '目的 IP' },
  { key: 'rsp_detect_time', label: '响应检测时长', getValue: (r) => formatMicroseconds(r.rsp_detect_time) },
  { key: 'dst_port', label: '目的端口' },
  { key: 'upstream_addr', label: '转发地址' },
  { key: 'x_forwarded_for', label: 'X-Forwarded-For' },
  { key: 'waf_name', label: '日志来源' },
]

export const detectInfoFields: DetailField[] = [
  { key: 'action', label: '执行动作', getValue: (r) => r.action?.translation || '-' },
  { key: 'reason', label: '原因', getValue: (r) => `${r.module || ''} ${r.reason || ''}`.trim() || '-' },
  { key: 'attack_type', label: '攻击类型' },
  { key: 'decode_path', label: '解码方式', getValue: (r) => formatDecodePath(r.decode_path) },
  { key: 'effective', label: '攻击有效性', getValue: (r) => translateEffective(r.effective) },
  { key: 'risk_level', label: '风险等级' },
  { key: 'location', label: '所处位置' },
  { key: 'http_body_is_abandoned', label: '大包绕过防护', getValue: (r) => r.http_body_is_abandoned ? '触发' : '-' },
  { key: 'waf_name', label: '日志来源' },
]

export function splitInHalf<T>(arr: T[]): [T[], T[]] {
  const mid = Math.ceil(arr.length / 2)
  return [arr.slice(0, mid), arr.slice(mid)]
}
