// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import LastUpdateTime from '@/components/LastUpdateTime'
import { botRecordList, botResultList, downloadLogAPI, LogDownLoadType } from '@/api/log'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'

@Component({ components: { Grid, ConditionFilter, LastUpdateTime } })
export default class BotLog extends Vue {
  activeTab = 'record'
  filterConditions: Condition[] = []
  selectedRecordRows: any[] = []
  selectedResultRows: any[] = []
  lastUpdateTime = 0
  autoRefresh = false

  filterFields = [
    { label: '源 IP', value: 'src_ip', type: 'text', operators: [{ label: '等于', value: '=' }] },
    { label: 'Bot 类型', value: 'bot_type', type: 'choice', operators: [
      { label: '等于', value: '=' },
      { label: '不等于', value: '!=' },
    ], choices: [
      { label: '爬虫', value: 'spider' },
      { label: '恶意 Bot', value: 'malicious_bot' },
      { label: '未知', value: 'unknown' },
    ] },
    { label: 'Bot 配置 ID', value: 'bot_config_id', type: 'text', operators: [{ label: '等于', value: '=' }] },
    { label: '验证模式', value: 'verify_mode', type: 'text', operators: [{ label: '等于', value: '=' }] },
  ]

  recordColumns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'src_ip', title: '源 IP' },
    { key: 'website_name', title: '站点名称' },
    { key: 'timestamp', title: '时间' },
  ]

  resultColumns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'src_ip', title: '源 IP' },
    { key: 'website_name', title: '站点名称' },
    { key: 'timestamp', title: '时间' },
  ]

  fetchRecords = (offset: number, count: number, conditions: Condition[]) => {
    return botRecordList(offset, count, conditions).then(resp => {
      if (resp.err === null) this.lastUpdateTime = Math.floor(Date.now() / 1000)
      return resp
    })
  }

  fetchResults = (offset: number, count: number, conditions: Condition[]) => {
    return botResultList(offset, count, conditions).then(resp => {
      if (resp.err === null) this.lastUpdateTime = Math.floor(Date.now() / 1000)
      return resp
    })
  }

  handleFilterSearch(conditions: Condition[]) {
    this.filterConditions = conditions
  }

  handleLogDownload(name: string, items: any[], type: LogDownLoadType) {
    return this.$confirm(`确认下载选中的日志(.${type})吗？`, '下载确认').then(() => {
      return downloadLogAPI({
        name,
        type,
        ids: items.map(i => i.id),
        all: false,
        conditions: this.filterConditions,
      }).then(() => {
        this.$message.success('下载任务已提交')
      })
    }).catch(() => {})
  }

  handleRefresh() {
    const grid = this.activeTab === 'record' ? this.$refs.recordGrid : this.$refs.resultGrid
    ;(grid as any)?.loadData()
  }

  renderDownloadDropdown(name: string, items: any[]) {
    return (
      <el-dropdown on-command={(cmd: string) => { if (items.length > 0) this.handleLogDownload(name, items, cmd as LogDownLoadType) }}>
        <el-button type="success" disabled={items.length === 0}>
          下载选中日志 ({items.length})<i class="el-icon-arrow-down el-icon--right" />
        </el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="json">下载选中日志(.json)</el-dropdown-item>
          <el-dropdown-item command="csv">下载选中日志(.csv)</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    )
  }

  render(h: any) {
    return (
      <div>
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px">
          <ConditionFilter conditions={this.filterConditions} fields={this.filterFields} on-change={(c: Condition[]) => { this.filterConditions = c }} on-search={this.handleFilterSearch} />
          {this.activeTab === 'record'
            ? this.renderDownloadDropdown('bot_record_log', this.selectedRecordRows)
            : this.renderDownloadDropdown('bot_result_log', this.selectedResultRows)
          }
        </div>
        <el-tabs v-model={this.activeTab}>
          <el-tab-pane label="Bot 记录" name="record">
            {this.activeTab === 'record' && <Grid ref="recordGrid" columns={[...this.recordColumns, { key: 'actions', title: '操作', width: 80, render: (h: any, row: any) => (
              <el-button type="text" on-click={() => this.$router.push({ name: 'botRecordDetail', query: { id: String(row.challenge_id) } })}>详情</el-button>
            )}]} fetchData={this.fetchRecords} selectable defaultConditions={this.filterConditions} on-selection-change={(rows: any[]) => { this.selectedRecordRows = rows }} />}
          </el-tab-pane>
          <el-tab-pane label="Bot 结果" name="result">
            {this.activeTab === 'result' && <Grid ref="resultGrid" columns={[...this.resultColumns, { key: 'actions', title: '操作', width: 80, render: (h: any, row: any) => (
              <el-button type="text" on-click={() => this.$router.push({ name: 'botResultDetail', query: { id: String(row.id) } })}>详情</el-button>
            )}]} fetchData={this.fetchResults} selectable defaultConditions={this.filterConditions} on-selection-change={(rows: any[]) => { this.selectedResultRows = rows }} />}
          </el-tab-pane>
        </el-tabs>
        <div style="display: flex; justify-content: flex-end; margin-top: 8px">
          <LastUpdateTime time={this.lastUpdateTime} immediate={this.autoRefresh} on-refresh={this.handleRefresh} on-start={() => { this.autoRefresh = true }} on-stop={() => { this.autoRefresh = false }} />
        </div>
      </div>
    )
  }
}
