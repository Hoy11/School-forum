// @ts-nocheck
import { ColumnDef } from '@/components/Grid'
import { AclLog } from '@/types/acl'

function formatAclTimestamp(ts: string | number): string {
  if (!ts) return '-'
  // Captain API may return string like "2026-05-11 10:15:00 CST" or numeric timestamp
  if (typeof ts === 'string' && isNaN(Number(ts))) return ts.replace(/\s*CST$/, '')
  const num = Number(ts)
  if (num > 1e12) return new Date(num).toLocaleString('zh-CN', { hour12: false }).replace(/\//g, '-')
  const d = new Date(num * 1000)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

const matchMethodTargetTypeMap: Record<string, string> = {
  ip: 'IP',
  cidr: 'IP',
  session: 'Session',
}

function formatAccessLogContent(h: any, row: AclLog) {
  const tmpl = row.acl_rule_template

  const parts: any[] = []

  const ipType = row.acl_rule_ip_group
    ? 'IP 组'
    : (matchMethodTargetTypeMap[tmpl?.match_method?.target_type || ''] || '')
  const target = row.acl_rule_ip_group || row.acl_rule_target || '-'

  parts.push(<span>对 </span>)
  if (ipType) {
    parts.push(<b>{ipType}: {target}</b>)
  } else {
    parts.push(<b>{target}</b>)
  }
  parts.push(<span> 的用户</span>)

  const scope = tmpl?.match_method?.scope
  if (scope !== 'all' && scope !== 'policy_rule' && scope !== 'hook_rule') {
    if (tmpl?.match_method?.scheme || tmpl?.match_method?.policy) {
      parts.push(<span>（访问 </span>)
      parts.push(<b>{tmpl.match_method.scheme}://{tmpl.match_method.policy}</b>)
      parts.push(<span>）</span>)
    }
  }

  parts.push(<span> 触发访问控制规则限制，</span>)

  if (tmpl?.dry_run) {
    parts.push(<span>超出 </span>)
    parts.push(<b>{row.count}</b>)
    parts.push(<span> 次，需注意</span>)
  } else {
    parts.push(<span>拦截 </span>)
    parts.push(<b>{row.count}</b>)
    parts.push(<span> 次</span>)
  }

  return <span>{parts}</span>
}

export const columns: ColumnDef[] = [
  {
    key: 'waf_name', title: '日志来源', width: 140,
    render: (h: any, row: AclLog) => {
      if (row.waf_deleted) return <b>已删除</b>
      return <span>{row.waf_name || '-'}</span>
    },
  },
  {
    key: 'log_content', title: '日志内容', minWidth: 360,
    render: formatAccessLogContent,
  },
  {
    key: 'acl_rule_template', title: '关联的规则', width: 180,
    render: (h: any, row: AclLog) => {
      if (!row.acl_rule_template) return <span>-</span>
      const status = row.acl_rule_template.status
      const name = row.acl_rule_template.name || '-'
      if (status === 'ok') return <span>{name}</span>
      if (status === 'deleted') return <b>已删除</b>
      if (status === 'edited') return <span>{name}(已修改)</span>
      return <span>{name}</span>
    },
  },
  {
    key: 'timestamp', title: '时间', width: 170,
    render: (h: any, row: AclLog) => <span>{formatAclTimestamp(row.timestamp)}</span>,
  },
]
