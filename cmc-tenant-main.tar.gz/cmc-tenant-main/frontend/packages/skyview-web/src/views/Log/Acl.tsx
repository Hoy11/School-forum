// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import LastUpdateTime from '@/components/LastUpdateTime'
import { aclLogList, aclLogDetail, aclLogSrcIPDetail, downloadLogAPI, LogDownLoadType } from '@/api/log'
import { wafBindingList } from '@/api/binding'
import { Condition } from '@/types/common'
import { AclLog, ACLRuleExecutionLogSrcIP } from '@/types/acl'
import { columns } from './Acl/columns'

const TARGET_OPERATORS = [{ label: '包含', value: 'like' }, { label: '精确', value: '=' }]
const TEMPLATE_NAME_OPERATORS = [{ label: '包含', value: 'like' }, { label: '不包含', value: 'not like' }]

const BASE_FILTER_FIELDS = [
  { label: '匹配目标', value: 'target', type: 'text', operators: TARGET_OPERATORS },
  { label: '规则名称', value: 'acl_rule_template_name', type: 'text', operators: TEMPLATE_NAME_OPERATORS },
  { label: '时间范围', value: 'timestamp_tsrange', type: 'time_range' },
]

@Component({ components: { Grid, ConditionFilter, LastUpdateTime } })
export default class AclLogView extends Vue {
  selectedRows: AclLog[] = []
  filterConditions: Condition[] = []
  wafChoices: { label: string; value: string }[] = []
  lastUpdateTime = 0
  autoRefresh = false

  get filterFields() {
    return [
      { label: '日志来源', value: 'log_id', type: 'multi_choice', choices: this.wafChoices, defaultOper: 'in' },
      ...BASE_FILTER_FIELDS,
    ]
  }

  mounted() {
    this.loadWafChoices()
  }

  async loadWafChoices() {
    try {
      const resp = await wafBindingList(0, 1000)
      if (resp.err !== null) return
      const seen = new Set<string>()
      this.wafChoices = (resp.data.items || []).reduce((acc: { label: string; value: string }[], waf: any) => {
        const value = String(waf.captain_instance_id)
        if (seen.has(value)) return acc
        seen.add(value)
        acc.push({ label: waf.instance_name || `WAF ${value}`, value })
        return acc
      }, [])
    } catch {
      this.wafChoices = []
    }
  }

  fetchData = (offset: number, count: number, conditions: Condition[]) => {
    return aclLogList(offset, count, conditions).then(resp => {
      if (resp.err === null) {
        this.lastUpdateTime = Math.floor(Date.now() / 1000)
      }
      return resp
    })
  }

  handleSearch(conditions: Condition[]) {
    this.filterConditions = conditions
    this.$nextTick(() => {
      const grid = this.$refs.grid as any
      if (grid?.handleConditionsChange) grid.handleConditionsChange(conditions)
    })
  }

  handleLogDownload(items: AclLog[], type: LogDownLoadType) {
    return this.$confirm(`确认下载选中的日志(.${type})吗？`, '下载确认').then(() => {
      return downloadLogAPI({
        name: 'acl_log',
        type,
        ids: items.map(i => i.id),
        all: false,
        conditions: this.filterConditions,
      }).then(() => {
        this.$message.success('下载任务已提交')
      })
    }).catch(() => {})
  }

  handleRefresh() {
    (this.$refs.grid as any).loadData()
  }

  async handleExpand(row: AclLog) {
    try {
      const detailResp = await aclLogDetail(row.origin_id, row.waf_id)
      if (detailResp.err !== null) return
      const v = detailResp.data

      const srcIpResp = await aclLogSrcIPDetail({
        captain_instance_id: row.waf_id,
        scope: 'log:access:src_ip',
        acl_rules_matched__iexact: `${v.acl_rule_id}:${v.acl_rule_template_id}:${v.acl_rule_template_version}`,
        timestamp__exact: v.timestamp,
      })

      if (srcIpResp.err === null && srcIpResp.data) {
        const items = Array.isArray(srcIpResp.data)
          ? srcIpResp.data
          : ((srcIpResp.data as any).data || [])
        row.acl_rule_execution_log_src_ip = items.sort((a: any, b: any) => b.count - a.count)
        row.isDesc = true
        this.$forceUpdate()
      }
    } catch {
      // 21 版本可能不存在 scope，静默忽略
    }
  }

  handleSortChange(row: AclLog, isDesc: boolean) {
    row.isDesc = isDesc
    if (row.acl_rule_execution_log_src_ip) {
      row.acl_rule_execution_log_src_ip.sort((a, b) =>
        isDesc ? b.count - a.count : a.count - b.count
      )
    }
    this.$forceUpdate()
  }

  expandRender = (h: any, row: AclLog) => {
    const srcIpList = row.acl_rule_execution_log_src_ip ?? []
    const title = row.acl_rule_template?.dry_run ? '当前观察 IP 及次数' : '当前拦截 IP 及次数'

    const ipCellStyles = (idx: number) => ({
      display: 'flex',
      alignItems: 'center',
      border: '1px solid #D9D9D9',
      borderLeft: 'none',
      borderTop: idx < 4 ? '1px solid #D9D9D9' : 'none',
      padding: 0,
    })

    return (
      <div style="margin: 14px; max-height: 324px; font-size: 12px">
        <div style="display: flex; align-items: center; justify-content: space-between">
          <span style="color: #333; font-weight: 700">{title}</span>
          <el-radio-group value={row.isDesc !== false} on-input={(v: boolean) => this.handleSortChange(row, v)} size="small" class="acl-expand-radio">
            <el-radio label={true} border={true}>次数倒序</el-radio>
            <el-radio label={false} border={true}>次数正序</el-radio>
          </el-radio-group>
        </div>
        <div style="display: flex; align-items: center; background: #F5F5F5; margin-top: 14px">
          <div style={{ width: '100%', maxHeight: '290px', overflow: 'overlay', borderLeft: '1px solid #D9D9D9' }}>
            <el-row gutter={0} style={!srcIpList.length ? { border: 'none' } : {}}>
              {srcIpList.length
                ? srcIpList.map((v: ACLRuleExecutionLogSrcIP, idx: number) => (
                  <el-col span={6} key={v.id} style={ipCellStyles(idx)}>
                    <div style={{ display: 'flex', alignItems: 'center', background: '#E9E9E9', height: '35px', color: '#999', paddingLeft: '14px', paddingRight: '14px', width: '100%' }}>{v.src_ip}</div>
                    <div style={{ paddingLeft: '14px', paddingRight: '14px' }}>{v.count} 次</div>
                  </el-col>
                ))
                : <div style="padding: 32px; text-align: center; color: #999">暂无数据</div>
              }
            </el-row>
          </div>
        </div>
      </div>
    )
  }

  render(h) {
    return (
      <div>
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px">
          <ConditionFilter conditions={this.filterConditions} fields={this.filterFields} on-change={(c: Condition[]) => { this.filterConditions = c }} on-search={this.handleSearch} />
          <LastUpdateTime time={this.lastUpdateTime} immediate={this.autoRefresh} on-refresh={this.handleRefresh} on-start={() => { this.autoRefresh = true }} on-stop={() => { this.autoRefresh = false }} />
          <el-dropdown on-command={(cmd: string) => { if (this.selectedRows.length > 0) this.handleLogDownload(this.selectedRows, cmd as LogDownLoadType) }}>
            <el-button type="success" disabled={this.selectedRows.length === 0}>
              下载选中日志 ({this.selectedRows.length})<i class="el-icon-arrow-down el-icon--right" />
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item command="json">下载选中日志(.json)</el-dropdown-item>
              <el-dropdown-item command="csv">下载选中日志(.csv)</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
        <Grid
          ref="grid"
          columns={columns}
          fetchData={this.fetchData}
          selectable
          defaultConditions={this.filterConditions}
          expandRender={this.expandRender}
          expandChange={this.handleExpand}
          on-selection-change={(rows: AclLog[]) => { this.selectedRows = rows }}
        />
      </div>
    )
  }
}
