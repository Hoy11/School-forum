// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import LastUpdateTime from '@/components/LastUpdateTime'
import { logTaskList, logTaskCancel, logTaskDelete, logTaskDownload } from '@/api/log-task'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { LogTask } from '@/types/log'

const statusMap: Record<string, { text: string; type: string }> = {
  running:   { text: '运行中', type: '' },
  completed: { text: '已完成', type: 'success' },
  failed:    { text: '失败',   type: 'danger' },
  canceled:  { text: '已取消', type: 'info' },
}

@Component({ components: { Grid, LastUpdateTime } })
export default class LogDownload extends Vue {
  lastUpdateTime = 0
  autoRefresh = false

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    {
      key: 'status', title: '状态', width: 100,
      render: (h: any, row: LogTask) => {
        const s = statusMap[row.status] || { text: row.status, type: 'info' }
        return <el-tag type={s.type} size="mini">{s.text}</el-tag>
      },
    },
    { key: 'task_log_name', title: '名称', minWidth: 200 },
    { key: 'created_at', title: '创建时间', width: 170 },
    { key: 'consumed_time', title: '耗时', width: 120 },
    {
      key: 'actions', title: '操作', width: 160,
      render: (h: any, row: LogTask) => {
        const canDownload = row.status === 'completed'
        const canCancel = row.status === 'running'
        return (
          <span style="display: flex; align-items: center">
            {canDownload && (
              <el-button type="text" icon="el-icon-download" on-click={() => this.handleDownload(row)} style="margin-right: 8px" />
            )}
            <el-dropdown trigger="click" on-command={(cmd: string) => this.handleAction(cmd, row)}>
              <el-button type="text" icon="el-icon-more" />
              <el-dropdown-menu slot="dropdown">
                {canCancel && <el-dropdown-item command="cancel">取消任务</el-dropdown-item>}
                <el-dropdown-item command="delete" style="color: #F56C6C">删除任务</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </span>
        )
      },
    },
  ]

  fetchData = (offset: number, count: number, conditions: Condition[]) => {
    return logTaskList(offset, count, conditions).then(resp => {
      if (resp.err === null) {
        this.lastUpdateTime = Math.floor(Date.now() / 1000)
      }
      return resp
    })
  }

  async handleDownload(row: LogTask) {
    try {
      const blob = await logTaskDownload(row.id)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `${row.task_log_name || `log-${row.id}`}.zip`
      a.click()
      URL.revokeObjectURL(url)
    } catch (e) {
      this.$message.error('下载失败')
    }
  }

  handleAction(cmd: string, row: LogTask) {
    if (cmd === 'cancel') this.handleCancel(row)
    if (cmd === 'delete') this.handleDelete(row)
  }

  async handleCancel(row: LogTask) {
    await logTaskCancel(row.id)
    ;(this.$refs.grid as any).loadData()
  }

  async handleDelete(row: LogTask) {
    await logTaskDelete([row.id])
    ;(this.$refs.grid as any).loadData()
  }

  handleRefresh() {
    const grid = this.$refs.grid as any
    grid.loadData()
  }

  render(h: any) {
    return (
      <div>
        <Grid ref="grid" columns={this.columns} fetchData={this.fetchData} />
        <div style="display: flex; justify-content: flex-end; margin-top: 8px">
          <LastUpdateTime
            time={this.lastUpdateTime}
            immediate={this.autoRefresh}
            on-refresh={this.handleRefresh}
            on-start={() => { this.autoRefresh = true }}
            on-stop={() => { this.autoRefresh = false }}
          />
        </div>
      </div>
    )
  }
}
