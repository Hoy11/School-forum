// @ts-nocheck
import { ColumnDef } from '@/components/Grid'
import { DetectLog } from '@/types/detect'
import { FilterFieldOption } from '@/types/common'
import { formatTimestamp, actionToType, riskLevelToType, formatGeo, translateEffective } from '@/utils/detectLogHelper'

export type ColumnKey = keyof DetectLog | 'actions'

export const defaultColumnKeys: ColumnKey[] = [
  'website_name', 'attack_type', 'website', 'src_ip', 'risk_level', 'action', 'timestamp',
]

export const columnOptions: { label: string; value: ColumnKey }[] = [
  { label: '防护站点名称', value: 'website_name' },
  { label: '攻击类型', value: 'attack_type' },
  { label: 'URL 地址', value: 'website' },
  { label: 'URL 路径', value: 'url_path' },
  { label: '源 IP', value: 'src_ip' },
  { label: '风险等级', value: 'risk_level' },
  { label: '执行动作', value: 'action' },
  { label: '时间', value: 'timestamp' },
  { label: '日志来源', value: 'waf_name' },
  { label: 'Event ID', value: 'event_id' },
  { label: '地理位置', value: 'country' },
  { label: '源端口', value: 'src_port' },
  { label: '目的 IP', value: 'dst_ip' },
  { label: '目的端口', value: 'dst_port' },
  { label: 'Host 端口', value: 'http_host_port' },
  { label: '协议', value: 'scheme' },
  { label: '请求方法', value: 'method' },
  { label: '响应码', value: 'status_code' },
  { label: '相关模块', value: 'module' },
  { label: '原因', value: 'reason' },
  { label: 'Payload', value: 'payload' },
  { label: '攻击有效性', value: 'effective' },
]

const columnDefs: Record<string, ColumnDef> = {
  website_name: { key: 'website_name', title: '防护站点名称', width: 160 },
  attack_type: { key: 'attack_type', title: '攻击类型', width: 140 },
  website: {
    key: 'website', title: 'URL 地址', width: 250,
    render: (h: any, row: DetectLog) => (
      <el-tooltip content={row.website} placement="top" open-delay={500}>
        <span class="text-ellipsis">{row.website || '-'}</span>
      </el-tooltip>
    ),
  },
  url_path: { key: 'url_path', title: 'URL 路径', width: 200 },
  src_ip: {
    key: 'src_ip', title: '源 IP', width: 140,
    render: (h: any, row: DetectLog) => {
      if (row.is_highlighted && row.highlight_color) {
        const style = `background-color:${row.highlight_color};color:#fff;padding:2px 6px;border-radius:3px`
        const ip = <span style={style}>{row.src_ip}</span>
        if (row.highlight_comment) {
          return <el-tooltip content={row.highlight_comment} placement="top">{ip}</el-tooltip>
        }
        return ip
      }
      return <span>{row.src_ip}</span>
    },
  },
  risk_level: {
    key: 'risk_level', title: '风险等级', width: 100,
    render: (h: any, row: DetectLog) => (
      <el-tag type={riskLevelToType(row.risk_level_num)} size="mini" effect="dark">{row.risk_level || '-'}</el-tag>
    ),
  },
  action: {
    key: 'action', title: '执行动作', width: 100,
    render: (h: any, row: DetectLog) => (
      <el-tag type={actionToType(row.action)} size="mini">{row.action?.translation || '-'}</el-tag>
    ),
  },
  timestamp: {
    key: 'timestamp', title: '时间', width: 170,
    render: (h: any, row: DetectLog) => <span>{formatTimestamp(row.timestamp)}</span>,
  },
  waf_name: { key: 'waf_name', title: '日志来源', width: 140 },
  event_id: { key: 'event_id', title: 'Event ID', width: 200 },
  country: {
    key: 'country', title: '地理位置', width: 140,
    render: (h: any, row: DetectLog) => <span>{formatGeo(row.country, row.province)}</span>,
  },
  src_port: { key: 'src_port', title: '源端口', width: 90 },
  dst_ip: { key: 'dst_ip', title: '目的 IP', width: 140 },
  dst_port: { key: 'dst_port', title: '目的端口', width: 90 },
  http_host_port: { key: 'http_host_port', title: 'Host 端口', width: 100 },
  scheme: { key: 'scheme', title: '协议', width: 80 },
  method: { key: 'method', title: '请求方法', width: 90 },
  status_code: { key: 'status_code', title: '响应码', width: 90 },
  module: { key: 'module', title: '相关模块', width: 120 },
  reason: { key: 'reason', title: '原因', width: 140 },
  payload: { key: 'payload', title: 'Payload', width: 200 },
  effective: {
    key: 'effective', title: '攻击有效性', width: 110,
    render: (h: any, row: DetectLog) => <span>{translateEffective(row.effective)}</span>,
  },
}

export function createColumns(
  selectedKeys: ColumnKey[],
  viewDetail: (row: DetectLog) => void,
  reportSoc: (row: DetectLog) => void,
): ColumnDef[] {
  const cols = selectedKeys
    .filter(k => columnDefs[k])
    .map(k => columnDefs[k])
  cols.push({
    key: 'actions', title: '操作', width: 140,
    render: (h: any, row: DetectLog) => (
      <span>
        <el-button type="text" on-click={() => viewDetail(row)}>详情</el-button>
        {row.soc_reported ? (
          <el-button type="text" disabled style="margin-left: 8px">已上报</el-button>
        ) : (
          <el-button type="text" style="margin-left: 8px" on-click={() => reportSoc(row)}>上报</el-button>
        )}
      </span>
    ),
  })
  return cols
}

const TEXT_OPERATORS: NonNullable<FilterFieldOption['operators']> = [
  { label: '精确', value: 'exact' },
  { label: '不等于', value: 'not_exact' },
  { label: '包含', value: 'contains' },
  { label: '不包含', value: 'not_contains' },
]

const URL_OPERATORS: NonNullable<FilterFieldOption['operators']> = [
  ...TEXT_OPERATORS,
  { label: '正则匹配', value: 'regex' },
  { label: '正则不匹配', value: 'not_regex' },
]

const ID_OPERATORS: NonNullable<FilterFieldOption['operators']> = [
  { label: '精确', value: 'exact' },
  { label: '不等于', value: 'not_exact' },
  { label: '属于列表', value: 'in' },
  { label: '不属于列表', value: 'not_in' },
]

const IP_OPERATORS: NonNullable<FilterFieldOption['operators']> = [
  { label: '精确', value: 'exact' },
  { label: '不等于', value: 'not_exact' },
  { label: '属于网段', value: 'net_contained_or_equal' },
  { label: '不属于网段', value: 'not_net_contained_or_equal' },
]

const NUMBER_OPERATORS: NonNullable<FilterFieldOption['operators']> = [
  { label: '精确', value: 'exact' },
  { label: '不等于', value: 'not_exact' },
]

const attackTypeChoices = [
  { label: '非攻击', value: '-1' }, { label: 'SQL 注入', value: '0' }, { label: 'XSS', value: '1' },
  { label: 'CSRF', value: '2' }, { label: 'SSRF', value: '3' }, { label: '拒绝服务', value: '4' },
  { label: '后门', value: '5' }, { label: '反序列化', value: '6' }, { label: '代码执行', value: '7' },
  { label: '代码注入', value: '8' }, { label: '命令注入', value: '9' }, { label: '文件上传', value: '10' },
  { label: '文件包含', value: '11' }, { label: '重定向', value: '12' }, { label: '权限不当', value: '13' },
  { label: '信息泄露', value: '14' }, { label: '未授权访问', value: '15' }, { label: '不安全的配置', value: '16' },
  { label: 'XXE', value: '17' }, { label: 'XPath 注入', value: '18' }, { label: 'LDAP 注入', value: '19' },
  { label: '目录穿越', value: '20' }, { label: '扫描器', value: '21' }, { label: '水平权限绕过', value: '22' },
  { label: '垂直权限绕过', value: '23' }, { label: '文件修改', value: '24' }, { label: '文件读取', value: '25' },
  { label: '文件删除', value: '26' }, { label: '逻辑错误', value: '27' }, { label: 'CRLF 注入', value: '28' },
  { label: '模板注入', value: '29' }, { label: '点击劫持', value: '30' }, { label: '缓冲区溢出', value: '31' },
  { label: '整数溢出', value: '32' }, { label: '格式化字符串', value: '33' }, { label: '条件竞争', value: '34' },
  { label: '超时', value: '61' }, { label: '未知', value: '62' }, { label: '威胁情报', value: '63' },
  { label: 'Cookie 篡改', value: '64' },
]

const riskLevelChoices = [
  { label: '无威胁', value: '0' }, { label: '低危', value: '1' }, { label: '中危', value: '2' }, { label: '高危', value: '3' },
]

const methodChoices = [
  { label: 'GET', value: 'GET' }, { label: 'POST', value: 'POST' }, { label: 'PUT', value: 'PUT' },
  { label: 'DELETE', value: 'DELETE' }, { label: 'HEAD', value: 'HEAD' }, { label: 'OPTIONS', value: 'OPTIONS' },
  { label: 'PATCH', value: 'PATCH' },
]

const boolChoices = [
  { label: '是', value: 'true' },
  { label: '否', value: 'false' },
]

export const filterFields: FilterFieldOption[] = [
  { label: '防护站点名称', value: 'website_name', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '日志来源', value: 'log_id', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '攻击类型', value: 'attack_type', type: 'multi_choice', choices: attackTypeChoices },
  { label: '国家', value: 'country', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '省份', value: 'province', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '源 IP', value: 'src_ip', type: 'text', operators: IP_OPERATORS, defaultOper: 'exact' },
  { label: 'Socket IP', value: 'socket_ip', type: 'text', operators: IP_OPERATORS, defaultOper: 'exact' },
  { label: '源端口', value: 'src_port', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '目的 IP', value: 'dst_ip', type: 'text', operators: IP_OPERATORS, defaultOper: 'exact' },
  { label: '目的端口', value: 'dst_port', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: 'Host 端口', value: 'http_host_port', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '域名', value: 'host', type: 'text', operators: URL_OPERATORS, defaultOper: 'contains' },
  { label: 'URL 路径', value: 'url_path', type: 'text', operators: URL_OPERATORS, defaultOper: 'contains' },
  { label: 'Event ID', value: 'event_id', type: 'text', operators: ID_OPERATORS, defaultOper: 'exact' },
  { label: '规则 ID', value: 'rule_id', type: 'text', operators: ID_OPERATORS, defaultOper: 'exact' },
  { label: '请求规则 ID', value: 'req_rule_id', type: 'text', operators: ID_OPERATORS, defaultOper: 'exact' },
  { label: '响应规则 ID', value: 'rsp_rule_id', type: 'text', operators: ID_OPERATORS, defaultOper: 'exact' },
  { label: '请求方法', value: 'method', type: 'multi_choice', choices: methodChoices },
  { label: '执行动作', value: 'action', type: 'multi_choice', choices: [
    { label: '放行', value: '0' }, { label: '拦截', value: '1' }, { label: '观察', value: '2' }, { label: '转发', value: '4' },
  ]},
  { label: '风险等级', value: 'risk_level', type: 'multi_choice', choices: riskLevelChoices },
  { label: '响应码', value: 'status_code', type: 'number', operators: ID_OPERATORS, defaultOper: 'exact' },
  { label: '请求开始时间', value: 'req_start_time_tsrange', type: 'time_range' },
  { label: '响应开始时间', value: 'rsp_start_time_tsrange', type: 'time_range' },
  { label: '时间范围', value: 'timestamp', type: 'time_range' },
  { label: '请求检测时长', value: 'req_detect_time', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '响应检测时长', value: 'rsp_detect_time', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '请求体截断', value: 'req_http_body_is_truncate', type: 'multi_choice', choices: boolChoices },
  { label: '响应体截断', value: 'rsp_http_body_is_truncate', type: 'multi_choice', choices: boolChoices },
  { label: 'HTTP Body 丢弃', value: 'http_body_is_abandoned', type: 'multi_choice', choices: boolChoices },
  { label: '请求检测引擎', value: 'req_detector_name', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '响应检测引擎', value: 'rsp_detector_name', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '请求解码路径', value: 'req_decode_path', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '响应解码路径', value: 'rsp_decode_path', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '威胁置信度', value: 'threat_confidence', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '威胁风险等级', value: 'threat_risk_level', type: 'multi_choice', choices: riskLevelChoices },
  { label: '威胁最近时间', value: 'threat_last_timestamp_tsrange', type: 'time_range' },
  { label: '威胁标签', value: 'matched_threat_tag', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '信誉库 IP 最近发现时间', value: 'threat_ip_last_timestamp_tsrange', type: 'time_range' },
  { label: '信誉库 FP 最近发现时间', value: 'threat_fp_last_timestamp_tsrange', type: 'time_range' },
  { label: '信誉库 IP 置信度', value: 'threat_ip_confidence', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '信誉库 FP 置信度', value: 'threat_fp_confidence', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '信誉库 IP 命中标签', value: 'ip_matched_threat_tags', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '信誉库 FP 命中标签', value: 'fp_matched_threat_tags', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '内层 VLAN ID', value: 'inner_vlan_id', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: '外层 VLAN ID', value: 'outer_vlan_id', type: 'number', operators: NUMBER_OPERATORS, defaultOper: 'exact' },
  { label: 'X-Forwarded-For', value: 'x_forwarded_for', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '指纹', value: 'fingerprint', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '上游地址', value: 'upstream_addr', type: 'text', operators: TEXT_OPERATORS, defaultOper: 'contains' },
  { label: '请求 Payload 解释', value: 'req_payload_explain_ids', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '响应 Payload 解释', value: 'rsp_payload_explain_ids', type: 'text', operators: ID_OPERATORS, defaultOper: 'in', placeholder: '多个值用英文逗号分隔' },
  { label: '攻击有效性', value: 'effective', type: 'multi_choice', choices: [
    { label: '无效攻击', value: '0' }, { label: '未知', value: '1' }, { label: '疑似有效', value: '2' }, { label: '有效攻击', value: '3' },
  ]},
]
