// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import LastUpdateTime from '@/components/LastUpdateTime'
import { detectLogList, downloadLogAPI, LogDownLoadType } from '@/api/log'
import { socReport } from '@/api/soc'
import { Condition } from '@/types/common'
import { DetectLog } from '@/types/detect'
import { RouteName } from '@/router/names'
import { createColumns, filterFields, defaultColumnKeys, columnOptions, ColumnKey } from './columns'

const STORAGE_KEY = 'cmc_detect_log_columns'

@Component({ components: { Grid, ConditionFilter, LastUpdateTime } })
export default class DetectLogView extends Vue {
  selectedRows: DetectLog[] = []
  filterConditions: Condition[] = []
  lastUpdateTime = 0
  autoRefresh = false
  showColumnSettings = false

  created() {
    const q = this.$route.query
    if (q.policy_rule_id) {
      this.filterConditions = [{ target: 'rule_id', items: [{ oper: 'exact', value: String(q.policy_rule_id) }] }]
    }
  }

  selectedColumnKeys: ColumnKey[] = this.loadColumnKeys()

  viewDetail = (row: DetectLog) => {
    this.$router.push({ name: 'detectLogDetail', query: { id: String(row.id) } })
  }

  loadColumnKeys(): ColumnKey[] {
    try {
      const saved = localStorage.getItem(STORAGE_KEY)
      if (saved) {
        const parsed = JSON.parse(saved)
        if (Array.isArray(parsed) && parsed.length > 0) {
          const valid = parsed.filter((k: string) => columnOptions.some(o => o.value === k))
          if (valid.length > 0) return valid
        }
      }
    } catch { /* ignore */ }
    return [...defaultColumnKeys]
  }

  saveColumnKeys() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.selectedColumnKeys))
  }

  handleColumnChange(keys: ColumnKey[]) {
    if (keys.length < 2) return
    this.selectedColumnKeys = keys
    this.saveColumnKeys()
  }

  get columns() {
    return createColumns(this.selectedColumnKeys, this.viewDetail, this.handleSocReport)
  }

  fetchData = (offset: number, count: number, conditions: Condition[]) => {
    return detectLogList(offset, count, conditions).then(resp => {
      if (resp.err === null) {
        this.lastUpdateTime = Math.floor(Date.now() / 1000)
      }
      return resp
    })
  }

  async handleSocReport(row: DetectLog) {
    if (row.soc_reported) return
    try {
      await socReport({ log_type: 'detect', log_id: row.id })
      this.$message.success('上报成功')
      ;(this.$refs.grid as any)?.loadData()
    } catch (e: any) {
      const msg = e?.message || '上报失败'
      if (msg.includes('无可用 SOC 配置')) {
        try {
          await this.$confirm('当前未配置可用 SOC，是否前往系统集成页面配置？', 'SOC 未配置', {
            confirmButtonText: '去配置',
            cancelButtonText: '取消',
            type: 'warning',
          })
          this.$router.push({ name: RouteName.integrationConfig })
        } catch { /* cancel */ }
        return
      }
      this.$message.error(msg)
    }
  }

  handleLogDownloadAPI(items: DetectLog[], type: LogDownLoadType, selectAll: boolean) {
    const label = selectAll ? '全部' : '选中'
    return this.$confirm(`确认下载${label}的日志(.${type})吗？`, '下载确认').then(() => {
      return downloadLogAPI({
        name: 'detect_log',
        type,
        ids: items.map(i => i.id),
        all: selectAll,
        conditions: this.filterConditions,
      }).then(() => {
        this.$message.success('下载任务已提交')
      })
    }).catch(() => {})
  }

  handleLogDownloadFn(type: LogDownLoadType) {
    return () => {
      this.handleLogDownloadAPI(this.selectedRows, type, false)
    }
  }

  handleSearch(conditions: Condition[]) {
    this.filterConditions = conditions
    this.$nextTick(() => {
      const grid = this.$refs.grid as any
      if (grid?.handleConditionsChange) grid.handleConditionsChange(conditions)
    })
  }

  handleRefresh() {
    (this.$refs.grid as any).loadData()
  }

  render(h: any) {
    return (
      <div>
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px">
          <ConditionFilter conditions={this.filterConditions} fields={filterFields} on-change={(c: Condition[]) => { this.filterConditions = c }} on-search={this.handleSearch} />
          <div style="display: flex; align-items: center; gap: 8px">
            <el-popover placement="bottom-end" trigger="click" width="280">
              <div style="max-height: 360px; overflow-y: auto">
                <div style="margin-bottom: 8px; color: #909399; font-size: 13px">选择展示列（至少2列）</div>
                <el-checkbox-group value={this.selectedColumnKeys} on-input={this.handleColumnChange}>
                  {columnOptions.map(opt => (
                    <el-checkbox label={opt.value} key={opt.value} style="display: block; margin-left: 0; margin-bottom: 4px">{opt.label}</el-checkbox>
                  ))}
                </el-checkbox-group>
              </div>
              <el-button slot="reference" icon="el-icon-setting" size="small">列设置</el-button>
            </el-popover>
            <el-dropdown on-command={(cmd: string) => { if (this.selectedRows.length > 0) this.handleLogDownloadAPI(this.selectedRows, cmd as LogDownLoadType, false) }} style="margin-right: 0">
              <el-button type="success" disabled={this.selectedRows.length === 0}>
                下载选中日志 ({this.selectedRows.length})<i class="el-icon-arrow-down el-icon--right" />
              </el-button>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="json">下载选中日志(.json)</el-dropdown-item>
                <el-dropdown-item command="csv">下载选中日志(.csv)</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
        <Grid ref="grid" columns={this.columns} fetchData={this.fetchData} selectable defaultConditions={this.filterConditions} on-selection-change={(rows: DetectLog[]) => { this.selectedRows = rows }} />
        <div style="display: flex; justify-content: flex-end; margin-top: 8px">
          <LastUpdateTime time={this.lastUpdateTime} immediate={this.autoRefresh} on-refresh={this.handleRefresh} on-start={() => { this.autoRefresh = true }} on-stop={() => { this.autoRefresh = false }} />
        </div>
      </div>
    )
  }
}
