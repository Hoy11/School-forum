// @ts-nocheck
import { Component, Vue, Mixins, Watch } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { certList, certUpload, certDelete, CertInfo } from '@/api/captain-cert'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { WafSelectorMixin } from '@/mixins/wafSelector'
import { format } from 'date-fns'
import { isAdmin } from '@/permission'

@Component({ components: { Grid } })
export default class SslCert extends Mixins(WafSelectorMixin) {
  get wafId(): number { return this.effectiveWafId }

  @Watch('wafReady')
  onWafReady() { if (this.wafReady) this.$nextTick(() => (this.$refs.grid as any)?.loadData()) }

  handleWafChange() { this.showWafOfflineMessage(); (this.$refs.grid as any)?.loadData() }

  showUpload = false
  uploadForm = { name: '', password: '', includeKey: false }

  formatTime(ts: number) {
    if (!ts) return '-'
    return format(new Date(ts * 1000), 'yyyy-MM-dd HH:mm:ss')
  }

  usageText(row: CertInfo) {
    const parts: string[] = []
    if (row.is_mgt_api_cert || row.is_system_cert) parts.push('系统使用中')
    const count = row.websites?.length || 0
    if (count > 0) parts.push(`有 ${count} 个站点正在使用`)
    return parts.length > 0 ? parts.join('，') : '未使用'
  }

  isSystemCert(row: CertInfo): boolean { return row.is_system_cert === true || row.is_mgt_api_cert === true }

  isInUse(row: CertInfo): boolean {
    return (row.websites?.length ?? 0) > 0
  }

  isShared(row: CertInfo): boolean {
    return (row.binding_count ?? 0) > 1
  }

  isEditProtected(row: CertInfo): boolean {
    return this.isSystemCert(row) || this.isShared(row) || row.has_external_ref === true
  }

  isDeleteProtected(row: CertInfo): boolean {
    if (this.isSystemCert(row) || this.isInUse(row)) return true
    if (!isAdmin() && this.isShared(row)) return true
    return false
  }

  deleteTooltip(row: CertInfo): string {
    if (this.isSystemCert(row)) return '该证书为系统管理接口证书，无法删除'
    if (this.isInUse(row)) {
      const count = row.websites?.length || 0
      return `该SSL证书正在被 ${count} 个站点使用，无法删除`
    }
    if (this.isShared(row)) {
      if (isAdmin()) {
        const groups = row.shared_group_names?.join('、') || '其他租户组'
        return `此证书被以下租户组共享：${groups}，确认删除？`
      }
      return '该资源被多个租户组绑定，不可删除'
    }
    if (isAdmin()) return '此证书已绑定给租户组，当前无站点引用，确认删除？'
    return '删除'
  }

  columns: ColumnDef[] = [
    { key: 'name', title: '证书名称', minWidth: 200, render: (h: any, row: CertInfo) => <span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block">{row.name}</span> },
    { key: 'usage', title: '使用情况', width: 200, render: (h: any, row: CertInfo) => <span>{this.usageText(row)}</span> },
    { key: 'create_time', title: '创建时间', width: 180, render: (h: any, row: CertInfo) => <span>{this.formatTime(row.create_time)}</span> },
  ]

  fetchData(offset: number, count: number, conditions: Condition[]) {
    if (!this.wafId) return Promise.resolve({ err: null, msg: 'success', data: { total: 0, items: [] } })
    if (this.isWafUnavailable) return this.emptyWafPage()
    return certList(this.wafId, offset, count, conditions)
  }

  async handleUpload(options: any) {
    if (!this.ensureWafOperable()) return
    const fd = new FormData()
    fd.append('crt_file', options.file)
    fd.append('name', this.uploadForm.name)
    fd.append('password', this.uploadForm.password)
    if (!this.uploadForm.includeKey && options.keyFile) {
      fd.append('key_file', options.keyFile)
    }
    try {
      const result = await certUpload(this.wafId, fd)
      if (result.err !== null) {
        this.$message.error(result.msg || '上传失败')
        return
      }
      this.$message.success('上传成功')
      this.showUpload = false
      ;(this.$refs.grid as any).loadData()
    } catch {
      this.$message.error('上传失败')
    }
  }

  handleDetail(row: CertInfo) {
    this.$router.push({ name: 'sslCertDetail', query: { id: String(row.id), waf: String(this.wafId) } })
  }

  async handleDelete(row: CertInfo) {
    if (!this.ensureWafOperable()) return
    if (this.isSystemCert(row)) {
      this.$message.warning('该证书为系统管理接口证书，无法删除')
      return
    }
    if (this.isInUse(row)) {
      this.$message.warning(`该SSL证书正在被 ${row.websites?.length || 0} 个站点使用，无法删除`)
      return
    }
    if (this.isShared(row)) {
      if (isAdmin()) {
        const groups = row.shared_group_names?.join('、') || '其他租户组'
        try {
          await this.$confirm(`此证书被以下租户组共享：${groups}，确认删除？`, '提示', { type: 'warning' })
        } catch {
          return
        }
      } else {
        this.$message.warning('该资源被多个租户组绑定，不可删除')
        return
      }
    } else if (isAdmin()) {
      try {
        await this.$confirm('此证书已绑定给租户组，当前无站点引用，确认删除？', '提示', { type: 'warning' })
      } catch {
        return
      }
    } else {
      await this.$confirm('确定删除该证书？', '提示', { type: 'warning' })
    }
    try {
      await certDelete(row.id, this.wafId)
      this.$message.success('删除成功')
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.handleProtectionError(e, '删除')
    }
  }

  handleProtectionError(e: any, action: string) {
    const errCode = e?.response?.data?.err
    const errMsg = e?.response?.data?.msg
    if (errCode === 'system_cert') {
      this.$message.warning(errMsg || '该证书为系统管理接口证书，无法操作')
    } else if (errCode === 'in_use') {
      this.$message.warning(errMsg || `该SSL证书正在被站点使用，无法${action}`)
    } else if (errCode === 'shared') {
      this.$message.warning(errMsg || '该资源被多个租户组绑定')
    } else {
      this.$message.error(errMsg || e?.message || '操作失败')
    }
  }

  certFile: File | null = null
  keyFile: File | null = null

  async handleUploadSubmit() {
    if (!this.ensureWafOperable()) return
    if (!this.certFile) {
      this.$message.warning('请选择证书文件')
      return
    }
    const fd = new FormData()
    fd.append('crt_file', this.certFile)
    fd.append('name', this.uploadForm.name)
    fd.append('password', this.uploadForm.password)
    if (!this.uploadForm.includeKey && this.keyFile) {
      fd.append('key_file', this.keyFile)
    }
    try {
      const result = await certUpload(this.wafId, fd)
      if (result.err !== null) {
        this.$message.error(result.msg || '上传失败')
        return
      }
      this.$message.success('上传成功')
      this.showUpload = false
      ;(this.$refs.grid as any).loadData()
    } catch {
      this.$message.error('上传失败')
    }
  }

  render(h: any) {
    return (
      <div>
        <div style="margin-bottom: 16px; display: flex; align-items: center; gap: 16px">
          <el-select v-model={this.selectedWafId} placeholder="选择 WAF 实例" on-change={this.handleWafChange} disabled={!this.wafReady}>
            {this.wafOptions.map(w => <el-option key={w.captain_instance_id} label={this.formatWafOptionLabel(w)} value={w.captain_instance_id} />)}
          </el-select>
          <el-button type="primary" on-click={() => { if (!this.ensureWafOperable()) return; this.uploadForm = { name: '', password: '', includeKey: false }; this.certFile = null; this.keyFile = null; this.showUpload = true }} disabled={!this.wafId || this.isWafUnavailable}>添加SSL证书</el-button>
        </div>
        {this.renderWafOfflineAlert(h)}
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 120, render: (h: any, row: CertInfo) => {
          const deleteProtected = this.isDeleteProtected(row)
          const delTooltip = this.deleteTooltip(row)
          return (
            <span>
              <el-button size="mini" icon="el-icon-view"
                style="width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;color:#666"
                on-click={() => this.handleDetail(row)} />
              <el-tooltip content={delTooltip} placement="top" disabled={!deleteProtected}>
                <el-button size="mini" icon="el-icon-delete"
                  style={`width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;margin-left:8px;color:${deleteProtected ? '#ccc' : '#666'}`}
                  on-click={() => deleteProtected ? this.$message.warning(delTooltip) : this.handleDelete(row)} />
              </el-tooltip>
            </span>
          )
        }}]} fetchData={this.fetchData} />

        <el-dialog title="添加 SSL 证书" visible={this.showUpload} on-close={() => { this.showUpload = false }} width="520px">
          <el-form label-width="140px">
            <el-form-item label="证书名称"><el-input v-model={this.uploadForm.name} placeholder="请输入证书名称" /></el-form-item>
            <el-form-item label="是否含私钥"><el-checkbox v-model={this.uploadForm.includeKey}>证书文件中包含私钥</el-checkbox></el-form-item>
            <el-form-item label="证书文件" required>
              <el-upload {...{ props: { onChange: (f: any) => { this.certFile = f.raw }, onRemove: () => { this.certFile = null } } }} drag action="" auto-upload={false} accept=".pem,.crt,.pfx,.p7b" limit={1} ref="certUpload">
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将证书文件拖到此处，或<em>点击上传</em></div>
              </el-upload>
            </el-form-item>
            {!this.uploadForm.includeKey && (
              <el-form-item label="私钥文件">
                <el-upload {...{ props: { onChange: (f: any) => { this.keyFile = f.raw }, onRemove: () => { this.keyFile = null } } }} drag action="" auto-upload={false} accept=".pem,.key" limit={1} ref="keyUpload">
                  <i class="el-icon-upload"></i>
                  <div class="el-upload__text">将私钥文件拖到此处，或<em>点击上传</em></div>
                </el-upload>
              </el-form-item>
            )}
            <el-form-item label="证书密码"><el-input v-model={this.uploadForm.password} placeholder="如有密码请输入" /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showUpload = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleUploadSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
