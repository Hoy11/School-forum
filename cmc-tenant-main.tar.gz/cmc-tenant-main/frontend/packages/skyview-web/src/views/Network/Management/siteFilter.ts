import { Condition } from '@/types/common'
import { Website } from '@/types/website'

/** 对全量站点数组应用条件筛选 */
export function filterSites(sites: Website[], conditions: Condition[]): Website[] {
  if (!conditions.length) return sites
  return sites.filter(site => conditions.every(cond => matchCondition(site, cond)))
}

/** 单个条件匹配（同一 condition 内 items 为 AND 语义） */
function matchCondition(site: Website, cond: Condition): boolean {
  if (!cond.items?.length) return true
  return cond.items.every(item => matchItem(site, cond.target, item))
}

/** 单个条件项匹配 */
function matchItem(site: Website, target: string, item: { oper: string; value: any }): boolean {
  switch (target) {
    case 'name': return matchText(site.name, item)
    case 'server_names': return matchArrayText(site.server_names, item)
    case 'url_paths': return matchUrlPaths(site, item)
    case 'anti_tamper_status': return matchExact(site.anti_tamper_status, item.value)
    case 'backend_type': return matchExact(site.backend_config?.type, item.value)
    case 'ssl_cert': return matchID(site.ssl_cert, item.value)
    case 'is_enabled': return matchSiteStatus(site.is_enabled, item.value)
    case 'policy_group': return matchID(site.policy_group, item.value)
    case 'ports': return matchPorts(site, item)
    case 'servers': return matchServers(site, item)
    case 'remark': return matchText(site.remark || '', item)
    case 'ntlm_enabled': return matchExact(String(site.ntlm_enabled), item.value)
    case 'create_time': return matchTimeRange(site.create_time, item)
    case 'last_update_time': return matchTimeRange(site.last_update_time, item)
    default: return true
  }
}

// === 文本匹配 ===

function matchText(field: string, item: { oper: string; value: any }): boolean {
  const val = String(item.value ?? '')
  if (!val) return true
  return item.oper === '=' ? field === val : field.toLowerCase().includes(val.toLowerCase())
}

function matchArrayText(arr: string[], item: { oper: string; value: any }): boolean {
  const val = String(item.value ?? '')
  if (!val) return true
  if (item.oper === '=') return arr.some(n => n === val)
  return arr.some(n => n.toLowerCase().includes(val.toLowerCase()))
}

// === 生效地址 ===

function matchUrlPaths(site: Website, item: { oper: string; value: any }): boolean {
  const val = String(item.value ?? '')
  if (!val) return true
  const paths = site.url_paths || []
  if (item.oper === '=') return paths.some(p => p.url_path === val)
  return paths.some(p => p.url_path.toLowerCase().includes(val.toLowerCase()))
}

// === 精确匹配 ===

function matchExact(field: any, value: any): boolean {
  return String(field ?? '') === String(value ?? '')
}

// === ID 匹配（ssl_cert / policy_group，null→"0"） ===

function matchID(field: number | null, value: any): boolean {
  return String(field ?? 0) === String(value ?? 0)
}

// === 站点状态 ===

function matchSiteStatus(isEnabled: boolean, value: any): boolean {
  return isEnabled ? value === 'enabled' : value === 'disabled'
}

// === 监听端口 ===

function matchPorts(site: Website, item: { oper: string; value: any }): boolean {
  const target = String(item.value ?? '')
  if (!target) return true
  return (site.ports || []).some(p => String(p.port) === target)
}

// === 业务服务器地址 ===

function matchServers(site: Website, item: { oper: string; value: any }): boolean {
  const val = String(item.value ?? '').toLowerCase()
  if (!val) return true
  const cfg = site.backend_config as any
  if (!cfg?.servers) return false
  return cfg.servers
    .filter((s: any) => s.is_enabled !== false)
    .some((s: any) => {
      const addr = `${s.protocol || 'http'}://${s.host}:${s.port}`
      return addr.toLowerCase().includes(val)
        || `${s.host}:${s.port}`.toLowerCase().includes(val)
        || String(s.host).toLowerCase().includes(val)
    })
}

// === 时间范围 ===

function matchTimeRange(field: number, item: { oper: string; value: any }): boolean {
  if (item.oper !== 'range' || !item.value) return true
  const [start, end] = String(item.value).split(',').map(Number)
  if (!start && !end) return true
  if (start && end) return field >= start && field <= end
  if (start) return field >= start
  if (end) return field <= end
  return true
}
