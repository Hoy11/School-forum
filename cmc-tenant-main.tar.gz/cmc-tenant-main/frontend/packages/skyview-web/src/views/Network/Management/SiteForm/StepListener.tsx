// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, SSLCertModel, NodeStatus, WorkGroupModel, WebsitePort, CertSettings } from '@/types/website'
import { BackendType, LoadBalancePolicy, SelectedTengineType } from '@/types/website'
import { CertOriginal } from '@/types/website-enums'
import { SessionType } from '@/types/website-security'
import { getDefaultPort, getDefaultForwardBackendConfig, getDefaultCertSettings, getDefaultWebsiteURLPath } from '@/utils/site'
import { siteWorkGroupIpList } from '@/api/captain-site'
import SiteStatusField from './SiteStatusField'
import SiteTypeField from './SiteTypeField'
import SiteNameField from './SiteNameField'
import HostField from './HostField'
import UrlPathsField from './UrlPathsField'
import RemarkField from './RemarkField'
import StepListenerTengine from './StepListenerTengine'
import StepListenerPort from './StepListenerPort'
import StepListenerCert from './StepListenerCert'

@Component({ components: { SiteStatusField, SiteTypeField, SiteNameField, HostField, UrlPathsField, RemarkField, StepListenerTengine, StepListenerPort, StepListenerCert } })
export default class StepListener extends Vue {
  @Prop() form!: Website
  @Prop({ default: () => [] }) certs!: SSLCertModel[]
  @Prop({ default: () => [] }) nodes!: NodeStatus[]
  @Prop({ default: () => [] }) workGroups!: WorkGroupModel[]
  @Prop({ default: false }) guomiEnabled!: boolean
  @Prop({ default: false }) isHardwareMode!: boolean
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => getDefaultCertSettings() }) certSettings!: CertSettings

  workGroupIps: string[] = []

  get showWorkGroup() {
    return this.workGroups.length > 0 || this.isHardwareMode
  }

  get hasSslPort() {
    return this.form.ports?.some(p => p.ssl)
  }

  handleNtlmChange(v: boolean) {
    this.form.ntlm_enabled = v
    if (v) {
      this.form.selected_tengine = { type: SelectedTengineType.all, tengine_list: null }
      this.form.backend_config = {
        ...getDefaultForwardBackendConfig(),
        load_balance_policy: LoadBalancePolicy.ntlm,
      }
    } else {
      this.form.backend_config = getDefaultForwardBackendConfig()
    }
    this.form.session_method = { type: SessionType.off, param: '' }
    this.$emit('ntlm-changed', v)
  }

  async handleWorkGroupChange(name: string) {
    this.form.interface = name
    this.workGroupIps = []
    if (!name || !this.captainInstanceId) return
    try {
      const resp = await siteWorkGroupIpList(this.captainInstanceId, name)
      if (resp.err === null) this.workGroupIps = (resp.data || []).map(d => d.addr)
    } catch { /* ignore */ }
  }

  handleNonHttpEnabled(portIndex: number) {
    this.form.url_paths = [getDefaultWebsiteURLPath()]
    this.form.ports[portIndex].proxy_protocol = false
  }

  render(h: any) {
    return (
      <div>
        <SiteStatusField value={this.form.is_enabled} on-input={(v: boolean) => { this.form.is_enabled = v }} />
        <SiteTypeField value={this.form.ntlm_enabled} on-input={this.handleNtlmChange} guomiEnabled={this.guomiEnabled} />
        <SiteNameField value={this.form.name} on-input={(v: string) => { this.form.name = v }} />
        <HostField value={this.form.server_names} on-input={(v: string[]) => { this.form.server_names = v }} />
        <UrlPathsField value={this.form.url_paths} on-input={(v: any[]) => { this.form.url_paths = v }}
          disabled={this.form.ports?.some(p => p.non_http)} />

        {!this.form.ntlm_enabled && (
          <StepListenerTengine value={this.form.selected_tengine} nodes={this.nodes}
            ntlmEnabled={this.form.ntlm_enabled}
            on-input={(v: any) => { this.form.selected_tengine = v }} />
        )}

        {this.showWorkGroup && (
          <el-form-item label="工作组" required={this.isHardwareMode}>
            <el-select value={this.form.interface} on-input={this.handleWorkGroupChange} placeholder="选择工作组" style="width:240px">
              {this.workGroups.map(wg => (
                <el-option label={wg.name} value={wg.name} />
              ))}
            </el-select>
          </el-form-item>
        )}

        {this.workGroupIps.length > 0 && (
          <el-form-item label="IP">
            <el-select value={this.form.ip} on-input={(v: string[]) => { this.form.ip = v }}
              multiple collapse-tags style="width:100%">
              {this.workGroupIps.map(ip => (
                <el-option label={ip} value={ip} />
              ))}
            </el-select>
          </el-form-item>
        )}

        <StepListenerPort value={this.form.ports} on-input={(v: WebsitePort[]) => { this.form.ports = v }}
          ntlmEnabled={this.form.ntlm_enabled}
          isSoftwareMode={!this.isHardwareMode}
          on-non-http-enabled={this.handleNonHttpEnabled} />

        {this.hasSslPort && (
          <StepListenerCert certSettings={this.certSettings} certs={this.certs}
            sslCert={this.form.ssl_cert} guomiEnabled={this.guomiEnabled}
            on-cert-change={(v: CertSettings) => this.$emit('cert-change', v)}
            on-ssl-cert-change={(v: number) => { this.form.ssl_cert = v }} />
        )}

        <RemarkField value={this.form.remark} on-input={(v: string) => { this.form.remark = v }} />
      </div>
    )
  }
}
