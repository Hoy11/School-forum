// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { PolicyModel } from '@/types/website'

@Component
export default class PolicyField extends Vue {
  @Prop({ default: null }) value!: number | null
  @Prop({ default: () => [] }) policyGroups!: PolicyModel[]
  @Prop({ default: false }) disabled!: boolean

  get options() {
    return [{ id: 'none', name: '不使用防护策略', is_default: false }, ...this.policyGroups]
  }

  get isNone() {
    return this.value === null || this.value === 'none' as any
  }

  render(h: any) {
    return (
      <div>
        <el-form-item label="防护策略">
          <el-select value={this.value || 'none'} on-input={(v: any) => this.$emit('input', v === 'none' ? null : v)}
            style="width: 240px" disabled={this.disabled}>
            {this.options.map(opt => (
              <el-option label={opt.name} value={opt.id} />
            ))}
          </el-select>
        </el-form-item>
        {this.isNone && !this.disabled && (
          <el-alert title='防护策略为"不使用防护策略"时，无法对站点进行防护且无法调整站点相关的防护配置'
            type="warning" show-icon closable={false} style="margin-bottom:12px" />
        )}
      </div>
    )
  }
}
