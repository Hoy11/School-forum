import { LoadBalancePolicy, BackendType, ForwardAction } from '@/types/website'
import { ConnectionConfig } from '@/types/website-security'
import { LogOption, SelectedTengineType } from '@/types/website-enums'

export const connectionConfigOptions = [
  { label: '默认连接配置', value: ConnectionConfig.default },
  { label: '自定义连接配置', value: ConnectionConfig.custom },
  { label: '不保持 TCP 连接', value: ConnectionConfig.unTcp },
]

export const logOptionOptions = [
  { label: '记录并储存', value: LogOption.persistence },
  { label: '记录但不储存', value: LogOption.nonPersistence },
  { label: '不记录', value: LogOption.drop },
]

export const ipSourceLabels: Record<string, string> = {
  from_socket: 'From Socket',
  from_x_forwarded_for: 'X-Forwarded-For',
  from_x_real_ip: 'X-Real-IP',
  from_proxy_protocol: 'Proxy Protocol',
  Socket: 'Socket',
  XForwardedFor: 'X-Forwarded-For',
  ProxyProtocol: 'Proxy Protocol',
  RealIP: 'Real IP',
}

export const ipSourceOptions = [
  { label: 'From Socket', value: 'from_socket' },
  { label: 'X-Forwarded-For', value: 'from_x_forwarded_for' },
  { label: 'X-Real-IP', value: 'from_x_real_ip' },
  { label: 'Proxy Protocol', value: 'from_proxy_protocol' },
]

export const redirectStatusOptions = [
  { label: '301 永久重定向', value: 301 },
  { label: '302 临时重定向', value: 302 },
  { label: '303 See Other', value: 303 },
  { label: '307 临时重定向', value: 307 },
  { label: '308 永久重定向', value: 308 },
]

export const healthCheckTypeOptions = [
  { label: 'TCP', value: 'tcp' },
  { label: 'HTTP', value: 'http' },
  { label: 'HTTPS', value: 'ssl_hello' },
]

export const healthCheckMethodOptions = [
  { label: 'GET', value: 'GET' },
  { label: 'HEAD', value: 'HEAD' },
]

export const healthCheckCodeOptions = [
  { label: '2xx', value: 'http_2xx' },
  { label: '3xx', value: 'http_3xx' },
  { label: '4xx', value: 'http_4xx' },
  { label: '5xx', value: 'http_5xx' },
]

export const fallbackTypeOptions = [
  { label: '使用过期缓存', value: 'stale' },
  { label: '切换下一服务器', value: 'next' },
  { label: '关闭服务', value: 'shutdown' },
]

export const hashSelectIpMethodOptions = [
  { label: '源地址哈希', value: 'remote_addr' },
  { label: '源地址端口哈希', value: 'remote_addr_and_port' },
]
