// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website } from '@/types/website'
import { canEditBusiness } from '@/permission'
import { createFieldUpdater } from './useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'

@Component({ components: { EditableRow } })
export default class DeepDetectionPanel extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number

  get canEdit() { return canEditBusiness() }
  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }

  render(h: any) {
    const s = this.site
    const enabled = s.deep_detection_config?.is_enabled
    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">深度检测</div>
        <EditableRow label="深度检测" editable={this.canEdit}
          value={String(enabled || false)}
          submitFn={(v) => this.updateField({ deep_detection_config: { ...this.site.deep_detection_config, is_enabled: v === 'true' } })}
          scopedSlots={{
            default: () => enabled
              ? <el-tag type="success" size="mini">启用</el-tag>
              : <el-tag type="info" size="mini">关闭</el-tag>,
            edit: ({ value, input }) => (
              <div>
                <el-switch value={value === 'true'} on-input={(v: boolean) => input(String(v))} active-text="启用深度检测模式" />
                <el-tooltip content="开启深度检测，会对请求进行全方位的攻击检测，检出并在攻击检测日志中展示请求包含的所有攻击检测信息，请求检测处理效率会略有下降。" placement="top">
                  <i class="el-icon-question" style="margin-left:4px;color:#909399;cursor:help" />
                </el-tooltip>
              </div>
            ),
          }} />
      </el-card>
    )
  }
}
