// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { WebsitePort } from '@/types/website'

@Component
export default class StepResponseProxyProtocol extends Vue {
  @Prop({ default: () => [] }) ports!: WebsitePort[]
  @Prop({ default: false }) realipConfigEnable!: boolean
  @Prop({ default: '' }) setRealIpFrom!: string

  get hasProxyProtocolPort() {
    return this.ports.some(p => p.proxy_protocol)
  }

  render(h: any) {
    return (
      <div>
        <el-form-item label="Proxy Protocol 配置">
          <el-switch value={this.realipConfigEnable} on-input={(v: boolean) => this.$emit('realip-toggle', v)}
            disabled={!this.hasProxyProtocolPort} />
          <span style="margin-left:8px;font-size:12px;color:#909399">
            {!this.hasProxyProtocolPort ? '（无端口启用 Proxy Protocol）' : ''}
          </span>
        </el-form-item>
        {this.realipConfigEnable && (
          <el-form-item label="set_real_ip_from">
            <el-input value={this.setRealIpFrom} on-input={(v: string) => this.$emit('realip-from-change', v)}
              placeholder="样例：10.0.0.0/24" style="width:360px" />
          </el-form-item>
        )}
        {this.realipConfigEnable && (
          <el-form-item label="real_ip_header">
            <el-input value="proxy_protocol" disabled style="width:200px" />
          </el-form-item>
        )}
      </div>
    )
  }
}
