// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { ipGroupList } from '@/api/captain-ip-group'

const IpSource = {
  socket: 'Socket',
  xffLeft: 'xff_left',
  xffRight: 'xff_right',
  customHeader: 'custom_header',
  rightmostNonProxy: 'rightmost_non_proxy_ip',
}

const addSourceLabels: Record<string, string> = {
  [IpSource.socket]: '从 Socket 连接中获取',
  [IpSource.xffLeft]: '从 X-Forwarded-For 左起第 N 层',
  [IpSource.xffRight]: '从 X-Forwarded-For 右起第 N 层',
  [IpSource.customHeader]: '从 HTTP 头中获取',
  [IpSource.rightmostNonProxy]: '从 Socket 和 X-Forwarded-For 中获取最后一层非信任 IP',
}

const socketValues = ['Socket', 'from_socket']

function isSocketSource(val: string): boolean {
  return socketValues.includes(val)
}

export function ipSourceDisplayText(val: string): string {
  if (val === 'Socket' || val === 'from_socket') return 'Socket'
  if (val === 'rightmost_non_proxy_ip') return '最后一层非信任代理IP'
  const xffMatch = val.match(/^X-Forwarded-For:(-?\d+)$/)
  if (xffMatch) {
    const n = parseInt(xffMatch[1])
    return n > 0 ? `X-Forwarded-For 左起第${n}层` : `X-Forwarded-For 右起第${-n}层`
  }
  if (val.startsWith('custom:')) return `HTTP 头 [${val.slice(7)}]`
  if (val === 'from_x_forwarded_for') return 'X-Forwarded-For'
  if (val === 'from_x_real_ip') return 'X-Real-IP'
  if (val === 'from_proxy_protocol') return 'Proxy Protocol'
  if (val === 'XForwardedFor') return 'X-Forwarded-For'
  if (val === 'ProxyProtocol') return 'Proxy Protocol'
  if (val === 'RealIP') return 'Real IP'
  return `HTTP 头 [${val}]`
}

@Component
export default class SourceIpDialog extends Vue {
  @Prop() value!: string[]
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) proxyIpList!: string[]
  @Prop({ default: () => [] }) proxyIpGroups!: number[]

  newSourceType = ''
  xffLevel = 1
  customHeaderName = ''
  trustIpType = 'ipList'
  localProxyIpList: string[] = []
  localProxyIpGroups: number[] = []
  ipGroups: any[] = []
  editingIndex: number | null = null

  created() {
    this.localProxyIpList = [...this.proxyIpList]
    this.localProxyIpGroups = [...this.proxyIpGroups]
    this.trustIpType = this.localProxyIpGroups.length > 0 ? 'ipGroup' : 'ipList'
    if (this.captainInstanceId) {
      ipGroupList(this.captainInstanceId, 0, 500).then((r: any) => {
        if (r.err === null) this.ipGroups = Array.isArray(r.data) ? r.data : (r.data?.items || [])
      }).catch(() => {})
    }
  }

  get sources() { return this.value || [] }
  get isSocket() { return isSocketSource }
  get hasRightmostNonProxy() { return this.sources.includes('rightmost_non_proxy_ip') }
  get isEditing() { return this.editingIndex !== null }
  get actionTitle() { return this.isEditing ? '编辑源 IP 获取方式' : '添加源 IP 获取方式' }
  get actionButtonText() { return this.isEditing ? '保存' : '添加' }

  getSavePayload() {
    return {
      detector_ip_source: this.sources,
      proxy_ip_list: this.hasRightmostNonProxy ? this.localProxyIpList : [],
      proxy_ip_groups: this.hasRightmostNonProxy ? this.localProxyIpGroups : [],
    }
  }

  handleTrustIpInput(v: string) {
    this.localProxyIpList = v.split('\n').map((s: string) => s.trim()).filter(Boolean)
  }

  handleTrustIpGroupInput(v: number[]) {
    this.localProxyIpGroups = v
  }

  handleTrustIpTypeInput(v: string) {
    this.trustIpType = v
    if (v === 'ipGroup') this.localProxyIpList = []
    else this.localProxyIpGroups = []
  }

  getInputSourceValue() {
    let val = ''
    if (this.newSourceType === IpSource.socket) val = 'Socket'
    else if (this.newSourceType === IpSource.xffLeft) val = `X-Forwarded-For:${this.xffLevel}`
    else if (this.newSourceType === IpSource.xffRight) val = `X-Forwarded-For:${-this.xffLevel}`
    else if (this.newSourceType === IpSource.customHeader) val = this.customHeaderName
    else if (this.newSourceType === IpSource.rightmostNonProxy) val = 'rightmost_non_proxy_ip'
    return val.trim()
  }

  resetInput() {
    this.newSourceType = ''
    this.xffLevel = 1
    this.customHeaderName = ''
    this.editingIndex = null
  }

  isDuplicateSource(val: string) {
    return this.sources.some((s: string, i: number) => s === val && i !== this.editingIndex)
  }

  upsertSource() {
    const val = this.getInputSourceValue()
    if (!val || this.isDuplicateSource(val)) return
    if (this.isEditing) {
      const list = [...this.sources]
      const old = list[this.editingIndex as number]
      list.splice(this.editingIndex as number, 1, val)
      if (old === 'rightmost_non_proxy_ip' && val !== 'rightmost_non_proxy_ip' && !list.includes('rightmost_non_proxy_ip')) {
        this.localProxyIpList = []
        this.localProxyIpGroups = []
      }
      this.$emit('input', list)
    } else {
      const withoutSocket = this.sources.filter(s => !this.isSocket(s))
      const newSources = [val, ...withoutSocket, 'Socket']
      this.$emit('input', newSources)
    }
    this.resetInput()
  }

  editSource(index: number) {
    const val = this.sources[index]
    if (this.isSocket(val)) return
    this.editingIndex = index
    if (val === 'rightmost_non_proxy_ip') {
      this.newSourceType = IpSource.rightmostNonProxy
      this.trustIpType = this.localProxyIpGroups.length > 0 ? 'ipGroup' : 'ipList'
    } else if (val.startsWith('X-Forwarded-For:')) {
      const n = parseInt(val.split(':')[1])
      this.newSourceType = n > 0 ? IpSource.xffLeft : IpSource.xffRight
      this.xffLevel = Math.abs(n) || 1
    } else {
      this.newSourceType = IpSource.customHeader
      this.customHeaderName = val.startsWith('custom:') ? val.slice(7) : val
    }
  }

  cancelEdit() {
    this.resetInput()
  }

  addSource() {
    this.upsertSource()
  }

  removeSource(index: number) {
    if (this.isSocket(this.sources[index])) return
    const list = [...this.sources]
    const removed = list[index]
    list.splice(index, 1)
    if (removed === 'rightmost_non_proxy_ip') {
      this.localProxyIpList = []
      this.localProxyIpGroups = []
    }
    this.$emit('input', list)
    if (this.editingIndex === index) this.resetInput()
  }

  moveUp(index: number) {
    if (index === 0) return
    if (this.isSocket(this.sources[index]) && index === this.sources.length - 1) return
    const list = [...this.sources]
    ;[list[index - 1], list[index]] = [list[index], list[index - 1]]
    this.$emit('input', list)
  }

  moveDown(index: number) {
    if (index >= this.sources.length - 1) return
    if (this.isSocket(this.sources[index + 1]) && index + 1 === this.sources.length - 1) return
    const list = [...this.sources]
    ;[list[index], list[index + 1]] = [list[index + 1], list[index]]
    this.$emit('input', list)
  }

  render(h: any) {
    const sources = this.sources
    const canSubmit = !!this.getInputSourceValue()
    return (
      <div>
        <el-alert type="info" closable={false} style="margin-bottom:12px"
          description="获取方式是一个列表，从列表第一项开始查找，若不存在或者是非法的 IP 格式则尝试下一条，最后一项必须是从 Socket 中获取。" />
        <div style="margin-bottom:12px">
          <div style="margin-bottom:8px;font-weight:500">当前链路顺序</div>
          {sources.length === 0 && <div style="color:#909399">未配置，请添加源 IP 获取方式</div>}
          {sources.map((s: string, i: number) => (
            <div key={i} class="source-ip-source-row" style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
              <el-tag size="small">{ipSourceDisplayText(s)}</el-tag>
              <el-button type="text" icon="el-icon-top" on-click={() => this.moveUp(i)} disabled={i === 0 || (this.isSocket(s) && i === sources.length - 1)} />
              <el-button type="text" icon="el-icon-bottom" on-click={() => this.moveDown(i)} disabled={i === sources.length - 1 || (this.isSocket(sources[i + 1]) && i + 1 === sources.length - 1)} />
              <el-button type="text" icon="el-icon-edit" on-click={() => this.editSource(i)} disabled={this.isSocket(s)} />
              {!this.isSocket(s) && <el-button type="text" icon="el-icon-delete" on-click={() => this.removeSource(i)} />}
            </div>
          ))}
        </div>
        <el-divider />
        <div style="margin-bottom:8px;font-weight:500">{this.actionTitle}</div>
        <el-select value={this.newSourceType} on-input={(v: string) => { this.newSourceType = v }} disabled={this.isEditing} style="width:100%;margin-bottom:8px" placeholder="选择获取方式">
          {Object.entries(addSourceLabels).map(([k, v]) => <el-option key={k} label={v} value={k} />)}
        </el-select>
        {this.newSourceType === IpSource.xffLeft && (
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="width:80px;text-align:right;color:#606266">左起层级</span>
            <el-input-number value={this.xffLevel} on-input={(v: number) => { this.xffLevel = v }} min={1} controls={false} style="width:200px" />
          </div>
        )}
        {this.newSourceType === IpSource.xffRight && (
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="width:80px;text-align:right;color:#606266">右起层级</span>
            <el-input-number value={this.xffLevel} on-input={(v: number) => { this.xffLevel = v }} min={1} controls={false} style="width:200px" />
          </div>
        )}
        {this.newSourceType === IpSource.customHeader && (
          <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
            <span style="width:80px;text-align:right;color:#606266">Header 名</span>
            <el-input value={this.customHeaderName} on-input={(v: string) => { this.customHeaderName = v }} style="width:300px" placeholder="X-Real-IP" />
          </div>
        )}
        {this.newSourceType === IpSource.rightmostNonProxy && (
          <div style="margin-bottom:8px">
            <el-radio-group value={this.trustIpType} on-input={(v: string) => this.handleTrustIpTypeInput(v)} style="margin-bottom:8px">
              <el-radio label="ipList">填写 IP</el-radio>
              <el-radio label="ipGroup">选择 IP 组</el-radio>
            </el-radio-group>
            {this.trustIpType === 'ipList' && (
              <el-input type="textarea" value={this.localProxyIpList.join('\n')} on-input={(v: string) => this.handleTrustIpInput(v)} rows={3} placeholder="每行一个 IP 或 CIDR，最多100条" />
            )}
            {this.trustIpType === 'ipGroup' && (
              this.ipGroups.length > 0
                ? <el-select value={this.localProxyIpGroups} on-input={(v: number[]) => this.handleTrustIpGroupInput(v)} multiple style="width:100%">
                  {this.ipGroups.map((g: any) => <el-option key={g.id} label={g.name || `IP组${g.id}`} value={g.id} />)}
                </el-select>
                : <div style="color:#909399">暂无可选 IP 组</div>
            )}
          </div>
        )}
        {this.newSourceType && <div style="display:flex;gap:8px;margin-top:8px">
          <el-button size="small" type="primary" on-click={this.addSource} disabled={!canSubmit}>{this.actionButtonText}</el-button>
          {this.isEditing && <el-button size="small" on-click={this.cancelEdit}>取消</el-button>}
        </div>}
      </div>
    )
  }
}
