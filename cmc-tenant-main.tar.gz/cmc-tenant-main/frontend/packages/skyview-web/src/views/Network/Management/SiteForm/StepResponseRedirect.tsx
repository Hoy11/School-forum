// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class StepResponseRedirect extends Vue {
  @Prop({ default: null }) statusCode!: number | null
  @Prop({ default: '' }) path!: string

  render(h: any) {
    return (
      <div>
        <el-form-item label="状态码" required>
          <el-input value={this.statusCode || ''} on-input={(v: string) => this.$emit('status-change', parseInt(v) || null)}
            placeholder="300-399" style="width:160px" />
        </el-form-item>
        <el-form-item label="重定向地址" required>
          <el-input value={this.path} on-input={(v: string) => this.$emit('path-change', v)}
            placeholder="https://example.com" style="width:360px" />
        </el-form-item>
        <el-alert title='请勿输入 payload 及可被拦截动作自定义规则命中的内容。' type="warning" show-icon closable={false} />
      </div>
    )
  }
}
