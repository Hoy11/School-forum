// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import { wafBindingList } from '@/api/binding'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { WafBindingWithInfo } from '@/types/tenant'
import { isAdmin } from '@/permission'

const SUPPORTED_WAF_VERSION = '23.01.014'

@Component({ components: { Grid, ConditionFilter } })
export default class WafList extends Vue {
  filterConditions: Condition[] = []

  filterFields = [
    { label: '实例名称', value: 'instance_name', type: 'text', operators: [{ label: '等于', value: '=' }] },
    { label: '状态', value: 'instance_status', type: 'choice', operators: [
      { label: '等于', value: '=' },
      { label: '不等于', value: '!=' },
    ], choices: [
      { label: '在线', value: 'HEALTHY' },
      { label: '异常', value: 'UNHEALTHY' },
      { label: '离线', value: 'OFFLINE' },
      { label: '宕机', value: 'DOWN' },
    ] },
    { label: '版本', value: 'version', type: 'text', operators: [{ label: '等于', value: '=' }] },
  ]

  get columns(): ColumnDef[] {
    const cols: ColumnDef[] = [
      { key: 'captain_instance_id', title: '实例 ID', width: 100 },
      { key: 'instance_name', title: 'WAF 名称' },
      { key: 'instance_host', title: '地址' },
      { key: 'version', title: '版本', width: 150, render: (h: any, row: WafBindingWithInfo) => this.renderVersion(h, row) },
      { key: 'instance_status', title: '状态' },
    ]
    if (isAdmin()) {
      cols.push({ key: 'bound_tenant_groups', title: '绑定租户组', minWidth: 160 })
    }
    return cols
  }

  isSupportedVersion(version?: string) {
    return !!version && version.startsWith(SUPPORTED_WAF_VERSION)
  }

  renderVersion(h: any, row: WafBindingWithInfo) {
    const version = row.version || '未知'
    const showRisk = !this.isSupportedVersion(row.version)
    if (!showRisk) return <span>{version}</span>

    return (
      <span style="display:inline-flex;align-items:center;gap:6px">
        <span>{version}</span>
        <el-tooltip content={`当前系统基于雷池 ${SUPPORTED_WAF_VERSION} 版本开发，该 WAF 版本可能存在兼容性风险`} placement="top">
          <i class="el-icon-warning" style="color:#E6A23C;cursor:pointer;font-size:16px" />
        </el-tooltip>
      </span>
    )
  }

  fetchData = async (offset: number, count: number, conditions: Condition[]) => {
    const resp = await wafBindingList(offset, count, conditions)
    if (resp.err === null && resp.data?.items) {
      // 聚合每个 WAF 的所有租户组名
      const groupMap = new Map<number, string[]>()
      resp.data.items.forEach((w: WafBindingWithInfo) => {
        if (!groupMap.has(w.captain_instance_id)) {
          groupMap.set(w.captain_instance_id, [])
        }
        if (w.tenant_group_name && !groupMap.get(w.captain_instance_id)!.includes(w.tenant_group_name)) {
          groupMap.get(w.captain_instance_id)!.push(w.tenant_group_name)
        }
      })
      // 按 captain_instance_id 去重
      const seen = new Set<number>()
      resp.data.items = resp.data.items.filter((w: WafBindingWithInfo) => {
        if (seen.has(w.captain_instance_id)) return false
        seen.add(w.captain_instance_id)
        return true
      })
      // 写入合并后的租户组名
      resp.data.items.forEach((w: WafBindingWithInfo) => {
        w.bound_tenant_groups = w.bound_tenant_groups || (groupMap.get(w.captain_instance_id) || []).join('，')
      })
    }
    return resp
  }

  handleFilterSearch(conditions: Condition[]) {
    this.filterConditions = conditions
  }

  navigateTo(row: WafBindingWithInfo, routeName: string) {
    this.$router.push({ name: routeName, query: { waf: String(row.captain_instance_id) } })
  }

  render(h: any) {
    return (
      <div>
        <ConditionFilter conditions={this.filterConditions} fields={this.filterFields} on-change={(c: Condition[]) => { this.filterConditions = c }} on-search={this.handleFilterSearch} />
        <Grid columns={[...this.columns, { key: 'actions', title: '操作', width: 350, render: (h: any, row: WafBindingWithInfo) => (
          <span>
            <el-button type="text" on-click={() => this.navigateTo(row, 'siteManagement')}>站点</el-button>
            <el-button type="text" on-click={() => this.navigateTo(row, 'ipGroup')}>IP组</el-button>
            <el-button type="text" on-click={() => this.navigateTo(row, 'sslCert')}>SSL</el-button>
            <el-button type="text" on-click={() => this.navigateTo(row, 'policy')}>策略</el-button>
            <el-button type="text" on-click={() => this.navigateTo(row, 'policyRule')}>规则</el-button>
          </span>
        )}]} fetchData={this.fetchData} defaultConditions={this.filterConditions} />
      </div>
    )
  }
}
