// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website } from '@/types/website'
import { createFieldUpdater } from '../useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'
import FieldEditDialog from '@/components/FieldEditDialog'
import SourceIpDialog from './SourceIpDialog'
import { ipSourceDisplayText } from './SourceIpDialog'

@Component({ components: { EditableRow, FieldEditDialog, SourceIpDialog } })
export default class SourceIpCard extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number

  dialogVisible = false
  dialogValue: string[] = []
  dialogSaving = false

  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }

  get ipSourceText() {
    const src = this.site.detector_ip_source || []
    if (!src.length) return '-'
    return src.map((s: string) => ipSourceDisplayText(s)).join(' → ')
  }

  openDialog() {
    this.dialogValue = JSON.parse(JSON.stringify(this.site.detector_ip_source || []))
    this.dialogVisible = true
  }

  async handleDialogSave() {
    const dialog = this.$refs.dialog as SourceIpDialog
    const payload = dialog.getSavePayload()
    this.dialogSaving = true
    try {
      await this.updateField(payload)
      this.dialogVisible = false
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.dialogSaving = false
    }
  }

  render(h: any) {
    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">源 IP 获取方式</div>
        <EditableRow label="源 IP 获取方式" editable mode="dialog"
          on-edit-click={this.openDialog}
          scopedSlots={{
            default: () => {
              const sources = this.site.detector_ip_source || []
              if (!sources.length) return <span style="color:#909399">未配置</span>
              return <span>{sources.map((s: string, i: number) => (
                <span>
                  <el-tag size="small" style="margin:2px">{ipSourceDisplayText(s)}</el-tag>
                  {i < sources.length - 1 && <span style="margin:0 4px;color:#909399">→</span>}
                </span>
              ))}</span>
            },
          }} />
        <FieldEditDialog visible={this.dialogVisible} title="编辑源 IP 获取方式"
          loading={this.dialogSaving} width="600px"
          on-close={() => { this.dialogVisible = false }}
          on-submit={this.handleDialogSave}>
          <SourceIpDialog ref="dialog" value={this.dialogValue}
            on-input={(v: string[]) => { this.dialogValue = v }}
            captainInstanceId={this.captainInstanceId}
            proxyIpList={this.site.proxy_ip_list || []}
            proxyIpGroups={this.site.proxy_ip_groups || []} />
        </FieldEditDialog>
      </el-card>
    )
  }
}
