// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

interface KVPair { key: string; value: string }

@Component
export default class CustomConfigDialog extends Vue {
  @Prop() value!: KVPair[]

  addRow() {
    this.$emit('input', [...this.value, { key: '', value: '' }])
  }

  removeRow(index: number) {
    const list = [...this.value]
    list.splice(index, 1)
    this.$emit('input', list)
  }

  updateField(index: number, field: string, val: string) {
    const list = [...this.value]
    list[index] = { ...list[index], [field]: val }
    this.$emit('input', list)
  }

  render(h: any) {
    const rows = this.value || []
    return (
      <div>
        <el-table data={rows} size="small" border>
          <el-table-column label="键" scopedSlots={{
            default: ({ row, $index }) => (
              <el-input value={row.key} on-input={(v: string) => this.updateField($index, 'key', v)} size="small" />
            ),
          }} />
          <el-table-column label="值" scopedSlots={{
            default: ({ row, $index }) => (
              <el-input value={row.value} on-input={(v: string) => this.updateField($index, 'value', v)} size="small" />
            ),
          }} />
          <el-table-column label="操作" width={60} scopedSlots={{
            default: ({ $index }) => (
              <el-button type="text" icon="el-icon-delete" on-click={() => this.removeRow($index)} />
            ),
          }} />
        </el-table>
        <el-button size="small" icon="el-icon-plus" on-click={this.addRow} style="margin-top:8px">添加</el-button>
        <el-alert type="error" closable={false} style="margin-top:8px" description="请确认添加的详细配置生效于 nginx location 块，否则将导致转发服务异常" />
        <el-alert type="warning" closable={false} style="margin-top:4px" description="该配置会修改 nginx 代理服务器默认参数，参数值中请勿添加分号" />
      </div>
    )
  }
}
