// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { BotSecurityType } from '@/types/website-security'

const ds = 'display:flex;border-bottom:1px solid #ebeef5;padding:8px 12px'
const ls = 'color:#909399;width:120px;flex-shrink:0;font-size:13px'
const vs = 'flex:1;font-size:13px;word-break:break-all'

@Component
export default class SiteBotTab extends Vue {
  @Prop() site!: any

  get bot() { return this.site.bot_config }

  get h() { return this.$createElement }

  row(label: string, value: any) {
    const h = this.h
    return h('div', { style: ds }, [
      h('span', { style: ls }, label),
      h('span', { style: vs }, [value || '-']),
    ])
  }

  ruleText(rule: any): string {
    if (!rule) return '-'
    if (!rule.is_enabled) return '未启用'
    const count = rule.pattern?.$AND?.length || 0
    return count > 0 ? `已启用 (${count} 条条件)` : '已启用'
  }

  render(h: any) {
    const bot = this.bot
    if (!bot) return <div style="color:#909399;padding:20px">无主动防护配置</div>

    const protLabel = bot.protection === BotSecurityType.js ? 'JS 挑战' : bot.protection === BotSecurityType.code ? '验证码' : `类型 ${bot.protection}`

    return (
      <div style="border:1px solid #ebeef5;border-radius:4px">
        {this.row('防护状态', <el-tag size="mini" type={bot.is_enabled ? 'success' : 'info'}>{bot.is_enabled ? '已启用' : '未启用'}</el-tag>)}
        {this.row('防护类型', protLabel)}
        {this.row('过期时间', bot.expire_period ? `${bot.expire_period} 秒` : '-')}
        {this.row('包含规则', this.ruleText(bot.include_rule))}
        {this.row('排除规则', this.ruleText(bot.exclude_rule))}
        {this.row('日志选项', bot.log_option === 'Persistence' ? '持久化' : bot.log_option === 'Drop' ? '丢弃' : bot.log_option || '-')}
        {this.row('排除已知 Bot', bot.exclude_known_bot?.length > 0
          ? bot.exclude_known_bot.map((b: string) => <el-tag size="mini" style="margin:2px">{b}</el-tag>)
          : '无')}
      </div>
    )
  }
}
