// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Website, PolicyModel, AssetGroupType } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { SessionType } from '@/types/website-security'
import { getDefaultReverseProxySite, prepareSiteForSubmit } from '@/utils/site'
import { siteCreate, siteUpdate } from '@/api/captain-site'
import SiteStatusField from './SiteStatusField'
import SiteNameField from './SiteNameField'
import HostField from './HostField'
import SimplePortField from './SimplePortField'
import UrlPathsField from './UrlPathsField'
import RemarkField from './RemarkField'
import PolicyField from './PolicyField'
import SessionMethodField from './SessionMethodField'
import AssetGroupField from './AssetGroupField'

@Component({ components: { SiteStatusField, SiteNameField, HostField, SimplePortField, UrlPathsField, RemarkField, PolicyField, SessionMethodField, AssetGroupField } })
export default class ClusterSite extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: null }) editingItem!: Website | null
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) policyGroups!: PolicyModel[]
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]
  @Prop({ default: '' }) operationMode!: string

  form: Website = { ...getDefaultReverseProxySite() }
  submitting = false

  get isDType() {
    return this.operationMode === WorkGroupOperationMode.SoftwarePortMirroring
  }

  get isProxy() { return true }

  @Watch('visible', { immediate: true })
  onVisibleChange(val: boolean) {
    if (!val) return
    this.form = this.editingItem?.id
      ? { ...getDefaultReverseProxySite(), ...this.editingItem }
      : getDefaultReverseProxySite()
    // C/D 型端口强制无 SSL
    this.form.ports = this.form.ports.map(p => ({ ...p, ssl: false, http2: false, sni: false, non_http: false, proxy_protocol: false }))
  }

  async handleSubmit() {
    if (!this.form.name) {
      this.$message.error('请输入站点名称'); return
    }
    if (!this.form.ports?.length || !this.form.ports.some(p => p.port)) {
      this.$message.error('请输入端口'); return
    }
    // C 型用户识别空参数校验
    if (!this.isDType && this.$refs.sessionField && !(this.$refs.sessionField as any).validate()) {
      return
    }

    this.submitting = true
    try {
      this.form.operation_mode = this.operationMode as WorkGroupOperationMode
      // D 型强制 session_method off
      if (this.isDType) {
        this.form.session_method = { type: SessionType.off, param: '' }
      }
      const data = prepareSiteForSubmit(this.form)

      if (this.editingItem?.id) {
        const resp = await siteUpdate({ ...data, id: this.editingItem.id, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '更新失败'); return }
      } else {
        const resp = await siteCreate({ ...data, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '创建失败'); return }
      }
      this.$emit('success')
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    } finally {
      this.submitting = false
    }
  }

  render(h: any) {
    if (!this.visible) return null

    return (
      <el-dialog title={this.editingItem ? '编辑站点' : '新建站点'}
        visible={this.visible} on-close={() => this.$emit('close')}
        width="60%" top="5vh" close-on-click-modal={false} close-on-press-escape={false} destroy-on-close>

        <el-form label-width="140px" size="small">
          <SiteStatusField value={this.form.is_enabled} on-input={(v: boolean) => { this.form.is_enabled = v }} />
          <SiteNameField value={this.form.name} on-input={(v: string) => { this.form.name = v }} />
          <SimplePortField value={this.form.ports} on-input={(v: any[]) => { this.form.ports = v }} />
          <HostField value={this.form.server_names} on-input={(v: string[]) => { this.form.server_names = v }} />

          {!this.isDType && (
            <UrlPathsField value={this.form.url_paths} on-input={(v: any[]) => { this.form.url_paths = v }} />
          )}

          <RemarkField value={this.form.remark} on-input={(v: string) => { this.form.remark = v }} />
          <PolicyField value={this.form.policy_group} policyGroups={this.policyGroups}
            on-input={(v: number | null) => { this.form.policy_group = v }} />

          {!this.isDType && (
            <SessionMethodField ref="sessionField" value={this.form.session_method}
              isProxy={this.isProxy} on-input={(v: any) => { this.form.session_method = v }} />
          )}

          <AssetGroupField value={this.form.asset_group} assetGroups={this.assetGroups}
            on-input={(v: number) => { this.form.asset_group = v }} />
        </el-form>

        <div slot="footer">
          <el-button on-click={() => this.$emit('close')}>取消</el-button>
          <el-button type="primary" on-click={this.handleSubmit} loading={this.submitting}>确定</el-button>
        </div>
      </el-dialog>
    )
  }
}
