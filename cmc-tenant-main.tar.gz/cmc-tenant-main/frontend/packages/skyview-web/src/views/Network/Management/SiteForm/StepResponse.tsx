// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, BackendType } from '@/types/website'
import { backendTypeOptions } from '@/utils/site'
import StepResponseProxy from './StepResponseProxy'
import StepResponseRedirect from './StepResponseRedirect'
import StepResponseCustom from './StepResponseCustom'
import StepResponseProxyProtocol from './StepResponseProxyProtocol'

@Component({ components: { StepResponseProxy, StepResponseRedirect, StepResponseCustom, StepResponseProxyProtocol } })
export default class StepResponse extends Vue {
  @Prop() form!: Website
  @Prop({ default: false }) ntlmEnabled!: boolean

  get bc() { return this.form.backend_config || {} }
  get isProxy() { return this.bc.type === BackendType.proxy }
  get isRedirect() { return this.bc.type === BackendType.redirect }
  get isResponse() { return this.bc.type === BackendType.response }

  handleBackendTypeChange(v: BackendType) {
    if (v === BackendType.proxy) {
      this.form.backend_config = { type: v, load_balance_policy: 'Round Robin', servers: [{ host: '', port: 80, protocol: 'http', is_enabled: true, weight: '', health_check_status: '' }], header_config: [], x_forwarded_for_action: 'append', health_check_config: { is_enabled: false, check_type: 'http', host: '', port: 80, path: '/', check_http_expect_alive: ['http_2xx', 'http_3xx'], interval: 30000, timeout: 1000, fall: 2, rise: 5, method: 'GET' }, session_sticky_cookie_max_age: null, keepalive_config: 'default_keepalive_config', keepalive: '', keepalive_timeout: '', custom_config: { ignore_types: [], custom: {}, custom_web: [] }, slow_attack: { is_enabled: false } }
    } else {
      this.form.backend_config = { type: v, status_code: null, path: '' }
    }
  }

  render(h: any) {
    return (
      <div>
        {!this.ntlmEnabled ? (
          <el-form-item label="响应方式">
            <el-radio-group value={this.bc.type} on-input={this.handleBackendTypeChange}>
              {backendTypeOptions.map(opt => (
                <el-radio label={opt.value}>{opt.label}</el-radio>
              ))}
            </el-radio-group>
          </el-form-item>
        ) : (
          <el-form-item label="响应方式">
            <span>转发（NTLM 模式固定）</span>
          </el-form-item>
        )}

        {this.isProxy && (
          <StepResponseProxy
            loadBalancePolicy={this.bc.load_balance_policy}
            servers={this.bc.servers}
            cookieMaxAge={this.bc.session_sticky_cookie_max_age}
            xForwardedFor={this.bc.x_forwarded_for_action}
            ntlmEnabled={this.ntlmEnabled}
            on-lb-change={(v: any) => { this.bc.load_balance_policy = v }}
            on-servers-change={(v: any) => { this.bc.servers = v }}
            on-cookie-age-change={(v: any) => { this.bc.session_sticky_cookie_max_age = v }}
            on-xff-change={(v: any) => { this.bc.x_forwarded_for_action = v }}
          />
        )}

        {this.isRedirect && (
          <StepResponseRedirect
            statusCode={this.bc.status_code}
            path={this.bc.path}
            on-status-change={(v: any) => { this.bc.status_code = v }}
            on-path-change={(v: any) => { this.bc.path = v }}
          />
        )}

        {this.isResponse && (
          <StepResponseCustom
            statusCode={this.bc.status_code}
            path={this.bc.path}
            on-status-change={(v: any) => { this.bc.status_code = v }}
            on-path-change={(v: any) => { this.bc.path = v }}
          />
        )}

        <StepResponseProxyProtocol
          ports={this.form.ports}
          realipConfigEnable={this.form.realip_config_enable}
          setRealIpFrom={this.form.realip_config?.set_real_ip_from || ''}
          on-realip-toggle={(v: boolean) => { this.form.realip_config_enable = v }}
          on-realip-from-change={(v: string) => { this.form.realip_config = { ...this.form.realip_config, set_real_ip_from: v } }}
        />
      </div>
    )
  }
}
