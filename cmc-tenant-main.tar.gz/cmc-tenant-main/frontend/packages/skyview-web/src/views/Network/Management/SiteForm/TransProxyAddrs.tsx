// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { WAddr } from '@/types/website'
import { getDefaultWAddr } from '@/utils/site'

@Component
export default class TransProxyAddrs extends Vue {
  @Prop({ default: () => [getDefaultWAddr()] }) value!: WAddr[]
  @Prop({ default: false }) bare!: boolean

  handleInput(v: string) {
    const lines = v.split('\n').filter(Boolean)
    const ssl = this.value.some(a => a.ssl)
    const http2 = this.value.some(a => a.ssl && a.http2)
    const sni = this.value.some(a => a.ssl && a.sni)
    const nonHttp = this.value.some(a => a.non_http)
    const addrs = lines.map(line => {
      const existing = this.value.find(a => a.ip_port === line.trim())
      return existing || { ...getDefaultWAddr(), ip_port: line.trim(), ssl, http2, sni, non_http: nonHttp }
    })
    this.$emit('input', addrs)
  }

  get displayValue() {
    return this.value.map(a => a.ip_port).join('\n')
  }

  render(h: any) {
    const input = <el-input value={this.displayValue} on-input={this.handleInput}
      type="textarea" rows={4} placeholder="每行一个，格式: IP:端口" />
    if (this.bare) return input
    return <el-form-item label="服务器地址" required>{input}</el-form-item>
  }
}
