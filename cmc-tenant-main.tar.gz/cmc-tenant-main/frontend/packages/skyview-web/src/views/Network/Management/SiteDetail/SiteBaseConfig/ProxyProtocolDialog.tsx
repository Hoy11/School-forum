// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class ProxyProtocolDialog extends Vue {
  @Prop() value!: any

  get v() { return this.value || {} }
  get enabled() { return !!this.v.realip_config_enable }
  get rc() { return this.v.realip_config || {} }

  emit(v: any) { this.$emit('input', v) }

  render(h: any) {
    const v = this.v, rc = this.rc, en = this.enabled
    return (
      <el-form label-width="130px" size="small">
        <el-form-item label="启用 Proxy Protocol">
          <el-switch value={!!v.realip_config_enable} on-input={(val: boolean) => this.emit({ ...v, realip_config_enable: val })} />
        </el-form-item>
        {en && [
          <el-form-item label="信任来源 IP">
            <el-input value={rc.set_real_ip_from || ''} on-input={(val: string) => this.emit({ ...v, realip_config: { ...rc, set_real_ip_from: val } })} style="width:300px" placeholder="样例：10.0.0.0/24" />
          </el-form-item>,
          <el-form-item label="real_ip_header">
            <el-input value="proxy_protocol" disabled style="width:300px" />
          </el-form-item>,
        ]}
      </el-form>
    )
  }
}
