// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { certDetail, certUpdate, certEdit } from '@/api/captain-cert'
import { CertInfo } from '@/api/captain-cert'
import { format } from 'date-fns'
import { isAdmin } from '@/permission'

@Component
export default class SslCertDetailPage extends Vue {
  get certId(): number { return Number(this.$route.query.id || 0) }
  get wafId(): number { return Number(this.$route.query.waf || 0) }

  get isShared(): boolean { return (this.detail?.binding_count ?? 0) > 1 }
  get hasExternalRef(): boolean { return this.detail?.has_external_ref === true }
  get isSystemCert(): boolean { return this.detail?.is_system_cert === true || this.detail?.is_mgt_api_cert === true }

  get isEditProtected(): boolean {
    if (isAdmin()) return false  // admin 通过确认框放行，不在此处硬拦截
    return this.isSystemCert || this.isShared || this.hasExternalRef
  }

  get editTooltip(): string {
    if (isAdmin()) {
      if (this.isSystemCert) return '系统管理接口证书，点击后将弹出确认'
      if (this.isShared) {
        const groups = this.detail?.shared_group_names?.join('、') || '其他租户组'
        return `共享证书（${groups}），点击后将弹出确认`
      }
      return '编辑'
    }
    if (this.isSystemCert) return '该证书为系统管理接口证书，无法编辑'
    if (this.isShared) return '该资源被多个租户组绑定，无法编辑'
    if (this.hasExternalRef) return '该SSL证书正在被其他站点引用，无法编辑'
    return '编辑'
  }

  adminEditConfirmMsg(): string {
    if (this.isSystemCert) return '此证书为系统管理接口证书，确认编辑？'
    if (this.isShared) {
      const groups = this.detail?.shared_group_names?.join('、') || '其他租户组'
      return `此证书被以下租户组共享：${groups}，确认编辑？`
    }
    const count = this.detail?.websites?.length ?? 0
    if (count > 0 || this.hasExternalRef) {
      return `此证书正在被 ${count} 个站点使用，编辑会立即生效，确认？`
    }
    if ((this.detail?.binding_count ?? 0) > 0) return '此证书已绑定给租户组，当前无站点引用，确认编辑？'
    return '确认编辑该证书？'
  }

  detail: CertInfo | null = null
  loading = false

  showEditName = false
  editName = ''

  showEditFile = false
  editCertFile: File | null = null
  editKeyFile: File | null = null
  editIncludeKey = false
  editPassword = ''

  created() { this.loadData() }

  async loadData() {
    this.loading = true
    try {
      const resp = await certDetail(this.certId, this.wafId)
      if (resp.err === null) this.detail = resp.data
    } finally {
      this.loading = false
    }
  }

  formatTime(ts: number) {
    if (!ts) return '-'
    return format(new Date(ts * 1000), 'yyyy-MM-dd HH:mm:ss')
  }

  formatTimestamp(ts: number) {
    if (!ts) return '-'
    return format(new Date(ts * 1000), 'yyyy-MM-dd')
  }

  async openEditName() {
    if (this.isEditProtected) {
      this.$message.warning(this.editTooltip)
      return
    }
    if (isAdmin()) {
      try {
        await this.$confirm(this.adminEditConfirmMsg(), '提示', { type: 'warning' })
      } catch {
        return
      }
    }
    this.editName = this.detail?.name || ''
    this.showEditName = true
  }

  async submitEditName() {
    try {
      await certUpdate({ id: this.certId, captain_instance_id: this.wafId, name: this.editName })
      this.$message.success('修改成功')
      this.showEditName = false
      this.loadData()
    } catch (e: any) {
      this.handleProtectionError(e, '编辑')
    }
  }

  async openEditFile() {
    if (this.isEditProtected) {
      this.$message.warning(this.editTooltip)
      return
    }
    if (isAdmin()) {
      try {
        await this.$confirm(this.adminEditConfirmMsg(), '提示', { type: 'warning' })
      } catch {
        return
      }
    }
    this.editCertFile = null
    this.editKeyFile = null
    this.editIncludeKey = false
    this.editPassword = ''
    this.showEditFile = true
  }

  async submitEditFile() {
    if (!this.editCertFile) {
      this.$message.warning('请选择证书文件')
      return
    }
    const fd = new FormData()
    fd.append('id', String(this.certId))
    fd.append('crt_file', this.editCertFile)
    fd.append('password', this.editPassword)
    if (!this.editIncludeKey && this.editKeyFile) {
      fd.append('key_file', this.editKeyFile)
    }
    try {
      await certEdit(this.wafId, fd)
      this.$message.success('证书文件更新成功')
      this.showEditFile = false
      this.loadData()
    } catch (e: any) {
      this.handleProtectionError(e, '编辑')
    }
  }

  handleProtectionError(e: any, action: string) {
    const errCode = e?.response?.data?.err
    const errMsg = e?.response?.data?.msg
    if (errCode === 'system_cert') {
      this.$message.warning(errMsg || '该证书为系统管理接口证书，无法操作')
    } else if (errCode === 'in_use') {
      this.$message.warning(errMsg || `该SSL证书正在被其他站点引用，无法${action}`)
    } else if (errCode === 'shared') {
      this.$message.warning(errMsg || '该资源被多个租户组绑定')
    } else {
      this.$message.error(errMsg || e?.message || '操作失败')
    }
  }

  render(h: any) {
    const kvItem = (label: string, value: any, editable?: 'name' | 'file') => (
      <div style="display:flex;border-bottom:1px solid #EBEEF5;padding:12px 16px;line-height:24px;align-items:center">
        <div style="width:140px;flex-shrink:0;color:#909399;font-size:14px">{label}</div>
        <div style="flex:1;font-size:14px;word-break:break-all;display:flex;align-items:center">
          <span style="flex:1">{value}</span>
          {editable && <el-tooltip content={this.editTooltip} placement="top" disabled={!this.isEditProtected}>
            <i class="el-icon-edit"
              style={`cursor:${this.isEditProtected ? 'not-allowed' : 'pointer'};color:${this.isEditProtected ? '#ccc' : '#409EFF'};margin-left:8px;font-size:14px`}
              on-click={() => editable === 'name' ? this.openEditName() : this.openEditFile()} />
          </el-tooltip>}
        </div>
      </div>
    )

    const siteLinks = this.detail?.websites?.length
      ? this.detail.websites.map((w, i) => (
        <span>
          {i > 0 && '、'}
          <router-link to={{ name: 'siteDetail', query: { id: String(w.id), waf: String(this.wafId) } }} style="color:#409EFF;text-decoration:none">{w.name}</router-link>
        </span>
      ))
      : '-'

    return (
      <div v-loading={this.loading}>
        <el-page-header on-back={() => this.$router.back()} content="SSL 证书详情" />
        {this.detail && (
          <el-card style="margin-top: 16px">
            <div slot="header"><span>证书详情</span></div>
            <div style="border:1px solid #EBEEF5;border-radius:4px">
              {kvItem('名称', this.detail.name, 'name')}
              {kvItem('证书文件', this.detail.file_names?.length ? this.detail.file_names.join(', ') : '-', 'file')}
              {kvItem('证书签名', this.detail.signature || '-')}
              {kvItem('上传时间', this.formatTime(this.detail.create_time))}
              {kvItem('颁发者', this.detail.info?.issuer || '-')}
              {kvItem('序列号', this.detail.info?.serial || '-')}
              {kvItem('有效期', `${this.formatTimestamp(this.detail.info?.not_valid_before)} - ${this.formatTimestamp(this.detail.info?.not_valid_after)}`)}
              {kvItem('域名', this.detail.info?.domains?.length ? this.detail.info.domains.join(', ') : '-')}
              {kvItem('关联站点', siteLinks)}
            </div>
          </el-card>
        )}

        <el-dialog title="编辑名称" visible={this.showEditName} on-close={() => { this.showEditName = false }} width="420px">
          <el-form label-width="80px">
            <el-form-item label="名称"><el-input v-model={this.editName} /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showEditName = false }}>取消</el-button>
            <el-button type="primary" on-click={this.submitEditName}>确定</el-button>
          </div>
        </el-dialog>

        <el-dialog title="编辑证书文件" visible={this.showEditFile} on-close={() => { this.showEditFile = false }} width="520px">
          <el-form label-width="120px">
            <el-form-item label="是否含私钥"><el-checkbox v-model={this.editIncludeKey}>证书文件中包含私钥</el-checkbox></el-form-item>
            <el-form-item label="证书文件" required>
              <el-upload {...{ props: { onChange: (f: any) => { this.editCertFile = f.raw }, onRemove: () => { this.editCertFile = null } } }} drag action="" auto-upload={false} accept=".pem,.crt,.pfx,.p7b" limit={1}>
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将证书文件拖到此处，或<em>点击上传</em></div>
              </el-upload>
            </el-form-item>
            {!this.editIncludeKey && (
              <el-form-item label="私钥文件">
                <el-upload {...{ props: { onChange: (f: any) => { this.editKeyFile = f.raw }, onRemove: () => { this.editKeyFile = null } } }} drag action="" auto-upload={false} accept=".pem,.key" limit={1}>
                  <i class="el-icon-upload"></i>
                  <div class="el-upload__text">将私钥文件拖到此处，或<em>点击上传</em></div>
                </el-upload>
              </el-form-item>
            )}
            <el-form-item label="证书密码"><el-input v-model={this.editPassword} placeholder="如有密码请输入" /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showEditFile = false }}>取消</el-button>
            <el-button type="primary" on-click={this.submitEditFile}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
