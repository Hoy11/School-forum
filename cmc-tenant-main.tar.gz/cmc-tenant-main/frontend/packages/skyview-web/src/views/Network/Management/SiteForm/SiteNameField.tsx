// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class SiteNameField extends Vue {
  @Prop() value!: string
  @Prop({ default: false }) bare!: boolean

  render(h: any) {
    const input = <el-input value={this.value} on-input={(v: string) => this.$emit('input', v)} placeholder="请输入站点名称" />
    if (this.bare) return input
    return <el-form-item label="站点名称" required>{input}</el-form-item>
  }
}
