// @ts-nocheck
import { Component, Vue, Mixins, Watch } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { policyList, policyCreate, policyDelete } from '@/api/captain-policy'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { PolicyGroup } from '@/types/policy'
import { WafSelectorMixin } from '@/mixins/wafSelector'
import { isAdmin } from '@/permission'

@Component({ components: { Grid } })
export default class Policy extends Mixins(WafSelectorMixin) {
  get wafId(): number { return this.effectiveWafId }

  @Watch('wafReady')
  onWafReady() { if (this.wafReady) this.$nextTick(() => (this.$refs.grid as any)?.loadData()) }

  handleWafChange() { this.showWafOfflineMessage(); (this.$refs.grid as any)?.loadData() }

  showForm = false
  form = { name: '', comment: '' }

  // --- spec24-5 protection helpers ---

  isSystemDefault(row: PolicyGroup): boolean { return row.is_default ?? false }
  isInUse(row: PolicyGroup): boolean { return (row.site_count ?? 0) > 0 }
  isShared(row: PolicyGroup): boolean { return (row.binding_count ?? 0) > 1 }
  isEditProtected(row: PolicyGroup): boolean { return this.isShared(row) || (row.has_external_ref ?? false) }
  isDeleteProtected(row: PolicyGroup): boolean { return this.isSystemDefault(row) || this.isInUse(row) || this.isShared(row) }

  deleteTooltip(row: PolicyGroup): string {
    if (this.isSystemDefault(row)) return '该策略为默认防护策略模板，无法删除'
    if (this.isInUse(row)) return `该策略正在被 ${row.site_count} 个站点引用，无法删除`
    if (this.isShared(row)) return '该策略被多个租户组共享，无法删除'
    return '删除'
  }

  editTooltip(row: PolicyGroup): string {
    if (this.isShared(row)) return '该策略被多个租户组共享，无法修改'
    if (row.has_external_ref) return '该策略被其他租户组的站点引用，无法修改'
    return ''
  }

  // --- end protection helpers ---

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'name', title: '策略名称' },
    { key: 'comment', title: '备注' },
    { key: 'is_global', title: '类型', width: 80, render: (h: any, row: PolicyGroup) => row.is_global ? '全局' : '站点' },
  ]

  fetchData(offset: number, count: number, conditions: Condition[]) {
    if (!this.wafId) return Promise.resolve({ err: null, msg: 'success', data: { total: 0, items: [] } })
    if (this.isWafUnavailable) return this.emptyWafPage()
    return policyList(this.wafId, offset, count, conditions)
  }

  async handleSubmit() {
    if (!this.ensureWafOperable()) return
    await policyCreate({ ...this.form, captain_instance_id: this.wafId })
    this.showForm = false
    ;(this.$refs.grid as any).loadData()
  }

  async handleDelete(row: PolicyGroup) {
    if (!this.ensureWafOperable()) return
    const adm = isAdmin()

    // is_default: hard limit for all users
    if (this.isSystemDefault(row)) {
      this.$message.warning('该策略为默认防护策略模板，无法删除')
      return
    }

    // Non-admin: protected → show warning tooltip
    if (!adm && this.isDeleteProtected(row)) {
      this.$message.warning(this.deleteTooltip(row))
      return
    }

    // Admin: soft limit → confirmation dialog with specific names
    if (adm && this.isInUse(row)) {
      const names = row.referenced_site_names || []
      const nameStr = names.length > 0 ? names.slice(0, 5).join('、') + (names.length > 5 ? ` 等${names.length}个` : '') : ''
      try {
        await this.$confirm(`该策略正在被${nameStr ? '站点 ' + nameStr : `${row.site_count} 个站点`}引用，确认删除？`, '提示', { type: 'warning' })
      } catch { return }
    } else if (adm && this.isShared(row)) {
      const names = row.shared_group_names || []
      const nameStr = names.length > 0 ? names.join('、') : '其他租户组'
      try {
        await this.$confirm(`该策略被租户组 ${nameStr} 共享，确认删除？`, '提示', { type: 'warning' })
      } catch { return }
    } else {
      // Normal delete: standard confirm
      try {
        await this.$confirm('确定删除？', '提示', { type: 'warning' })
      } catch { return }
    }

    try {
      const resp = await policyDelete(row.id, this.wafId)
      if (resp.err !== null) {
        if (resp.err === 'system_default' || resp.err === 'in_use' || resp.err === 'shared') {
          this.$message.warning(resp.msg || '无法删除')
        } else {
          this.$message.error(resp.msg || '删除失败')
        }
        return
      }
      // eslint-disable-next-line @typescript-eslint/no-extra-semi
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '删除失败')
    }
  }

  handleDetail(row: PolicyGroup) {
    this.$router.push({ name: 'policyDetail', query: { id: String(row.id), waf: String(this.wafId) } })
  }

  render(h: any) {
    const iconBtnStyle = 'width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;'
    const adm = isAdmin()

    return (
      <div>
        <div style="margin-bottom: 16px; display: flex; align-items: center; gap: 16px">
          <el-select v-model={this.selectedWafId} placeholder="选择 WAF 实例" on-change={this.handleWafChange} disabled={!this.wafReady}>
            {this.wafOptions.map(w => <el-option key={w.captain_instance_id} label={this.formatWafOptionLabel(w)} value={w.captain_instance_id} />)}
          </el-select>
          <el-button type="primary" on-click={() => { if (!this.ensureWafOperable()) return; this.form = { name: '', comment: '' }; this.showForm = true }} disabled={!this.wafId || this.isWafUnavailable}>新建策略</el-button>
        </div>
        {this.renderWafOfflineAlert(h)}
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 160, render: (h: any, row: PolicyGroup) => {
          const editProtected = !adm && this.isEditProtected(row)
          const deleteProtected = !adm && this.isDeleteProtected(row)
          // Admin: is_default still disables delete button (hard limit)
          const adminDeleteDisabled = adm && this.isSystemDefault(row)

          // Detail button: always navigable (read-only viewing is always allowed)
          // Edit protection is enforced in the detail page, not here
          const detailStyle = iconBtnStyle + 'color:#666'
          const delStyle = (deleteProtected || adminDeleteDisabled) ? iconBtnStyle + 'color:#ccc' : iconBtnStyle + 'color:#666'

          return (
            <span>
              <el-tooltip content={editProtected ? this.editTooltip(row) : '查看详情'} placement="top">
                <el-button size="mini" icon="el-icon-document" style={detailStyle}
                  on-click={() => this.handleDetail(row)} />
              </el-tooltip>
              <el-tooltip content={this.deleteTooltip(row)} placement="top" disabled={!deleteProtected && !adminDeleteDisabled}>
                <el-button size="mini" icon="el-icon-delete" style={delStyle + ';margin-left:8px'}
                  on-click={() => (deleteProtected || adminDeleteDisabled) ? this.$message.warning(this.deleteTooltip(row)) : this.handleDelete(row)} />
              </el-tooltip>
            </span>
          )
        }}]} fetchData={this.fetchData} />

        <el-dialog title="新建防护策略" visible={this.showForm} on-close={() => { this.showForm = false }}>
          <el-form label-width="80px">
            <el-form-item label="名称"><el-input v-model={this.form.name} /></el-form-item>
            <el-form-item label="备注"><el-input v-model={this.form.comment} /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
