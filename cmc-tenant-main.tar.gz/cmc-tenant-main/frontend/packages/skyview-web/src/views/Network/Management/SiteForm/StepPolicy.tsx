// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, PolicyModel, AssetGroupType } from '@/types/website'
import { BackendType } from '@/types/website'
import PolicyField from './PolicyField'
import AssetGroupField from './AssetGroupField'
import SessionMethodField from './SessionMethodField'

@Component({ components: { PolicyField, AssetGroupField, SessionMethodField } })
export default class StepPolicy extends Vue {
  @Prop() form!: Website
  @Prop({ default: () => [] }) policyGroups!: PolicyModel[]
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]
  @Prop({ default: false }) ntlmEnabled!: boolean

  get isProxy() { return this.form.backend_config?.type === BackendType.proxy }

  validateSession(): boolean {
    const ref = this.$refs.sessionField as any
    return ref ? ref.validate() : true
  }

  render(h: any) {
    if (this.ntlmEnabled) {
      return (
        <div>
          <AssetGroupField value={this.form.asset_group} assetGroups={this.assetGroups}
            on-input={(v: number) => { this.form.asset_group = v }} />
        </div>
      )
    }

    return (
      <div>
        {!this.isProxy && (
          <el-alert title="非转发模式下不可配置以下设置" type="info" show-icon closable={false} style="margin-bottom:12px" />
        )}

        <PolicyField value={this.form.policy_group} policyGroups={this.policyGroups}
          disabled={!this.isProxy} on-input={(v: number | null) => { this.form.policy_group = v }} />

        <SessionMethodField ref="sessionField" value={this.form.session_method}
          isProxy={this.isProxy} on-input={(v: any) => { this.form.session_method = v }} />

        <AssetGroupField value={this.form.asset_group} assetGroups={this.assetGroups}
          on-input={(v: number) => { this.form.asset_group = v }} />
      </div>
    )
  }
}
