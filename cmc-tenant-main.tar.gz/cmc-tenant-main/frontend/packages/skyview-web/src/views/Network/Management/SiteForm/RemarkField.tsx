// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class RemarkField extends Vue {
  @Prop({ default: '' }) value!: string
  @Prop({ default: false }) bare!: boolean

  render(h: any) {
    const input = <el-input value={this.value} on-input={(v: string) => this.$emit('input', v)} type="textarea" rows={2} />
    if (this.bare) return input
    return <el-form-item label="备注">{input}</el-form-item>
  }
}
