// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, SSLCertModel, WorkGroupModel } from '@/types/website'
import { canEditBusiness } from '@/permission'
import { createFieldUpdater } from './SiteDetail/useSiteFieldUpdate'
import { getFilteredIps, getCertName, formatTime, getHealthTag, renderPortsDisplay, renderPathsDisplay, SSL_PROTOCOL_OPTIONS } from './SiteDetail/SiteBasicInfoTabFields'
import EditableRow from '@/components/EditableRow'
import FieldEditDialog from '@/components/FieldEditDialog'
import UrlPathsField from './SiteForm/UrlPathsField'
import StepListenerPort from './SiteForm/StepListenerPort'
import StepListenerCert from './SiteForm/StepListenerCert'
import { getDefaultPort, getDefaultCertSettings, uploadCertIfNeeded } from '@/utils/site'
import { CertOriginal } from '@/types/website-enums'
import { CertSettings } from '@/types/website'
import { siteWorkGroupList, siteWorkGroupIpList, siteNodeList } from '@/api/captain-site'

const IP_DEFAULTS = new Set(['0.0.0.0', '::'])

@Component({ components: { EditableRow, FieldEditDialog, UrlPathsField, StepListenerPort, StepListenerCert } })
export default class SiteBasicInfoTab extends Vue {
  @Prop() site!: Website
  @Prop() certs!: SSLCertModel[]
  @Prop({ default: 0 }) captainInstanceId!: number

  dialogField = ''
  dialogVisible = false
  dialogValue: any = null
  dialogSaving = false
  dialogCertSettings: CertSettings = getDefaultCertSettings()
  dialogSslCert: number | null = null
  workGroups: WorkGroupModel[] = []
  dialogWorkGroup = ''
  workGroupIps: string[] = []
  linkAddrs: string[] = []

  get canEdit() { return canEditBusiness() }

  get hasWorkGroups() { return this.workGroups.length > 0 }

  get ipOptions() { return this.hasWorkGroups ? this.workGroupIps : this.linkAddrs }

  get updateField() {
    return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s))
  }

  get hasSSL() { return (this.site.ports || []).some(p => p.ssl) }
  get filteredIps() { return getFilteredIps(this.site) }
  get certName() { return getCertName(this.site, this.certs) }
  get healthTag() { return getHealthTag(this.site) }

  created() {
    this.fetchWorkGroups()
    this.fetchLinkAddrs()
  }

  openDialog(field: string) {
    this.dialogField = field
    this.dialogValue = JSON.parse(JSON.stringify(this.site[field] || (field === 'ports' ? [getDefaultPort()] : [])))
    if (field === 'ports' && this.dialogValue.length === 0) {
      this.dialogValue = [getDefaultPort()]
    }
    if (field === 'url_paths' && this.dialogValue.length === 0) {
      this.dialogValue = [{ op: 'pre', url_path: '/' }]
    }
    if (field === 'ip') {
      this.dialogValue = (this.site.ip || []).filter((ip: string) => !IP_DEFAULTS.has(ip))
      this.dialogWorkGroup = this.site.interface || ''
      if (this.hasWorkGroups) {
        this.fetchWorkGroupIps()
      }
    }
    this.dialogSslCert = this.site.ssl_cert || null
    this.dialogCertSettings = this.site.ssl_cert
      ? { ...getDefaultCertSettings(), type: CertOriginal.select }
      : getDefaultCertSettings()
    this.dialogVisible = true
  }

  async fetchWorkGroups() {
    this.workGroups = []
    if (!this.captainInstanceId) return
    try {
      const resp = await siteWorkGroupList(this.captainInstanceId)
      if (resp.err === null) this.workGroups = resp.data || []
    } catch { /* ignore */ }
  }

  async fetchLinkAddrs() {
    this.linkAddrs = []
    if (!this.captainInstanceId) return
    try {
      const resp = await siteNodeList(this.captainInstanceId)
      if (resp.err === null) {
        this.linkAddrs = (resp.data || []).reduce((acc: string[], cur: any) => {
          return acc.concat(cur.node?.link_addrs || [])
        }, [])
      }
    } catch { /* ignore */ }
  }

  async fetchWorkGroupIps() {
    this.workGroupIps = []
    if (!this.dialogWorkGroup || !this.captainInstanceId) return
    try {
      const resp = await siteWorkGroupIpList(this.captainInstanceId, this.dialogWorkGroup)
      if (resp.err === null) this.workGroupIps = (resp.data || []).map((d: any) => d.addr)
    } catch { /* ignore */ }
  }

  async handleDialogSave() {
    this.dialogSaving = true
    try {
      if (this.dialogField === 'ports') {
        const hasSslPort = this.dialogValue.some(p => p.ssl)
        if (hasSslPort && this.dialogCertSettings.type !== CertOriginal.select) {
          const certId = await uploadCertIfNeeded(this.captainInstanceId, this.dialogCertSettings, this.site)
          await this.updateField({ ports: this.dialogValue, ssl_cert: certId })
        } else if (hasSslPort) {
          await this.updateField({ ports: this.dialogValue, ssl_cert: this.dialogSslCert })
        } else {
          await this.updateField({ ports: this.dialogValue })
        }
      } else if (this.dialogField === 'url_paths') {
        await this.updateField({ url_paths: this.dialogValue })
      } else if (this.dialogField === 'ip') {
        const ips = this.dialogValue.length ? this.dialogValue : ['0.0.0.0', '::']
        const update: any = { ip: ips }
        if (this.hasWorkGroups) update.interface = this.dialogWorkGroup
        await this.updateField(update)
      }
      this.dialogVisible = false
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.dialogSaving = false
    }
  }

  renderIpEdit(h: any) {
    return (
      <div>
        {this.hasWorkGroups && (
          <div style="margin-bottom:12px">
            <div style="font-size:12px;color:#909399;margin-bottom:4px">工作组</div>
            <el-select value={this.dialogWorkGroup} on-input={(v: string) => {
              this.dialogWorkGroup = v
              this.dialogValue = []
              this.fetchWorkGroupIps()
            }} style="width:100%" placeholder="选择工作组">
              {this.workGroups.map(wg => (
                <el-option key={wg.name} label={wg.comment ? `${wg.name}(${wg.comment})` : wg.name} value={wg.name} />
              ))}
            </el-select>
          </div>
        )}
        <div>
          <div style="font-size:12px;color:#909399;margin-bottom:4px">IP</div>
          <el-select value={this.dialogValue} on-input={(v: string[]) => { this.dialogValue = v }}
            multiple collapse-tags style="width:100%" placeholder="选择 IP">
            {this.ipOptions.map(ip => (
              <el-option key={ip} label={ip} value={ip} />
            ))}
          </el-select>
        </div>
      </div>
    )
  }

  render(h: any) {
    const s = this.site
    const canEdit = this.canEdit

    return (
      <el-card>
        <EditableRow label="站点类型" value={s.ntlm_enabled ? 'NTLM 站点' : '普通站点'} />

        <EditableRow label="站点名称" value={s.name} editable={canEdit}
          submitFn={(v) => this.updateField({ name: v })}
          scopedSlots={{
            default: () => <span>{s.name || '-'}</span>,
            edit: ({ value, input }) => <el-input value={value} on-input={input} placeholder="请输入站点名称" />,
          }} />

        <EditableRow label="站点状态" value={s.is_enabled} editable={canEdit}
          submitFn={(v) => this.updateField({ is_enabled: v })}
          scopedSlots={{
            default: () => <el-tag type={this.healthTag.type} size="mini">{this.healthTag.text}</el-tag>,
            edit: ({ value, input }) => (
              <el-select value={value} on-input={input} style="width:120px">
                <el-option key="on" label="启用" value={true} />
                <el-option key="off" label="禁用" value={false} />
              </el-select>
            ),
          }} />

        <EditableRow label="IP" editable={canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('ip')}
          scopedSlots={{ default: () => <span>{this.filteredIps.join(', ') || '-'}</span> }} />

        <EditableRow label="监听端口" editable={canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('ports')}
          scopedSlots={{ default: () => <span>{renderPortsDisplay(h, s)}</span> }} />

        <EditableRow label="域名" value={(s.server_names || []).join(',')} editable={canEdit}
          submitFn={(v) => this.updateField({ server_names: v.split(',').map((x: string) => x.trim()).filter(Boolean) })}
          scopedSlots={{
            default: () => <span>{s.server_names?.join(', ') || '-'}</span>,
            edit: ({ value, input }) => <el-input value={value} on-input={input} placeholder="多个域名用逗号分隔，可使用 * 通配" />,
          }} />

        <EditableRow label="生效地址" editable={canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('url_paths')}
          scopedSlots={{ default: () => <span>{renderPathsDisplay(h, s)}</span> }} />

        <EditableRow label="备注信息" value={s.remark || ''} editable={canEdit}
          submitFn={(v) => this.updateField({ remark: v })}
          scopedSlots={{
            default: () => <span>{s.remark || '-'}</span>,
            edit: ({ value, input }) => <el-input value={value} on-input={input} type="textarea" rows={2} />,
          }} />

        {this.hasSSL && (
          <EditableRow label="HTTPS 证书" editable={canEdit} mode="dialog"
            on-edit-click={() => this.openDialog('ports')}
            scopedSlots={{ default: () => <span>{this.certName}</span> }} />
        )}
        {this.hasSSL && s.ssl_cert && (
          <EditableRow label="SSL 版本" value={s.ssl_protocols || []} editable={canEdit}
            submitFn={(v) => this.updateField({ ssl_protocols: v })}
            scopedSlots={{
              default: () => <span>{(s.ssl_protocols || []).join(', ') || '-'}</span>,
              edit: ({ value, input }) => (
                <el-select value={value} on-input={input} multiple style="width:100%">
                  {SSL_PROTOCOL_OPTIONS.map(opt => <el-option key={opt.value} label={opt.label} value={opt.value} />)}
                </el-select>
              ),
            }} />
        )}
        {this.hasSSL && s.ssl_cert && (
          <EditableRow label="SSL 加密算法" value={s.ssl_ciphers || ''} editable={canEdit}
            submitFn={(v) => this.updateField({ ssl_ciphers: v })}
            scopedSlots={{
              default: () => <span>{s.ssl_ciphers || '-'}</span>,
              edit: ({ value, input }) => <el-input value={value} on-input={input} type="textarea" rows={2} />,
            }} />
        )}

        <EditableRow label="创建时间" value={formatTime(s.create_time)} />
        <EditableRow label="最后更新时间" value={formatTime(s.last_update_time)} />

        <FieldEditDialog visible={this.dialogVisible}
          title={`编辑${this.dialogField === 'ports' ? '监听端口' : this.dialogField === 'url_paths' ? '生效地址' : 'IP'}`}
          loading={this.dialogSaving} width="700px"
          on-close={() => { this.dialogVisible = false }}
          on-submit={this.handleDialogSave}>
          {this.dialogField === 'ports' && (
            <el-form label-width="100px" label-position="right">
              <StepListenerPort value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />
              {this.dialogValue.some(p => p.ssl) && (
                <StepListenerCert certSettings={this.dialogCertSettings} certs={this.certs}
                  sslCert={this.dialogSslCert}
                  on-cert-change={(v: CertSettings) => { this.dialogCertSettings = v }}
                  on-ssl-cert-change={(v: number) => { this.dialogSslCert = v }} />
              )}
            </el-form>
          )}
          {this.dialogField === 'url_paths' && (
            <UrlPathsField value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} bare />
          )}
          {this.dialogField === 'ip' && this.renderIpEdit(h)}
        </FieldEditDialog>
      </el-card>
    )
  }
}
