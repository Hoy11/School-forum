// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website } from '@/types/website'
import { createFieldUpdater } from './useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'
import FieldEditDialog from '@/components/FieldEditDialog'
import SourceIpDialog from './SiteBaseConfig/SourceIpDialog'
import { ipSourceDisplayText } from './SiteBaseConfig/SourceIpDialog'

@Component({ components: { EditableRow, FieldEditDialog, SourceIpDialog } })
export default class SourceIpPanel extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number

  dialogVisible = false
  dialogValue: string[] = []
  dialogSaving = false

  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }

  openDialog() {
    this.dialogValue = JSON.parse(JSON.stringify(this.site.detector_ip_source || []))
    this.dialogVisible = true
  }

  async handleDialogSave() {
    this.dialogSaving = true
    try {
      await this.updateField({ detector_ip_source: this.dialogValue })
      this.dialogVisible = false
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.dialogSaving = false
    }
  }

  async handleClearProxyIp() {
    try { await this.updateField({ proxy_ip_list: [], proxy_ip_groups: [] }) } catch (_) { /* best effort */ }
  }

  render(h: any) {
    const sources = this.site.detector_ip_source || []
    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">源 IP 获取方式</div>
        <EditableRow label="源 IP 获取方式" editable mode="dialog"
          on-edit-click={this.openDialog}
          scopedSlots={{
            default: () => {
              if (!sources.length) return <span style="color:#909399">未配置</span>
              return <span>{sources.map((s: string, i: number) => (
                <span>
                  <el-tag size="small" style="margin:2px">{ipSourceDisplayText(s)}</el-tag>
                  {i < sources.length - 1 && <span style="margin:0 4px;color:#909399">→</span>}
                </span>
              ))}</span>
            },
          }} />
        <FieldEditDialog visible={this.dialogVisible} title="编辑源 IP 获取方式"
          loading={this.dialogSaving} width="600px"
          on-close={() => { this.dialogVisible = false }}
          on-submit={this.handleDialogSave}>
          <SourceIpDialog value={this.dialogValue} on-input={(v: string[]) => { this.dialogValue = v }} captainInstanceId={this.captainInstanceId} on-clear-proxy-ip={this.handleClearProxyIp} />
        </FieldEditDialog>
      </el-card>
    )
  }
}
