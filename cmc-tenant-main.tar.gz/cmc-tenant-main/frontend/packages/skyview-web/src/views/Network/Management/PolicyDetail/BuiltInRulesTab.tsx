// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { ColumnDef } from '@/components/Grid'
import { PolicyModel, SkynetRule } from '@/types/policy'
import { Condition, PageResult, ApiResponse } from '@/types/common'
import { skynetRuleList, skynetRuleUpdate } from '@/api/captain-skynet-rule'

const ACTION_MAP: Record<string, string> = {
  deny: '拦截',
  dry_run: '观察',
}

const ATTACK_TYPE_MAP: Record<number, string> = {
  0: 'SQL 注入',
  1: 'XSS',
  2: '路径穿越',
  3: 'SSRF',
  4: '命令注入',
  5: '信息泄露',
  6: '反序列化',
  7: '代码执行',
  8: '代码注入',
  9: 'PHP 注入',
  10: '文件包含',
  11: '扫描器',
  12: 'CSRF',
  13: '弱权限',
  14: '信息泄漏',
  15: '未授权访问',
}

const SEVERITY_MAP: Record<number, string> = {
  1: '低危',
  2: '中危',
  3: '高危',
  4: '严重',
}

const SEVERITY_OPTIONS = [
  { label: '低危', value: 1 },
  { label: '中危', value: 2 },
  { label: '高危', value: 3 },
  { label: '严重', value: 4 },
]

function formatTimestamp(ts: string | number): string {
  if (!ts) return '-'
  const num = typeof ts === 'string' ? parseInt(ts, 10) : ts
  if (isNaN(num) || num === 0) return '-'
  return new Date(num * 1000).toLocaleString('zh-CN', { hour12: false })
}

@Component({ components: { Grid } })
export default class BuiltInRulesTab extends Vue {
  @Prop({ required: true }) policy!: PolicyModel
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: false }) isEditProtected!: boolean
  @Prop({ default: '' }) editTooltip!: string

  dialogVisible = false
  editingRule: SkynetRule | null = null
  submitting = false

  form: {
    is_enabled: boolean
    action: string
    comment: string
    tag: string[]
    risk_level: number
    enable_log: boolean
  } = {
    is_enabled: true,
    action: 'deny',
    comment: '',
    tag: [],
    risk_level: 3,
    enable_log: true,
  }

  columns: ColumnDef[] = [
    {
      key: 'is_enabled',
      title: '状态',
      width: 100,
      render: (h: any, row: SkynetRule) => {
        if (row.is_obsolete) {
          return <el-tag size="mini" type="info">已停用</el-tag>
        }
        return row.is_enabled
          ? <el-tag size="mini" type="success">启用</el-tag>
          : <el-tag size="mini" type="info">禁用</el-tag>
      },
    },
    { key: 'ruleid', title: '规则ID', width: 80 },
    {
      key: 'action',
      title: '动作',
      width: 80,
      render: (h: any, row: SkynetRule) => ACTION_MAP[row.action] || row.action,
    },
    {
      key: 'name',
      title: '规则名称',
      minWidth: 200,
      render: (h: any, row: SkynetRule) => (
        <el-tooltip content={row.name} placement="top" open-delay={500}>
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;max-width:100%">{row.name}</span>
        </el-tooltip>
      ),
    },
    {
      key: 'tag',
      title: '标签',
      width: 120,
      render: (h: any, row: SkynetRule) => {
        const tags = row.tag || []
        if (tags.length === 0) return <span style="color: #909399">-</span>
        return <span>{tags.join(', ')}</span>
      },
    },
    {
      key: 'attack_type',
      title: '攻击类型',
      width: 100,
      render: (h: any, row: SkynetRule) => ATTACK_TYPE_MAP[row.attack_type] || '未知',
    },
    {
      key: 'description',
      title: '描述',
      minWidth: 160,
      render: (h: any, row: SkynetRule) => (
        <el-tooltip content={row.description} placement="top" open-delay={500}>
          <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;max-width:100%">{row.description || '-'}</span>
        </el-tooltip>
      ),
    },
    {
      key: 'create_time',
      title: '创建时间',
      width: 160,
      render: (h: any, row: SkynetRule) => formatTimestamp(row.create_time),
    },
    {
      key: 'last_update_time',
      title: '最后修改',
      width: 160,
      render: (h: any, row: SkynetRule) => formatTimestamp(row.last_update_time),
    },
    {
      key: 'comment',
      title: '备注',
      width: 100,
      render: (h: any, row: SkynetRule) => row.comment || <span style="color: #909399">-</span>,
    },
  ]

  fetchData(offset: number, count: number, conditions: Condition[]): Promise<ApiResponse<PageResult<SkynetRule>>> {
    if (!this.captainInstanceId) {
      return Promise.resolve({ err: null, msg: 'success', data: { total: 0, items: [] } })
    }
    return skynetRuleList(this.captainInstanceId, offset, count, this.policy.id)
  }

  openEditDialog(row: SkynetRule) {
    this.editingRule = row
    this.form = {
      is_enabled: row.is_enabled,
      action: row.action,
      comment: row.comment || '',
      tag: Array.isArray(row.tag) ? [...row.tag] : [],
      risk_level: row.risk_level,
      enable_log: row.enable_log,
    }
    this.dialogVisible = true
  }

  handleDialogClose() {
    this.dialogVisible = false
    this.editingRule = null
  }

  async handleDialogSubmit() {
    if (!this.editingRule) return
    this.submitting = true
    try {
      const resp = await skynetRuleUpdate({
        id: this.editingRule.id,
        captain_instance_id: this.captainInstanceId,
        is_enabled: this.form.is_enabled,
        action: this.form.action,
        comment: this.form.comment,
        tag: this.form.tag,
        risk_level: this.form.risk_level,
        enable_log: this.form.enable_log,
      })
      if (resp.err !== null) {
        this.$message.error(resp.msg || '更新失败')
        return
      }
      this.dialogVisible = false
      this.editingRule = null
      ;(this.$refs.grid as any)?.loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    } finally {
      this.submitting = false
    }
  }

  render(h: any) {
    return (
      <div>
        <div style="margin-bottom:12px;display:flex;align-items:center;justify-content:space-between">
          <span style="font-size:14px;color:#303133">内置规则配置</span>
        </div>
        <Grid
          ref="grid"
          columns={[...this.columns, {
            key: 'actions', title: '操作', width: 60, render: (h: any, row: SkynetRule) => (
              <el-tooltip content="编辑" placement="top">
                <el-button
                  size="mini"
                  icon="el-icon-edit"
                  style={this.isEditProtected ? 'width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;color:#ccc' : 'width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;color:#666'}
                  on-click={() => this.isEditProtected ? this.$message.warning(this.editTooltip) : this.openEditDialog(row)}
                />
              </el-tooltip>
            )
          }]}
          fetchData={this.fetchData}
        />

        <el-dialog
          title="编辑内置规则"
          visible={this.dialogVisible}
          on-close={this.handleDialogClose}
          width="560px"
          top="8vh"
        >
          {this.editingRule && (
            <el-form label-width="100px" size="small">
              <el-form-item label="规则名称">
                <span style="color:#606266">{this.editingRule.name}</span>
              </el-form-item>
              <el-form-item label="状态">
                <el-switch
                  value={this.form.is_enabled}
                  on-change={(v: boolean) => { this.form.is_enabled = v }}
                  disabled={this.editingRule.is_obsolete}
                />
              </el-form-item>
              <el-form-item label="标签">
                <el-select
                  value={this.form.tag}
                  multiple
                  filterable
                  allow-create
                  default-first-option
                  placeholder="输入标签"
                  style="width:100%"
                  on-input={(v: string[]) => { this.form.tag = v }}
                >
                  {this.form.tag.map((t: string) => (
                    <el-option key={t} label={t} value={t} />
                  ))}
                </el-select>
              </el-form-item>
              <el-form-item label="攻击类型">
                <span style="color:#606266">{ATTACK_TYPE_MAP[this.editingRule.attack_type] || '未知'}</span>
              </el-form-item>
              <el-form-item label="描述">
                <span style="color:#606266">{this.editingRule.description || '-'}</span>
              </el-form-item>
              <el-form-item label="备注">
                <el-input
                  type="textarea"
                  value={this.form.comment}
                  on-input={(v: string) => { this.form.comment = v }}
                  rows={2}
                />
              </el-form-item>
              <el-form-item label="模式">
                <el-select value={this.form.action} on-input={(v: string) => { this.form.action = v }} style="width:100%">
                  <el-option label="拦截" value="deny" />
                  <el-option label="观察" value="dry_run" />
                </el-select>
              </el-form-item>
              <el-form-item label="记录日志">
                <el-switch
                  value={this.form.enable_log}
                  on-change={(v: boolean) => { this.form.enable_log = v }}
                />
              </el-form-item>
              <el-form-item label="严重级别">
                <el-select value={this.form.risk_level} on-input={(v: number) => { this.form.risk_level = v }} style="width:100%">
                  {SEVERITY_OPTIONS.map(o => (
                    <el-option key={o.value} label={o.label} value={o.value} />
                  ))}
                </el-select>
              </el-form-item>
            </el-form>
          )}

          <div slot="footer">
            <el-button on-click={this.handleDialogClose}>取消</el-button>
            <el-button type="primary" loading={this.submitting} on-click={this.handleDialogSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
