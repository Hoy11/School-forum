// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { SSLCertModel } from '@/types/website'
import { CertOriginal } from '@/types/website-enums'
import { CertSettings } from '@/types/website'
import { certOriginalOptions, getDefaultCertSettings } from '@/utils/site'

@Component
export default class StepListenerCert extends Vue {
  @Prop({ default: () => getDefaultCertSettings() }) certSettings!: CertSettings
  @Prop({ default: null }) sslCert!: number | null
  @Prop({ default: () => [] }) certs!: SSLCertModel[]
  @Prop({ default: false }) guomiEnabled!: boolean

  localCert: CertSettings = { ...this.certSettings }

  @Watch('certSettings', { deep: true })
  onCertSettingsChange(v: CertSettings) {
    this.localCert = { ...v }
  }

  get hasSslPort() {
    return true
  }

  get certMode() {
    return this.localCert.type
  }

  get filteredOptions() {
    return this.guomiEnabled
      ? certOriginalOptions
      : certOriginalOptions.filter(o => o.value !== CertOriginal.encrypt)
  }

  handleModeChange(type: CertOriginal) {
    this.localCert = {
      ...getDefaultCertSettings(),
      type,
    }
    this.$emit('cert-change', this.localCert)
  }

  handleCertFile(file: File) {
    this.localCert.cert = file
    this.$emit('cert-change', { ...this.localCert })
  }

  handleKeyFile(file: File) {
    this.localCert.key = file
    this.$emit('cert-change', { ...this.localCert })
  }

  handleEncCertFile(file: File) {
    this.localCert.enc_cert = file
    this.$emit('cert-change', { ...this.localCert })
  }

  handleEncKeyFile(file: File) {
    this.localCert.enc_key = file
    this.$emit('cert-change', { ...this.localCert })
  }

  handleSelectCert(id: number) {
    this.$emit('ssl-cert-change', id)
  }

  render(h: any) {
    if (!this.hasSslPort) return null

    return (
      <el-form-item label="证书设置">
        <el-radio-group value={this.certMode} on-input={this.handleModeChange}>
          {this.filteredOptions.map(opt => (
            <el-radio label={opt.value}>{opt.label}</el-radio>
          ))}
        </el-radio-group>

        {this.certMode === CertOriginal.upload && (
          <div style="margin-top:8px">
            <el-form-item label="证书名称" label-width="100px">
              <el-input value={this.localCert.certName} on-input={(v: string) => { this.localCert.certName = v; this.$emit('cert-change', { ...this.localCert }) }}
                placeholder="请输入证书名称" style="width:240px" />
            </el-form-item>
            <el-form-item label="证书文件" label-width="100px">
              <el-upload action="" auto-upload={false} on-change={(f: any) => this.handleCertFile(f.raw)} show-file-list={false}>
                <el-button size="small">选择证书文件</el-button>
              </el-upload>
              {this.localCert.cert && <span style="margin-left:8px;color:#67C23A">{this.localCert.cert.name}</span>}
            </el-form-item>
            <el-form-item label="私钥文件" label-width="100px">
              <el-checkbox value={this.localCert.certWithKey} on-change={(v: boolean) => { this.localCert.certWithKey = v; this.$emit('cert-change', { ...this.localCert }) }}>
                私钥包含在证书中
              </el-checkbox>
              {!this.localCert.certWithKey && (
                <div style="margin-top:4px">
                  <el-upload action="" auto-upload={false} on-change={(f: any) => this.handleKeyFile(f.raw)} show-file-list={false}>
                    <el-button size="small">选择私钥文件</el-button>
                  </el-upload>
                  {this.localCert.key && <span style="margin-left:8px;color:#67C23A">{this.localCert.key.name}</span>}
                </div>
              )}
            </el-form-item>
            <el-form-item label="证书密码" label-width="100px">
              <el-input value={this.localCert.certPassword} on-input={(v: string) => { this.localCert.certPassword = v; this.$emit('cert-change', { ...this.localCert }) }}
                placeholder="可选" type="password" style="width:240px" />
            </el-form-item>
          </div>
        )}

        {this.certMode === CertOriginal.encrypt && (
          <div style="margin-top:8px">
            <el-form-item label="证书名称" label-width="100px">
              <el-input value={this.localCert.certName} on-input={(v: string) => { this.localCert.certName = v; this.$emit('cert-change', { ...this.localCert }) }}
                placeholder="请输入证书名称" style="width:240px" />
            </el-form-item>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
              <div>
                <el-form-item label="签名证书" label-width="100px">
                  <el-upload action="" auto-upload={false} on-change={(f: any) => this.handleCertFile(f.raw)} show-file-list={false}>
                    <el-button size="small">选择文件</el-button>
                  </el-upload>
                </el-form-item>
                <el-form-item label="签名私钥" label-width="100px">
                  <el-upload action="" auto-upload={false} on-change={(f: any) => this.handleKeyFile(f.raw)} show-file-list={false}>
                    <el-button size="small">选择文件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
              <div>
                <el-form-item label="加密证书" label-width="100px">
                  <el-upload action="" auto-upload={false} on-change={(f: any) => this.handleEncCertFile(f.raw)} show-file-list={false}>
                    <el-button size="small">选择文件</el-button>
                  </el-upload>
                </el-form-item>
                <el-form-item label="加密私钥" label-width="100px">
                  <el-upload action="" auto-upload={false} on-change={(f: any) => this.handleEncKeyFile(f.raw)} show-file-list={false}>
                    <el-button size="small">选择文件</el-button>
                  </el-upload>
                </el-form-item>
              </div>
            </div>
          </div>
        )}

        {this.certMode === CertOriginal.select && (
          <div style="margin-top:8px">
            <el-select value={this.sslCert} on-input={this.handleSelectCert} placeholder="选择已有证书" style="width:240px">
              {this.certs.map(c => (
                <el-option label={c.name} value={c.id} />
              ))}
            </el-select>
          </div>
        )}
      </el-form-item>
    )
  }
}
