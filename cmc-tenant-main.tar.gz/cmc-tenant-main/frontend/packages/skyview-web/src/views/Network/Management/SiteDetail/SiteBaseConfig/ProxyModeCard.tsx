// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, BackendType, AssetGroupType, LoadBalancePolicy } from '@/types/website'
import { ConnectionConfig } from '@/types/website-security'
import { LogOption } from '@/types/website-enums'
import { createFieldUpdater } from '../useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'
import FieldEditDialog from '@/components/FieldEditDialog'
import { loadBalancePolicyOptions, xForwardedForOptions, selectedTengineTypeOptions } from '@/utils/site/constants'
import { connectionConfigOptions, logOptionOptions, redirectStatusOptions } from './constants'
import ServersDialog from './ServersDialog'
import HeadersDialog from './HeadersDialog'
import ProxyIpDialog from './ProxyIpDialog'
import IgnoreTypesDialog from './IgnoreTypesDialog'
import CustomConfigDialog from './CustomConfigDialog'
import HealthCheckDialog from './HealthCheckDialog'
import DynamicResolveDialog from './DynamicResolveDialog'
import ProxyProtocolDialog from './ProxyProtocolDialog'

@Component({ components: { EditableRow, FieldEditDialog, ServersDialog, HeadersDialog, ProxyIpDialog, IgnoreTypesDialog, CustomConfigDialog, HealthCheckDialog, DynamicResolveDialog, ProxyProtocolDialog } })
export default class ProxyModeCard extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]

  dialogField = ''
  dialogVisible = false
  dialogValue: any = null
  dialogSaving = false

  get cfg() { return this.site.backend_config as any }
  get isProxy() { return this.cfg?.type === BackendType.proxy }
  get isRedirect() { return this.cfg?.type === BackendType.redirect }
  get isResponse() { return this.cfg?.type === BackendType.response }
  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }
  get isRoundBin() { return this.cfg?.load_balance_policy === LoadBalancePolicy.roundBin }

  // Display text computed
  get tengineText() {
    const t = this.site.selected_tengine
    if (!t) return '-'
    if (t.type === 'all') return '全部节点'
    if (t.type === 'selected') return (t.tengine_list || []).join('，')
    if (t.type === 'regexp') return `正则: ${(t.tengine_list || []).join(', ')}`
    return '-'
  }
  get hcText() {
    const hc = this.cfg?.health_check_config
    if (!hc?.is_enabled) return '已禁用'
    const type = hc.check_type === 'http' ? 'HTTP' : hc.check_type === 'ssl_hello' ? 'HTTPS' : 'TCP'
    return `已启用 (${type})`
  }
  get connText() {
    const cfg = this.cfg
    if (!cfg) return '-'
    const opt = connectionConfigOptions.find(o => o.value === cfg.keepalive_config)
    const label = opt?.label || cfg.keepalive_config || '-'
    if (cfg.keepalive_config === ConnectionConfig.custom) return `${label} (keepalive: ${cfg.keepalive ?? '-'}, timeout: ${cfg.keepalive_timeout ?? '-'})`
    return label
  }
  get lbText() {
    const cfg = this.cfg
    const label = loadBalancePolicyOptions.find(o => o.value === cfg?.load_balance_policy)?.label || '-'
    if (cfg?.load_balance_policy === LoadBalancePolicy.sessionSticky) {
      const age = cfg.session_sticky_cookie_max_age
      return age ? `${label} (保持时间: ${age})` : label
    }
    return label
  }
  get accessLogText() {
    const al = this.site.access_log
    if (!al) return '-'
    const label = logOptionOptions.find(o => o.value === al.log_option)?.label || al.log_option || '-'
    const extras: string[] = []
    if (al.log_option !== LogOption.drop) {
      if (al.req_body) extras.push('请求Body')
      if (al.rsp_body) extras.push('响应Body')
    }
    return extras.length ? `${label} (${extras.join('，')})` : label
  }
  get backOriginText() {
    const ips = this.site.proxy_ip_list || [], groups = this.site.proxy_ip_groups || []
    if (!ips.length && !groups.length) return '默认回源方式'
    const parts: string[] = []
    if (ips.length) parts.push(ips.join(', '))
    if (groups.length) parts.push(`${groups.length} 个 IP 组`)
    return parts.join(' + ')
  }
  get ignoreTypesText() { const t = this.cfg?.custom_config?.ignore_types || []; return t.length ? t.join('，') : '-' }
  get customConfigText() {
    const c = this.cfg?.custom_config?.custom
    if (!c || !Object.keys(c).length) return '-'
    return Object.entries(c).map(([k, v]) => `${k} ${v}`).join('，')
  }
  get ddnsText() {
    const ddns = this.site.dynamic_resolve_upstream_config || {}
    if (!ddns.is_enabled) return '关闭'
    const fb = ddns.dynamic_resolve_fallback
    return `开启${fb ? ` (${fb})` : ''}`
  }
  get ppText() {
    const s = this.site
    if (!s.realip_config_enable) return '关闭'
    const rc = s.realip_config
    if (rc?.set_real_ip_from) return `开启 (信任来源: ${rc.set_real_ip_from})`
    return '开启'
  }

  openDialog(field: string) {
    this.dialogField = field
    if (field === 'servers') this.dialogValue = JSON.parse(JSON.stringify(this.cfg?.servers || []))
    else if (field === 'headers') this.dialogValue = JSON.parse(JSON.stringify(this.cfg?.header_config || []))
    else if (field === 'proxyIp') this.dialogValue = { proxy_ip_list: JSON.parse(JSON.stringify(this.site.proxy_ip_list || [])), proxy_ip_groups: JSON.parse(JSON.stringify(this.site.proxy_ip_groups || [])) }
    else if (field === 'ignoreTypes') this.dialogValue = JSON.parse(JSON.stringify(this.cfg?.custom_config?.ignore_types || []))
    else if (field === 'customConfig') this.dialogValue = Object.entries(this.cfg?.custom_config?.custom || {}).map(([key, value]) => ({ key, value: value as string }))
    else if (field === 'healthCheck') this.dialogValue = JSON.parse(JSON.stringify(this.cfg?.health_check_config || {}))
    else if (field === 'dynamicResolve') this.dialogValue = JSON.parse(JSON.stringify(this.site.dynamic_resolve_upstream_config || {}))
    else if (field === 'proxyProtocol') this.dialogValue = { realip_config_enable: this.site.realip_config_enable, realip_config: JSON.parse(JSON.stringify(this.site.realip_config || {})) }
    this.dialogVisible = true
  }

  async handleDialogSave() {
    this.dialogSaving = true
    try {
      const cfg = this.cfg
      if (this.dialogField === 'servers') await this.updateField({ backend_config: { ...cfg, servers: this.dialogValue } })
      else if (this.dialogField === 'headers') await this.updateField({ backend_config: { ...cfg, header_config: this.dialogValue } })
      else if (this.dialogField === 'proxyIp') await this.updateField({ proxy_ip_list: this.dialogValue.proxy_ip_list, proxy_ip_groups: this.dialogValue.proxy_ip_groups })
      else if (this.dialogField === 'ignoreTypes') await this.updateField({ backend_config: { ...cfg, custom_config: { ...cfg.custom_config, ignore_types: this.dialogValue } } })
      else if (this.dialogField === 'customConfig') {
        const custom: Record<string, string> = {}
        for (const item of this.dialogValue) { if (item.key) custom[item.key] = item.value }
        await this.updateField({ backend_config: { ...cfg, custom_config: { ...cfg.custom_config, custom } } })
      } else if (this.dialogField === 'healthCheck') await this.updateField({ backend_config: { ...cfg, health_check_config: this.dialogValue } })
      else if (this.dialogField === 'dynamicResolve') await this.updateField({ dynamic_resolve_upstream_config: this.dialogValue })
      else if (this.dialogField === 'proxyProtocol') await this.updateField({ realip_config_enable: this.dialogValue.realip_config_enable, realip_config: this.dialogValue.realip_config })
      this.dialogVisible = false
    } catch (e: any) { this.$message.error(e?.message || '保存失败') }
    finally { this.dialogSaving = false }
  }

  // Compound inline edit renderers
  renderTengineEdit({ value, input }: any) {
    const h = this.$createElement
    const parsed = JSON.parse(value || '{}')
    const tType = parsed.type || 'all', tList = parsed.tengine_list || []
    return (
      <div>
        <el-select value={tType} on-input={(v: string) => input(JSON.stringify({ type: v, tengine_list: v === 'selected' || v === 'regexp' ? tList : [] }))} style="width:100%;margin-bottom:8px">
          {selectedTengineTypeOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
        </el-select>
        {tType === 'selected' && <el-select value={tList} on-input={(v: string[]) => input(JSON.stringify({ type: tType, tengine_list: v }))} multiple filterable allow-create style="width:100%" placeholder="输入节点ID" />}
        {tType === 'regexp' && <el-select value={tList} on-input={(v: string[]) => input(JSON.stringify({ type: tType, tengine_list: v }))} multiple filterable allow-create style="width:100%" placeholder="输入正则表达式" />}
      </div>
    )
  }

  renderKeepaliveEdit({ value, input }: any) {
    const h = this.$createElement
    const p = JSON.parse(value || '{}')
    return (
      <div>
        <el-select value={p.keepalive_config} on-input={(v: string) => input(JSON.stringify({ ...p, keepalive_config: v, keepalive: v === ConnectionConfig.custom ? (p.keepalive || '32') : '', keepalive_timeout: v === ConnectionConfig.custom ? (p.keepalive_timeout || '65') : '' }))} style="width:100%;margin-bottom:8px">
          {connectionConfigOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
        </el-select>
        {p.keepalive_config === ConnectionConfig.custom && (
          <div style="display:flex;gap:8px">
            <el-input-number value={Number(p.keepalive) || 32} on-input={(v: number) => input(JSON.stringify({ ...p, keepalive: v }))} min={32} controls={false} style="flex:1" placeholder="保持连接数" />
            <el-input-number value={Number(p.keepalive_timeout) || 65} on-input={(v: number) => input(JSON.stringify({ ...p, keepalive_timeout: v }))} min={8} max={1024} controls={false} style="flex:1" placeholder="保持时间(秒)" />
          </div>
        )}
      </div>
    )
  }

  renderLoadBalanceEdit({ value, input }: any) {
    const h = this.$createElement
    const p = JSON.parse(value || '{}')
    return (
      <div>
        <el-select value={p.load_balance_policy} on-input={(v: string) => input(JSON.stringify({ ...p, load_balance_policy: v, session_sticky_cookie_max_age: v === LoadBalancePolicy.sessionSticky ? (p.session_sticky_cookie_max_age || 60) : null }))} style="width:100%;margin-bottom:8px">
          {loadBalancePolicyOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
        </el-select>
        {p.load_balance_policy === LoadBalancePolicy.sessionSticky && (
          <el-input-number value={p.session_sticky_cookie_max_age || 60} on-input={(v: number) => input(JSON.stringify({ ...p, session_sticky_cookie_max_age: v }))} min={1} controls={false} style="width:100%">
            <template slot="append">分钟</template>
          </el-input-number>
        )}
      </div>
    )
  }

  renderAccessLogEdit({ value, input }: any) {
    const h = this.$createElement
    const p = JSON.parse(value || '{}')
    const isDrop = p.log_option === LogOption.drop
    return (
      <div>
        <el-select value={p.log_option} on-input={(v: string) => input(JSON.stringify({ ...p, log_option: v, req_body: v === LogOption.drop ? false : p.req_body, rsp_body: v === LogOption.drop ? false : p.rsp_body }))} style="width:100%;margin-bottom:8px">
          {logOptionOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
        </el-select>
        {!isDrop && (
          <div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
              <span style="font-size:12px;color:#909399;width:100px">记录请求Body</span>
              <el-switch value={!!p.req_body} on-input={(v: boolean) => input(JSON.stringify({ ...p, req_body: v }))} />
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:12px;color:#909399;width:100px">记录响应Body</span>
              <el-switch value={!!p.rsp_body} on-input={(v: boolean) => input(JSON.stringify({ ...p, rsp_body: v }))} />
            </div>
          </div>
        )}
        {isDrop && <el-alert type="info" closable={false} style="margin-top:4px" description="选择不记录后，将不再保存任何访问日志" />}
      </div>
    )
  }

  dialogTitle() {
    const map: Record<string, string> = { servers: '编辑业务服务器地址', headers: '编辑 HTTP 头设置', proxyIp: '编辑回源 IP 配置', ignoreTypes: '编辑忽略 content_type', customConfig: '编辑代理服务器详细配置', healthCheck: '编辑业务服务器健康检查', dynamicResolve: '编辑动态域名解析', proxyProtocol: '编辑 Proxy Protocol 配置' }
    return map[this.dialogField] || '编辑'
  }

  render(h: any) {
    const s = this.site, cfg = this.cfg, isProxy = this.isProxy
    const t = s.selected_tengine || { type: 'all', tengine_list: [] }
    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">请求处理方式</div>
        <EditableRow label={s.ntlm_enabled ? '转发节点' : '检测节点'} value={JSON.stringify(t)} editable
          submitFn={(v) => this.updateField({ selected_tengine: JSON.parse(v) })}
          scopedSlots={{ default: () => <span>{this.tengineText}</span>, edit: (scope) => this.renderTengineEdit(scope) }} />
        {!s.ntlm_enabled && <EditableRow label="响应方式" value={cfg?.type} editable
          submitFn={(v) => this.updateField({ backend_config: { ...cfg, type: v } })}
          scopedSlots={{ default: () => <span>{isProxy ? '转发到业务服务器' : isRedirect ? '重定向' : '自定义响应'}</span>,
            edit: ({ value, input }) => (<el-select value={value} on-input={input} style="width:100%"><el-option label="转发到业务服务器" value={BackendType.proxy} /><el-option label="重定向" value={BackendType.redirect} /><el-option label="自定义响应" value={BackendType.response} /></el-select>) }} />}
        {isProxy ? this.renderProxyFields(h) : this.renderRedirectFields(h)}
        <FieldEditDialog visible={this.dialogVisible} title={this.dialogTitle()} loading={this.dialogSaving} width="700px"
          on-close={() => { this.dialogVisible = false }} on-submit={this.handleDialogSave}>
          {this.dialogField === 'servers' && <ServersDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} isRoundBin={this.isRoundBin} />}
          {this.dialogField === 'headers' && <HeadersDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />}
          {this.dialogField === 'proxyIp' && <ProxyIpDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} captainInstanceId={this.captainInstanceId} assetGroups={this.assetGroups} />}
          {this.dialogField === 'ignoreTypes' && <IgnoreTypesDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />}
          {this.dialogField === 'customConfig' && <CustomConfigDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />}
          {this.dialogField === 'healthCheck' && <HealthCheckDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />}
          {this.dialogField === 'dynamicResolve' && <DynamicResolveDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />}
          {this.dialogField === 'proxyProtocol' && <ProxyProtocolDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />}
        </FieldEditDialog>
      </el-card>
    )
  }

  renderProxyFields(h: any) {
    const s = this.site, cfg = this.cfg
    const lbVal = JSON.stringify({ load_balance_policy: cfg?.load_balance_policy, session_sticky_cookie_max_age: cfg?.session_sticky_cookie_max_age })
    const connVal = JSON.stringify({ keepalive_config: cfg?.keepalive_config, keepalive: cfg?.keepalive, keepalive_timeout: cfg?.keepalive_timeout })
    const al = s.access_log || {}
    const alVal = JSON.stringify({ log_option: al.log_option, req_body: al.req_body, rsp_body: al.rsp_body })
    return [
      <EditableRow label="调度算法" value={lbVal} editable={!s.ntlm_enabled}
        submitFn={(v) => { const p = JSON.parse(v); return this.updateField({ backend_config: { ...cfg, load_balance_policy: p.load_balance_policy, session_sticky_cookie_max_age: p.session_sticky_cookie_max_age } }) }}
        scopedSlots={{ default: () => <span>{this.lbText}</span>, edit: (scope) => this.renderLoadBalanceEdit(scope) }} />,
      !s.ntlm_enabled && <EditableRow label="保持连接配置" value={connVal} editable
        submitFn={(v) => { const p = JSON.parse(v); return this.updateField({ backend_config: { ...cfg, keepalive_config: p.keepalive_config, keepalive: p.keepalive, keepalive_timeout: p.keepalive_timeout } }) }}
        scopedSlots={{ default: () => <span>{this.connText}</span>, edit: (scope) => this.renderKeepaliveEdit(scope) }} />,
      !s.ntlm_enabled && <EditableRow label="X-Forwarded-For" value={cfg?.x_forwarded_for_action} editable
        submitFn={(v) => this.updateField({ backend_config: { ...cfg, x_forwarded_for_action: v } })}
        scopedSlots={{ default: () => <span>{xForwardedForOptions.find(o => o.value === cfg?.x_forwarded_for_action)?.label || '-'}</span>, edit: ({ value, input }) => <el-select value={value} on-input={input} style="width:100%">{xForwardedForOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}</el-select> }} />,
      !s.ntlm_enabled && <EditableRow label="业务服务器健康检查" editable mode="dialog" on-edit-click={() => this.openDialog('healthCheck')}
        scopedSlots={{ default: () => <span>{this.hcText}</span> }} />,
      <EditableRow label="业务服务器地址" editable mode="dialog" on-edit-click={() => this.openDialog('servers')}
        scopedSlots={{ default: () => { const sv = (cfg?.servers || []).filter((sv: any) => sv.is_enabled); return sv.length ? <span>{sv.map((sv: any) => `${sv.protocol}://${sv.host}:${sv.port}`).join('，')}</span> : <span style="color:#909399">暂无内容</span> } }} />,
      !s.ntlm_enabled && <EditableRow label="记录访问日志" value={alVal} editable
        submitFn={(v) => { const p = JSON.parse(v); const isDrop = p.log_option === LogOption.drop; return this.updateField({ access_log: { ...al, log_option: p.log_option, req_body: isDrop ? false : p.req_body, rsp_body: isDrop ? false : p.rsp_body, is_enabled: !isDrop } }) }}
        scopedSlots={{ default: () => <span>{this.accessLogText}</span>, edit: (scope) => this.renderAccessLogEdit(scope) }} />,
      !s.ntlm_enabled && <EditableRow label="HTTP 头设置" editable mode="dialog" on-edit-click={() => this.openDialog('headers')}
        scopedSlots={{ default: () => { const hdrs = cfg?.header_config || []; return hdrs.length ? <span>{hdrs.map((x: any) => `${x.name}(${x.action === 'set' ? '设置' : '隐藏'})`).join('，')}</span> : <span style="color:#909399">暂无内容</span> } }} />,
      !s.ntlm_enabled && <EditableRow label="回源 IP 配置" editable mode="dialog" on-edit-click={() => this.openDialog('proxyIp')}
        scopedSlots={{ default: () => <span>{this.backOriginText}</span> }} />,
      !s.ntlm_enabled && <EditableRow label="动态域名解析" editable mode="dialog" on-edit-click={() => this.openDialog('dynamicResolve')}
        scopedSlots={{ default: () => <span>{this.ddnsText}</span> }} />,
      <EditableRow label="Proxy Protocol 配置" editable mode="dialog" on-edit-click={() => this.openDialog('proxyProtocol')}
        scopedSlots={{ default: () => <span>{this.ppText}</span> }} />,
      !s.ntlm_enabled && <EditableRow label="忽略特定 content_type" editable mode="dialog" on-edit-click={() => this.openDialog('ignoreTypes')}
        scopedSlots={{ default: () => <span>{this.ignoreTypesText}</span> }} />,
      !s.ntlm_enabled && <EditableRow label="代理服务器详细配置" editable mode="dialog" on-edit-click={() => this.openDialog('customConfig')}
        scopedSlots={{ default: () => <span>{this.customConfigText}</span> }} />,
    ]
  }

  renderRedirectFields(h: any) {
    const cfg = this.cfg, isResp = this.isResponse
    return [
      <EditableRow label="HTTP 状态码设置" value={cfg?.status_code} editable
        submitFn={(v) => this.updateField({ backend_config: { ...cfg, status_code: v } })}
        scopedSlots={{ default: () => <span>{cfg?.status_code || '-'}</span>,
          edit: ({ value, input }) => isResp
            ? <el-input-number value={value || 200} on-input={input} min={200} max={599} controls={false} style="width:100%" placeholder="200-299 或 400-599" />
            : <el-select value={value} on-input={input} style="width:100%">{redirectStatusOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}</el-select> }} />,
      <EditableRow label={isResp ? '响应内容' : '重定向地址'} value={cfg?.path} editable
        submitFn={(v) => this.updateField({ backend_config: { ...cfg, path: v } })}
        scopedSlots={{ default: () => <span>{cfg?.path || '-'}</span>,
          edit: ({ value, input }) => isResp
            ? <el-input value={value} on-input={input} type="textarea" rows={4} style="width:100%" placeholder="输入自定义响应内容" />
            : <el-input value={value} on-input={input} style="width:100%" placeholder="https://example.com" /> }} />,
      isResp && <el-alert type="info" closable={false} description="状态码请输入 200-299 或 400-599 的整数" />,
      <EditableRow label="忽略特定 content_type" editable mode="dialog" on-edit-click={() => this.openDialog('ignoreTypes')}
        scopedSlots={{ default: () => <span>{this.ignoreTypesText}</span> }} />,
      <EditableRow label="代理服务器详细配置" editable mode="dialog" on-edit-click={() => this.openDialog('customConfig')}
        scopedSlots={{ default: () => <span>{this.customConfigText}</span> }} />,
    ]
  }
}
