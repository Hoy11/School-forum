import { siteUpdate, siteDetail } from '@/api/captain-site'
import { Website } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { prepareSiteForSubmit, prepareWTransProxySiteForSubmit } from '@/utils/site'

export function createFieldUpdater(
  site: Website,
  captainInstanceId: number,
  onUpdated: (site: Website) => void,
) {
  return async function updateField(partial: Partial<Website>) {
    // Captain API requires full object PUT — merge partial into complete site
    const full: any = JSON.parse(JSON.stringify({ ...site, ...partial, id: site.id, captain_instance_id: captainInstanceId }))
    // Convert policy_rules objects to IDs (Captain expects number[])
    if (full.policy_rules && Array.isArray(full.policy_rules)) {
      full.policy_rules = full.policy_rules.map((r: any) => typeof r === 'object' ? r.id : r)
    }
    const payload = full.operation_mode === WorkGroupOperationMode.HardwareTransparentProxy
      ? prepareWTransProxySiteForSubmit(full, full.addrs || [])
      : prepareSiteForSubmit(full, false)
    const resp = await siteUpdate({ ...payload, id: site.id, captain_instance_id: captainInstanceId })
    if (resp.err !== null) {
      throw new Error(resp.msg || '更新失败')
    }
    const detailResp = await siteDetail(site.id, captainInstanceId)
    if (detailResp.err === null) {
      onUpdated(detailResp.data)
    }
  }
}
