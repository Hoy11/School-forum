// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class SiteStatusField extends Vue {
  @Prop() value!: boolean
  @Prop({ default: false }) bare!: boolean

  render(h: any) {
    const select = (
      <el-select value={this.value} on-input={(v: boolean) => this.$emit('input', v)} style="width: 120px">
        <el-option label="启用" value={true} />
        <el-option label="禁用" value={false} />
      </el-select>
    )
    if (this.bare) return select
    return <el-form-item label="站点状态">{select}</el-form-item>
  }
}
