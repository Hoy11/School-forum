// @ts-nocheck
import { Component, Mixins, Watch } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { ColumnDef } from '@/components/Grid'
import { Condition, FilterFieldOption } from '@/types/common'
import { PolicyRule } from '@/types/policy'
import { WafSelectorMixin } from '@/mixins/wafSelector'
import { ruleList, ruleCreate, ruleUpdate, ruleDelete, ruleEnable, getDetectionModules, getSkynetRules } from '@/api/captain-rule'
import { siteList } from '@/api/captain-site'
import { ipGroupList } from '@/api/captain-ip-group'
import { Website } from '@/types/website'
import { IPGroup } from '@/types/ip-group'
import ConditionEditor from '@/components/ConditionEditor'
import RuleFilterBar from '@/components/RuleFilterBar'
import { ACTION_MAP, ACTION_TOOLTIP, RISK_LEVEL_OPTIONS, ATTACK_TYPE_OPTIONS, LOG_OPTION_OPTIONS, LOG_OPTION_DESCRIPTIONS, LOG_OPTION_DESCRIPTION_STYLE, DECODE_METHOD_OPTIONS, WEEKDAY_OPTIONS, formatTimestamp, formatDate, isSharedRule, applyDecodeMethods, formatCronConfig, parseCronConfig, normalizeDecodeMethods } from './ruleConstants'
import { isAdmin } from '@/permission'

const ACTION_OPTIONS = [
  { label: '拦截', value: 'deny' },
  { label: '放行', value: 'allow' },
  { label: '观察', value: 'dry_run' },
  { label: '检测模块控制', value: 'modify_module' },
  { label: '内置规则控制', value: 'modify_skynet_rule' },
]

@Component({ components: { Grid, ConditionEditor, RuleFilterBar } })
export default class PolicyRulePage extends Mixins(WafSelectorMixin) {
  get wafId(): number { return this.effectiveWafId }

  @Watch('wafReady')
  onWafReady() { if (this.wafReady) this.$nextTick(() => (this.$refs.grid as any)?.loadData()) }

  @Watch('form.action')
  onActionChange(newAction: string) {
    if (newAction !== 'modify_module') this.moduleActions = []
    if (newAction !== 'modify_skynet_rule') this.skynetActions = []
  }

  handleWafChange() {
    this.showWafOfflineMessage()
    this.filterConditions = []
    const grid = this.$refs.grid as any
    grid?.handleConditionsChange([])
    grid?.loadData()
    this.loadSites()
    this.loadIPGroups()
    // Clear cached data on WAF switch
    this.detectionModules = []
    this.skynetRuleList = []
  }

  showForm = false
  isReadOnly = false
  editingItem: PolicyRule | null = null
  submitting = false
  advancedOpen: string[] = []

  sites: Website[] = []
  ipGroups: IPGroup[] = []
  moduleActions: any[] = []
  skynetActions: any[] = []
  detectionModules: any[] = []
  skynetRuleList: any[] = []
  filterConditions: Condition[] = []

  form: Record<string, any> = {
    is_enabled: true,
    action: 'deny',
    comment: '',
    risk_level: 0,
    pattern: null,
    websites: [],
    attack_type: null,
    log_option: 'Persistence',
    cron_config: { type: 'all' },
    expire_time: null,
    decode_before_detection: false,
    decode_methods: ['url_decode'],
    status_code: 403,
  }

  get isSpecialAction() {
    return this.form.action === 'modify_module' || this.form.action === 'modify_skynet_rule'
  }

  // --- Filter bar fields (1:1 from 雷池 custom rule page) ---
  get defaultFilterFields(): FilterFieldOption[] {
    return [
      { label: 'ID', value: 'id', type: 'text', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
        { label: '小于', value: '<' },
        { label: '大于', value: '>' },
      ]},
      { label: '备注', value: 'comment', type: 'text', operators: [
        { label: '包含', value: 'like' },
        { label: '不包含', value: 'not like' },
      ]},
      { label: '自定义规则状态', value: 'is_enabled', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '启用', value: 'true' },
        { label: '禁用', value: 'false' },
      ]},
      { label: '拦截码', value: 'status_code', type: 'text', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
        { label: '小于', value: '<' },
        { label: '大于', value: '>' },
        { label: '等于一系列值（逗号分隔）', value: 'in' },
        { label: '不等于一系列值（逗号分隔）', value: 'not in' },
      ]},
    ]
  }

  get optionalFilterFields(): FilterFieldOption[] {
    return [
      { label: '重定向地址', value: 'forward_address', type: 'text', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
        { label: '包含', value: 'like' },
        { label: '不包含', value: 'not like' },
        { label: '正则匹配', value: 'regex' },
        { label: '正则不匹配', value: 'not regex' },
      ]},
      { label: '风险等级', value: 'risk_level', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '无威胁', value: '0' },
        { label: '低危', value: '1' },
        { label: '中危', value: '2' },
        { label: '高危', value: '3' },
      ]},
      { label: '攻击类型', value: 'attack_type', type: 'multi_choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
        { label: '在列表中', value: 'in' },
        { label: '不在列表中', value: 'not in' },
      ], choices: ATTACK_TYPE_OPTIONS.map(o => ({ label: o.label, value: String(o.value) })) },
      { label: '触发率', value: 'percentage', type: 'text', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
        { label: '小于', value: '<' },
        { label: '大于', value: '>' },
      ]},
      { label: '规则生效时间', value: 'cron_config', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '永久', value: 'all' },
        { label: '定时', value: 'time_range' },
        { label: '周期', value: 'weekly' },
      ]},
      { label: '创建时间', value: 'create_time', type: 'time_range' },
      { label: '过期时间', value: 'expire_time', type: 'time_range' },
      { label: '最后修改时间', value: 'last_update_time', type: 'time_range' },
    ]
  }

  handleFilterSearch(conditions: Condition[]) {
    this.filterConditions = conditions
    this.$nextTick(() => {
      const grid = this.$refs.grid as any
      grid?.handleConditionsChange(conditions)
    })
  }

  columns: ColumnDef[] = [
    {
      key: 'is_enabled',
      title: '状态',
      width: 80,
      showOverflowTooltip: true,
      render: (h: any, row: PolicyRule) =>
        row.is_enabled
          ? <el-tag size="mini" type="success">启用</el-tag>
          : <el-tag size="mini" type="info">禁用</el-tag>,
    },
    { key: 'id', title: '规则ID', width: 80, showOverflowTooltip: true },
    {
      key: 'action',
      title: '动作',
      width: 120,
      showOverflowTooltip: true,
      renderHeader: (h: any) => (
        <span>
          动作{' '}
          <el-tooltip content={ACTION_TOOLTIP} placement="top" effect="dark" popper-class="action-tooltip">
            <i class="el-icon-warning" style="color: #E6A23C; cursor: pointer" />
          </el-tooltip>
        </span>
      ),
      render: (h: any, row: PolicyRule) => ACTION_MAP[row.action] || row.action,
    },
    {
      key: 'comment',
      title: '备注',
      minWidth: 120,
      showOverflowTooltip: true,
      render: (h: any, row: PolicyRule) => row.comment || <span style="color: #909399">-</span>,
    },
    {
      key: 'site_names',
      title: '正在使用的站点',
      minWidth: 120,
      showOverflowTooltip: true,
      render: (h: any, row: PolicyRule) => {
        const names = row.site_names || []
        if (names.length === 0) return <span style="color: #909399">-</span>
        const display = names.slice(0, 2).join(', ')
        const suffix = names.length > 2 ? ` 等${names.length}个` : ''
        return <span>{display}{suffix}</span>
      },
    },
    {
      key: 'expire_time',
      title: '过期时间',
      width: 120,
      showOverflowTooltip: true,
      render: (h: any, row: PolicyRule) => row.expire_time ? formatTimestamp(row.expire_time) : '永不过期',
    },
    {
      key: 'create_time',
      title: '创建时间',
      width: 160,
      showOverflowTooltip: true,
      render: (h: any, row: PolicyRule) => formatTimestamp(row.create_time),
    },
    {
      key: 'last_update_time',
      title: '最后修改',
      width: 160,
      showOverflowTooltip: true,
      render: (h: any, row: PolicyRule) => formatTimestamp(row.last_update_time),
    },
  ]

  fetchData(offset: number, count: number, conditions: Condition[]) {
    if (!this.wafId) return Promise.resolve({ err: null, msg: 'success', data: { total: 0, items: [] } })
    if (this.isWafUnavailable) return this.emptyWafPage()
    return ruleList(this.wafId, offset, count, conditions)
  }

  isShared(row: PolicyRule): boolean { return isSharedRule(row) }

  isInUse(row: PolicyRule): boolean {
    return (row.websites?.length ?? 0) > 0
  }

  isEditProtected(row: PolicyRule): boolean {
    return this.isShared(row) || row.has_external_ref === true
  }

  isDeleteProtected(row: PolicyRule): boolean {
    return this.isInUse(row) || this.isShared(row)
  }

  // adminConfirmEdit shows a confirmation dialog for admin before edit/enable/disable.
  // Returns true if the operation should proceed, false if cancelled.
  async adminConfirmEdit(row: PolicyRule): Promise<boolean> {
    if (!isAdmin()) return true
    const bc = row.binding_count ?? 1
    const inUse = this.isInUse(row)
    const shared = this.isShared(row)
    const extRef = row.has_external_ref === true

    // Row 4: binding_count > 1
    if (shared) {
      const names = row.shared_group_names || []
      const nameStr = names.length > 0 ? names.join('、') : '多个租户组'
      try { await this.$confirm(`该规则被租户组 ${nameStr} 共享，确认操作？`, '提示', { type: 'warning' }) } catch { return false }
      return true
    }

    // Row 2: has_external_ref (binding_count=1, sites from other TG)
    if (extRef) {
      const names = row.shared_group_names || []
      const nameStr = names.length > 0 ? names.join('、') : '其他租户组'
      try { await this.$confirm(`该规则被租户组 ${nameStr} 的站点引用，确认操作？`, '提示', { type: 'warning' }) } catch { return false }
      return true
    }

    // Row 1: binding_count=1, websites non-empty, all own sites
    if (inUse && bc === 1 && !extRef) {
      const names = row.site_names || []
      const nameStr = names.length > 0 ? names.slice(0, 5).join('、') + (names.length > 5 ? ` 等${names.length}个` : '') : `${(row.websites || []).length} 个站点`
      try { await this.$confirm(`该规则正在被 ${nameStr} 引用，操作后立即生效，确认？`, '提示', { type: 'warning' }) } catch { return false }
      return true
    }

    // Row 3: binding_count=1, websites empty
    if (!inUse && bc === 1) {
      try { await this.$confirm('此规则已绑定给租户组，当前无站点引用，确认操作？', '提示', { type: 'warning' }) } catch { return false }
      return true
    }

    return true
  }

  // adminConfirmDelete shows a confirmation dialog for admin before delete.
  async adminConfirmDelete(row: PolicyRule): Promise<boolean> {
    if (!isAdmin()) return true
    const bc = row.binding_count ?? 1
    const shared = this.isShared(row)

    // Row 4: binding_count > 1; if also in_use, backend hard-blocks — let it through so backend returns in_use error
    if (shared) {
      if (this.isInUse(row)) return true
      const names = row.shared_group_names || []
      const nameStr = names.length > 0 ? names.join('、') : '多个租户组'
      try { await this.$confirm(`该规则被租户组 ${nameStr} 共享，确认删除？`, '提示', { type: 'warning' }) } catch { return false }
      return true
    }

    // Row 3: binding_count=1, websites empty (in_use check already passed at UI level)
    if (bc === 1) {
      try { await this.$confirm('此规则已绑定给租户组，当前无站点引用，确认删除？', '提示', { type: 'warning' }) } catch { return false }
      return true
    }

    return true
  }

  handleViewLog(row: PolicyRule) {
    this.$router.push({ path: '/threat/detect-log', query: { policy_rule_id: String(row.id), captain_instance_id: String(row.captain_instance_id) } })
  }

  handleCreate() {
    if (!this.ensureWafOperable()) return
    this.editingItem = null
    this.isReadOnly = false
    this.form = {
      is_enabled: true,
      action: 'deny',
      comment: '',
      risk_level: 0,
      pattern: null,
      websites: [],
      attack_type: null,
      log_option: 'Persistence',
      cron_config: { type: 'all' },
      expire_time: null,
      decode_before_detection: false,
      decode_methods: ['url_decode'],
      status_code: 403,
    }
    this.moduleActions = []
    this.skynetActions = []
    this.advancedOpen = []
    this.showForm = true
    this.loadSites()
    this.loadIPGroups()
    this.loadDetectionModules()
    this.loadSkynetRuleList()
  }

  async handleEdit(row: PolicyRule) {
    if (!this.ensureWafOperable()) return
    if (isAdmin()) {
      const proceed = await this.adminConfirmEdit(row)
      if (!proceed) return
    }
    this.isReadOnly = isAdmin() ? false : this.isEditProtected(row)
    this.editingItem = row
    let decodeBeforeDetection = false
    let decodeMethods: string[] = ['url_decode']
    const findDecoded = (items: any[]): any | undefined => {
      for (const item of items) {
        if (item.$AND || item.$OR) {
          const found = findDecoded(item.$AND || item.$OR)
          if (found) return found
        }
        if (item.decode_methods && item.decode_methods.length > 0) return item
      }
      return undefined
    }
    if (row.pattern) {
      const items = (row.pattern as any).$AND || (row.pattern as any).$OR
      if (items) {
        const firstDecoded = findDecoded(items)
        if (firstDecoded) {
          decodeBeforeDetection = true
          decodeMethods = normalizeDecodeMethods(firstDecoded.decode_methods)
        }
      }
    }
    this.form = {
      is_enabled: row.is_enabled,
      action: row.action,
      comment: row.comment || '',
      risk_level: row.risk_level,
      pattern: row.pattern,
      websites: row.websites || [],
      attack_type: row.attack_type === -1 ? null : row.attack_type,
      log_option: row.log_option || 'Persistence',
      cron_config: parseCronConfig(row.cron_config),
      expire_time: row.expire_time
        ? new Date(row.expire_time * 1000)
        : null,
      decode_before_detection: decodeBeforeDetection,
      decode_methods: decodeMethods,
      status_code: (row as any).forbidden_page_config?.status_code || 403,
    }
    this.moduleActions = this.normalizeModuleManagement((row as any).module_management)
    this.skynetActions = this.normalizeSkynetRuleManagement((row as any).skynet_rule_management)
    this.advancedOpen = []
    this.showForm = true
    this.loadSites()
    this.loadIPGroups()
    this.loadDetectionModules()
    this.loadSkynetRuleList()
  }

  async handleToggle(row: PolicyRule, enable: boolean) {
    if (!this.ensureWafOperable()) return
    if (isAdmin()) {
      const proceed = await this.adminConfirmEdit(row)
      if (!proceed) return
    }
    try {
      const action = enable ? 'enable' : 'disable'
      await ruleEnable([row.id], this.wafId, action)
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.handleProtectionError(e, enable ? '启用' : '禁用')
    }
  }

  async handleDelete(row: PolicyRule) {
    if (!this.ensureWafOperable()) return
    if (isAdmin()) {
      const proceed = await this.adminConfirmDelete(row)
      if (!proceed) return
    } else {
      await this.$confirm('确定删除该规则？', '提示', { type: 'warning' })
    }
    try {
      await ruleDelete(row.id, this.wafId)
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.handleProtectionError(e, '删除')
    }
  }

  handleProtectionError(e: any, action: string) {
    const errCode = e?.response?.data?.err
    const errMsg = e?.response?.data?.msg
    if (errCode === 'in_use') {
      this.$message.warning(errMsg || `该规则正在被站点使用，无法${action}`)
    } else if (errCode === 'shared') {
      this.$message.warning(errMsg || '该资源被多个租户组绑定')
    } else {
      this.$message.error(errMsg || e?.message || '操作失败')
    }
  }

  async handleSubmit() {
    if (!this.ensureWafOperable()) return
    if (this.submitting || this.isReadOnly) return
    if (!this.form.comment || !this.form.comment.trim()) { this.$message.warning('备注不能为空'); return }
    if (this.form.action === 'modify_module') {
      if (this.moduleActions.length === 0) { this.$message.warning('请添加至少一个规则动作'); return }
      if (this.moduleActions.some((a: any) => !a.key)) { this.$message.warning('请选择检测模块'); return }
    }
    if (this.form.action === 'modify_skynet_rule') {
      if (this.skynetActions.length === 0) { this.$message.warning('请添加至少一个规则动作'); return }
      if (this.skynetActions.some((a: any) => !a.key)) { this.$message.warning('请选择内置规则'); return }
    }
    if (!this.isSpecialAction && (this.form.attack_type === null || this.form.attack_type === undefined)) { this.$message.warning('请选择攻击类型'); return }
    if (!this.isSpecialAction) {
      const condEditor = this.$refs.conditionEditor as any
      if (condEditor && condEditor.validate) {
        const err = condEditor.validate()
        if (err) { this.$message.warning(err); return }
      }
    }
    this.submitting = true
    try {
      const payload: any = {
        captain_instance_id: this.wafId,
        is_global: false,
        is_enabled: this.form.is_enabled,
        action: this.form.action,
        comment: this.form.comment,
        risk_level: this.form.risk_level,
        websites: this.form.websites,
        attack_type: this.form.attack_type,
        log_option: this.form.log_option,
        cron_config: formatCronConfig(this.form),
        expire_time: this.form.expire_time
          ? Math.floor(new Date(this.form.expire_time).getTime() / 1000)
          : null,
        forbidden_page_config: this.form.action === 'deny'
          ? { action: 'response', status_code: this.form.status_code, path: '' }
          : null,
      }
      payload.pattern = this.form.decode_before_detection
        ? applyDecodeMethods(this.form.pattern, this.form.decode_methods)
        : applyDecodeMethods(this.form.pattern, [])
      if (this.form.action === 'modify_module') {
        payload.module_management = this.moduleActions
      }
      if (this.form.action === 'modify_skynet_rule') {
        payload.skynet_rule_management = this.skynetActions
      }

      if (this.editingItem) {
        const resp = await ruleUpdate({ id: this.editingItem.id, ...payload })
        if (resp.err !== null) { this.$message.error(resp.msg || '更新失败'); return }
      } else {
        const resp = await ruleCreate(payload)
        if (resp.err !== null) { this.$message.error(resp.msg || '创建失败'); return }
      }
      this.showForm = false
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.handleProtectionError(e, '操作')
    } finally {
      this.submitting = false
    }
  }

  async loadSites() {
    if (!this.wafId) return
    if (this.isWafUnavailable) { this.sites = []; return }
    try {
      const resp = await siteList(this.wafId, 0, 1000)
      if (resp.err === null) {
        this.sites = resp.data?.items || []
      }
    } catch { /* ignore */ }
  }

  async loadIPGroups() {
    if (!this.wafId) return
    if (this.isWafUnavailable) { this.ipGroups = []; return }
    try {
      const resp = await ipGroupList(this.wafId, 0, 1000)
      if (resp.err === null) {
        this.ipGroups = resp.data?.items || []
      }
    } catch { /* ignore */ }
  }

  async loadDetectionModules() {
    if (!this.wafId) return
    if (this.isWafUnavailable) { this.detectionModules = []; return }
    if (this.detectionModules.length > 0) return // cached
    try {
      const resp = await getDetectionModules(this.wafId)
      if (resp.err === null && resp.data) {
        const config = resp.data.detection_config || resp.data
        this.detectionModules = config.modules_detection_config || []
      }
    } catch { /* ignore */ }
  }

  async loadSkynetRuleList() {
    if (!this.wafId) return
    if (this.isWafUnavailable) { this.skynetRuleList = []; return }
    if (this.skynetRuleList.length > 0) return // cached
    try {
      const resp = await getSkynetRules(this.wafId)
      if (resp.err === null) {
        const data = resp.data
        // Captain API returns {items: [...]} pagination format, not plain array
        this.skynetRuleList = Array.isArray(data) ? data : (data?.items || [])
      }
    } catch { /* ignore */ }
  }

  addDecodeMethod() {
    this.form = { ...this.form, decode_methods: [...this.form.decode_methods, 'url_decode'] }
  }

  removeDecodeMethod(i: number) {
    this.form = { ...this.form, decode_methods: this.form.decode_methods.filter((_: string, idx: number) => idx !== i) }
  }

  /** Convert Captain API dict format {disabled:[], enabled:[]} to frontend array [{key, enabled}] */
  normalizeModuleManagement(data: any): any[] {
    if (!data) return []
    if (Array.isArray(data)) return data
    const result: any[] = []
    if (data.disabled && Array.isArray(data.disabled)) {
      for (const key of data.disabled) result.push({ key, enabled: false })
    }
    if (data.enabled && Array.isArray(data.enabled)) {
      for (const key of data.enabled) result.push({ key, enabled: true })
    }
    return result
  }

  /** Convert Captain API dict format {disabled:[], enabled:[]} to frontend array [{key, enabled}] */
  normalizeSkynetRuleManagement(data: any): any[] {
    if (!data) return []
    if (Array.isArray(data)) return data
    const result: any[] = []
    if (data.disabled && Array.isArray(data.disabled)) {
      for (const key of data.disabled) result.push({ key, enabled: false })
    }
    if (data.enabled && Array.isArray(data.enabled)) {
      for (const key of data.enabled) result.push({ key, enabled: true })
    }
    return result
  }

  addModuleAction() {
    this.moduleActions = [...this.moduleActions, { key: '', enabled: false }]
  }

  removeModuleAction(i: number) {
    this.moduleActions = this.moduleActions.filter((_: any, idx: number) => idx !== i)
  }

  addSkynetAction() {
    this.skynetActions = [...this.skynetActions, { key: '', enabled: false }]
  }

  removeSkynetAction(i: number) {
    this.skynetActions = this.skynetActions.filter((_: any, idx: number) => idx !== i)
  }

  renderModuleConfig(h: any) {
    if (this.form.action !== 'modify_module') return null
    const moduleOptions = this.detectionModules
      .filter((m: any) => m.key !== 'm_rule')
      .map((m: any) => ({ label: (m.name?.cn || m.name?.translation || m.key), value: m.key }))
    return (
      <el-form-item label="规则动作" required>
        <div style="width: 100%">
          {this.moduleActions.map((item: any, i: number) => (
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px">
              <el-select v-model={item.key} placeholder="选择模块" size="small" filterable style="flex: 1"
                disabled={this.isReadOnly}
                on-change={(v: string) => { const a = [...this.moduleActions]; a[i] = { ...a[i], key: v }; this.moduleActions = a }}>
                {moduleOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
              </el-select>
              <el-select v-model={item.enabled} size="small" disabled={this.isReadOnly}
                on-change={(v: boolean) => { const a = [...this.moduleActions]; a[i] = { ...a[i], enabled: v }; this.moduleActions = a }}>
                <el-option label="开启" value={true} />
                <el-option label="关闭" value={false} />
              </el-select>
              {!this.isReadOnly && <el-button type="text" icon="el-icon-delete" size="small" style="color: #F56C6C" on-click={() => this.removeModuleAction(i)} />}
            </div>
          ))}
          {!this.isReadOnly && <el-button type="text" icon="el-icon-plus" size="small" on-click={this.addModuleAction}>添加一个动作</el-button>}
        </div>
      </el-form-item>
    )
  }

  renderSkynetConfig(h: any) {
    if (this.form.action !== 'modify_skynet_rule') return null
    const ruleOptions = this.skynetRuleList
      .map((r: any) => ({ label: `【${r.ruleid || r.id}】${r.name || ''}`, value: String(r.ruleid || r.id) }))
    return (
      <el-form-item label="规则动作" required>
        <div style="width: 100%">
          {this.skynetActions.map((item: any, i: number) => (
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px">
              <el-select v-model={item.key} placeholder="选择内置规则" size="small" filterable style="flex: 1" popperClass="skynet-rule-select"
                disabled={this.isReadOnly}
                on-change={(v: string) => { const a = [...this.skynetActions]; a[i] = { ...a[i], key: v }; this.skynetActions = a }}>
                {ruleOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
              </el-select>
              <el-select v-model={item.enabled} size="small" disabled={this.isReadOnly}
                on-change={(v: boolean) => { const a = [...this.skynetActions]; a[i] = { ...a[i], enabled: v }; this.skynetActions = a }}>
                <el-option label="开启" value={true} />
                <el-option label="关闭" value={false} />
              </el-select>
              {!this.isReadOnly && <el-button type="text" icon="el-icon-delete" size="small" style="color: #F56C6C" on-click={() => this.removeSkynetAction(i)} />}
            </div>
          ))}
          {!this.isReadOnly && <el-button type="text" icon="el-icon-plus" size="small" on-click={this.addSkynetAction}>添加一个动作</el-button>}
        </div>
      </el-form-item>
    )
  }

  render(h: any) {
    return (
      <div>
        <el-alert
          title="配置此功能时，可能因匹配规则问题导致正常业务被拦截或产生过多日志（磁盘占用过大），请上线后观察"
          type="warning"
          closable={false}
          show-icon
          style="margin-bottom: 16px"
        />

        <div style="margin-bottom: 16px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap">
          <el-select v-model={this.selectedWafId} placeholder="选择 WAF 实例" on-change={this.handleWafChange} disabled={!this.wafReady} style="width: 280px">
            {this.wafOptions.map(w => <el-option key={w.captain_instance_id} label={this.formatWafOptionLabel(w)} value={w.captain_instance_id} />)}
          </el-select>
          <RuleFilterBar
            defaultFields={this.defaultFilterFields}
            optionalFields={this.optionalFilterFields}
            conditions={this.filterConditions}
            on-search={this.handleFilterSearch}
          />
          <el-button type="primary" on-click={this.handleCreate} disabled={!this.wafId || this.isWafUnavailable}>新建规则</el-button>
        </div>
        {this.renderWafOfflineAlert(h)}

        <Grid ref="grid" columns={[...this.columns, {
          key: 'actions', title: '操作', width: 120, render: (h: any, row: PolicyRule) => {
            const adm = isAdmin()
            const editProtected = !adm && this.isEditProtected(row)
            const deleteProtected = !adm && this.isDeleteProtected(row)
            const inUseBlocked = adm && this.isInUse(row)
            const iconBtnStyle = 'width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;'
            const editStyle = editProtected ? iconBtnStyle + 'color:#ccc' : iconBtnStyle + 'color:#666'

            let editTooltip = '编辑'
            if (!adm) {
              if (this.isShared(row)) editTooltip = '该资源被多个租户组绑定，无法编辑'
              else if (row.has_external_ref) editTooltip = '该规则正在被其他站点引用，无法编辑'
            }

            return (
              <span style="display: inline-flex; align-items: center">
                <el-tooltip content={editTooltip} placement="top">
                  <el-button size="mini" icon="el-icon-edit" style={editStyle}
                    on-click={() => this.handleEdit(row)} />
                </el-tooltip>
                <el-dropdown trigger="click" style="margin-left: 8px" on-command={(cmd: string) => {
                  if (cmd === 'viewLog') this.handleViewLog(row)
                  else if (cmd === 'enable') {
                    if (editProtected) {
                      const msg = this.isShared(row)
                        ? '该资源被多个租户组绑定，不可变更状态'
                        : '该规则正在被其他站点引用，无法启用'
                      this.$message.warning(msg)
                    } else {
                      this.handleToggle(row, true)
                    }
                  }
                  else if (cmd === 'disable') {
                    if (editProtected) {
                      const msg = this.isShared(row)
                        ? '该资源被多个租户组绑定，不可变更状态'
                        : '该规则正在被其他站点引用，无法禁用'
                      this.$message.warning(msg)
                    } else {
                      this.handleToggle(row, false)
                    }
                  }
                  else if (cmd === 'delete') {
                    if (inUseBlocked) {
                      this.$message.warning(`该规则正在被 ${(row.websites || []).length} 个站点使用，无法删除`)
                    } else if (deleteProtected) {
                      const msg = this.isInUse(row)
                        ? `该规则正在被 ${(row.websites || []).length} 个站点使用，无法删除`
                        : '该资源被多个租户组绑定，不可删除'
                      this.$message.warning(msg)
                    } else {
                      this.handleDelete(row)
                    }
                  }
                }}>
                  <el-button size="mini" icon="el-icon-more" style={iconBtnStyle + 'color:#666'} />
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="viewLog">查看日志</el-dropdown-item>
                    <el-dropdown-item command="enable" style={editProtected ? 'color: #ccc' : ''}>启用规则</el-dropdown-item>
                    <el-dropdown-item command="disable" style={editProtected ? 'color: #ccc' : ''}>禁用规则</el-dropdown-item>
                    <el-dropdown-item command="delete" style={(deleteProtected || inUseBlocked) ? 'color: #ccc' : 'color: red'}>删除规则</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </span>
            )
          }
        }]} fetchData={this.fetchData} defaultConditions={this.filterConditions} />

        <el-dialog
          title={this.isReadOnly ? '查看规则' : (this.editingItem ? '编辑规则' : '新建规则')}
          visible={this.showForm}
          on-close={() => { this.showForm = false }}
          width="720px"
          top="8vh"
        >
          <el-form label-width="100px" size="small">
            <el-form-item label="状态">
              <el-select v-model={this.form.is_enabled} disabled={this.isReadOnly}>
                <el-option label="启用" value={true} />
                <el-option label="禁用" value={false} />
              </el-select>
            </el-form-item>
            <el-form-item label="模式">
              <span style="display: flex; align-items: center; gap: 4px">
                <el-select v-model={this.form.action} disabled={this.isReadOnly}>
                  {ACTION_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
                </el-select>
              </span>
            </el-form-item>
            <el-form-item label="备注" required>
              <el-input type="textarea" v-model={this.form.comment} rows={2} disabled={this.isReadOnly} />
            </el-form-item>
            {!this.isSpecialAction && (
              <el-form-item label="风险等级">
                <el-select v-model={this.form.risk_level} disabled={this.isReadOnly}>
                  {RISK_LEVEL_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
                </el-select>
              </el-form-item>
            )}
            <el-form-item label="匹配条件">
              <ConditionEditor
                key={this.editingItem ? 'edit-' + this.editingItem.id : 'create'}
                ref="conditionEditor"
                value={this.form.pattern}
                on-input={(val: any) => { this.form.pattern = val }}
                captainInstanceId={this.wafId}
                disabled={this.isReadOnly}
              />
            </el-form-item>
            {this.renderModuleConfig(h)}
            {this.renderSkynetConfig(h)}
            <el-form-item label="使用范围">
              <el-select v-model={this.form.websites} multiple placeholder="选择站点" style="width: 100%" disabled={this.isReadOnly}>
                {this.sites.map(s => <el-option key={s.id} label={s.name || `Site ${s.id}`} value={s.id} />)}
              </el-select>
            </el-form-item>
            {!this.isSpecialAction && (
              <el-form-item label="攻击类型" required>
                <el-select v-model={this.form.attack_type} placeholder="请选择攻击类型" clearable disabled={this.isReadOnly}>
                  {ATTACK_TYPE_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
                </el-select>
              </el-form-item>
            )}

            <el-collapse v-model={this.advancedOpen}>
              <el-collapse-item title="高级设置" name="advanced">
                <el-form-item label="是否记录日志">
                  <el-select v-model={this.form.log_option} disabled={this.isReadOnly}>
                    {LOG_OPTION_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
                  </el-select>
                </el-form-item>
                <div style={LOG_OPTION_DESCRIPTION_STYLE}>
                  {LOG_OPTION_OPTIONS.map(o => (
                    <div><b>{o.label}：</b>{LOG_OPTION_DESCRIPTIONS[o.value]}</div>
                  ))}
                </div>
                {this.form.action === 'deny' && (
                  <el-form-item label="阻断状态码">
                    <el-input type="number" v-model={this.form.status_code} min={100} max={599} disabled={this.isReadOnly} style="width: 230px" />
                  </el-form-item>
                )}
                <el-form-item label="过期时间">
                  <el-date-picker v-model={this.form.expire_time} type="datetime" placeholder="选择过期时间" disabled={this.isReadOnly} />
                </el-form-item>
                <el-form-item label="检测前解码">
                  <el-switch v-model={this.form.decode_before_detection} disabled={this.isReadOnly} />
                  {this.form.decode_before_detection && (
                    <div style="margin-top: 8px; width: 100%">
                      {this.form.decode_methods.map((method: string, i: number) => (
                        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px">
                          <el-select v-model={this.form.decode_methods[i]} size="small" disabled={this.isReadOnly}
                            on-change={(v: string) => { const m = [...this.form.decode_methods]; m[i] = v; this.form = { ...this.form, decode_methods: m } }}>
                            {DECODE_METHOD_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
                          </el-select>
                          {!this.isReadOnly && this.form.decode_methods.length > 1 && (
                            <el-button type="text" icon="el-icon-delete" size="small" style="color: #F56C6C" on-click={() => this.removeDecodeMethod(i)} />
                          )}
                        </div>
                      ))}
                      {!this.isReadOnly && <el-button type="text" icon="el-icon-plus" size="small" on-click={this.addDecodeMethod}>添加一层解码</el-button>}
                    </div>
                  )}
                </el-form-item>
                <div style={LOG_OPTION_DESCRIPTION_STYLE}>开关开启后，解码方式将按照配置顺序进行解码。</div>
                <el-form-item label="规则生效时间">
                  <el-radio-group
                    value={this.form.cron_config.type}
                    disabled={this.isReadOnly}
                    on-input={(type: string) => {
                      if (type === 'period') {
                        this.form = { ...this.form, cron_config: { type: 'period', weekdays: [], start_time: '00:00', end_time: '23:59' } }
                      } else if (type === 'timing') {
                        this.form = { ...this.form, cron_config: { type: 'timing', range: [] } }
                      } else {
                        this.form = { ...this.form, cron_config: { type: 'all' } }
                      }
                    }}
                  >
                    <el-radio label="all">永久</el-radio>
                    <el-radio label="timing">定时</el-radio>
                    <el-radio label="period">周期</el-radio>
                  </el-radio-group>
                  {this.form.cron_config.type === 'timing' && (
                    <div style="margin-top: 8px">
                      <el-date-picker type="datetimerange" v-model={this.form.cron_config.range}
                        start-placeholder="开始时间" end-placeholder="结束时间"
                        value-format="yyyy-MM-ddTHH:mm:ssZ" disabled={this.isReadOnly} />
                    </div>
                  )}
                  {this.form.cron_config.type === 'period' && (
                    <div style="margin-top: 8px">
                      <el-checkbox-group v-model={this.form.cron_config.weekdays} disabled={this.isReadOnly}>
                        {WEEKDAY_OPTIONS.map(o => <el-checkbox key={o.value} label={o.value}>{o.label}</el-checkbox>)}
                      </el-checkbox-group>
                      <div style="display: flex; align-items: center; gap: 8px; margin-top: 8px">
                        <el-time-picker v-model={this.form.cron_config.start_time} placeholder="开始时间" format="HH:mm" value-format="HH:mm" disabled={this.isReadOnly} />
                        <span>-</span>
                        <el-time-picker v-model={this.form.cron_config.end_time} placeholder="结束时间" format="HH:mm" value-format="HH:mm" disabled={this.isReadOnly} />
                      </div>
                    </div>
                  )}
                </el-form-item>
              </el-collapse-item>
            </el-collapse>
          </el-form>

          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>{this.isReadOnly ? '关闭' : '取消'}</el-button>
            {!this.isReadOnly && <el-button type="primary" loading={this.submitting} on-click={this.handleSubmit}>确定</el-button>}
          </div>
        </el-dialog>
      </div>
    )
  }
}
