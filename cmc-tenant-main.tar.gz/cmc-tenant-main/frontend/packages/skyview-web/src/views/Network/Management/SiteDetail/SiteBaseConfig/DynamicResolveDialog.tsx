// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { fallbackTypeOptions } from './constants'

@Component
export default class DynamicResolveDialog extends Vue {
  @Prop() value!: any

  get v() { return this.value || {} }
  get rc() { return this.v.resolver_config || {} }
  get enabled() { return !!this.v.is_enabled }

  emit(v: any) { this.$emit('input', v) }

  render(h: any) {
    const v = this.v, rc = this.rc, en = this.enabled
    return (
      <el-form label-width="140px" size="small">
        <el-form-item label="启用动态域名解析">
          <el-switch value={!!v.is_enabled} on-input={(val: boolean) => this.emit({ ...v, is_enabled: val })} />
        </el-form-item>
        {en && [
          <el-form-item label="解析失败备用方案">
            <el-select value={v.dynamic_resolve_fallback || 'stale'} on-input={(val: string) => this.emit({ ...v, dynamic_resolve_fallback: val })} style="width:300px">
              {fallbackTypeOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
            </el-select>
          </el-form-item>,
          <el-form-item label="解析失败冷却时间">
            <el-input-number value={v.dynamic_resolve_fail_timeout || 10} on-input={(val: number) => this.emit({ ...v, dynamic_resolve_fail_timeout: val })} min={0} max={86400} controls={false} style="width:200px" />
            <span style="margin-left:8px;color:#909399;font-size:12px">秒</span>
          </el-form-item>,
          <el-form-item label="缓存过期时间">
            <el-input-number value={rc.valid} on-input={(val: number) => this.emit({ ...v, resolver_config: { ...rc, valid: val } })} min={1} max={86400} controls={false} style="width:200px" placeholder="使用 DNS 服务器返回的 TTL 值" />
            <span style="margin-left:8px;color:#909399;font-size:12px">秒</span>
          </el-form-item>,
          <el-form-item label="解析超时时间">
            <el-input-number value={rc.resolver_timeout} on-input={(val: number) => this.emit({ ...v, resolver_config: { ...rc, resolver_timeout: val } })} min={1} max={3600} controls={false} style="width:200px" placeholder="默认 30 秒超时" />
            <span style="margin-left:8px;color:#909399;font-size:12px">秒</span>
          </el-form-item>,
        ]}
      </el-form>
    )
  }
}
