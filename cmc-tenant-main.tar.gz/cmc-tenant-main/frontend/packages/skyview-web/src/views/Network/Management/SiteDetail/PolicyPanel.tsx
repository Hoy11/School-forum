// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, PolicyModel } from '@/types/website'
import { canEditBusiness } from '@/permission'
import { createFieldUpdater } from './useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'
import PolicyDetailWidget from './PolicyDetailWidget'
import { RouteName } from '@/router/names'

@Component({ components: { EditableRow, PolicyDetailWidget } })
export default class PolicyPanel extends Vue {
  @Prop() site!: Website
  @Prop({ default: () => [] }) policies!: PolicyModel[]
  @Prop({ default: 0 }) captainInstanceId!: number

  get canEdit() { return canEditBusiness() }
  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }

  get policyName() {
    if (!this.site.policy_group) return '不使用防护策略'
    const p = this.policies.find(p => p.id === this.site.policy_group)
    return p?.name || String(this.site.policy_group)
  }

  goToPolicyDetail() {
    if (!this.site.policy_group) return
    this.$router.push({
      name: RouteName.policyDetail,
      query: { id: String(this.site.policy_group), waf: String(this.captainInstanceId) },
    })
  }

  render(h: any) {
    const s = this.site
    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">攻击防护策略</div>

        <EditableRow label="防护策略" editable={this.canEdit}
          value={String(s.policy_group || 0)}
          submitFn={(v) => this.updateField({ policy_group: v === '0' ? null : Number(v) })}
          scopedSlots={{
            default: () => s.policy_group
              ? <span style="color:#409EFF;cursor:pointer" on-click={this.goToPolicyDetail}>{this.policyName}</span>
              : <el-tag type="warning" size="mini">不使用防护策略</el-tag>,
            edit: ({ value, input }) => (
              <el-select value={value} on-input={input} style="width:100%">
                <el-option key={0} label="不使用防护策略" value="0" />
                {this.policies.map(p => <el-option key={p.id} label={p.name} value={String(p.id)} />)}
              </el-select>
            ),
          }} />

        {!s.policy_group && (
          <el-alert title={'防护策略为"不使用防护策略"时，无法对站点进行防护且无法调整站点相关的防护配置'} type="warning" show-icon closable={false} style="margin:8px 0" />
        )}

        {s.policy_group && (
          <PolicyDetailWidget policyId={s.policy_group} captainInstanceId={this.captainInstanceId} />
        )}
      </el-card>
    )
  }
}
