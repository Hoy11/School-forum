import { ColumnDef } from '@/components/Grid'
import {
  Website, BackendType, LoadBalancePolicy,
  WebsiteHealthyCheckStatus,
} from '@/types/website'
import { SessionType } from '@/types/website-security'

// === Column context ===

export interface ColumnContext {
  certOptions: { value: number; label: string }[]
  policyOptions: { id: number; name: string }[]
}

// === Column key constants ===

export const ALL_COLUMN_KEYS = [
  'is_enabled', 'ntlm_enabled', 'name', 'remark',
  'ports', 'server_names', 'url_paths', 'ssl_cert',
  'type', 'load_balance_policy', 'servers', 'proxy_bind_config',
  'policy_group', 'session_method', 'cookie_security',
  'create_time', 'last_update_time',
] as const

export type ColumnKey = typeof ALL_COLUMN_KEYS[number]

export const DEFAULT_COLUMN_KEYS: ColumnKey[] = [
  'is_enabled', 'name', 'ports', 'server_names', 'create_time',
]

export const COLUMN_LABELS: Record<ColumnKey, string> = {
  is_enabled: '状态',
  ntlm_enabled: '站点类型',
  name: '站点名称',
  remark: '备注',
  ports: '端口',
  server_names: '域名',
  url_paths: '生效地址',
  ssl_cert: 'HTTPS 证书',
  type: '响应方式',
  load_balance_policy: '调度算法',
  servers: '服务器地址',
  proxy_bind_config: '回源 IP',
  policy_group: '防护策略',
  session_method: '用户识别',
  cookie_security: 'cookie 防护状态',
  create_time: '创建时间',
  last_update_time: '最后更新时间',
}

export const MIN_COLUMNS = 2
export const MAX_COLUMNS = 10
export const STORAGE_KEY = 'cmc_selectedSiteColumn'

// === Column definitions ===

function buildAllColumns(ctx: ColumnContext): Record<ColumnKey, ColumnDef> {
  return {
    is_enabled: { key: 'is_enabled', title: '状态', width: 85, render: renderStatus },
    ntlm_enabled: { key: 'ntlm_enabled', title: '站点类型', width: 100, render: renderSiteType },
    name: { key: 'name', title: '站点名称', width: 160, render: renderName },
    remark: { key: 'remark', title: '备注', width: 140, render: renderRemark },
    ports: { key: 'ports', title: '端口', width: 180, render: renderPorts },
    server_names: { key: 'server_names', title: '域名', render: renderServerNames },
    url_paths: { key: 'url_paths', title: '生效地址', width: 160, render: renderUrlPaths },
    ssl_cert: { key: 'ssl_cert', title: 'HTTPS 证书', width: 140, render: (h, row) => renderSslCert(h, row, ctx.certOptions) },
    type: { key: 'type', title: '响应方式', width: 120, render: renderBackendType },
    load_balance_policy: { key: 'load_balance_policy', title: '调度算法', width: 120, render: renderLoadBalance },
    servers: { key: 'servers', title: '服务器地址', width: 200, render: renderServers },
    proxy_bind_config: { key: 'proxy_bind_config', title: '回源 IP', width: 140, render: renderProxyBind },
    policy_group: { key: 'policy_group', title: '防护策略', width: 140, render: (h, row) => renderPolicy(h, row, ctx.policyOptions) },
    session_method: { key: 'session_method', title: '用户识别', width: 140, render: renderSessionMethod },
    cookie_security: { key: 'cookie_security', title: 'cookie 防护状态', width: 130, render: renderCookieSecurity },
    create_time: { key: 'create_time', title: '创建时间', width: 170, render: renderCreateTime },
    last_update_time: { key: 'last_update_time', title: '最后更新时间', width: 170, render: renderLastUpdateTime },
  }
}

export function getSiteColumns(ctx: ColumnContext, selectedKeys: readonly ColumnKey[]): ColumnDef[] {
  const all = buildAllColumns(ctx)
  return selectedKeys.filter(k => k in all).map(k => all[k])
}

// === Column renderers ===

function renderStatus(h: any, row: Website) {
  if (!row.is_enabled) return <el-tag type="info" size="mini">禁用</el-tag>
  switch (row.health_check_status) {
    case WebsiteHealthyCheckStatus.unhealthy:
      return <el-tag type="danger" size="mini">异常</el-tag>
    case WebsiteHealthyCheckStatus.unknown:
      return <el-tag type="warning" size="mini">未知</el-tag>
    default:
      return <el-tag type="success" size="mini">启用</el-tag>
  }
}

function renderSiteType(h: any, row: Website) {
  return row.ntlm_enabled ? 'NTLM 站点' : '普通站点'
}

function renderName(h: any, row: Website) {
  return (
    <span>
      {row.flag && <span style={`display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px;vertical-align:middle;background:${flagColor(row.flag)}`} />}
      {row.name}
    </span>
  )
}

function renderRemark(h: any, row: Website) {
  return row.remark || '-'
}

function renderPorts(h: any, row: Website) {
  const ports = row.ports
  if (!ports?.length) return '-'
  return (
    <span>
      {ports.map((p, i) => {
        const sep = i > 0 ? ', ' : ''
        const text = p.ssl
          ? (p.proxy_protocol ? `${p.port}/ssl - Proxy Protocol` : `${p.port}/ssl`)
          : (p.proxy_protocol ? `${p.port} - Proxy Protocol` : `${p.port}`)
        return p.ssl
          ? <span>{sep}<span style="color: #67C23A">{text}</span></span>
          : <span>{sep}{text}</span>
      })}
    </span>
  )
}

function renderServerNames(h: any, row: Website) {
  return row.server_names?.filter(Boolean).join(', ') || '-'
}

function renderUrlPaths(h: any, row: Website) {
  if (!row.url_paths?.length) return '-'
  return row.url_paths.map(p => `${translateUrlPathOp(p.op)} ${p.url_path}`).join(', ')
}

function renderSslCert(h: any, row: Website, certOptions: { value: number; label: string }[]) {
  if (!row.ports?.some(p => p.ssl)) return '-'
  const cert = certOptions.find(c => c.value === row.ssl_cert)
  return cert ? cert.label : '默认'
}

function renderBackendType(h: any, row: Website) {
  return translateBackendType(row.backend_config?.type)
}

function renderLoadBalance(h: any, row: Website) {
  const cfg = row.backend_config as any
  if (cfg?.type !== BackendType.proxy) return '-'
  return translateLoadBalancePolicy(cfg.load_balance_policy)
}

function renderServers(h: any, row: Website) {
  const cfg = row.backend_config as any
  if (cfg?.type !== BackendType.proxy) return '-'
  const servers = cfg.servers || []
  if (!servers.length) return '-'
  return servers
    .filter((s: any) => s.is_enabled)
    .map((s: any) => `${s.protocol || 'http'}://${s.host}:${s.port}`)
    .join(', ') || '-'
}

function renderProxyBind(h: any, row: Website) {
  const cfg = row.proxy_bind_config
  if (!cfg?.enable || !cfg.proxy_bind_ip_list?.length) return '默认回源方式'
  return '回源到指定 IP'
}

function renderPolicy(h: any, row: Website, policyOptions: { id: number; name: string }[]) {
  if (!row.policy_group) return <span style="color: #909399">不使用防护策略</span>
  const policy = policyOptions.find(p => p.id === row.policy_group)
  return policy ? policy.name : <span style="color: #909399">不使用防护策略</span>
}

function renderSessionMethod(h: any, row: Website) {
  return translateSessionMethod(row.session_method?.type)
}

function renderCookieSecurity(h: any, row: Website) {
  return row.cookie_security?.is_enabled ? '开启' : '关闭'
}

function renderCreateTime(h: any, row: Website) {
  return row.create_time ? formatTime(row.create_time) : '-'
}

function renderLastUpdateTime(h: any, row: Website) {
  return row.last_update_time ? formatTime(row.last_update_time) : '-'
}

// === Translation helpers ===

function translateBackendType(type: string) {
  switch (type) {
    case BackendType.proxy: return '反向代理'
    case BackendType.redirect: return '重定向'
    case BackendType.response: return '自定义响应'
    default: return '-'
  }
}

function translateLoadBalancePolicy(policy: string) {
  switch (policy) {
    case LoadBalancePolicy.roundBin: return '加权轮询法'
    case LoadBalancePolicy.leastConn: return '最小连接数法'
    case LoadBalancePolicy.ipHash: return '源地址哈希法'
    case LoadBalancePolicy.sessionSticky: return '会话保持'
    case LoadBalancePolicy.hash: return '一致性哈希法'
    case LoadBalancePolicy.ntlm: return 'NTLM 默认调度算法'
    default: return '-'
  }
}

function translateSessionMethod(type: string) {
  switch (type) {
    case SessionType.off: return '不使用'
    case SessionType.safelineSession: return 'WAF 用户系统'
    case SessionType.srcIP: return '源 IP'
    case SessionType.cookie:
    case SessionType.urlQuery:
    case SessionType.bodyForm:
    case SessionType.header:
    case SessionType.custom:
      return '从请求中提取用户 ID'
    default: return '-'
  }
}

function translateUrlPathOp(op: string) {
  switch (op) {
    case 'pre': return '前缀匹配'
    case 'reg': return '正则匹配'
    case 'exact': return '完全匹配'
    default: return op
  }
}

function formatTime(unix: number): string {
  const d = new Date(unix * 1000)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`
}

// === Shared helpers ===

export function flagColor(flag: string | null | undefined): string {
  const map: Record<string, string> = {
    red: '#F56C6C', orange: '#E6A23C', yellow: '#F2C94C',
    green: '#67C23A', blue: '#409EFF', purple: '#9B59B6',
  }
  return map[flag || ''] || '#C0C4CC'
}
