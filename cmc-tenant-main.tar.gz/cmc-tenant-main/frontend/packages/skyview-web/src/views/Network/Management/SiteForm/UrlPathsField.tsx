// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { urlPathOpOptions } from '@/utils/site'

@Component
export default class UrlPathsField extends Vue {
  @Prop({ default: () => [{ op: 'pre', url_path: '/' }] }) value!: Array<{ op: string; url_path: string }>
  @Prop({ default: false }) disabled!: boolean
  @Prop({ default: false }) bare!: boolean

  addPath() {
    this.$emit('input', [...this.value, { op: 'pre', url_path: '/' }])
  }

  removePath(i: number) {
    if (this.value.length <= 1) return
    this.$emit('input', this.value.filter((_, idx) => idx !== i))
  }

  updatePath(i: number, field: string, v: string) {
    const updated = this.value.map((item, idx) => idx === i ? { ...item, [field]: v } : item)
    this.$emit('input', updated)
  }

  renderPaths(h: any) {
    return this.value.map((up, i) => (
      <div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
        <el-select value={up.op} on-input={(v: string) => this.updatePath(i, 'op', v)} style="width:120px" disabled={this.disabled}>
          {urlPathOpOptions.map(opt => (
            <el-option label={opt.label} value={opt.value} />
          ))}
        </el-select>
        <el-input value={up.url_path} on-input={(v: string) => this.updatePath(i, 'url_path', v)}
          style="flex:1" placeholder={up.op === 'reg' ? '请输路径，如 ^pages./' : '请输路径，如 /a/pages'}
          disabled={this.disabled} />
        {this.value.length > 1 && (
          <el-button type="text" icon="el-icon-delete" on-click={() => this.removePath(i)} />
        )}
      </div>
    ))
  }

  render(h: any) {
    const content = (
      <div>
        {this.renderPaths(h)}
        {!this.disabled && (
          <el-button type="text" icon="el-icon-plus" on-click={this.addPath}>添加生效地址</el-button>
        )}
      </div>
    )
    if (this.bare) return content
    return <el-form-item label="生效地址">{content}</el-form-item>
  }
}
