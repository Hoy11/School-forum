// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { ProxyHeadersConfig } from '@/types/website-backend'

@Component
export default class HeadersDialog extends Vue {
  @Prop() value!: ProxyHeadersConfig[]

  addRow() {
    const list = [...this.value, { name: '', context: 'request', action: 'set', value: '' }]
    this.$emit('input', list)
  }

  removeRow(index: number) {
    const list = [...this.value]
    list.splice(index, 1)
    this.$emit('input', list)
  }

  updateField(index: number, field: string, val: any) {
    const list = [...this.value]
    list[index] = { ...list[index], [field]: val }
    this.$emit('input', list)
  }

  render(h: any) {
    const rows = this.value || []
    return (
      <div>
        <el-table data={rows} size="small" border>
          <el-table-column label="名称" scopedSlots={{
            default: ({ row, $index }) => (
              <el-input value={row.name} on-input={(v: string) => this.updateField($index, 'name', v)} size="small" />
            ),
          }} />
          <el-table-column label="方向" width={100} scopedSlots={{
            default: ({ row, $index }) => (
              <el-select value={row.context} on-input={(v: string) => this.updateField($index, 'context', v)} size="small">
                <el-option label="请求" value="request" />
                <el-option label="响应" value="response" />
              </el-select>
            ),
          }} />
          <el-table-column label="动作" width={100} scopedSlots={{
            default: ({ row, $index }) => (
              <el-select value={row.action} on-input={(v: string) => this.updateField($index, 'action', v)} size="small">
                <el-option label="设置" value="set" />
                <el-option label="隐藏" value="hide" />
              </el-select>
            ),
          }} />
          <el-table-column label="值" scopedSlots={{
            default: ({ row, $index }) => (
              row.action === 'set'
                ? <el-input value={row.value || ''} on-input={(v: string) => this.updateField($index, 'value', v)} size="small" />
                : <span style="color:#909399">-</span>
            ),
          }} />
          <el-table-column label="操作" width={60} scopedSlots={{
            default: ({ $index }) => (
              <el-button type="text" icon="el-icon-delete" on-click={() => this.removeRow($index)} />
            ),
          }} />
        </el-table>
        <el-button size="small" icon="el-icon-plus" on-click={this.addRow} style="margin-top:8px">添加</el-button>
      </div>
    )
  }
}
