// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Website, SSLCertModel, PolicyModel, NodeStatus, AssetGroupType, WorkGroupModel, CertSettings } from '@/types/website'
import { CertOriginal, WorkGroupOperationMode } from '@/types/website-enums'
import { getDefaultReverseProxySite, getDefaultCertSettings, uploadCertIfNeeded, uploadResponseFileIfNeeded, prepareSiteForSubmit, validateCertSettings, validateBackendConfig } from '@/utils/site'
import { siteCreate, siteUpdate } from '@/api/captain-site'
import StepListener from './StepListener'
import StepResponse from './StepResponse'
import StepPolicy from './StepPolicy'
import StepFinish from './StepFinish'

const STEPS = [
  { title: '监听信息', description: '配置防护站点信息' },
  { title: '响应方式', description: '配置服务器响应方式' },
  { title: '防护策略', description: '配置请求检测处理方式' },
  { title: '完成', description: '完成防护站点配置' },
]

@Component({ components: { StepListener, StepResponse, StepPolicy, StepFinish } })
export default class ReverseProxySite extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: null }) editingItem!: Website | null
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) policyGroups!: PolicyModel[]
  @Prop({ default: () => [] }) certs!: SSLCertModel[]
  @Prop({ default: () => [] }) nodes!: NodeStatus[]
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]
  @Prop({ default: () => [] }) workGroups!: WorkGroupModel[]
  @Prop({ default: false }) guomiEnabled!: boolean
  @Prop({ default: false }) isHardwareMode!: boolean
  @Prop({ default: '' }) operationMode!: string

  activeStep = 0
  form: Website = getDefaultReverseProxySite()
  certSettings: CertSettings = getDefaultCertSettings()
  submitting = false

  get steps() {
    return STEPS.map((s, i) => ({
      ...s,
      description: i === 2 && this.form.ntlm_enabled ? '完成资产组配置' : s.description,
    }))
  }

  @Watch('visible', { immediate: true })
  onVisibleChange(val: boolean) {
    if (!val) return
    this.activeStep = 0
    this.certSettings = getDefaultCertSettings()
    if (this.editingItem?.id) {
      this.form = { ...getDefaultReverseProxySite(), ...this.editingItem }
    } else {
      this.form = getDefaultReverseProxySite()
    }
  }

  handlePrev() {
    if (this.activeStep > 0) this.activeStep--
  }

  async handleNext() {
    if (this.activeStep === 2) {
      await this.handleSubmit()
    } else {
      this.activeStep++
    }
  }

  get hasSslPort() { return this.form.ports?.some(p => p.ssl) }

  async handleSubmit() {
    // StepPolicy session validation
    const stepPolicy = this.$refs.stepPolicy as any
    if (stepPolicy && !stepPolicy.validateSession()) return

    this.submitting = true
    try {
      if (this.hasSslPort) {
        const certError = validateCertSettings(this.certSettings)
        if (certError) { this.$message.error(certError); return }

        if (this.certSettings.type === CertOriginal.upload || this.certSettings.type === CertOriginal.encrypt) {
          const certId = await uploadCertIfNeeded(this.captainInstanceId, this.certSettings, this.form)
          this.form.ssl_cert = certId
        }
      }

      const backendError = validateBackendConfig(this.form)
      if (backendError) { this.$message.error(backendError); return }

      const data = prepareSiteForSubmit(this.form)
      // Set correct operation_mode from parent
      data.operation_mode = this.operationMode || WorkGroupOperationMode.SoftwareReverseProxy
      if (this.editingItem?.id) {
        const resp = await siteUpdate({ ...data, id: this.editingItem.id, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '更新失败'); return }
      } else {
        const resp = await siteCreate({ ...data, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '创建失败'); return }
      }
      this.activeStep = 3
      this.$emit('success')
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    } finally {
      this.submitting = false
    }
  }

  get nextButtonText() {
    if (this.activeStep === 2) return '完成'
    if (this.activeStep === 3) return '完成'
    return '下一步'
  }

  render(h: any) {
    if (!this.visible) return null

    return (
      <el-dialog title={this.editingItem ? '编辑站点' : '新建站点'}
        visible={this.visible} on-close={() => this.$emit('close')}
        width="780px" top="5vh" destroy-on-close>

        <el-steps active={this.activeStep} finish-status="success" simple style="margin-bottom:20px">
          {this.steps.map(s => (
            <el-step title={s.title} description={s.description} />
          ))}
        </el-steps>

        <el-form label-width="140px" size="small">
          {this.activeStep === 0 && (
            <StepListener form={this.form} certs={this.certs} nodes={this.nodes}
              workGroups={this.workGroups} guomiEnabled={this.guomiEnabled}
              isHardwareMode={this.isHardwareMode} captainInstanceId={this.captainInstanceId}
              certSettings={this.certSettings}
              on-cert-change={(v: CertSettings) => { this.certSettings = v }}
              on-ntlm-changed={() => {}} />
          )}
          {this.activeStep === 1 && (
            <StepResponse form={this.form} ntlmEnabled={this.form.ntlm_enabled} />
          )}
          {this.activeStep === 2 && (
            <StepPolicy ref="stepPolicy" form={this.form} policyGroups={this.policyGroups}
              assetGroups={this.assetGroups} ntlmEnabled={this.form.ntlm_enabled} />
          )}
          {this.activeStep === 3 && <StepFinish />}
        </el-form>

        <div slot="footer">
          {this.activeStep > 0 && this.activeStep < 3 && (
            <el-button on-click={this.handlePrev}>上一步</el-button>
          )}
          {this.activeStep < 3 && (
            <el-button type="primary" on-click={this.handleNext} loading={this.submitting}>
              {this.nextButtonText}
            </el-button>
          )}
          {this.activeStep === 3 && (
            <el-button type="primary" on-click={() => this.$emit('close')}>关闭</el-button>
          )}
        </div>
      </el-dialog>
    )
  }
}
