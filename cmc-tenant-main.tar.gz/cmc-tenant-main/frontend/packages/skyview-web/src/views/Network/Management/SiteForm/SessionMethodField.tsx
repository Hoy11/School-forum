// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { SessionType } from '@/types/website-security'

const CUSTOM_TYPES = [SessionType.cookie, SessionType.urlQuery, SessionType.bodyForm, SessionType.header]

function getMainType(t: string): string {
  if (CUSTOM_TYPES.includes(t as SessionType)) return 'custom'
  if (t === SessionType.safelineSession) return 'internal_session'
  if (t === SessionType.srcIP) return 'src_ip'
  return 'off'
}

const LOCATION_OPTIONS = [
  { label: 'Cookie', value: SessionType.cookie },
  { label: 'POST 参数', value: SessionType.bodyForm },
  { label: 'HTTP 头', value: SessionType.header },
  { label: 'GET 参数', value: SessionType.urlQuery },
]

@Component
export default class SessionMethodField extends Vue {
  @Prop({ default: () => ({ type: SessionType.off, param: '' }) }) value!: { type: string; param: string }
  @Prop({ default: false }) isProxy!: boolean

  get mainType() { return getMainType(this.value.type) }

  emit(v: { type: string; param: string }) { this.$emit('input', v) }

  handleMainTypeChange(v: string) {
    if (v === 'off') this.emit({ type: SessionType.off, param: '' })
    else if (v === 'internal_session') this.emit({ type: SessionType.safelineSession, param: '' })
    else if (v === 'src_ip') this.emit({ type: SessionType.srcIP, param: '' })
    else this.emit({ type: SessionType.cookie, param: '' })
  }

  validate(): boolean {
    if (this.mainType === 'custom' && !this.value.param) {
      this.$message.warning('请输入用户 ID 参数名')
      return false
    }
    return true
  }

  render(h: any) {
    return (
      <div>
        <el-form-item label="用户识别方式">
          <el-select value={this.mainType} on-input={this.handleMainTypeChange} style="width:240px">
            <el-option label="不使用" value="off" />
            {this.isProxy && <el-option label="WAF 用户系统" value="internal_session" />}
            <el-option label="从请求中提取用户 ID" value="custom" />
            <el-option label="源 IP" value="src_ip" />
          </el-select>
        </el-form-item>

        {this.mainType === 'custom' && (
          <div style="margin-left:140px;margin-bottom:12px">
            <div style="display:flex;gap:8px;align-items:center">
              <span>用户 ID 位于</span>
              <el-select value={this.value.type} on-input={(v: string) => this.emit({ type: v, param: this.value.param || '' })}
                style="width:120px">
                {LOCATION_OPTIONS.map(opt => <el-option label={opt.label} value={opt.value} />)}
              </el-select>
              <span>参数名</span>
              <el-input value={this.value.param} on-input={(v: string) => this.emit({ ...this.value, param: v })}
                placeholder="参数名" style="width:160px" />
            </div>
            <el-alert title="从请求中提取用户 ID：需与业务方确认参数名是否正确，否则无法正确识别用户。"
              type="warning" show-icon closable={false} style="margin-top:8px" />
          </div>
        )}
      </div>
    )
  }
}
