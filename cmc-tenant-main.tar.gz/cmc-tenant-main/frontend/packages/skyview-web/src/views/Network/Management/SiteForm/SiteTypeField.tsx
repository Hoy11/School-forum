// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class SiteTypeField extends Vue {
  @Prop() value!: boolean
  @Prop({ default: false }) guomiEnabled!: boolean

  render(h: any) {
    return (
      <el-form-item label="站点类型">
        <el-radio-group value={this.value} on-input={(v: boolean) => this.$emit('input', v)}>
          <el-radio label={false}>普通站点</el-radio>
          {!this.guomiEnabled && (
            <el-tooltip content="NTLM 站点仅支持转发流量至业务服务器，暂不支持攻击检测。同端口、同域名不同路径的情况下，配置一个普通 SSL 站点（不带 SSL 的话不受影响）和一个 NTLM 站点，会影响到该域名相关的转发配置。" placement="top">
              <el-radio label={true}>NTLM 站点</el-radio>
            </el-tooltip>
          )}
        </el-radio-group>
      </el-form-item>
    )
  }
}
