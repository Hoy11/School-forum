// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, AntiTamperStatus } from '@/types/website'
import { antiTamperRuleList } from '@/api/captain-rule'
import { AntiTamperRule } from '@/types/policy'

const pmLabels: Record<string, string> = { string: '精确', regex: '正则' }
const statusLabels: Record<string, string> = { normal: '正常', abnormal: '异常', not_enabled: '未启用' }

@Component
export default class SiteAntiTamperTab extends Vue {
  @Prop() site!: Website
  rules: AntiTamperRule[] = []
  loading = false

  get wafId(): number { return this.site.captain_instance_id || 0 }

  async created() {
    if (!this.wafId) return
    this.loading = true
    try {
      const resp = await antiTamperRuleList(this.wafId, 0, 200, [
        { oper: '=', target: 'websites', value: this.site.id },
      ])
      if (resp.err === null) {
        const data = resp.data as any
        this.rules = data?.items || data || []
      }
    } finally {
      this.loading = false
    }
  }

  get h() { return this.$createElement }

  render(h: any) {
    if (this.loading) return <div v-loading style="min-height:200px" />

    if (!this.rules.length) {
      return <div style="color:#909399;text-align:center;padding:40px">无防篡改规则</div>
    }

    return (
      <div>
        <el-table data={this.rules} size="small" border>
          <el-table-column prop="id" label="ID" width={80} />
          <el-table-column prop="comment" label="备注" />
          <el-table-column prop="host" label="域名" />
          <el-table-column prop="path" label="路径" />
          <el-table-column label="路径模式" width={80} render={(h: any, { row }: any) =>
            <span>{pmLabels[row.path_mode] || row.path_mode}</span>
          } />
          <el-table-column label="状态" width={80} render={(h: any, { row }: any) =>
            <el-tag size="mini" type={row.is_enabled ? 'success' : 'info'}>{row.is_enabled ? '启用' : '禁用'}</el-tag>
          } />
          <el-table-column label="防篡改状态" width={100} render={(h: any, { row }: any) => {
            const st = row.anti_tamper_status
            const type = st === 'normal' ? 'success' : st === 'abnormal' ? 'danger' : 'info'
            return <el-tag size="mini" type={type}>{statusLabels[st] || st}</el-tag>
          }} />
        </el-table>
      </div>
    )
  }
}
