// @ts-nocheck
import { Website, SSLCertModel } from '@/types/website'
import { WebsiteHealthyCheckStatus } from '@/types/website'

export function getHealthTag(site: Website): { type: string; text: string } {
  if (!site.is_enabled) return { type: 'info', text: '禁用' }
  switch (site.health_check_status) {
    case WebsiteHealthyCheckStatus.unhealthy: return { type: 'danger', text: '异常' }
    case WebsiteHealthyCheckStatus.unknown: return { type: 'warning', text: '未知' }
    default: return { type: 'success', text: '正常' }
  }
}

export function getFilteredIps(site: Website): string[] {
  return (site.ip || []).filter(ip => ip !== '0.0.0.0' && ip !== '::')
}

export function getCertName(site: Website, certs: SSLCertModel[]): string {
  if (!site.ssl_cert) return '无'
  const c = certs.find(x => x.id === site.ssl_cert)
  return c ? `${c.name} (${(c.info?.domains || []).join(', ')})` : `证书 #${site.ssl_cert}`
}

export function formatTime(ts: number): string {
  return ts ? new Date(ts * 1000).toLocaleString() : '-'
}

export function pathOpLabel(op: string): string {
  return op === 'pre' ? '前缀' : op === 'reg' ? '正则' : op === 'exact' ? '精确' : op
}

export function renderPortsDisplay(h: any, site: Website) {
  return (site.ports || []).map(p => {
    const tags = [`${p.port}`]
    if (p.ssl) tags.push('SSL')
    if (p.http2) tags.push('HTTP2')
    if (p.sni) tags.push('SNI')
    if (p.non_http) tags.push('TCP')
    if (p.proxy_protocol) tags.push('PP')
    return <el-tag size="mini" type={p.ssl ? 'success' : ''} effect={p.ssl ? 'dark' : 'plain'} style="margin:2px">{tags.join(' ')}</el-tag>
  })
}

export function renderPathsDisplay(h: any, site: Website) {
  return (site.url_paths || []).map(u => (
    <el-tag size="mini" style="margin:2px">{pathOpLabel(u.op)} {u.url_path}</el-tag>
  ))
}

export const SSL_PROTOCOL_OPTIONS = [
  { label: 'TLSv1', value: 'TLSv1' },
  { label: 'TLSv1.1', value: 'TLSv1.1' },
  { label: 'TLSv1.2', value: 'TLSv1.2' },
  { label: 'TLSv1.3', value: 'TLSv1.3' },
]
