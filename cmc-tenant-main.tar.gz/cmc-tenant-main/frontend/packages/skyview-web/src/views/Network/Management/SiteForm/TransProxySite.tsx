// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Website, SSLCertModel, PolicyModel, AssetGroupType, WorkGroupModel, WAddr, CertSettings } from '@/types/website'
import { CertOriginal, WorkGroupOperationMode } from '@/types/website-enums'
import { getDefaultReverseProxySite, getDefaultWAddr, getDefaultCertSettings, uploadCertIfNeeded, prepareWTransProxySiteForSubmit, validateCertSettings } from '@/utils/site'
import { siteCreate, siteUpdate } from '@/api/captain-site'
import SiteStatusField from './SiteStatusField'
import SiteTypeField from './SiteTypeField'
import SiteNameField from './SiteNameField'
import RemarkField from './RemarkField'
import UrlPathsField from './UrlPathsField'
import PolicyField from './PolicyField'
import AssetGroupField from './AssetGroupField'
import TransProxyAddrs from './TransProxyAddrs'
import TransProxySSL from './TransProxySSL'
import StepListenerCert from './StepListenerCert'

@Component({ components: { SiteStatusField, SiteTypeField, SiteNameField, RemarkField, UrlPathsField, PolicyField, AssetGroupField, TransProxyAddrs, TransProxySSL, StepListenerCert } })
export default class TransProxySite extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: null }) editingItem!: Website | null
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) policyGroups!: PolicyModel[]
  @Prop({ default: () => [] }) certs!: SSLCertModel[]
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]
  @Prop({ default: () => [] }) workGroups!: WorkGroupModel[]
  @Prop({ default: false }) guomiEnabled!: boolean

  form: Website = { ...getDefaultReverseProxySite() }
  addrs: WAddr[] = [getDefaultWAddr()]
  certSettings: CertSettings = getDefaultCertSettings()
  submitting = false

  normalizeAddrs(addrs: any[] | undefined): WAddr[] {
    const result = (addrs || []).map((addr: any) => {
      if (addr.ip_port) return { ...getDefaultWAddr(), ...addr }
      const ip = addr.ip || ''
      const port = addr.port ? `:${addr.port}` : ''
      return { ...getDefaultWAddr(), ...addr, ip_port: `${ip}${port}` }
    }).filter((addr: WAddr) => addr.ip_port)
    return result.length > 0 ? result : [getDefaultWAddr()]
  }

  @Watch('visible', { immediate: true })
  onVisibleChange(val: boolean) {
    if (!val) return
    this.certSettings = getDefaultCertSettings()
    if (this.editingItem?.id) {
      this.form = { ...getDefaultReverseProxySite(), ...this.editingItem }
      this.form.operation_mode = WorkGroupOperationMode.HardwareTransparentProxy
      this.addrs = this.normalizeAddrs(this.editingItem.addrs as any[])
    } else {
      this.form = getDefaultReverseProxySite()
      this.form.operation_mode = WorkGroupOperationMode.HardwareTransparentProxy
      this.addrs = [getDefaultWAddr()]
    }
  }

  get hasSslAddrs() { return this.addrs.some(a => a.ssl) }
  get hasNonHttpAddrs() { return this.addrs.some(a => a.non_http) }

  async handleSubmit() {
    this.submitting = true
    try {
      if (this.hasSslAddrs) {
        const certError = validateCertSettings(this.certSettings)
        if (certError) { this.$message.error(certError); return }

        if (this.certSettings.type === CertOriginal.upload || this.certSettings.type === CertOriginal.encrypt) {
          const certId = await uploadCertIfNeeded(this.captainInstanceId, this.certSettings, this.form)
          this.form.ssl_cert = certId
        }
      }

      const submitData = prepareWTransProxySiteForSubmit(this.form, this.normalizeAddrs(this.addrs))

      if (this.editingItem?.id) {
        const resp = await siteUpdate({ ...submitData, id: this.editingItem.id, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '更新失败'); return }
      } else {
        const resp = await siteCreate({ ...submitData, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '创建失败'); return }
      }
      this.$emit('success')
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    } finally {
      this.submitting = false
    }
  }

  render(h: any) {
    if (!this.visible) return null

    return (
      <el-dialog title={this.editingItem ? '编辑站点' : '新建站点'}
        visible={this.visible} on-close={() => this.$emit('close')}
        width="60%" top="5vh" close-on-click-modal={false} close-on-press-escape={false} destroy-on-close>

        <el-form label-width="140px" size="small">
          <SiteStatusField value={this.form.is_enabled} on-input={(v: boolean) => { this.form.is_enabled = v }} />
          <SiteTypeField value={this.form.ntlm_enabled} on-input={(v: boolean) => { this.form.ntlm_enabled = v }} guomiEnabled={this.guomiEnabled} />
          <SiteNameField value={this.form.name} on-input={(v: string) => { this.form.name = v }} />

          <el-form-item label="工作组" required>
            <el-select value={this.form.interface} on-input={(v: string) => { this.form.interface = v }} placeholder="选择工作组" style="width:240px">
              {this.workGroups.map(wg => (
                <el-option label={wg.name} value={wg.name} />
              ))}
            </el-select>
          </el-form-item>

          <TransProxyAddrs value={this.addrs} on-input={(v: WAddr[]) => { this.addrs = v }} />

          <el-form-item label="绑定域名">
            <el-input value={this.form.server_names?.join('\n') || ''} type="textarea" rows={3}
              on-input={(v: string) => { this.form.server_names = v.split('\n').map(s => s.trim()).filter(Boolean) }}
              placeholder="每行一个域名" />
          </el-form-item>

          <UrlPathsField value={this.form.url_paths} on-input={(v: any[]) => { this.form.url_paths = v }}
            disabled={this.hasNonHttpAddrs} />

          <RemarkField value={this.form.remark} on-input={(v: string) => { this.form.remark = v }} />

          {!this.form.ntlm_enabled && (
            <PolicyField value={this.form.policy_group} policyGroups={this.policyGroups}
              on-input={(v: number | null) => { this.form.policy_group = v }} />
          )}

          <TransProxySSL addrs={this.addrs} ntlmEnabled={this.form.ntlm_enabled}
            on-input={(v: WAddr[]) => { this.addrs = v }} />

          {this.hasSslAddrs && (
            <StepListenerCert certSettings={this.certSettings} certs={this.certs}
              sslCert={this.form.ssl_cert} guomiEnabled={this.guomiEnabled}
              on-cert-change={(v: CertSettings) => { this.certSettings = v }}
              on-ssl-cert-change={(v: number) => { this.form.ssl_cert = v }} />
          )}

          <AssetGroupField value={this.form.asset_group} assetGroups={this.assetGroups}
            on-input={(v: number) => { this.form.asset_group = v }} />
        </el-form>

        <div slot="footer">
          <el-button on-click={() => this.$emit('close')}>取消</el-button>
          <el-button type="primary" on-click={this.handleSubmit} loading={this.submitting}>确定</el-button>
        </div>
      </el-dialog>
    )
  }
}
