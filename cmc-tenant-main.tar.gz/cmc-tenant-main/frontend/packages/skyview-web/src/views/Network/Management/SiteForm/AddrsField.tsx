// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class AddrsField extends Vue {
  @Prop({ default: () => [] }) value!: string[]
  @Prop({ default: '' }) placeholder!: string
  @Prop({ default: false }) required!: boolean
  @Prop({ default: false }) bare!: boolean

  handleInput(v: string) {
    const addrs = v.split('\n').map(s => s.trim()).filter(Boolean)
    this.$emit('input', addrs)
  }

  get displayValue() {
    return (this.value || []).join('\n')
  }

  render(h: any) {
    const input = <el-input value={this.displayValue} on-input={this.handleInput}
      type="textarea" rows={4}
      placeholder={this.placeholder || '每行一个服务器，例如：\n192.168.10.123\n192.168.10.123:443'} />
    if (this.bare) return input
    return <el-form-item label="服务器地址" prop="addrs" required={this.required}>{input}</el-form-item>
  }
}
