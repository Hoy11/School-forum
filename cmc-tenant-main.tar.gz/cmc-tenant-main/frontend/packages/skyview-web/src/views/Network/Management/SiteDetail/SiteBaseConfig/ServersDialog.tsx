// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Backends } from '@/types/website'

@Component
export default class ServersDialog extends Vue {
  @Prop() value!: Backends[]
  @Prop({ default: false }) isRoundBin!: boolean

  addRow() {
    const list = [...this.value, { host: '', port: 80, protocol: 'http', is_enabled: true, weight: 1, health_check_status: '' }]
    this.$emit('input', list)
  }

  removeRow(index: number) {
    const list = [...this.value]
    list.splice(index, 1)
    this.$emit('input', list)
  }

  updateField(index: number, field: string, val: any) {
    const list = [...this.value]
    list[index] = { ...list[index], [field]: val }
    // Protocol inheritance: first row change propagates to all rows
    if (field === 'protocol' && index === 0) {
      for (let i = 1; i < list.length; i++) list[i] = { ...list[i], protocol: val }
    }
    this.$emit('input', list)
  }

  render(h: any) {
    const rows = this.value || []
    return (
      <div>
        <el-table data={rows} size="small" border>
          <el-table-column label="协议" width={100} scopedSlots={{
            default: ({ row, $index }) => (
              <el-select value={row.protocol} on-input={(v: string) => this.updateField($index, 'protocol', v)} size="small" disabled={$index > 0}>
                <el-option label="HTTP" value="http" />
                <el-option label="HTTPS" value="https" />
              </el-select>
            ),
          }} />
          <el-table-column label="地址" scopedSlots={{
            default: ({ row, $index }) => (
              <el-input value={row.host} on-input={(v: string) => this.updateField($index, 'host', v)} size="small" placeholder="IP 或域名" />
            ),
          }} />
          <el-table-column label="端口" width={90} scopedSlots={{
            default: ({ row, $index }) => (
              <el-input value={row.port} on-input={(v: number) => this.updateField($index, 'port', v)} size="small" type="number" />
            ),
          }} />
          {this.isRoundBin && <el-table-column label="权重" width={90} scopedSlots={{
            default: ({ row, $index }) => (
              <el-input value={row.weight} on-input={(v: number) => this.updateField($index, 'weight', v)} size="small" type="number" />
            ),
          }} />}
          <el-table-column label="启用" width={70} scopedSlots={{
            default: ({ row, $index }) => (
              <el-checkbox value={row.is_enabled} on-input={(v: boolean) => this.updateField($index, 'is_enabled', v)} />
            ),
          }} />
          <el-table-column label="操作" width={60} scopedSlots={{
            default: ({ $index }) => (
              <el-button type="text" icon="el-icon-delete" on-click={() => this.removeRow($index)} />
            ),
          }} />
        </el-table>
        <el-button size="small" icon="el-icon-plus" on-click={this.addRow} style="margin-top:8px">添加</el-button>
      </div>
    )
  }
}
