// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { WebsitePort } from '@/types/website'
import { getDefaultPort } from '@/utils/site'

@Component
export default class StepListenerPort extends Vue {
  @Prop({ default: () => [getDefaultPort()] }) value!: WebsitePort[]
  @Prop({ default: false }) ntlmEnabled!: boolean
  @Prop({ default: false }) isSoftwareMode!: boolean

  addPort() {
    this.$emit('input', [...this.value, getDefaultPort()])
  }

  removePort(i: number) {
    if (this.value.length <= 1) return
    this.$emit('input', this.value.filter((_, idx) => idx !== i))
  }

  updatePort(i: number, field: string, v: any) {
    const updated = this.value.map((p, idx) => {
      if (idx !== i) return p
      const port = { ...p, [field]: v }
      if (field === 'ssl') {
        port.http2 = v && p.http2
        port.sni = !this.ntlmEnabled && v
      }
      if (field === 'non_http' && v) {
        port.proxy_protocol = false
      }
      if (field === 'proxy_protocol' && v) {
        port.non_http = false
      }
      return port
    })
    this.$emit('input', updated)
    if (field === 'non_http' && v) {
      this.$emit('non-http-enabled', i)
    }
  }

  get showTcpForward() {
    return !this.ntlmEnabled
  }

  render(h: any) {
    return (
      <el-form-item label="端口设置">
        {this.value.map((port, i) => (
          <div style="border:1px solid #EBEEF5;border-radius:4px;padding:12px;margin-bottom:12px">
            <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
              <el-input value={port.port} on-input={(v: string) => this.updatePort(i, 'port', parseInt(v) || 0)}
                placeholder="端口" style="width:100px" />
              <el-checkbox value={port.ssl} on-change={(v: boolean) => this.updatePort(i, 'ssl', v)}>SSL</el-checkbox>
              {port.ssl && !this.ntlmEnabled && (
                <el-checkbox value={port.http2} on-change={(v: boolean) => this.updatePort(i, 'http2', v)}>HTTP2</el-checkbox>
              )}
              {port.ssl && !this.ntlmEnabled && (
                <el-checkbox value={port.sni} on-change={(v: boolean) => this.updatePort(i, 'sni', v)}>SNI</el-checkbox>
              )}
              <el-tooltip content="若需获取 Proxy Protocol 协议下的源 IP 信息，请在 响应方式 步骤中进行 Proxy Protocol 配置" placement="top">
                <el-checkbox value={port.proxy_protocol} on-change={(v: boolean) => this.updatePort(i, 'proxy_protocol', v)}>Proxy Protocol</el-checkbox>
              </el-tooltip>
              {this.showTcpForward && (
                <el-checkbox value={port.non_http} on-change={(v: boolean) => this.updatePort(i, 'non_http', v)}>TCP 流量转发</el-checkbox>
              )}
              {this.value.length > 1 && (
                <el-button type="text" icon="el-icon-delete" on-click={() => this.removePort(i)}
                  style="margin-left:auto" />
              )}
            </div>
            {port.non_http && (
              <el-alert title='请谨慎开启"TCP 流量转发"功能。开启后雷池将直接放行/转发非 HTTP 流量及报文中无 SNI 的 HTTPS 流量，存在被攻击者绕过检测的风险。'
                type="error" show-icon closable={false} style="margin-top:8px" />
            )}
          </div>
        ))}
        <el-button type="text" icon="el-icon-plus" on-click={this.addPort}>添加一组端口</el-button>
      </el-form-item>
    )
  }
}
