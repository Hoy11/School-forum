// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { policyDetail, policyUpdate } from '@/api/captain-policy'
import { PolicyModel, ModuleDetectionConfig } from '@/types/policy'
import BasicConfigTab from './PolicyDetail/BasicConfigTab'
import SemanticEngineTab from './PolicyDetail/SemanticEngineTab'
import BuiltInRulesTab from './PolicyDetail/BuiltInRulesTab'
import { isAdmin } from '@/permission'

@Component({ components: { BasicConfigTab, SemanticEngineTab, BuiltInRulesTab } })
export default class PolicyDetail extends Vue {
  get policyId(): number { return Number(this.$route.query.id || 0) }
  get wafId(): number { return Number(this.$route.query.waf || 0) }

  policy: PolicyModel | null = null
  loading = false
  activeTab = 'basic'

  created() { this.loadData() }

  async loadData() {
    this.loading = true
    try {
      const resp = await policyDetail(this.policyId, this.wafId)
      if (resp.err === null) this.policy = resp.data
    } finally {
      this.loading = false
    }
  }

  // --- spec24-5 protection helpers ---

  get isEditProtected(): boolean {
    if (!this.policy) return false
    if (isAdmin()) return false // admin: buttons not disabled, use confirm dialogs instead
    return this.isShared || (this.policy.has_external_ref ?? false)
  }

  get editTooltip(): string {
    if (!this.policy || isAdmin()) return ''
    if (this.isShared) return '该策略被多个租户组共享，无法修改'
    if (this.policy.has_external_ref) return '该策略被其他租户组的站点引用，无法修改'
    return ''
  }

  get isShared(): boolean {
    return (this.policy?.binding_count ?? 0) > 1
  }

  get isSystemDefault(): boolean {
    return this.policy?.is_default ?? false
  }

  /**
   * adminConfirmOrProceed checks if admin needs a confirmation dialog before editing.
   * Returns true if the operation should proceed, false if cancelled.
   * For non-admin: if isEditProtected, shows warning and returns false.
   */
  async adminConfirmOrProceed(): Promise<boolean> {
    const p = this.policy
    if (!p) return false

    // Non-admin: if edit protected, block
    if (this.isEditProtected) {
      this.$message.warning(this.editTooltip)
      return false
    }

    // Admin: soft limits via confirmation dialogs
    if (isAdmin()) {
      // is_default: info message (no forced confirmation)
      if (p.is_default) {
        this.$message.info('这是默认防护策略模板，修改会影响所有引用站点')
      }

      // shared: confirm dialog
      if (this.isShared) {
        const names = p.shared_group_names || []
        const nameStr = names.length > 0 ? names.join('、') : '其他租户组'
        try {
          await this.$confirm(`该策略被租户组 ${nameStr} 共享，确认修改？`, '提示', { type: 'warning' })
        } catch { return false }
      }

      // has_external_ref: confirm dialog
      if (p.has_external_ref) {
        const names = p.referenced_site_names || []
        const nameStr = names.length > 0 ? names.slice(0, 5).join('、') + (names.length > 5 ? ` 等${names.length}个` : '') : '其他租户组的站点'
        try {
          await this.$confirm(`该策略被${nameStr}引用，确认修改？`, '提示', { type: 'warning' })
        } catch { return false }
      }
    }

    return true
  }

  // --- end protection helpers ---

  async handlePolicyUpdate(partial: Partial<PolicyModel>) {
    if (!this.policy) return

    // spec24-5: check protection before update
    const proceed = await this.adminConfirmOrProceed()
    if (!proceed) return

    const full: any = { ...this.policy, ...partial, captain_instance_id: this.wafId }
    // If the update doesn't include base_modules_detection_config, omit it from the payload.
    // Captain API recalculates module thresholds from BMC when present; omitting BMC
    // preserves per-module thresholds for individual module edits.
    if (!partial.base_modules_detection_config) {
      delete full.base_modules_detection_config
    }
    const resp = await policyUpdate(full)
    if (resp.err !== null) {
      if (resp.err === 'shared' || resp.err === 'has_external_ref') {
        this.$message.warning(resp.msg || '无法修改')
      } else {
        this.$message.error(resp.msg || '更新失败')
      }
      return
    }
    await this.loadData()
  }

  render(h: any) {
    if (!this.policy) return <div v-loading={this.loading} style="min-height: 200px" />

    const p = this.policy

    return (
      <div>
        <el-page-header on-back={() => this.$router.push({ name: 'policy' })}>
          <div slot="content" style="display:flex;align-items:center;gap:8px;width:100%">
            <span style="font-size:16px;font-weight:500">{p.name}</span>
            {p.is_default && <el-tag type="warning" size="mini">默认策略</el-tag>}
          </div>
        </el-page-header>

        {this.isEditProtected && (
          <el-alert type="warning" closable={false} show-icon style="margin-top:12px"
            title={this.editTooltip} />
        )}

        <el-tabs v-model={this.activeTab} style="margin-top:16px">
          <el-tab-pane label="基础配置" name="basic">
            <BasicConfigTab
              policy={p}
              captainInstanceId={this.wafId}
              isEditProtected={this.isEditProtected}
              editTooltip={this.editTooltip}
              on-updated={(policy: PolicyModel) => { this.policy = policy }}
            />
          </el-tab-pane>

          <el-tab-pane label="语义分析引擎" name="semantic">
            <SemanticEngineTab
              policy={p}
              captainInstanceId={this.wafId}
              isEditProtected={this.isEditProtected}
              editTooltip={this.editTooltip}
              on-update={this.handlePolicyUpdate}
            />
          </el-tab-pane>

          <el-tab-pane label="内置规则" name="rules">
            <BuiltInRulesTab
              policy={p}
              captainInstanceId={this.wafId}
              isEditProtected={this.isEditProtected}
              editTooltip={this.editTooltip}
              on-updated={(policy: PolicyModel) => { this.policy = policy }}
            />
          </el-tab-pane>
        </el-tabs>
      </div>
    )
  }
}
