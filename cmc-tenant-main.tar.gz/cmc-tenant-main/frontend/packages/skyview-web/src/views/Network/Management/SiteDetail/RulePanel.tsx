// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website } from '@/types/website'
import { PolicyRule } from '@/types/policy'
import { canEditBusiness } from '@/permission'
import { ruleList, ruleUnbind, rulePriority } from '@/api/captain-rule'
import { siteList } from '@/api/captain-site'
import { ipGroupList } from '@/api/captain-ip-group'
import { buildSiteCondition, isSharedRule } from '../ruleConstants'
import RuleTable from './RuleTable'
import RuleFormDialog from './RuleFormDialog'

@Component({ components: { RuleTable, RuleFormDialog } })
export default class RulePanel extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number

  rules: PolicyRule[] = []
  loading = false
  showForm = false
  editingItem: PolicyRule | null = null
  sites: Website[] = []
  ipGroups: any[] = []

  get canEdit() { return canEditBusiness() }
  get wafId() { return this.captainInstanceId || Number(this.$route.query.waf || 0) }

  async created() { await this.loadRules() }

  async loadRules() {
    if (!this.site?.id || !this.site?.policy_group || !this.wafId) return
    this.loading = true
    try {
      const resp = await ruleList(this.wafId, 0, 200, [buildSiteCondition(this.site.id)], '1')
      if (resp.err === null) {
        const items = resp.data?.items || []
        this.rules = items.filter((r: any) => r.websites?.includes(this.site.id))
      }
    } finally {
      this.loading = false
    }
  }

  async handleDelete(row: PolicyRule) {
    try {
      await ruleUnbind(this.wafId, this.site.id, row.id)
      this.$message.success('删除规则成功')
      await this.loadRules()
    } catch (e: any) { this.$message.error(e?.message || '删除失败') }
  }

  handleViewLog(row: PolicyRule) {
    this.$router.push({ path: '/threat/detect-log', query: { policy_rule_id: String(row.id), captain_instance_id: String(this.wafId) } })
  }

  handleCreate() {
    this.editingItem = null
    this.showForm = true
    this.loadFormData()
  }

  async handleSortChange(sortedIds: number[]) {
    try {
      await rulePriority(this.wafId, this.site.id, sortedIds)
      this.$message.success('修改规则优先级成功')
      await this.loadRules()
    } catch (e: any) { this.$message.error(e?.message || '排序失败'); await this.loadRules() }
  }

  async loadFormData() {
    if (!this.wafId) return
    const [siteResp, ipResp] = await Promise.all([
      siteList(this.wafId, 0, 1000).catch(() => ({ err: 1, data: { items: [] } })),
      ipGroupList(this.wafId, 0, 1000).catch(() => ({ err: 1, data: { items: [] } })),
    ])
    if (siteResp.err === null) this.sites = siteResp.data?.items || []
    if (ipResp.err === null) this.ipGroups = ipResp.data?.items || []
  }

  async handleFormSubmitted() { await this.loadRules() }

  render(h: any) {
    if (!this.site?.policy_group) return null
    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">自定义规则</div>
        <RuleTable
          rules={this.rules} loading={this.loading} canEdit={this.canEdit} sortable
          on-delete={this.handleDelete}
          on-view-log={this.handleViewLog} on-create={this.handleCreate}
          on-sort-change={this.handleSortChange}
        />
        <RuleFormDialog
          visible={this.showForm} editingItem={this.editingItem}
          wafId={this.wafId} siteId={this.site.id}
          sites={this.sites} ipGroups={this.ipGroups}
          on-close={() => { this.showForm = false }}
          on-submitted={this.handleFormSubmitted}
        />
      </el-card>
    )
  }
}
