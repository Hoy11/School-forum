// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class IgnoreTypesDialog extends Vue {
  @Prop() value!: string[]
  newType = ''

  addType() {
    const v = (this.newType || '').trim()
    if (!v) return
    const list = [...this.value, v]
    this.$emit('input', list)
    this.newType = ''
  }

  removeType(index: number) {
    const list = [...this.value]
    list.splice(index, 1)
    this.$emit('input', list)
  }

  render(h: any) {
    const types = this.value || []
    return (
      <div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;min-height:32px">
          {types.length === 0 && <span style="color:#909399">暂无忽略类型</span>}
          {types.map((t: string, i: number) => (
            <el-tag key={i} closable on-close={() => this.removeType(i)} size="small">{t}</el-tag>
          ))}
        </div>
        <div style="display:flex;gap:8px">
          <el-input value={this.newType} on-input={(v: string) => { this.newType = v }} placeholder="输入 content_type" size="small" style="flex:1"
            on-keydown-native={(e: KeyboardEvent) => { if (e.key === 'Enter') { e.preventDefault(); this.addType() } }} />
          <el-button size="small" type="primary" on-click={this.addType}>添加</el-button>
        </div>
        <el-alert type="warning" closable={false} style="margin-top:8px" description="参数值中请勿添加分号，如有空格，请在参数值外加双引号" />
      </div>
    )
  }
}
