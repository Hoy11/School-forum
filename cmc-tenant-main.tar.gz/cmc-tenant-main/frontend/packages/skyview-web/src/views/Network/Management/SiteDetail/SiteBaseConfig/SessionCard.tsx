// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { SessionType } from '@/types/website-security'
import { createFieldUpdater } from '../useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'

const REVERSE_PROXY_MODES = new Set([
  WorkGroupOperationMode.SoftwareReverseProxy,
  WorkGroupOperationMode.HardwareReverseProxy,
  WorkGroupOperationMode.SoftwareClusterReverseProxy,
  WorkGroupOperationMode.HardwareRouterProxy,
])

const allSessionOptions = [
  { label: '不使用', value: SessionType.off },
  { label: 'WAF 用户系统', value: SessionType.safelineSession },
  { label: '源 IP', value: SessionType.srcIP },
  { label: '从请求中提取', value: SessionType.custom },
]

const customLocationOptions = [
  { label: 'Cookie', value: SessionType.cookie },
  { label: 'GET 参数', value: SessionType.urlQuery },
  { label: 'POST 参数', value: SessionType.bodyForm },
  { label: 'HTTP 头', value: SessionType.header },
]

function isCustomType(t: string) {
  return [SessionType.cookie, SessionType.urlQuery, SessionType.bodyForm, SessionType.header].includes(t as SessionType)
}

function getMainType(t: string) {
  if (isCustomType(t)) return SessionType.custom
  return t
}

function sessionDisplayText(sm: any): string {
  if (!sm) return '-'
  const main = getMainType(sm.type)
  const mainLabel = allSessionOptions.find(o => o.value === main)?.label || '-'
  if (main === SessionType.custom && isCustomType(sm.type)) {
    const locLabel = customLocationOptions.find(o => o.value === sm.type)?.label || sm.type
    return sm.param ? `${locLabel} (${sm.param})` : locLabel
  }
  return mainLabel
}

@Component({ components: { EditableRow } })
export default class SessionCard extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: '' }) mode!: string

  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }
  get sessionText() { return sessionDisplayText(this.site.session_method) }

  get sessionOptions() {
    const isRP = REVERSE_PROXY_MODES.has(this.mode as WorkGroupOperationMode)
    return isRP ? allSessionOptions : allSessionOptions.filter(o => o.value !== SessionType.safelineSession)
  }

  renderSessionEdit({ value, input }: any) {
    const h = this.$createElement
    const parsed = JSON.parse(value || '{}')
    const mainType = getMainType(parsed.type)
    return (
      <div>
        <el-select value={mainType} on-input={(v: string) => {
          if (v === SessionType.custom) {
            input(JSON.stringify({ type: SessionType.cookie, param: '' }))
          } else {
            input(JSON.stringify({ type: v, param: '' }))
          }
        }} style="width:100%;margin-bottom:8px">
          {this.sessionOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
        </el-select>
        {mainType === SessionType.custom && (
          <div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
              <span style="font-size:12px;color:#909399;width:80px">用户 ID 位于</span>
              <el-select value={parsed.type} on-input={(v: string) => input(JSON.stringify({ ...parsed, type: v }))} style="flex:1">
                {customLocationOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
              </el-select>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:12px;color:#909399;width:80px">参数名</span>
              <el-input value={parsed.param || ''} on-input={(v: string) => input(JSON.stringify({ ...parsed, param: v }))} style="flex:1" placeholder="参数名" />
            </div>
          </div>
        )}
        {mainType === SessionType.custom && (
          <el-alert type="info" closable={false} style="margin-top:8px" description="从请求中提取用户 ID：需与业务方确认参数名称，确保业务请求中携带该参数" />
        )}
      </div>
    )
  }

  render(h: any) {
    const sm = this.site.session_method || { type: SessionType.off, param: '' }
    const val = JSON.stringify({ type: sm.type, param: sm.param })
    return (
      <el-card>
        <div slot="header" style="font-weight:bold">用户识别方式</div>
        <EditableRow label="用户识别方式" value={val} editable
          submitFn={(v) => {
            const p = JSON.parse(v)
            if (getMainType(p.type) === SessionType.custom && !p.param) {
              this.$message.warning('请输入用户 ID 参数名')
              return Promise.reject()
            }
            return this.updateField({ session_method: { type: p.type, param: p.param || '' } })
          }}
          scopedSlots={{
            default: () => <span>{this.sessionText}</span>,
            edit: (scope) => this.renderSessionEdit(scope),
          }} />
      </el-card>
    )
  }
}
