// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Website, SSLCertModel, PolicyModel, NodeStatus, AssetGroupType, WorkGroupModel, CertSettings } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { sitePolicyList, siteCertList, siteNodeList, siteAssetGroupList, siteWorkGroupList } from '@/api/captain-site'
import ReverseProxySite from './SiteForm/ReverseProxySite'
import TransProxySite from './SiteForm/TransProxySite'
import TransBridgeSite from './SiteForm/TransBridgeSite'
import PortMirroringSite from './SiteForm/PortMirroringSite'
import ClusterSite from './SiteForm/ClusterSite'

@Component({ components: { ReverseProxySite, TransProxySite, TransBridgeSite, PortMirroringSite, ClusterSite } })
export default class SiteForm extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: null }) editingItem!: Website | null
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: '' }) operationMode!: string

  policyGroups: PolicyModel[] = []
  certs: SSLCertModel[] = []
  nodes: NodeStatus[] = []
  assetGroups: AssetGroupType[] = []
  workGroups: WorkGroupModel[] = []

  @Watch('visible', { immediate: true })
  async onVisibleChange(val: boolean) {
    if (!val || !this.captainInstanceId) return
    const [pRes, cRes, nRes, aRes, wRes] = await Promise.all([
      sitePolicyList(this.captainInstanceId).catch(() => null),
      siteCertList(this.captainInstanceId).catch(() => null),
      siteNodeList(this.captainInstanceId).catch(() => null),
      siteAssetGroupList(this.captainInstanceId).catch(() => null),
      siteWorkGroupList(this.captainInstanceId).catch(() => null),
    ])
    if (pRes?.err === null) this.policyGroups = pRes.data || []
    if (cRes?.err === null) this.certs = cRes.data || []
    if (nRes?.err === null) this.nodes = nRes.data || []
    if (aRes?.err === null) this.assetGroups = aRes.data || []
    if (wRes?.err === null) this.workGroups = wRes.data || []
  }

  get isHardwareMode() {
    return [
      WorkGroupOperationMode.HardwareReverseProxy,
      WorkGroupOperationMode.HardwareTransparentProxy,
      WorkGroupOperationMode.HardwareTransparentBridging,
      WorkGroupOperationMode.HardwarePortMirroring,
      WorkGroupOperationMode.HardwareRouterProxy,
    ].includes(this.operationMode as WorkGroupOperationMode)
  }

  get guomiEnabled() { return false }

  handleClose() { this.$emit('close') }
  handleSuccess() { this.$emit('success') }

  get modeComponent() {
    switch (this.operationMode) {
      case WorkGroupOperationMode.HardwareTransparentProxy:
        return TransProxySite
      case WorkGroupOperationMode.HardwareTransparentBridging:
        return TransBridgeSite
      case WorkGroupOperationMode.HardwarePortMirroring:
        return PortMirroringSite
      case WorkGroupOperationMode.SoftwareClusterReverseProxy:
      case WorkGroupOperationMode.SoftwarePortMirroring:
        return ClusterSite
      default:
        return ReverseProxySite
    }
  }

  render(h: any) {
    const commonProps = {
      visible: this.visible,
      editingItem: this.editingItem,
      captainInstanceId: this.captainInstanceId,
      policyGroups: this.policyGroups,
      certs: this.certs,
      assetGroups: this.assetGroups,
      workGroups: this.workGroups,
      guomiEnabled: this.guomiEnabled,
    }

    const SiteComponent = this.modeComponent
    const extraProps = SiteComponent === ReverseProxySite
      ? { nodes: this.nodes, isHardwareMode: this.isHardwareMode, operationMode: this.operationMode }
      : SiteComponent === PortMirroringSite
      ? { operationMode: this.operationMode }
      : SiteComponent === ClusterSite
      ? { operationMode: this.operationMode }
      : {}

    return (
      <SiteComponent
        {...{ props: { ...commonProps, ...extraProps } }}
        on-close={this.handleClose}
        on-success={this.handleSuccess}
      />
    )
  }
}
