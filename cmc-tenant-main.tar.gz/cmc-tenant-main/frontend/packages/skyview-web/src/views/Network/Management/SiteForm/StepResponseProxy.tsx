// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { LoadBalancePolicy, Backends } from '@/types/website'
import { loadBalancePolicyOptions } from '@/utils/site'

@Component
export default class StepResponseProxy extends Vue {
  @Prop() loadBalancePolicy!: LoadBalancePolicy
  @Prop({ default: () => [] }) servers!: Backends[]
  @Prop({ default: null }) cookieMaxAge!: number | null
  @Prop({ default: 'append' }) xForwardedFor!: string
  @Prop({ default: false }) ntlmEnabled!: boolean

  get lbOptions() {
    return this.ntlmEnabled
      ? loadBalancePolicyOptions.filter(o => o.value === LoadBalancePolicy.ntlm)
      : loadBalancePolicyOptions
  }

  get isSessionSticky() {
    return this.loadBalancePolicy === LoadBalancePolicy.sessionSticky
  }

  get showWeight() {
    return this.loadBalancePolicy === LoadBalancePolicy.roundBin
  }

  addServer() {
    this.$emit('servers-change', [...this.servers, {
      host: '', port: 80, protocol: this.servers[0]?.protocol || 'http',
      is_enabled: true, weight: '', health_check_status: '',
    }])
  }

  removeServer(i: number) {
    this.$emit('servers-change', this.servers.filter((_, idx) => idx !== i))
  }

  updateServer(i: number, field: string, v: any) {
    const updated = this.servers.map((s, idx) => idx === i ? { ...s, [field]: v } : s)
    if (field === 'protocol' && i === 0) {
      updated.forEach((s, idx) => { if (idx > 0) s.protocol = v })
    }
    this.$emit('servers-change', updated)
  }

  render(h: any) {
    return (
      <div>
        <el-form-item label="负载调度算法">
          <el-select value={this.loadBalancePolicy} on-input={(v: LoadBalancePolicy) => this.$emit('lb-change', v)}
            style="width:200px">
            {this.lbOptions.map(opt => (
              <el-option label={opt.label} value={opt.value}>
                <span>{opt.label}</span>
                {opt.tooltip && <el-tooltip content={opt.tooltip} placement="right"><i class="el-icon-question" style="margin-left:4px;color:#909399" /></el-tooltip>}
              </el-option>
            ))}
          </el-select>
        </el-form-item>

        {this.isSessionSticky && (
          <el-form-item label="Cookie 保持时间">
            <el-input value={this.cookieMaxAge || ''} on-input={(v: string) => this.$emit('cookie-age-change', v ? parseInt(v) : null)}
              placeholder="秒" style="width:160px">
              <template slot="append">秒</template>
            </el-input>
            <span style="margin-left:8px;color:#909399;font-size:12px">不设置则默认为临时 cookie，浏览器关闭时失效</span>
          </el-form-item>
        )}

        <el-form-item label="业务服务器地址">
          {this.servers.map((server, i) => (
            <div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
              <el-checkbox value={server.is_enabled} on-input={(v: boolean) => this.updateServer(i, 'is_enabled', v)} />
              <el-select value={server.protocol} on-input={(v: string) => this.updateServer(i, 'protocol', v)}
                style="width:90px" disabled={i !== 0}>
                <el-option label="http" value="http" />
                <el-option label="https" value="https" />
              </el-select>
              <el-input value={server.host} on-input={(v: string) => this.updateServer(i, 'host', v)}
                placeholder="主机" style="width:160px" disabled={!server.is_enabled} />
              <el-input value={server.port} on-input={(v: string) => this.updateServer(i, 'port', parseInt(v) || 80)}
                placeholder="端口" style="width:80px" disabled={!server.is_enabled} />
              {this.showWeight && (
                <el-input value={server.weight} on-input={(v: string) => this.updateServer(i, 'weight', v)}
                  placeholder="权重" style="width:80px" disabled={!server.is_enabled} />
              )}
              {this.servers.length > 1 && (
                <el-button type="text" icon="el-icon-delete" on-click={() => this.removeServer(i)} />
              )}
            </div>
          ))}
          <el-button type="text" icon="el-icon-plus" on-click={this.addServer}>增加一个转发地址</el-button>
        </el-form-item>

        {!this.ntlmEnabled && (
          <el-form-item label="X-Forwarded-For">
            <el-select value={this.xForwardedFor} on-input={(v: string) => this.$emit('xff-change', v)} style="width:120px">
              <el-option label="追加" value="append" />
              <el-option label="覆盖" value="cover" />
              <el-option label="不设置" value="no_action" />
            </el-select>
          </el-form-item>
        )}
      </div>
    )
  }
}
