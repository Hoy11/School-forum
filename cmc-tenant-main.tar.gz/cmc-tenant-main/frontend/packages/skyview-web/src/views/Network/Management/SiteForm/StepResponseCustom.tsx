// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class StepResponseCustom extends Vue {
  @Prop({ default: null }) statusCode!: number | null
  @Prop({ default: '' }) path!: string
  @Prop({ default: null }) responseFile!: File | null

  handleFileChange(f: any) {
    this.$emit('file-change', f.raw)
  }

  render(h: any) {
    return (
      <div>
        <el-form-item label="状态码" required>
          <el-input value={this.statusCode || ''} on-input={(v: string) => this.$emit('status-change', parseInt(v) || null)}
            placeholder="200-299 或 400-599" style="width:160px" />
        </el-form-item>
        <el-form-item label="响应内容">
          <el-upload action="" auto-upload={false} on-change={this.handleFileChange} show-file-list={false}>
            <el-button size="small">选择响应文件</el-button>
          </el-upload>
          {this.responseFile && <span style="margin-left:8px;color:#67C23A">{this.responseFile.name}</span>}
          {!this.responseFile && this.path && <span style="margin-left:8px;color:#909399">已有文件</span>}
        </el-form-item>
      </div>
    )
  }
}
