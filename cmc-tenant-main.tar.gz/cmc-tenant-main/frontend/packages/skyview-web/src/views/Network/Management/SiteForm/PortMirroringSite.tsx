// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { Website, PolicyModel, AssetGroupType } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { getDefaultReverseProxySite, prepareSiteForSubmit } from '@/utils/site'
import { siteCreate, siteUpdate } from '@/api/captain-site'
import SiteStatusField from './SiteStatusField'
import SiteNameField from './SiteNameField'
import RemarkField from './RemarkField'
import UrlPathsField from './UrlPathsField'
import PolicyField from './PolicyField'
import AssetGroupField from './AssetGroupField'
import AddrsField from './AddrsField'

@Component({ components: { SiteStatusField, SiteNameField, RemarkField, UrlPathsField, PolicyField, AssetGroupField, AddrsField } })
export default class PortMirroringSite extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: null }) editingItem!: Website | null
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) policyGroups!: PolicyModel[]
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]
  @Prop({ default: '' }) operationMode!: string

  form: Website = { ...getDefaultReverseProxySite() }
  addrs: string[] = []
  submitting = false

  @Watch('visible', { immediate: true })
  onVisibleChange(val: boolean) {
    if (!val) return
    this.addrs = []
    this.form = this.editingItem?.id
      ? { ...getDefaultReverseProxySite(), ...this.editingItem }
      : getDefaultReverseProxySite()
  }

  async handleSubmit() {
    if (this.addrs.length === 0) {
      this.$message.error('请输入服务器地址'); return
    }
    this.submitting = true
    try {
      this.form.operation_mode = this.operationMode || WorkGroupOperationMode.HardwarePortMirroring
      const data = prepareSiteForSubmit(this.form)
      const submitData = {
        ...data,
        addrs: this.addrs,
      }

      if (this.editingItem?.id) {
        const resp = await siteUpdate({ ...submitData, id: this.editingItem.id, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '更新失败'); return }
      } else {
        const resp = await siteCreate({ ...submitData, captain_instance_id: this.captainInstanceId })
        if (resp.err) { this.$message.error(resp.msg || '创建失败'); return }
      }
      this.$emit('success')
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    } finally {
      this.submitting = false
    }
  }

  render(h: any) {
    if (!this.visible) return null

    return (
      <el-dialog title={this.editingItem ? '编辑站点' : '新建站点'}
        visible={this.visible} on-close={() => this.$emit('close')}
        width="60%" top="5vh" close-on-click-modal={false} close-on-press-escape={false} destroy-on-close>

        <el-form label-width="140px" size="small">
          <SiteStatusField value={this.form.is_enabled} on-input={(v: boolean) => { this.form.is_enabled = v }} />
          <SiteNameField value={this.form.name} on-input={(v: string) => { this.form.name = v }} />
          <AddrsField value={this.addrs} on-input={(v: string[]) => { this.addrs = v }} required
            placeholder="每行一个服务器，例如：\n1.2.3.4:80\n1.2.3.5:80" />

          <el-form-item label="绑定域名">
            <el-input value={(this.form.server_names || []).join('\n')} type="textarea" rows={3}
              on-input={(v: string) => { this.form.server_names = v.split('\n').map((s: string) => s.trim()).filter(Boolean) }}
              placeholder="每行一个域名，可使用 * 通配，例如：\ntest.com" />
          </el-form-item>

          <UrlPathsField value={this.form.url_paths} on-input={(v: any[]) => { this.form.url_paths = v }} />
          <RemarkField value={this.form.remark} on-input={(v: string) => { this.form.remark = v }} />
          <PolicyField value={this.form.policy_group} policyGroups={this.policyGroups}
            on-input={(v: number | null) => { this.form.policy_group = v }} />
          <AssetGroupField value={this.form.asset_group} assetGroups={this.assetGroups}
            on-input={(v: number) => { this.form.asset_group = v }} />
        </el-form>

        <div slot="footer">
          <el-button on-click={() => this.$emit('close')}>取消</el-button>
          <el-button type="primary" on-click={this.handleSubmit} loading={this.submitting}>确定</el-button>
        </div>
      </el-dialog>
    )
  }
}
