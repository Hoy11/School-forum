// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { PolicyRule } from '@/types/policy'
import { Website } from '@/types/website'
import { IPGroup } from '@/types/ip-group'
import { ruleCreate, ruleUpdate, ruleList, ruleBind, getDetectionModules, getSkynetRules } from '@/api/captain-rule'
import ConditionEditor from '@/components/ConditionEditor'
import { RISK_LEVEL_OPTIONS, ATTACK_TYPE_OPTIONS, LOG_OPTION_OPTIONS, LOG_OPTION_DESCRIPTIONS, LOG_OPTION_DESCRIPTION_STYLE, DECODE_METHOD_OPTIONS, WEEKDAY_OPTIONS, defaultRuleForm, applyDecodeMethods, formatCronConfig, parseCronConfig, ACTION_MAP, ACTION_TAG_TYPE, formatTimestamp, normalizeDecodeMethods } from '../ruleConstants'

const ACTION_OPTIONS = [
  { label: '拦截', value: 'deny' },
  { label: '放行', value: 'allow' },
  { label: '观察', value: 'dry_run' },
  { label: '检测模块控制', value: 'modify_module' },
  { label: '内置规则控制', value: 'modify_skynet_rule' },
]

type DialogMode = 'create' | 'bind' | 'edit'

@Component({ components: { ConditionEditor } })
export default class RuleFormDialog extends Vue {
  @Prop({ default: false }) visible!: boolean
  @Prop({ default: null }) editingItem!: PolicyRule | null
  @Prop({ default: 0 }) wafId!: number
  @Prop({ default: 0 }) siteId!: number
  @Prop({ default: () => [] }) sites!: Website[]
  @Prop({ default: () => [] }) ipGroups!: IPGroup[]

  mode: DialogMode = 'create'
  form: Record<string, any> = defaultRuleForm(0)
  submitting = false
  advancedOpen: string[] = []
  bindRuleIds: number[] = []
  allRules: PolicyRule[] = []
  loadingRules = false
  moduleActions: any[] = []
  skynetActions: any[] = []
  detectionModules: any[] = []
  skynetRuleList: any[] = []

  @Watch('visible')
  onVisibleChange(v: boolean) {
    if (!v) return
    this.bindRuleIds = []
    if (this.editingItem) {
      this.mode = 'edit'
      this.fillForm(this.editingItem)
    } else {
      this.mode = 'bind'
      this.form = defaultRuleForm(this.siteId)
      this.moduleActions = []
      this.skynetActions = []
      this.loadAvailableRules()
      this.loadDetectionModules()
      this.loadSkynetRuleList()
    }
    this.advancedOpen = []
  }

  @Watch('form.action')
  onActionChange(newAction: string) {
    if (newAction !== 'modify_module') this.moduleActions = []
    if (newAction !== 'modify_skynet_rule') this.skynetActions = []
  }

  fillForm(row: PolicyRule) {
    let decodeBeforeDetection = false
    let decodeMethods: string[] = ['url_decode']
    const findDecoded = (items: any[]): any | undefined => {
      for (const item of items) {
        if (item.$AND || item.$OR) {
          const found = findDecoded(item.$AND || item.$OR)
          if (found) return found
        }
        if (item.decode_methods && item.decode_methods.length > 0) return item
      }
      return undefined
    }
    if (row.pattern) {
      const items = (row.pattern as any).$AND || (row.pattern as any).$OR
      if (items) {
        const firstDecoded = findDecoded(items)
        if (firstDecoded) {
          decodeBeforeDetection = true
          decodeMethods = normalizeDecodeMethods(firstDecoded.decode_methods)
        }
      }
    }
    this.form = {
      is_enabled: row.is_enabled, action: row.action, comment: row.comment || '',
      risk_level: row.risk_level, pattern: row.pattern, websites: row.websites || [],
      attack_type: row.attack_type === -1 ? null : row.attack_type, log_option: row.log_option || 'Persistence',
      cron_config: parseCronConfig(row.cron_config),
      expire_time: row.expire_time
        ? new Date(row.expire_time * 1000)
        : null,
      decode_before_detection: decodeBeforeDetection,
      decode_methods: decodeMethods,
      status_code: (row as any).forbidden_page_config?.status_code || 403,
    }
    this.moduleActions = this.normalizeModuleManagement((row as any).module_management)
    this.skynetActions = this.normalizeSkynetRuleManagement((row as any).skynet_rule_management)
  }

  get isSpecialAction() {
    return this.form.action === 'modify_module' || this.form.action === 'modify_skynet_rule'
  }

  get availableBindRules() {
    return this.allRules.filter(r => !r.is_expired && !(r.websites || []).includes(this.siteId))
  }

  switchMode(m: DialogMode) {
    this.mode = m
    if (m === 'create') {
      this.form = defaultRuleForm(this.siteId)
      this.moduleActions = []
      this.skynetActions = []
    }
  }

  async loadAvailableRules() {
    if (!this.wafId) return
    this.loadingRules = true
    try {
      const resp = await ruleList(this.wafId, 0, 500, [], '1')
      if (resp.err === null) this.allRules = resp.data?.items || []
    } finally {
      this.loadingRules = false
    }
  }

  async loadDetectionModules() {
    if (!this.wafId) return
    if (this.detectionModules.length > 0) return // cached
    try {
      const resp = await getDetectionModules(this.wafId)
      if (resp.err === null && resp.data) {
        const config = resp.data.detection_config || resp.data
        this.detectionModules = config.modules_detection_config || []
      }
    } catch { /* ignore */ }
  }

  async loadSkynetRuleList() {
    if (!this.wafId) return
    if (this.skynetRuleList.length > 0) return // cached
    try {
      const resp = await getSkynetRules(this.wafId)
      if (resp.err === null) {
        const data = resp.data
        // Captain API returns {items: [...]} pagination format, not plain array
        this.skynetRuleList = Array.isArray(data) ? data : (data?.items || [])
      }
    } catch { /* ignore */ }
  }

  validate(): string | null {
    if (this.mode === 'bind') {
      if (this.bindRuleIds.length === 0) return '请选择要绑定的规则'
      return null
    }
    if (!this.form.comment || !this.form.comment.trim()) return '备注不能为空'
    if (this.form.action === 'modify_module') {
      if (this.moduleActions.length === 0) return '请添加至少一个规则动作'
      if (this.moduleActions.some((a: any) => !a.key)) return '请选择检测模块'
    }
    if (this.form.action === 'modify_skynet_rule') {
      if (this.skynetActions.length === 0) return '请添加至少一个规则动作'
      if (this.skynetActions.some((a: any) => !a.key)) return '请选择内置规则'
    }
    if (!this.isSpecialAction && (this.form.attack_type === null || this.form.attack_type === undefined)) return '请选择攻击类型'
    if (!this.isSpecialAction) {
      const condEditor = this.$refs.conditionEditor as any
      if (condEditor && condEditor.validate) {
        const err = condEditor.validate()
        if (err) return err
      }
    }
    return null
  }

  async handleSubmit() {
    if (this.submitting) return
    const err = this.validate()
    if (err) { this.$message.warning(err); return }
    this.submitting = true
    try {
      if (this.mode === 'bind') {
        await this.handleBindSubmit()
      } else {
        await this.handleFormSubmit()
      }
    } finally {
      this.submitting = false
    }
  }

  async handleBindSubmit() {
    const resp = await ruleBind(this.wafId, this.siteId, this.bindRuleIds)
    if (resp.err !== null) { this.$message.error(resp.msg || '绑定失败'); return }
    this.$message.success('绑定成功')
    this.$emit('submitted')
    this.$emit('close')
  }

  async handleFormSubmit() {
    const f = this.form
    const payload: any = {
      captain_instance_id: this.wafId,
      is_global: false,
      is_enabled: f.is_enabled,
      action: f.action,
      comment: f.comment,
      risk_level: f.risk_level,
      websites: f.websites,
      attack_type: f.attack_type,
      log_option: f.log_option,
      cron_config: formatCronConfig(f),
      expire_time: f.expire_time
        ? Math.floor(new Date(f.expire_time).getTime() / 1000)
        : null,
      forbidden_page_config: f.action === 'deny'
        ? { action: 'response', status_code: f.status_code, path: '' }
        : null,
    }
    payload.pattern = f.decode_before_detection ? applyDecodeMethods(f.pattern, f.decode_methods) : applyDecodeMethods(f.pattern, [])
    if (f.action === 'modify_module') {
      payload.module_management = this.moduleActions
    }
    if (f.action === 'modify_skynet_rule') {
      payload.skynet_rule_management = this.skynetActions
    }
    if (this.editingItem) {
      const resp = await ruleUpdate({ id: this.editingItem.id, ...payload })
      if (resp.err !== null) { this.$message.error(resp.msg || '更新失败'); return }
    } else {
      const resp = await ruleCreate(payload)
      if (resp.err !== null) { this.$message.error(resp.msg || '创建失败'); return }
    }
    this.$emit('submitted')
    this.$emit('close')
  }


  /** Convert Captain API dict format {disabled:[], enabled:[]} to frontend array [{key, enabled}] */
  normalizeModuleManagement(data: any): any[] {
    if (!data) return []
    if (Array.isArray(data)) return data
    const result: any[] = []
    if (data.disabled && Array.isArray(data.disabled)) {
      for (const key of data.disabled) result.push({ key, enabled: false })
    }
    if (data.enabled && Array.isArray(data.enabled)) {
      for (const key of data.enabled) result.push({ key, enabled: true })
    }
    return result
  }

  /** Convert Captain API dict format {disabled:[], enabled:[]} to frontend array [{key, enabled}] */
  normalizeSkynetRuleManagement(data: any): any[] {
    if (!data) return []
    if (Array.isArray(data)) return data
    const result: any[] = []
    if (data.disabled && Array.isArray(data.disabled)) {
      for (const key of data.disabled) result.push({ key, enabled: false })
    }
    if (data.enabled && Array.isArray(data.enabled)) {
      for (const key of data.enabled) result.push({ key, enabled: true })
    }
    return result
  }

  addModuleAction() {
    this.moduleActions = [...this.moduleActions, { key: '', enabled: false }]
  }

  removeModuleAction(i: number) {
    this.moduleActions = this.moduleActions.filter((_: any, idx: number) => idx !== i)
  }

  addSkynetAction() {
    this.skynetActions = [...this.skynetActions, { key: '', enabled: false }]
  }

  removeSkynetAction(i: number) {
    this.skynetActions = this.skynetActions.filter((_: any, idx: number) => idx !== i)
  }

  addDecodeMethod() {
    this.form = { ...this.form, decode_methods: [...this.form.decode_methods, 'url_decode'] }
  }

  removeDecodeMethod(i: number) {
    this.form = { ...this.form, decode_methods: this.form.decode_methods.filter((_: string, idx: number) => idx !== i) }
  }

  renderModeSwitch(h: any) {
    if (this.editingItem) return null
    return h('el-form-item', { props: { label: '类型' } }, [
      h('el-radio-group', {
        props: { value: this.mode },
        on: { input: (v: DialogMode) => this.switchMode(v) },
      }, [
        h('el-radio', { props: { label: 'bind' } }, ['使用已存在规则']),
        h('el-radio', { props: { label: 'create' } }, ['添加一条新的规则']),
      ]),
    ])
  }

  renderBindMode(h: any) {
    return h('el-form-item', { props: { label: '自定义规则', required: true } }, [
      h('el-select', {
        props: { value: this.bindRuleIds, multiple: true, filterable: true, placeholder: '选择规则', loading: this.loadingRules },
        style: 'width:100%',
        on: { input: (v: number[]) => { this.bindRuleIds = v } },
      }, this.availableBindRules.map(r =>
        h('el-option', { key: r.id, props: { label: r.comment || `规则 ${r.id}`, value: r.id } })
      )),
    ])
  }

  renderActionSelect(h: any) {
    return h('span', { style: 'display:flex;align-items:center;gap:4px' }, [
      h('el-select', { props: { value: this.form.action }, on: { input: (v: string) => { this.form.action = v } } },
        ACTION_OPTIONS.map(o => h('el-option', { key: o.value, props: { label: o.label, value: o.value } }))),
    ])
  }


  renderModuleConfig(h: any) {
    if (this.form.action !== 'modify_module') return null
    const moduleOptions = this.detectionModules
      .filter((m: any) => m.key !== 'm_rule')
      .map((m: any) => ({ label: (m.name?.cn || m.name?.translation || m.key), value: m.key }))
    return h('el-form-item', { props: { label: '规则动作', required: true } }, [
      h('div', { style: 'width:100%' }, [
        ...this.moduleActions.map((item: any, i: number) =>
          h('div', { style: 'display:flex;align-items:center;gap:8px;margin-bottom:8px' }, [
            h('el-select', { props: { value: item.key, placeholder: '选择模块', size: 'small', filterable: true }, style: 'flex:1', on: { input: (v: string) => { const a = [...this.moduleActions]; a[i] = { ...a[i], key: v }; this.moduleActions = a } } },
              moduleOptions.map(o => h('el-option', { key: o.value, props: { label: o.label, value: o.value } }))),
            h('el-select', { props: { value: item.enabled, size: 'small' }, on: { input: (v: boolean) => { const a = [...this.moduleActions]; a[i] = { ...a[i], enabled: v }; this.moduleActions = a } } }, [
              h('el-option', { props: { label: '开启', value: true } }),
              h('el-option', { props: { label: '关闭', value: false } }),
            ]),
            h('el-button', { props: { type: 'text', icon: 'el-icon-delete', size: 'small' }, style: 'color:#F56C6C', on: { click: () => this.removeModuleAction(i) } }),
          ])
        ),
        h('el-button', { props: { type: 'text', icon: 'el-icon-plus', size: 'small' }, on: { click: this.addModuleAction } }, ['添加一个动作']),
      ]),
    ])
  }

  renderSkynetConfig(h: any) {
    if (this.form.action !== 'modify_skynet_rule') return null
    const ruleOptions = this.skynetRuleList
      .map((r: any) => ({ label: `【${r.ruleid || r.id}】${r.name || ''}`, value: String(r.ruleid || r.id) }))
    return h('el-form-item', { props: { label: '规则动作', required: true } }, [
      h('div', { style: 'width:100%' }, [
        ...this.skynetActions.map((item: any, i: number) =>
          h('div', { style: 'display:flex;align-items:center;gap:8px;margin-bottom:8px' }, [
            h('el-select', { props: { value: item.key, placeholder: '选择内置规则', size: 'small', filterable: true, popperClass: 'skynet-rule-select' }, style: 'flex:1', on: { input: (v: string) => { const a = [...this.skynetActions]; a[i] = { ...a[i], key: v }; this.skynetActions = a } } },
              ruleOptions.map(o => h('el-option', { key: o.value, props: { label: o.label, value: o.value } }))),
            h('el-select', { props: { value: item.enabled, size: 'small' }, on: { input: (v: boolean) => { const a = [...this.skynetActions]; a[i] = { ...a[i], enabled: v }; this.skynetActions = a } } }, [
              h('el-option', { props: { label: '开启', value: true } }),
              h('el-option', { props: { label: '关闭', value: false } }),
            ]),
            h('el-button', { props: { type: 'text', icon: 'el-icon-delete', size: 'small' }, style: 'color:#F56C6C', on: { click: () => this.removeSkynetAction(i) } }),
          ])
        ),
        h('el-button', { props: { type: 'text', icon: 'el-icon-plus', size: 'small' }, on: { click: this.addSkynetAction } }, ['添加一个动作']),
      ]),
    ])
  }

  renderAdvanced(h: any) {
    const f = this.form
    return h('el-collapse', { props: { value: this.advancedOpen }, on: { input: (v: string[]) => { this.advancedOpen = v } } }, [
      h('el-collapse-item', { props: { title: '高级设置', name: 'advanced' } }, [
        h('el-form-item', { props: { label: '是否记录日志' } }, [
          h('el-select', { props: { value: f.log_option }, on: { input: (v: string) => { f.log_option = v } } },
            LOG_OPTION_OPTIONS.map(o => h('el-option', { key: o.value, props: { label: o.label, value: o.value } }))),
        ]),
        h('div', { style: LOG_OPTION_DESCRIPTION_STYLE },
          LOG_OPTION_OPTIONS.map(o => h('div', [h('b', [o.label + '：']), LOG_OPTION_DESCRIPTIONS[o.value]]))
        ),
        f.action === 'deny' ? h('el-form-item', { props: { label: '阻断状态码' } }, [
          h('el-input', { props: { type: 'number', value: f.status_code, min: 100, max: 599, disabled: false }, style: 'width:230px', on: { input: (v: string) => { f.status_code = Number(v) } } }),
        ]) : null,
        h('el-form-item', { props: { label: '过期时间' } }, [
          h('el-date-picker', { props: { value: f.expire_time, type: 'datetime', placeholder: '选择过期时间' }, on: { input: (v: any) => { f.expire_time = v } } }),
        ]),
        h('el-form-item', { props: { label: '检测前解码' } }, [
          h('el-switch', { props: { value: f.decode_before_detection }, on: { input: (v: boolean) => { f.decode_before_detection = v } } }),
          f.decode_before_detection ? h('div', { style: 'margin-top:8px;width:100%' }, [
            ...f.decode_methods.map((method: string, i: number) =>
              h('div', { style: 'display:flex;align-items:center;gap:8px;margin-bottom:8px' }, [
                h('el-select', { props: { value: f.decode_methods[i], size: 'small' }, on: { input: (v: string) => { const m = [...f.decode_methods]; m[i] = v; f.decode_methods = m } } },
                  DECODE_METHOD_OPTIONS.map(o => h('el-option', { key: o.value, props: { label: o.label, value: o.value } }))),
                f.decode_methods.length > 1 ? h('el-button', { props: { type: 'text', icon: 'el-icon-delete', size: 'small' }, style: 'color:#F56C6C', on: { click: () => this.removeDecodeMethod(i) } }) : null,
              ])
            ),
            h('el-button', { props: { type: 'text', icon: 'el-icon-plus', size: 'small' }, on: { click: this.addDecodeMethod } }, ['添加一层解码']),
          ]) : null,
        ]),
        h('div', { style: LOG_OPTION_DESCRIPTION_STYLE }, ['开关开启后，解码方式将按照配置顺序进行解码。']),
        h('el-form-item', { props: { label: '规则生效时间' } }, [
          h('el-radio-group', { props: { value: f.cron_config.type }, on: { input: (type: string) => {
            if (type === 'period') {
              this.formData = { ...this.formData, cron_config: { type: 'period', weekdays: [], start_time: '00:00', end_time: '23:59' } }
            } else if (type === 'timing') {
              this.formData = { ...this.formData, cron_config: { type: 'timing', range: [] } }
            } else {
              this.formData = { ...this.formData, cron_config: { type: 'all' } }
            }
          } } }, [
            h('el-radio', { props: { label: 'all' } }, ['永久']),
            h('el-radio', { props: { label: 'timing' } }, ['定时']),
            h('el-radio', { props: { label: 'period' } }, ['周期']),
          ]),
          f.cron_config.type === 'timing' ? h('div', { style: 'margin-top:8px' }, [
            h('el-date-picker', { props: { type: 'datetimerange', value: f.cron_config.range, startPlaceholder: '开始时间', endPlaceholder: '结束时间', 'value-format': 'yyyy-MM-ddTHH:mm:ssZ' }, on: { input: (v: any) => { f.cron_config = { ...f.cron_config, range: v } } } }),
          ]) : null,
          f.cron_config.type === 'period' ? h('div', { style: 'margin-top:8px' }, [
            h('el-checkbox-group', { props: { value: f.cron_config.weekdays || [] }, on: { input: (v: number[]) => { f.cron_config = { ...f.cron_config, weekdays: v } } } },
              WEEKDAY_OPTIONS.map(o => h('el-checkbox', { key: o.value, props: { label: o.value } }, [o.label]))),
            h('div', { style: 'display:flex;align-items:center;gap:8px;margin-top:8px' }, [
              h('el-time-picker', { props: { value: f.cron_config.start_time, placeholder: '开始时间', format: 'HH:mm', 'value-format': 'HH:mm' }, on: { input: (v: string) => { f.cron_config = { ...f.cron_config, start_time: v } } } }),
              h('span', ['-']),
              h('el-time-picker', { props: { value: f.cron_config.end_time, placeholder: '结束时间', format: 'HH:mm', 'value-format': 'HH:mm' }, on: { input: (v: string) => { f.cron_config = { ...f.cron_config, end_time: v } } } }),
            ]),
          ]) : null,
        ]),
      ]),
    ])
  }

  renderCreateForm(h: any) {
    return [
      h('el-form-item', { props: { label: '状态' } }, [
        h('el-select', { props: { value: this.form.is_enabled }, on: { input: (v: boolean) => { this.form.is_enabled = v } } }, [
          h('el-option', { props: { label: '启用', value: true } }),
          h('el-option', { props: { label: '禁用', value: false } }),
        ]),
      ]),
      h('el-form-item', { props: { label: '模式' } }, [this.renderActionSelect(h)]),
      h('el-form-item', { props: { label: '备注', required: true } }, [
        h('el-input', { props: { type: 'textarea', value: this.form.comment, rows: 2, placeholder: '请输入备注' }, on: { input: (v: string) => { this.form.comment = v } } }),
      ]),
      !this.isSpecialAction ? h('el-form-item', { props: { label: '风险等级' } }, [
        h('el-select', { props: { value: this.form.risk_level }, on: { input: (v: number) => { this.form.risk_level = v } } },
          RISK_LEVEL_OPTIONS.map(o => h('el-option', { key: o.value, props: { label: o.label, value: o.value } }))),
      ]) : null,
      h('el-form-item', { props: { label: '匹配条件' } }, [
        h('ConditionEditor', { ref: 'conditionEditor', key: this.editingItem ? 'edit-' + this.editingItem.id : 'create', props: { value: this.form.pattern, captainInstanceId: this.wafId }, on: { input: (v: any) => { this.form.pattern = v } } }),
      ]),
      this.renderModuleConfig(h),
      this.renderSkynetConfig(h),
      h('el-form-item', { props: { label: '使用范围' } }, [
        h('el-select', { props: { value: this.form.websites, multiple: true, placeholder: '选择站点' }, style: 'width:100%', on: { input: (v: number[]) => { this.form.websites = v } } },
          this.sites.map(s => h('el-option', { key: s.id, props: { label: s.name || `Site ${s.id}`, value: s.id } }))),
      ]),
      !this.isSpecialAction ? h('el-form-item', { props: { label: '攻击类型', required: true } }, [
        h('el-select', { props: { value: this.form.attack_type, placeholder: '请选择攻击类型', clearable: true }, on: { input: (v: number) => { this.form.attack_type = v } } },
          ATTACK_TYPE_OPTIONS.map(o => h('el-option', { key: o.value, props: { label: o.label, value: o.value } }))),
      ]) : null,
      this.renderAdvanced(h),
    ]
  }

  render(h: any) {
    const title = this.editingItem ? '编辑规则' : '新建规则'
    return h('el-dialog', {
      props: { title, visible: this.visible, width: '720px', top: '8vh', 'close-on-click-modal': false },
      on: { close: () => this.$emit('close'), 'update:visible': (v: boolean) => { if (!v) this.$emit('close') } },
    }, [
      h('el-form', { props: { labelWidth: '100px', size: 'small' } }, [
        this.renderModeSwitch(h),
        this.mode === 'bind' ? this.renderBindMode(h) : this.renderCreateForm(h),
      ]),
      h('div', { slot: 'footer' }, [
        h('el-button', { on: { click: () => this.$emit('close') } }, ['取消']),
        h('el-button', { props: { type: 'primary', loading: this.submitting }, on: { click: this.handleSubmit } }, ['确定']),
      ]),
    ])
  }
}
