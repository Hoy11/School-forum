import { policyUpdate, policyDetail } from '@/api/captain-policy'
import { PolicyModel } from '@/types/policy'

export function createFieldUpdater(
  policy: PolicyModel,
  captainInstanceId: number,
  onUpdated: (policy: PolicyModel) => void,
) {
  return async function updateField(partial: Partial<PolicyModel>) {
    const full: any = { ...policy, ...partial, captain_instance_id: captainInstanceId }
    const resp = await policyUpdate(full)
    if (resp.err !== null) {
      throw new Error(resp.msg || '更新失败')
    }
    const detailResp = await policyDetail(policy.id, captainInstanceId)
    if (detailResp.err === null) {
      onUpdated(detailResp.data)
    }
  }
}
