// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { ModuleDetectionConfig, MODULE_NAMES } from '@/types/policy'
import FieldEditDialog from '@/components/FieldEditDialog'

const BLOCKING_OPTIONS = [
  { value: 'high', label: '仅拦截高危' },
  { value: 'medium', label: '拦截高/中危' },
  { value: 'low', label: '拦截全部' },
  { value: 'none', label: '仅观察' },
]

const LOGGING_OPTIONS = [
  { value: 'high', label: '高危' },
  { value: 'medium', label: '中危' },
  { value: 'low', label: '低危' },
  { value: 'none', label: '不记录' },
]

const BLOCKING_ACTION_MAP: Record<string, { high: string; medium: string; low: string }> = {
  none: { high: 'continue', medium: 'continue', low: 'continue' },
  high: { high: 'deny', medium: 'continue', low: 'continue' },
  medium: { high: 'deny', medium: 'deny', low: 'continue' },
  low: { high: 'deny', medium: 'deny', low: 'deny' },
}

const LOGGING_MAP: Record<string, { high: number; medium: number; low: number }> = {
  none: { high: 0, medium: 0, low: 0 },
  high: { high: 1, medium: 0, low: 0 },
  medium: { high: 1, medium: 1, low: 0 },
  low: { high: 1, medium: 1, low: 1 },
}

const DETECT_CONFIG_LABELS: Record<string, string> = {
  detect_non_injection_sql: '检测非注入型 SQL，如完整的 SQL 语句执行',
  detect_complete_html: '检测非注入型 XSS，如完整的 HTML 文件',
  detect_suspicious_schema: '检测可疑协议',
  detect_file_content: '文件内容攻击检测',
  detect_real_file_content: '检查真实文件内容',
  forbidden_extra_token: '禁止 Extra-Token(RFC 6266)',
  forbidden_multiple_filename: '禁止 filename 多写(RFC 1806)',
  forbidden_suspicious_filename: '禁止可疑文件名',
  detect_shiro: '检测 Shiro 反序列化漏洞',
  detect_lookup: '检测恶意 Lookup',
  strict_syntax_parse: '严格语法检测',
  warning_http_parse_failed: 'HTTP 协议解析失败告警',
  warning_suspicious_http_method: 'HTTP 请求方法异常告警',
  warning_suspicious_http_version: 'HTTP 版本号异常告警',
  compatibility_mode: '兼容模式',
}

const NON_BOOLEAN_KEYS = new Set([
  'file_type_of_custome_action',
  'action_of_handling_custome_file',
  'enable_module_in_detecting_file_content',
  'error_types',
  'detection_configure',
  'effective_configure',
  'other_types',
  'spider_types',
  'language_types',
  'info_leak_types',
  'rules_config',
])

// m_file_upload 多选选项
const FILE_UPLOAD_DETECT_MODULES = [
  { key: 'sqli', label: 'SQL 注入检测模块' },
  { key: 'xss', label: 'XSS 检测模块' },
  { key: 'php_unserialize', label: 'PHP 反序列化检测模块' },
  { key: 'java_unserialize', label: 'Java 反序列化检测模块' },
  { key: 'java', label: 'Java 代码注入检测模块' },
  { key: 'file_include', label: '文件包含攻击检测模块' },
  { key: 'php_code_injection', label: 'PHP 代码注入检测模块' },
  { key: 'cmd_injection', label: '命令注入检测模块' },
  { key: 'asp_code_injection', label: 'ASP 代码注入检测模块' },
  { key: 'ssti', label: '模板注入检测模块' },
]

const FILE_TYPE_OPTIONS = [
  { key: 'file_type_image', label: '图片文件' },
  { key: 'file_type_video', label: '视频文件' },
  { key: 'file_type_audio', label: '音频文件' },
  { key: 'file_type_compressed', label: '压缩文件' },
  { key: 'file_type_document', label: '文档文件' },
  { key: 'file_type_executable', label: '可执行文件' },
]

const FILE_ACTION_OPTIONS = [
  { key: 'deny transmission', label: '不允许传输' },
  { key: 'allow transmission', label: '允许传输' },
]

// m_scanner 多选选项
const SCANNER_LANGUAGE_OPTIONS = [
  { key: 'python_scanner', label: 'Python' },
  { key: 'go_scanner', label: 'Go' },
]

const SCANNER_SPIDER_OPTIONS = [
  { key: 'baidu_spider', label: '百度' },
  { key: 'bing_spider', label: '必应' },
  { key: 'sogou_spider', label: '搜狗' },
  { key: 'qihoo_spider', label: '360' },
  { key: 'google_spider', label: '谷歌' },
  { key: 'yandex_spider', label: 'Yandex' },
  { key: 'byte_spider', label: '字节跳动' },
  { key: 'headless_chrome', label: '无头谷歌浏览器' },
  { key: 'normal_spider', label: '其他爬虫' },
]

const SCANNER_OTHER_OPTIONS = [
  { key: 'abnormal', label: '疑似非浏览器请求' },
  { key: 'normal_scanner', label: '扫描器' },
]

// m_response 多选选项
const RESPONSE_ERROR_TYPES = [
  { key: 'directory indexing', label: '列目录' },
  { key: 'SQL execution error', label: 'SQL 报错' },
  { key: 'server exception', label: '服务器异常' },
]

const RESPONSE_DETECT_CONFIG = [
  { key: 'detect_jsp_code_leak', label: '检测 jsp 代码泄漏' },
  { key: 'detect_php_code_leak', label: '检测 php 代码泄漏' },
  { key: 'detect_webshell', label: '检测 webshell' },
]

const RESPONSE_EFFECTIVE_CONFIG = [
  { key: 'detect_cmd_execute_success', label: '检测命令执行成功内容' },
]

// m_rule (内置规则模块) 多选选项
const RULE_DETECTION_CONFIGURE = [
  { key: 'detect_phpinfo', label: '检测 phpinfo 泄漏' },
  { key: 'detect_admin_page', label: '检测管理后台界面' },
  { key: 'detect_backdoor', label: '检测后门' },
  { key: 'detect_php_vuln', label: '检测 PHP 漏洞' },
  { key: 'detect_nginx', label: '检测 Nginx 漏洞' },
  { key: 'detect_dedecms', label: '检测 DedeCMS 漏洞' },
  { key: 'detect_apache', label: '检测 Apache 漏洞' },
  { key: 'detect_xml', label: '检测 XML 漏洞' },
  { key: 'detect_struts2', label: '检测 Struts2 漏洞' },
  { key: 'detect_java_vuln', label: '检测 Java 漏洞' },
  { key: 'detect_php168', label: '检测 PHP168 漏洞' },
  { key: 'detect_wordpress', label: '检测 WordPress 漏洞' },
  { key: 'detect_directory_traversal', label: '检测路径穿越攻击' },
  { key: 'detect_iis', label: '检测 IIS 漏洞' },
  { key: 'detect_gogs_gitea', label: '检测 Gogs 和 Gitea 漏洞' },
  { key: 'detect_thinkphp', label: '检测 ThinkPHP 漏洞' },
  { key: 'detect_jenkins', label: '检测 Jenkins 漏洞' },
  { key: 'detect_ecshop', label: '检测 ECShop 漏洞' },
  { key: 'detect_nexus', label: '检测 Nexus 漏洞' },
  { key: 'detect_drupal', label: '检测 Drupal 漏洞' },
  { key: 'detect_ghostscript', label: '检测 Ghostscript 漏洞' },
  { key: 'detect_atlassian', label: '检测 Atlassian 漏洞' },
  { key: 'detect_weblogic', label: '检测 Weblogic 漏洞' },
  { key: 'detect_coremail', label: '检测 Coremail 漏洞' },
  { key: 'detect_phpcms', label: '检测 PHPCMS 漏洞' },
  { key: 'detect_spring', label: '检测 Spring 漏洞' },
  { key: 'detect_southidc', label: '检测 南方数据 漏洞' },
  { key: 'detect_fastjson', label: '检测 Fastjson 漏洞' },
  { key: 'detect_tbk_dvr', label: '检测 TBK DVR 漏洞' },
  { key: 'detect_joomla', label: '检测 Joomla 漏洞' },
  { key: 'detect_ecology_oa', label: '检测 E-cology 漏洞' },
  { key: 'detect_jackson', label: '检测 Jackson 漏洞' },
  { key: 'detect_xstream', label: '检测 Xstream 漏洞' },
  { key: 'detect_activemq', label: '检测 ActiveMQ 漏洞' },
  { key: 'detect_solr', label: '检测 Solr 漏洞' },
  { key: 'detect_csii', label: '检测 科蓝 漏洞' },
  { key: 'detect_big_ip', label: '检测 Big-IP 漏洞' },
  { key: 'detect_apisix', label: '检测 APISIX 漏洞' },
  { key: 'detect_druid', label: '检测 Druid 漏洞' },
  { key: 'detect_log4j', label: '检测 Log4j 漏洞' },
]

const RULE_INFO_LEAK_TYPES = [
  { key: 'test file', label: '测试文件' },
  { key: 'backup file', label: '备份文件' },
  { key: 'code repository', label: '代码仓库' },
  { key: 'server sensitive file', label: '服务器敏感文件' },
]

@Component({ components: { FieldEditDialog } })
export default class EngineModuleCard extends Vue {
  @Prop({ required: true }) moduleKey!: string
  @Prop({ required: true }) config!: ModuleDetectionConfig
  @Prop({ default: false }) masterEnabled!: boolean
  @Prop({ default: false }) isEditProtected!: boolean
  @Prop({ default: '' }) editTooltip!: string

  dialogVisible = false
  editConfig: ModuleDetectionConfig | null = null

  get moduleName(): string {
    return MODULE_NAMES[this.moduleKey] || this.moduleKey
  }

  get isEnabled(): boolean {
    return this.config.state === 'enabled'
  }

  get statusText(): string {
    if (!this.masterEnabled || this.config.state === 'disabled') return '已禁用'
    const opt = BLOCKING_OPTIONS.find(o => o.value === this.configBlockingThreshold)
    return opt?.label || '仅拦截高危'
  }

  get statusColor(): string {
    if (!this.masterEnabled || this.config.state === 'disabled') return '#909399'
    const bt = this.configBlockingThreshold
    if (bt === 'low') return '#f56c6c'
    if (bt === 'none') return '#e6a23c'
    return '#e6a23c'
  }

  get configBlockingThreshold(): string {
    const cfg = this.config
    if (cfg.high_risk_action === 'continue') return 'none'
    if (cfg.low_risk_action === 'deny') return 'low'
    if (cfg.medium_risk_action === 'deny') return 'medium'
    return 'high'
  }

  get blockingThreshold(): string {
    const cfg = this.editConfig || this.config
    if (cfg.high_risk_action === 'continue') return 'none'
    if (cfg.low_risk_action === 'deny') return 'low'
    if (cfg.medium_risk_action === 'deny') return 'medium'
    return 'high'
  }

  set blockingThreshold(val: string) {
    if (!this.editConfig) return
    const actions = BLOCKING_ACTION_MAP[val] || BLOCKING_ACTION_MAP.high
    this.editConfig = {
      ...this.editConfig,
      high_risk_action: actions.high,
      medium_risk_action: actions.medium,
      low_risk_action: actions.low,
    }
  }

  get configLoggingThreshold(): string {
    const cfg = this.config
    if (cfg.high_risk_enable_log === 0) return 'none'
    if (cfg.low_risk_enable_log === 1) return 'low'
    if (cfg.medium_risk_enable_log === 1) return 'medium'
    return 'high'
  }

  get loggingThreshold(): string {
    const cfg = this.editConfig || this.config
    if (cfg.high_risk_enable_log === 0) return 'none'
    if (cfg.low_risk_enable_log === 1) return 'low'
    if (cfg.medium_risk_enable_log === 1) return 'medium'
    return 'high'
  }

  set loggingThreshold(val: string) {
    if (!this.editConfig) return
    const logs = LOGGING_MAP[val] || LOGGING_MAP.high
    this.editConfig = {
      ...this.editConfig,
      high_risk_enable_log: logs.high,
      medium_risk_enable_log: logs.medium,
      low_risk_enable_log: logs.low,
    }
  }

  get booleanDetectEntries(): [string, boolean][] {
    const dc = this.editConfig?.detect_config || this.config.detect_config
    if (!dc) return []
    return Object.entries(dc)
      .filter(([key, val]) => typeof val === 'boolean' && !NON_BOOLEAN_KEYS.has(key))
      .map(([key, val]) => [key, val as boolean])
  }

  getArrayField(key: string): string[] {
    const dc = this.editConfig?.detect_config
    if (!dc) return []
    return (dc[key] as string[]) || []
  }

  setArrayField(key: string, val: string[]) {
    if (!this.editConfig) return
    this.editConfig = {
      ...this.editConfig,
      detect_config: { ...this.editConfig.detect_config, [key]: val },
    }
  }

  getSingleSelectField(key: string): string {
    const arr = this.getArrayField(key)
    return arr.length > 0 ? arr[0] : ''
  }

  setSingleSelectField(key: string, val: string) {
    this.setArrayField(key, val ? [val] : [])
  }

  openDialog() {
    this.editConfig = JSON.parse(JSON.stringify(this.config))
    this.dialogVisible = true
  }

  handleDialogClose() {
    this.dialogVisible = false
    this.editConfig = null
  }

  async handleDialogSubmit() {
    if (!this.editConfig) return
    this.$emit('update', this.editConfig)
    this.dialogVisible = false
    this.editConfig = null
  }

  handleEditStateToggle(val: boolean) {
    if (!this.editConfig) return
    this.editConfig = { ...this.editConfig, state: val ? 'enabled' : 'disabled' }
  }

  handleDetectConfigToggle(key: string, val: boolean) {
    if (!this.editConfig) return
    this.editConfig = {
      ...this.editConfig,
      detect_config: { ...this.editConfig.detect_config, [key]: val },
    }
  }

  renderCheckboxGroup(h: any, label: string, field: string, options: { key: string; label: string }[], disabled = false) {
    const dc = this.editConfig?.detect_config
    if (!dc) return null
    const selected: string[] = (dc[field] as string[]) || []
    return (
      <el-form-item label={label}>
        <el-checkbox-group value={selected} on-input={(val: string[]) => this.setArrayField(field, val)} disabled={disabled}>
          {options.map(opt => (
            <el-checkbox key={opt.key} label={opt.key} style="margin-bottom:4px">{opt.label}</el-checkbox>
          ))}
        </el-checkbox-group>
      </el-form-item>
    )
  }

  renderModuleSpecificFields(h: any) {
    const mk = this.moduleKey

    if (mk === 'm_file_upload') {
      const fileContentEnabled = !!(this.editConfig?.detect_config?.detect_file_content)
      return (
        <div>
          {this.renderCheckboxGroup(h, '文件内容攻击检测模块', 'enable_module_in_detecting_file_content', FILE_UPLOAD_DETECT_MODULES, !fileContentEnabled)}
          <el-form-item label="特定文件类型检测处置行为">
            <el-select
              value={this.getSingleSelectField('action_of_handling_custome_file')}
              on-input={(v: string) => this.setSingleSelectField('action_of_handling_custome_file', v)}
              style="width:100%"
            >
              {FILE_ACTION_OPTIONS.map(opt => (
                <el-option key={opt.key} label={opt.label} value={opt.key} />
              ))}
            </el-select>
          </el-form-item>
          {this.renderCheckboxGroup(h, '特定文件类型检测处置列表', 'file_type_of_custome_action', FILE_TYPE_OPTIONS)}
        </div>
      )
    }

    if (mk === 'm_scanner') {
      return (
        <div>
          {this.renderCheckboxGroup(h, '编程语言 HTTP 库', 'language_types', SCANNER_LANGUAGE_OPTIONS)}
          {this.renderCheckboxGroup(h, '爬虫检测类型', 'spider_types', SCANNER_SPIDER_OPTIONS)}
          {this.renderCheckboxGroup(h, '其他检测配置项', 'other_types', SCANNER_OTHER_OPTIONS)}
        </div>
      )
    }

    if (mk === 'm_response') {
      return (
        <div>
          {this.renderCheckboxGroup(h, '响应错误类型', 'error_types', RESPONSE_ERROR_TYPES)}
          {this.renderCheckboxGroup(h, '响应检测模块需要检测的类型', 'detection_configure', RESPONSE_DETECT_CONFIG)}
          {this.renderCheckboxGroup(h, '攻击有效性', 'effective_configure', RESPONSE_EFFECTIVE_CONFIG)}
        </div>
      )
    }

    if (mk === 'm_rule') {
      return (
        <div>
          {this.renderCheckboxGroup(h, '检测配置项', 'detection_configure', RULE_DETECTION_CONFIGURE)}
          {this.renderCheckboxGroup(h, '信息泄露需要检测的类型', 'info_leak_types', RULE_INFO_LEAK_TYPES)}
        </div>
      )
    }

    return null
  }

  render(h: any) {
    const isDisabled = !this.masterEnabled || !this.isEnabled

    return (
      <div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          padding: '10px 0',
          borderBottom: '1px solid #ebeef5',
          opacity: isDisabled ? 0.6 : 1,
        }}>
          <span style="flex:1;font-size:14px;color:#303133">{this.moduleName}</span>
          <span style={`font-size:13px;color:${this.statusColor};margin-right:12px`}>{this.statusText}</span>
          <el-tooltip content={this.editTooltip} placement="top" disabled={!this.isEditProtected}>
            <el-button type="text" icon="el-icon-edit" style={this.isEditProtected ? 'flex-shrink:0;padding:4px;color:#ccc' : 'flex-shrink:0;padding:4px'}
              on-click={() => this.isEditProtected ? this.$message.warning(this.editTooltip) : this.openDialog()} />
          </el-tooltip>
        </div>

        <FieldEditDialog
          visible={this.dialogVisible}
          title={`编辑 ${this.moduleName}`}
          on-close={this.handleDialogClose}
          on-submit={this.handleDialogSubmit}
          width="560px"
        >
          <el-form label-width="180px" size="small">
            <el-form-item label="是否启用">
              <el-switch value={this.editConfig?.state === 'enabled'} on-change={this.handleEditStateToggle} />
            </el-form-item>
            <el-form-item label="阻断阈值">
              <div>
                <el-slider
                  value={BLOCKING_OPTIONS.findIndex(o => o.value === this.blockingThreshold)}
                  min={0} max={3} step={1} show-stops
                  format-tooltip={(idx: number) => BLOCKING_OPTIONS[idx]?.label || ''}
                  on-input={(idx: number) => { this.blockingThreshold = BLOCKING_OPTIONS[idx].value }}
                  style="width:260px"
                />
                <div style="display:flex;justify-content:space-between;width:260px;margin-top:-4px">
                  <span style="font-size:12px;color:#909399">高危</span>
                  <span style="font-size:12px;color:#909399">中危</span>
                  <span style="font-size:12px;color:#909399">低危</span>
                  <span style="font-size:12px;color:#909399">仅观察</span>
                </div>
              </div>
            </el-form-item>
            <el-form-item label="记录日志阈值">
              <div>
                <el-slider
                  value={LOGGING_OPTIONS.findIndex(o => o.value === this.loggingThreshold)}
                  min={0} max={3} step={1} show-stops
                  format-tooltip={(idx: number) => LOGGING_OPTIONS[idx]?.label || ''}
                  on-input={(idx: number) => { this.loggingThreshold = LOGGING_OPTIONS[idx].value }}
                  style="width:260px"
                />
                <div style="display:flex;justify-content:space-between;width:260px;margin-top:-4px">
                  <span style="font-size:12px;color:#909399">高危</span>
                  <span style="font-size:12px;color:#909399">中危</span>
                  <span style="font-size:12px;color:#909399">低危</span>
                  <span style="font-size:12px;color:#909399">不记录</span>
                </div>
              </div>
            </el-form-item>
            {this.booleanDetectEntries.map(([key, val]) => (
              <el-form-item label={DETECT_CONFIG_LABELS[key] || key} key={key}>
                <el-switch value={val} on-change={(v: boolean) => this.handleDetectConfigToggle(key, v)} />
              </el-form-item>
            ))}
            {this.renderModuleSpecificFields(h)}
          </el-form>
        </FieldEditDialog>
      </div>
    )
  }
}
