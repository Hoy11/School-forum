// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { PolicyModel, TenginePageConfigItem } from '@/types/policy'
import { BlockPageInfo } from '@/types/block-page'
import { blockPageList } from '@/api/captain-block-page'
import FieldEditDialog from '@/components/FieldEditDialog'
import { createFieldUpdater } from './usePolicyFieldUpdate'

const NGINX_ERR_CONTENT_STATUS = [
  { value: 400, label: '400 (Bad Request)' },
  { value: 401, label: '401 (Unauthorized)' },
  { value: 402, label: '402 (Payment Required)' },
  { value: 403, label: '403 (Forbidden)' },
  { value: 404, label: '404 (Not Found)' },
  { value: 405, label: '405 (Method Not Allowed)' },
  { value: 406, label: '406 (Not Acceptable)' },
  { value: 407, label: '407 (Proxy Authentication Required)' },
  { value: 409, label: '409 (Conflict)' },
  { value: 410, label: '410 (Gone)' },
  { value: 411, label: '411 (Length Required)' },
  { value: 412, label: '412 (Precondition Failed)' },
  { value: 413, label: '413 (Request Entity Too Large)' },
  { value: 414, label: '414 (Request-URI Too Large)' },
  { value: 415, label: '415 (Unsupported Media Type)' },
  { value: 416, label: '416 (Requested range not satisfiable)' },
  { value: 417, label: '417 (Expectation Failed)' },
  { value: 418, label: '418 (I\'m a teapot)' },
  { value: 422, label: '422 (Unprocessable Entity)' },
  { value: 425, label: '425 (Too Early)' },
  { value: 426, label: '426 (Upgrade Required)' },
  { value: 428, label: '428 (Precondition Required)' },
  { value: 429, label: '429 (Too Many Requests)' },
  { value: 431, label: '431 (Request Header Fields Too Large)' },
  { value: 451, label: '451 (Unavailable For Legal Reasons)' },
  { value: 500, label: '500 (Internal Server Error)' },
  { value: 501, label: '501 (Not Implemented)' },
  { value: 502, label: '502 (Bad Gateway)' },
  { value: 503, label: '503 (Service Unavailable)' },
  { value: 504, label: '504 (Gateway Time-out)' },
  { value: 505, label: '505 (HTTP Version not supported)' },
  { value: 506, label: '506 (Variant Also Negotiates)' },
  { value: 507, label: '507 (Insufficient Storage)' },
  { value: 508, label: '508 (Loop Detected)' },
  { value: 510, label: '510 (Not Extended)' },
  { value: 511, label: '511 (Network Authentication Required)' },
]

const DECODE_OPTIONS = [
  { key: 'url decode', label: 'URL 解码' },
  { key: 'JSON', label: 'JSON 解析' },
  { key: 'base64', label: 'Base64 解码' },
  { key: 'base64(RFC 2045)', label: 'Base64 (RFC 2045) 解码' },
  { key: 'hex', label: '十六进制转换' },
  { key: 'binary', label: '二进制解码' },
  { key: 'eval', label: '斜杠反转义' },
  { key: 'XML', label: 'XML 解析' },
  { key: 'PHP deserialize', label: 'PHP 序列化对象解析' },
  { key: 'utf7', label: 'UTF-7 解码' },
  { key: 'line feed parameter', label: '换行分割的参数' },
]

const MAX_INT32 = 2147483647
const HTTP_BODY_RECORD_MAX = 10240
const RESPONSE_DETECTION_BODY_MAX = 4096

@Component({ components: { FieldEditDialog } })
export default class BasicConfigTab extends Vue {
  @Prop({ required: true }) policy!: PolicyModel
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: false }) isEditProtected!: boolean
  @Prop({ default: '' }) editTooltip!: string

  activeDialog: string | null = null
  dialogSaving = false

  editDecodeMethods: string[] = []
  editForbidden: { path: string; action: string; status_code: number | string } = { path: '', action: 'response', status_code: '' }
  editResponseDetection = { enabled: false, max_body_size: 0 }
  editRequestMaxBodySize = 0
  editBodyRecordMaxSize = 0
  editTimeout = { enabled: false, threshold: 0, log_event: false }
  editPayloadExplain = false
  editBodySizeCheck = 0
  editTenginePages: TenginePageConfigItem[] = []
  forbiddenPages: BlockPageInfo[] = []
  forbiddenPagesLoading = false
  availablePages: BlockPageInfo[] = []
  tenginePagesLoading = false
  tengineAddRow: { status_code: number; path: string } = { status_code: 403, path: '' }

  get updateField() {
    return createFieldUpdater(this.policy, this.captainInstanceId, (p) => this.$emit('updated', p))
  }

  get decodeDisplayText(): string {
    const methods = this.policy.misc_detection_config?.decode_config?.decode_methods || []
    if (methods.length === 0) return '-'
    return methods.map(m => DECODE_OPTIONS.find(o => o.key === m)?.label || m).join('、')
  }

  isRedirect(statusCode: number | string): boolean {
    const num = Number(statusCode)
    return num >= 300 && num < 400
  }

  get forbiddenDisplayText(): string {
    const cfg = this.policy.forbidden_page_config
    if (!cfg || !cfg.status_code) return '未配置'
    return `阻断时返回 ${cfg.status_code}`
  }

  get responseDetectionText(): string { return this.policy.response_detection_state ? '已启用' : '未启用' }
  get timeoutText(): string { return this.policy.is_timeout_enabled ? '已启用' : '未启用' }
  get bodySizeCheckText(): string { return this.policy.max_file_size ? '已开启' : '已关闭' }

  get tengineAvailableStatusCodes() {
    const usedCodes = new Set(this.editTenginePages.map(item => item.status_code))
    return NGINX_ERR_CONTENT_STATUS.filter(opt => !usedCodes.has(opt.value))
  }

  get tenginePageDisplayText(): string {
    const cfg = this.policy.tengine_page_config
    if (!cfg || cfg.length === 0) return '未配置'
    return cfg.map(item => {
      const pageName = this.availablePages.find(p => p.name === item.path)?.comment || item.path
      return `${item.status_code} ${pageName}`
    }).join('；')
  }

  mounted() {
    this.loadBlockPages()
  }

  @Watch('captainInstanceId')
  onCaptainInstanceChange() { this.loadBlockPages() }

  async loadBlockPages() {
    if (!this.captainInstanceId) return
    try {
      const resp = await blockPageList(this.captainInstanceId, 0, 999)
      if (resp.err === null) {
        const items = resp.data?.items || resp.data || []
        this.forbiddenPages = items
        this.availablePages = items
      }
    } catch { /* ignore */ }
  }

  openDecodeDialog() { this.editDecodeMethods = [...(this.policy.misc_detection_config?.decode_config?.decode_methods || [])]; this.activeDialog = 'decode' }
  async openForbiddenDialog() {
    const cfg = this.policy.forbidden_page_config
    this.editForbidden = { path: cfg?.path || '', action: cfg?.action || 'response', status_code: cfg?.status_code || '' }
    this.activeDialog = 'forbidden'
  }
  openResponseDialog() { this.editResponseDetection = { enabled: this.policy.response_detection_state, max_body_size: this.policy.response_detection_max_body_size }; this.activeDialog = 'response' }
  openRequestMaxBodyDialog() { this.editRequestMaxBodySize = this.policy.request_detection_max_body_size; this.activeDialog = 'requestBody' }
  openBodyRecordDialog() { this.editBodyRecordMaxSize = this.policy.req_http_body_max_size; this.activeDialog = 'bodyRecord' }
  openTimeoutDialog() { this.editTimeout = { enabled: this.policy.is_timeout_enabled, threshold: this.policy.detection_timeout_threshold, log_event: this.policy.log_detection_timeout_event }; this.activeDialog = 'timeout' }
  openBodySizeCheckDialog() { this.editBodySizeCheck = this.policy.max_file_size; this.activeDialog = 'bodySizeCheck' }
  openPayloadDialog() { this.editPayloadExplain = this.policy.payload_explain_state; this.activeDialog = 'payload' }
  async openTenginePageDialog() {
    this.editTenginePages = JSON.parse(JSON.stringify(this.policy.tengine_page_config || []))
    this.tengineAddRow = { status_code: 403, path: '' }
    this.activeDialog = 'tenginePage'
    this.tenginePagesLoading = true
    try {
      const resp = await blockPageList(this.captainInstanceId, 0, 999)
      if (resp.err === null) this.availablePages = resp.data?.items || resp.data || []
    } finally {
      this.tenginePagesLoading = false
    }
  }
  closeDialog() { this.activeDialog = null }

  toggleDecodeMethod(key: string) {
    const idx = this.editDecodeMethods.indexOf(key)
    if (idx >= 0) this.editDecodeMethods.splice(idx, 1)
    else this.editDecodeMethods.push(key)
  }

  isIntegerInRange(value: unknown, min: number, max?: number) {
    if (value === '') return false
    if (typeof value === 'string' && value.trim() === '') return false
    const num = Number(value)
    if (!Number.isInteger(num) || num < min) return false
    return max === undefined || num <= max
  }

  warnInvalid(message: string) {
    this.$message.warning(message)
  }

  async saveDecode() { await this.updateField({ misc_detection_config: { ...this.policy.misc_detection_config, decode_config: { decode_methods: this.editDecodeMethods } } }); this.activeDialog = null }
  async saveForbidden() {
    if (!this.editForbidden.status_code) {
      await this.updateField({ forbidden_page_config: null })
    } else {
      const action = this.isRedirect(this.editForbidden.status_code) ? 'redirect' : 'response'
      await this.updateField({ forbidden_page_config: { path: this.editForbidden.path, action, status_code: Number(this.editForbidden.status_code) } })
    }
    this.activeDialog = null
  }
  async saveResponse() {
    if (this.editResponseDetection.enabled && !this.isIntegerInRange(this.editResponseDetection.max_body_size, 1, RESPONSE_DETECTION_BODY_MAX)) {
      this.warnInvalid('response_detection_max_body_size: 请确保该值小于或者等于 4096。')
      return
    }
    await this.updateField({ response_detection_state: this.editResponseDetection.enabled, response_detection_max_body_size: Number(this.editResponseDetection.max_body_size) })
    this.activeDialog = null
  }
  async saveRequestMaxBody() {
    if (!this.isIntegerInRange(this.editRequestMaxBodySize, 0, MAX_INT32)) {
      this.warnInvalid('request_detection_max_body_size:请确保该值小于或者等于 2147483647。')
      return
    }
    await this.updateField({ request_detection_max_body_size: Number(this.editRequestMaxBodySize) })
    this.activeDialog = null
  }
  async saveBodyRecord() {
    if (!this.isIntegerInRange(this.editBodyRecordMaxSize, 0, HTTP_BODY_RECORD_MAX)) {
      this.warnInvalid('请输入 0 ~ 10240 的整数')
      return
    }
    await this.updateField({ req_http_body_max_size: Number(this.editBodyRecordMaxSize), rsp_http_body_max_size: Number(this.editBodyRecordMaxSize) })
    this.activeDialog = null
  }
  async saveTimeout() {
    if (this.editTimeout.enabled && !this.isIntegerInRange(this.editTimeout.threshold, 1)) {
      this.warnInvalid('请输入 >=1 的整数')
      return
    }
    await this.updateField({ is_timeout_enabled: this.editTimeout.enabled, detection_timeout_threshold: Number(this.editTimeout.threshold), log_detection_timeout_event: this.editTimeout.log_event })
    this.activeDialog = null
  }
  async saveBodySizeCheck() {
    if (!this.isIntegerInRange(this.editBodySizeCheck, 0, HTTP_BODY_RECORD_MAX)) {
      this.warnInvalid('请输入 0 ~ 10240 的整数')
      return
    }
    await this.updateField({ max_file_size: Number(this.editBodySizeCheck) })
    this.activeDialog = null
  }
  async savePayload() { await this.updateField({ payload_explain_state: this.editPayloadExplain }); this.activeDialog = null }
  async saveTenginePage() { await this.updateField({ tengine_page_config: this.editTenginePages }); this.activeDialog = null }

  removeTenginePageItem(idx: number) {
    this.editTenginePages.splice(idx, 1)
    this.editTenginePages = [...this.editTenginePages]
  }

  addTenginePageItem() {
    if (!this.tengineAddRow.path) return
    this.editTenginePages = [...this.editTenginePages, { status_code: this.tengineAddRow.status_code, path: this.tengineAddRow.path }]
    this.tengineAddRow = { status_code: 403, path: '' }
  }

  render(h: any) {
    const p = this.policy

    const row = (label: string, value: string, onEdit: (() => void) | null) => (
      <div style="display:flex;align-items:center;padding:10px 0;border-bottom:1px solid #ebeef5">
        <span style="flex:1;font-size:14px;color:#303133">{label}</span>
        <span style="font-size:13px;color:#606266;margin-right:12px">{value || '-'}</span>
        {onEdit && <el-tooltip content={this.editTooltip} placement="top" disabled={!this.isEditProtected}>
          <el-button type="text" icon="el-icon-edit" style={this.isEditProtected ? 'flex-shrink:0;padding:4px;color:#ccc' : 'flex-shrink:0;padding:4px'}
            on-click={() => this.isEditProtected ? this.$message.warning(this.editTooltip) : onEdit()} />
        </el-tooltip>}
      </div>
    )

    const sectionHeader = (label: string) => (
      <div style="display:flex;align-items:center;padding:10px 0;border-bottom:1px solid #ebeef5;background:#fafafa">
        <span style="flex:1;font-size:14px;color:#909399">{label}</span>
      </div>
    )

    return (
      <div>
        {row('解码方法', this.decodeDisplayText, this.openDecodeDialog)}
        {row('拦截方式', this.forbiddenDisplayText, this.openForbiddenDialog)}
        {row('反向代理默认响应页配置', this.tenginePageDisplayText, this.openTenginePageDialog)}
        {row('HTTP 响应处理', this.policy.response_detection_state ? '已启用' : '未启用', this.openResponseDialog)}
        {row('HTTP 请求体检测', `${p.request_detection_max_body_size} KB`, this.openRequestMaxBodyDialog)}
        {row('HTTP Body 记录限制', `${p.req_http_body_max_size} KB`, this.openBodyRecordDialog)}
        {row('检测超时限制', this.policy.is_timeout_enabled ? '已启用' : '未启用', this.openTimeoutDialog)}
        {sectionHeader('其他模块')}
        {row('大包绕过防护', this.bodySizeCheckText, this.openBodySizeCheckDialog)}
        {row('载荷分析', this.policy.payload_explain_state ? '已启用' : '未启用', this.openPayloadDialog)}

        <FieldEditDialog visible={this.activeDialog === 'decode'} title="编辑解码方法" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.saveDecode}>
          <div style="margin-bottom:8px;font-size:13px;color:#909399">解码方法</div>
          {DECODE_OPTIONS.map(opt => (
            <div key={opt.key} style="margin-bottom:8px">
              <el-checkbox value={this.editDecodeMethods.includes(opt.key)} on-change={() => this.toggleDecodeMethod(opt.key)}>{opt.label}</el-checkbox>
            </div>
          ))}
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'forbidden'} title="编辑拦截方式" loading={this.dialogSaving || this.forbiddenPagesLoading}
          on-close={this.closeDialog} on-submit={this.saveForbidden}>
          <el-form label-width="140px" size="small">
            <el-form-item label="HTTP 状态码">
              <el-input value={this.editForbidden.status_code} on-input={(v: string) => {
                const action = this.isRedirect(v) ? 'redirect' : 'response'
                this.editForbidden = { ...this.editForbidden, status_code: v, action, path: '' }
              }} type="number" placeholder="如 403" style="width:100%" />
            </el-form-item>
            {!this.editForbidden.status_code && (
              <el-alert title="默认返回 403" type="warning" showIcon closable={false} style="margin-bottom:12px" />
            )}
            {this.isRedirect(this.editForbidden.status_code) && this.editForbidden.status_code && (
              <div>
                <el-form-item label="重定向地址" required>
                  <el-input value={this.editForbidden.path} on-input={(v: string) => { this.editForbidden = { ...this.editForbidden, path: v } }} placeholder="https://example.com" style="width:100%" />
                </el-form-item>
                <el-alert title="请勿输入 payload 及可被拦截动作自定义规则命中的内容。" type="error" showIcon closable={false} style="margin-bottom:12px" />
              </div>
            )}
            {!this.isRedirect(this.editForbidden.status_code) && this.editForbidden.status_code && (
              <el-form-item label="阻断页面">
                <el-select value={this.editForbidden.path} on-input={(v: string) => { this.editForbidden = { ...this.editForbidden, path: v } }} style="width:100%">
                  <el-option label="默认" value="" />
                  {this.forbiddenPages.map(p => (
                    <el-option key={p.name} label={p.comment || p.name} value={p.name} />
                  ))}
                </el-select>
              </el-form-item>
            )}
          </el-form>
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'response'} title="编辑 HTTP 响应处理" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.saveResponse}>
          <el-form label-width="180px" size="small">
            <el-form-item label="启用 HTTP 响应处理">
              <el-switch value={this.editResponseDetection.enabled} on-change={(v: boolean) => { this.editResponseDetection = { ...this.editResponseDetection, enabled: v } }} />
            </el-form-item>
            <el-form-item label="允许最大 Body 长度">
              <el-input value={this.editResponseDetection.max_body_size} on-input={(v: string) => { this.editResponseDetection = { ...this.editResponseDetection, max_body_size: v } }} type="number" style="width:200px">
                <template slot="append">KB</template>
              </el-input>
            </el-form-item>
          </el-form>
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'requestBody'} title="编辑 HTTP 请求体检测" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.saveRequestMaxBody}>
          <el-form label-width="180px" size="small">
            <el-form-item label="请求体检测最大大小">
              <el-input value={this.editRequestMaxBodySize} on-input={(v: string) => { this.editRequestMaxBodySize = v as any }} type="number" style="width:200px">
                <template slot="append">KB</template>
              </el-input>
            </el-form-item>
          </el-form>
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'bodyRecord'} title="编辑 HTTP Body 记录限制" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.saveBodyRecord}>
          <el-form label-width="200px" size="small">
            <el-form-item label="允许记录的最大 Body 长度">
              <el-input value={this.editBodyRecordMaxSize} on-input={(v: string) => { this.editBodyRecordMaxSize = v as any }} type="number" style="width:200px">
                <template slot="append">KB</template>
              </el-input>
            </el-form-item>
            <div style="font-size:12px;color:#909399;line-height:1.6;padding:0 0 8px 200px">
              当 Body 大小超过限制时，攻击检测日志仅记录 HTTP 消息中靠前的 Body 内容。
            </div>
          </el-form>
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'timeout'} title="编辑检测超时限制" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.saveTimeout}>
          <el-form label-width="180px" size="small">
            <el-form-item label="启用检测超时">
              <el-switch value={this.editTimeout.enabled} on-change={(v: boolean) => { this.editTimeout = { ...this.editTimeout, enabled: v } }} />
            </el-form-item>
            <el-form-item label="超时阈值">
              <el-input value={this.editTimeout.threshold} on-input={(v: string) => { this.editTimeout = { ...this.editTimeout, threshold: v } }} type="number" style="width:200px">
                <template slot="append">ms</template>
              </el-input>
            </el-form-item>
            <el-form-item label="记录超时事件">
              <el-switch value={this.editTimeout.log_event} on-change={(v: boolean) => { this.editTimeout = { ...this.editTimeout, log_event: v } }} />
            </el-form-item>
          </el-form>
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'bodySizeCheck'} title="编辑大包绕过防护" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.saveBodySizeCheck}>
          <el-form label-width="180px" size="small">
            <el-form-item label="大包绕过防护">
              <div style="display:flex;align-items:center;gap:8px">
                <span style="font-size:13px;color:#606266">文件大小超过</span>
                <el-input value={this.editBodySizeCheck} on-input={(v: string) => { this.editBodySizeCheck = v as any }} type="number" style="width:160px">
                  <template slot="append">KB</template>
                </el-input>
                <span style="font-size:13px;color:#606266">则跳过检测</span>
              </div>
            </el-form-item>
            <div style="font-size:12px;color:#909399;line-height:1.6;padding:0 0 8px 180px">
              开启后，智能识别请求体中大小超限文件将不再转发至攻击检测引擎进行检测，降低攻击绕过风险，检测资源将被用于检测更可能存在攻击的部分。设为 0 则关闭此功能。
            </div>
          </el-form>
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'payload'} title="编辑载荷分析" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.savePayload}>
          <el-form label-width="140px" size="small">
            <el-form-item label="启用">
              <el-switch value={this.editPayloadExplain} on-change={(v: boolean) => { this.editPayloadExplain = v }} />
            </el-form-item>
          </el-form>
        </FieldEditDialog>

        <FieldEditDialog visible={this.activeDialog === 'tenginePage'} title="编辑反向代理默认响应页配置" loading={this.dialogSaving}
          on-close={this.closeDialog} on-submit={this.saveTenginePage} width="640px">
          <div v-loading={this.tenginePagesLoading}>
            {this.editTenginePages.length > 0 && (
              <div style="margin-bottom:12px">
                {this.editTenginePages.map((item, idx) => (
                  <div key={idx} style="display:flex;align-items:center;padding:6px 0;border-bottom:1px solid #f0f0f0">
                    <span style="flex:1;font-size:13px;color:#303133">
                      {NGINX_ERR_CONTENT_STATUS.find(o => o.value === item.status_code)?.label || `${item.status_code}`}
                    </span>
                    <span style="font-size:13px;color:#606266;margin-right:8px">
                      {this.availablePages.find(p => p.name === item.path)?.comment || item.path}
                    </span>
                    <el-button type="text" icon="el-icon-delete" style="flex-shrink:0;padding:4px;color:#f56c6c" on-click={() => this.removeTenginePageItem(idx)} />
                  </div>
                ))}
              </div>
            )}
            {this.editTenginePages.length === 0 && !this.tenginePagesLoading && (
              <div style="text-align:center;padding:16px;color:#909399;font-size:13px">暂无配置，请添加响应页</div>
            )}
            {this.editTenginePages.length < NGINX_ERR_CONTENT_STATUS.length && (
            <div style="border-top:1px solid #ebeef5;padding-top:12px">
              <div style="font-size:13px;color:#303133;margin-bottom:8px;font-weight:500">添加响应页配置</div>
              <div style="display:flex;align-items:center;gap:8px">
                <el-select value={this.tengineAddRow.status_code} on-input={(v: number) => { this.tengineAddRow = { ...this.tengineAddRow, status_code: v } }} style="width:200px" placeholder="状态码">
                  {this.tengineAvailableStatusCodes.map(opt => (
                    <el-option key={opt.value} label={opt.label} value={opt.value} />
                  ))}
                </el-select>
                <el-select value={this.tengineAddRow.path} on-input={(v: string) => { this.tengineAddRow = { ...this.tengineAddRow, path: v } }} style="flex:1" placeholder="选择响应页" filterable>
                  {this.availablePages.map(page => (
                    <el-option key={page.name} label={page.comment || page.name} value={page.name} />
                  ))}
                </el-select>
                <el-button type="primary" size="small" icon="el-icon-plus" on-click={this.addTenginePageItem}
                  disabled={!this.tengineAddRow.path}>添加</el-button>
              </div>
            </div>
            )}
          </div>
        </FieldEditDialog>
      </div>
    )
  }
}
