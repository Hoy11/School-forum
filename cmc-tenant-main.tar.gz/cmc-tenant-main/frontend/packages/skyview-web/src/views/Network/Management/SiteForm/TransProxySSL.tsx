// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { WAddr } from '@/types/website'

@Component
export default class TransProxySSL extends Vue {
  @Prop({ default: () => [] }) addrs!: WAddr[]
  @Prop({ default: false }) ntlmEnabled!: boolean

  get hasSsl() { return this.addrs.some(a => a.ssl) }

  handleSslToggle(ssl: boolean) {
    const updated = this.addrs.map(a => ({
      ...a,
      ssl,
      http2: ssl && a.http2,
      sni: !this.ntlmEnabled && ssl,
    }))
    this.$emit('input', updated)
  }

  handleHttp2Toggle(http2: boolean) {
    const updated = this.addrs.map(a => ({ ...a, http2: a.ssl && http2 }))
    this.$emit('input', updated)
  }

  handleSniToggle(sni: boolean) {
    const updated = this.addrs.map(a => ({ ...a, sni }))
    this.$emit('input', updated)
  }

  handleNonHttpToggle(nonHttp: boolean) {
    const updated = this.addrs.map(a => ({ ...a, non_http: nonHttp }))
    this.$emit('input', updated)
  }

  render(h: any) {
    const hasNonHttp = this.addrs.some(a => a.non_http)
    return (
      <div>
        <el-form-item label="SSL 配置">
          <div style="display:flex;gap:16px;flex-wrap:wrap">
            <el-checkbox value={this.hasSsl} on-input={this.handleSslToggle}>SSL</el-checkbox>
            {this.hasSsl && <el-checkbox value={this.addrs.some(a => a.http2)} on-input={this.handleHttp2Toggle}>HTTP2</el-checkbox>}
            {this.hasSsl && !this.ntlmEnabled && <el-checkbox value={this.addrs.some(a => a.sni)} on-input={this.handleSniToggle}>SNI</el-checkbox>}
            <el-checkbox value={hasNonHttp} on-input={this.handleNonHttpToggle}>TCP 流量转发</el-checkbox>
          </div>
        </el-form-item>
        {hasNonHttp && (
          <el-alert title="开启 TCP 流量转发后，雷池将直接转发非 HTTP 流量及无 SNI 的 HTTPS 流量。" type="error" show-icon closable={false} style="margin-bottom:12px" />
        )}
        {this.hasSsl && this.addrs.some(a => a.http2) && (
          <el-alert title="启用 HTTP2 后，WAF 与客户端使用 http 2.0 协议建立连接，请确保后端业务服务器支持 HTTP2。" type="warning" show-icon closable={false} style="margin-bottom:12px" />
        )}
      </div>
    )
  }
}
