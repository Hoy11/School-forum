// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { WebsitePort } from '@/types/website'
import { getDefaultPort } from '@/utils/site'

@Component
export default class SimplePortField extends Vue {
  @Prop({ default: () => [getDefaultPort()] }) value!: WebsitePort[]

  addPort() {
    this.$emit('input', [...this.value, getDefaultPort()])
  }

  removePort(i: number) {
    if (this.value.length <= 1) return
    this.$emit('input', this.value.filter((_, idx) => idx !== i))
  }

  updatePort(i: number, v: string) {
    const updated = this.value.map((p, idx) =>
      idx !== i ? p : { ...p, port: parseInt(v) || 0 }
    )
    this.$emit('input', updated)
  }

  render(h: any) {
    return (
      <el-form-item label="端口" required>
        {this.value.map((port, i) => (
          <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px">
            <el-input value={port.port} on-input={(v: string) => this.updatePort(i, v)}
              placeholder="端口" style="width:120px" />
            {this.value.length > 1 && (
              <el-button type="text" icon="el-icon-delete" on-click={() => this.removePort(i)} />
            )}
          </div>
        ))}
        <el-button type="text" icon="el-icon-plus" on-click={this.addPort}>添加端口</el-button>
      </el-form-item>
    )
  }
}
