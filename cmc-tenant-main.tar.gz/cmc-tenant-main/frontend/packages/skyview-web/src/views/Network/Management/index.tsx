// @ts-nocheck
import { Component, Vue, Mixins, Watch } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import ConditionFilter from '@/components/ConditionFilter'
import { siteList, siteDelete, siteBatchDelete, siteDetail, siteUpdate, siteCertList, sitePolicyList } from '@/api/captain-site'
import { ColumnDef } from '@/components/Grid'
import { Condition, FilterFieldOption, PageResult } from '@/types/common'
import { Website, SSLCertModel, PolicyModel } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { prepareWTransProxySiteForSubmit } from '@/utils/site'
import { WafSelectorMixin } from '@/mixins/wafSelector'
import { filterSites } from './siteFilter'
import SiteForm from './SiteForm'
import {
  getSiteColumns, ColumnContext,
  ALL_COLUMN_KEYS, ColumnKey, DEFAULT_COLUMN_KEYS,
  COLUMN_LABELS, MIN_COLUMNS, MAX_COLUMNS, STORAGE_KEY,
} from './columns'

@Component({ components: { Grid, SiteForm, ConditionFilter } })
export default class SiteManagement extends Mixins(WafSelectorMixin) {
  get wafId(): number { return this.effectiveWafId }
  get operationMode(): string {
    const selected = this.wafOptions.find(w => w.captain_instance_id === this.wafId)
    return selected?.operation_mode || ''
  }

  auxDataPromise: Promise<void> | null = null

  @Watch('wafReady')
  onWafReady() {
    if (this.wafReady) {
      this.loadAuxData()
      this.$nextTick(() => this.checkEditQuery())
    }
  }

  async checkEditQuery() {
    const editId = Number(this.$route.query.editSiteId || 0)
    const waf = Number(this.$route.query.waf || 0)
    if (editId && waf) {
      const resp = await siteDetail(editId, waf)
      if (resp.err === null) { this.editingItem = resp.data; this.showForm = true }
      this.$router.replace({ name: 'siteManagement' }).catch(() => {})
    }
  }

  showForm = false
  editingItem: Website | null = null
  filterConditions: Condition[] = []
  allSites: Website[] = []
  selectedRows: Website[] = []
  certOptions: { value: number; label: string }[] = []
  policyOptions: PolicyModel[] = []
  selectedColumnKeys: ColumnKey[] = []

  created() {
    this.restoreColumnSelection()
  }

  restoreColumnSelection() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]')
      const valid = saved.filter((k: string) => (ALL_COLUMN_KEYS as readonly string[]).includes(k))
      this.selectedColumnKeys = valid.length >= MIN_COLUMNS ? valid : [...DEFAULT_COLUMN_KEYS]
    } catch {
      this.selectedColumnKeys = [...DEFAULT_COLUMN_KEYS]
    }
  }

  saveColumnSelection() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(this.selectedColumnKeys))
  }

  isColumnDisabled(key: ColumnKey): boolean {
    const len = this.selectedColumnKeys.length
    if (this.selectedColumnKeys.includes(key)) return len <= MIN_COLUMNS
    return len >= MAX_COLUMNS
  }

  handleColumnChange(keys: ColumnKey[]) {
    this.selectedColumnKeys = keys
    this.saveColumnSelection()
  }

  get filterFields(): FilterFieldOption[] {
    return [
      { label: '名称', value: 'name', type: 'text', operators: [{ label: '等于', value: '=' }] },
      { label: '站点域名', value: 'server_names', type: 'text', operators: [{ label: '等于', value: '=' }] },
      { label: '生效地址', value: 'url_paths', type: 'text', operators: [{ label: '等于', value: '=' }] },
      { label: '防篡改状态', value: 'anti_tamper_status', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '正常', value: 'normal' },
        { label: '异常', value: 'abnormal' },
        { label: '未启用', value: 'not_enabled' },
      ]},
      { label: '响应方式', value: 'backend_type', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '反向代理', value: 'proxy' },
        { label: '重定向', value: 'redirect' },
        { label: '自定义响应', value: 'response' },
      ]},
      { label: '证书名称', value: 'ssl_cert', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '默认', value: '0' },
        ...this.certOptions.map(c => ({ label: c.label, value: String(c.value) })),
      ]},
      { label: '站点状态', value: 'is_enabled', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '启用', value: 'enabled' },
        { label: '禁用', value: 'disabled' },
      ]},
      { label: '防护策略名称', value: 'policy_group', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '不使用防护策略', value: '0' },
        ...this.policyOptions.map(p => ({ label: p.name, value: String(p.id) })),
      ]},
      { label: '监听端口', value: 'ports', type: 'text', operators: [{ label: '等于', value: '=' }] },
      { label: '业务服务器地址', value: 'servers', type: 'text', operators: [
        { label: '包含', value: 'like' },
        { label: '不包含', value: 'not like' },
      ]},
      { label: '备注', value: 'remark', type: 'text', operators: [
        { label: '包含', value: 'like' },
        { label: '不包含', value: 'not like' },
      ]},
      { label: '站点类型', value: 'ntlm_enabled', type: 'choice', operators: [
        { label: '等于', value: '=' },
        { label: '不等于', value: '!=' },
      ], choices: [
        { label: '普通站点', value: 'false' },
        { label: 'NTLM 站点', value: 'true' },
      ]},
      { label: '创建时间', value: 'create_time', type: 'time_range' },
      { label: '最后修改时间', value: 'last_update_time', type: 'time_range' },
    ]
  }

  get columns(): ColumnDef[] {
    return getSiteColumns(
      { certOptions: this.certOptions, policyOptions: this.policyOptions },
      this.selectedColumnKeys,
    )
  }

  get actionColumn(): ColumnDef {
    return {
      key: 'actions', title: '操作', width: 200,
      render: (h: any, row: Website) => (
        <span>
          <el-button type="text" on-click={() => this.handleDetail(row)}>详情</el-button>
          {row.is_enabled
            ? <el-button type="text" on-click={() => this.handleToggleEnable(row)}>禁用</el-button>
            : <el-button type="text" style="color: #67C23A" on-click={() => this.handleToggleEnable(row)}>启用</el-button>
          }
          <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>删除</el-button>
        </span>
      )
    }
  }

  async fetchData(offset: number, count: number, conditions: Condition[]) {
    if (!this.wafId) return Promise.resolve({ err: null, msg: 'success', data: { total: 0, items: [] } })
    if (this.isWafUnavailable) return this.emptyWafPage()
    await this.auxDataPromise

    // 拉取全量站点（Captain API 不支持筛选）
    const resp = await siteList(this.wafId, 0, 99999, [])
    if (resp.err !== null) return resp as any
    this.allSites = resp.data?.items || []

    // 客户端筛选
    const filtered = filterSites(this.allSites, this.filterConditions)
    const total = filtered.length
    const start = Math.min(offset, total)
    const end = Math.min(offset + count, total)
    const items = filtered.slice(start, end)

    return { err: null, msg: 'success', data: { total, items } }
  }

  async handleWafChange() { this.showWafOfflineMessage(); await this.loadAuxData(); (this.$refs.grid as any)?.loadData() }

  handleSearch(conditions: Condition[]) {
    this.filterConditions = conditions
    this.$nextTick(() => {
      const grid = this.$refs.grid as any
      if (grid?.handleConditionsChange) grid.handleConditionsChange(conditions)
    })
  }

  async loadAuxData() {
    if (!this.wafId) { this.certOptions = []; this.policyOptions = []; return }
    if (this.isWafUnavailable) { this.certOptions = []; this.policyOptions = []; return }
    const p = Promise.all([
      siteCertList(this.wafId),
      sitePolicyList(this.wafId),
    ]).then(([certResp, policyResp]) => {
      if (certResp.err === null) {
        this.certOptions = (certResp.data || []).map((c: SSLCertModel) => ({
          value: c.id, label: c.name,
        }))
      }
      if (policyResp.err === null) {
        this.policyOptions = policyResp.data || []
      }
    })
    this.auxDataPromise = p
    await p
  }

  handleCreate() {
    if (!this.ensureWafOperable()) return
    this.editingItem = null
    this.showForm = true
  }

  handleDetail(row: Website) {
    this.$router.push({ name: 'siteDetail', query: { id: String(row.id), waf: String(this.wafId) } })
  }

  async handleToggleEnable(row: Website) {
    if (!this.ensureWafOperable()) return
    const action = row.is_enabled ? '禁用' : '启用'
    await this.$confirm(`确定${action}站点"${row.name}"吗？`, '提示', { type: 'warning' })
    try {
      const detailResp = await siteDetail(row.id, this.wafId)
      if (detailResp.err !== null) { this.$message.error(detailResp.msg || '获取站点详情失败'); return }
      const full: any = { ...detailResp.data, is_enabled: !row.is_enabled, captain_instance_id: this.wafId }
      if (full.policy_rules && Array.isArray(full.policy_rules)) {
        full.policy_rules = full.policy_rules.map((r: any) => typeof r === 'object' ? r.id : r)
      }
      const payload = full.operation_mode === WorkGroupOperationMode.HardwareTransparentProxy
        ? prepareWTransProxySiteForSubmit(full, full.addrs || [])
        : full
      const resp = await siteUpdate({ ...payload, id: row.id, captain_instance_id: this.wafId })
      if (resp.err !== null) { this.$message.error(resp.msg || '操作失败'); return }
      this.$message.success(`已${action}`)
      ;(this.$refs.grid as any)?.loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    }
  }

  async handleDelete(row: Website) {
    if (!this.ensureWafOperable()) return
    await this.$confirm('确定删除该站点？', '提示', { type: 'warning' })
    try {
      await siteDelete(row.id, this.wafId)
      ;(this.$refs.grid as any)?.loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '删除失败')
    }
  }

  handleSelectionChange(rows: Website[]) { this.selectedRows = rows }

  async handleBatchDelete() {
    if (!this.selectedRows.length) return
    if (!this.ensureWafOperable()) return
    await this.$confirm(`确定删除选中的 ${this.selectedRows.length} 个站点？`, '提示', { type: 'warning' })
    try {
      await siteBatchDelete(this.selectedRows.map(r => r.id), this.wafId)
      this.selectedRows = []
      ;(this.$refs.grid as any)?.loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '删除失败')
    }
  }

  handleFormSuccess() { this.showForm = false; (this.$refs.grid as any)?.loadData() }

  render(h: any) {
    return (
      <div>
        <div style="margin-bottom: 16px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap">
          <el-select v-model={this.selectedWafId} placeholder="选择 WAF 实例"
            on-change={this.handleWafChange} disabled={!this.wafReady} style="width: 280px">
            {this.wafOptions.map(w => <el-option key={w.id}
              label={this.formatWafOptionLabel(w)} value={w.captain_instance_id} />)}
          </el-select>
          <ConditionFilter
            conditions={this.filterConditions}
            fields={this.filterFields}
            on-change={(c: Condition[]) => { this.filterConditions = c }}
            on-search={this.handleSearch}
          />
          <el-button type="primary" on-click={this.handleCreate} disabled={!this.wafId || this.isWafUnavailable}>新建站点</el-button>
          {this.selectedRows.length > 0 && (
            <el-button type="danger" plain on-click={this.handleBatchDelete} disabled={this.isWafUnavailable}>
              批量删除 ({this.selectedRows.length})
            </el-button>
          )}
          <div style="flex: 1" />
          <el-dropdown trigger="click" on-command={() => {}} hide-on-click={false}>
            <el-button icon="el-icon-setting">列设置</el-button>
            <el-dropdown-menu slot="dropdown">
              {ALL_COLUMN_KEYS.map(key => (
                <el-dropdown-item command={key} disabled={this.isColumnDisabled(key)}>
                  <el-checkbox
                    value={this.selectedColumnKeys.includes(key)}
                    on-change={(checked: boolean) => {
                      const keys = checked
                        ? [...this.selectedColumnKeys, key]
                        : this.selectedColumnKeys.filter(k => k !== key)
                      this.handleColumnChange(keys)
                    }}
                    disabled={this.isColumnDisabled(key)}
                  >
                    {COLUMN_LABELS[key]}
                  </el-checkbox>
                </el-dropdown-item>
              ))}
            </el-dropdown-menu>
          </el-dropdown>
        </div>
        {this.renderWafOfflineAlert(h)}
        <Grid ref="grid" columns={[...this.columns, this.actionColumn]}
          fetchData={this.fetchData} selectable defaultConditions={this.filterConditions}
          on-selection-change={this.handleSelectionChange} />
        <SiteForm visible={this.showForm} editingItem={this.editingItem}
          captainInstanceId={this.wafId} operationMode={this.operationMode}
          on-close={() => { this.showForm = false }}
          on-success={this.handleFormSuccess} />
      </div>
    )
  }
}
