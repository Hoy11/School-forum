// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { AssetGroupType } from '@/types/website'

@Component
export default class AssetGroupField extends Vue {
  @Prop({ default: 0 }) value!: number
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]

  render(h: any) {
    return (
      <el-form-item label="资产组">
        <el-select value={this.value} on-input={(v: number) => this.$emit('input', v)} style="width: 240px">
          {this.assetGroups.map(opt => (
            <el-option label={opt.name} value={opt.id || 0} />
          ))}
        </el-select>
      </el-form-item>
    )
  }
}
