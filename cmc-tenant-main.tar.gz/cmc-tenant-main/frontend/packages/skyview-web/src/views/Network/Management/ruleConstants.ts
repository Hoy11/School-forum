import { PolicyRule } from '@/types/policy'
import { Condition } from '@/types/common'

export const ACTION_MAP: Record<string, string> = {
  deny: '拦截',
  allow: '放行',
  dry_run: '观察',
  forward: '转发',
  modify_module: '模块',
  modify_skynet_rule: '内置',
}

export const ACTION_TAG_TYPE: Record<string, string> = {
  deny: 'danger',
  allow: 'success',
  dry_run: 'warning',
  forward: 'success',
  modify_module: '',
  modify_skynet_rule: 'info',
}

export const RISK_LEVEL_OPTIONS = [
  { label: '无威胁', value: 0 },
  { label: '低危', value: 1 },
  { label: '中危', value: 2 },
  { label: '高危', value: 3 },
  { label: '严重', value: 4 },
]

export const ATTACK_TYPE_OPTIONS = [
  { label: '非攻击', value: -1 },
  { label: 'SQL 注入', value: 0 },
  { label: 'XSS', value: 1 },
  { label: 'CSRF', value: 2 },
  { label: 'SSRF', value: 3 },
  { label: '拒绝服务', value: 4 },
  { label: '后门', value: 5 },
  { label: '反序列化', value: 6 },
  { label: '代码执行', value: 7 },
  { label: '代码注入', value: 8 },
  { label: '命令注入', value: 9 },
  { label: '文件上传', value: 10 },
  { label: '文件包含', value: 11 },
  { label: '重定向', value: 12 },
  { label: '权限不当', value: 13 },
  { label: '信息泄露', value: 14 },
  { label: '未授权访问', value: 15 },
  { label: '不安全的配置', value: 16 },
  { label: 'XXE', value: 17 },
  { label: 'XPath 注入', value: 18 },
  { label: 'LDAP 注入', value: 19 },
  { label: '目录穿越', value: 20 },
  { label: '扫描器', value: 21 },
  { label: '水平权限绕过', value: 22 },
  { label: '垂直权限绕过', value: 23 },
  { label: '文件修改', value: 24 },
  { label: '文件读取', value: 25 },
  { label: '文件删除', value: 26 },
  { label: '逻辑错误', value: 27 },
  { label: 'CRLF 注入', value: 28 },
  { label: '模板注入', value: 29 },
  { label: '点击劫持', value: 30 },
  { label: '缓冲区溢出', value: 31 },
  { label: '整数溢出', value: 32 },
  { label: '格式化字符串', value: 33 },
  { label: '条件竞争', value: 34 },
  { label: 'HTTP 协议违规', value: 35 },
  { label: 'HTTP 请求走私', value: 36 },
  { label: '超时', value: 61 },
  { label: '未知', value: 62 },
  { label: '威胁情报', value: 63 },
  { label: 'Cookie 篡改', value: 64 },
]

export const LOG_OPTION_OPTIONS = [
  { label: '记录并存储日志', value: 'Persistence' },
  { label: '记录但不存储日志', value: 'Non-Persistence' },
  { label: '不记录日志', value: 'Drop' },
]

export const LOG_OPTION_DESCRIPTIONS: Record<string, string> = {
  'Non-Persistence': '系统进行攻击/拦截等行为数量统计，但不生成存储相关日志；',
  'Persistence': '系统进行攻击/拦截等行为数量统计，生成并存储攻击检测日志，在日志界面可以查询筛选相关日志；',
  'Drop': '系统不进行攻击/拦截等行为数量统计，且不生成存储相关日志。',
}

export const LOG_OPTION_DESCRIPTION_STYLE = {
  backgroundColor: '#E6F7FF',
  border: '1px solid #91D5FF',
  borderRadius: '4px',
  padding: '0 10px',
  color: '#333',
  fontSize: '13px',
  lineHeight: '22px',
  marginTop: '8px',
}

export const DECODE_METHOD_OPTIONS = [
  { label: 'URL 解码', value: 'url_decode' },
  { label: 'Base64 解码', value: 'base64_decode' },
  { label: '十六进制转换', value: 'hex_transform' },
  { label: '二进制解码', value: 'binary_decode' },
  { label: '斜杠反转义', value: 'slash_unescape' },
]

// ServerControlledConfigAPI 返回的 key（新格式）→ pattern 中实际存储的值（旧格式）映射
// Captain API 存储和识别旧格式值，但配置 API 返回新格式 key
export const DECODE_METHOD_NEW_TO_OLD: Record<string, string> = {
  url: 'url_decode',
  base64: 'base64_decode',
  hex: 'hex_transform',
  binary: 'binary_decode',
  eval: 'slash_unescape',
}

// 将 decode_methods 数组中的新格式值转换为旧格式值（兼容已存储的新格式数据）
export function normalizeDecodeMethods(methods: string[]): string[] {
  return methods.map(m => DECODE_METHOD_NEW_TO_OLD[m] || m)
}

export const WEEKDAY_OPTIONS = [
  { label: '周一', value: 1 },
  { label: '周二', value: 2 },
  { label: '周三', value: 3 },
  { label: '周四', value: 4 },
  { label: '周五', value: 5 },
  { label: '周六', value: 6 },
  { label: '周日', value: 7 },
]

export const ACTION_TOOLTIP = '请求触发自定义规则的拦截、放行动作后，将不再继续进行自定义规则的匹配和引擎检测，进行放行或拦截。\n触发观察动作后，将继续进行自定义规则的匹配和引擎检测。\n触发检测模块控制动作后，将在后续引擎检测时对检测模块进行相应的动作。若触发多个对同一检测模块控制的动作，以最后一个触发的动作为准。'

export function formatTimestamp(ts: number): string {
  if (!ts) return '-'
  return new Date(ts * 1000).toLocaleString('zh-CN', { hour12: false })
}

export function formatDate(str: string | null): string {
  if (!str) return '永不过期'
  return new Date(str).toLocaleDateString('zh-CN')
}

export function buildSiteCondition(siteId: number): Condition {
  return { target: 'site_id', items: [{ oper: '=', value: siteId }] }
}

export function isSharedRule(row: PolicyRule): boolean {
  return (row.binding_count ?? 0) > 1
}

export function defaultRuleForm(siteId: number) {
  return {
    is_enabled: true,
    action: 'dry_run',
    comment: '',
    risk_level: 0,
    pattern: null,
    websites: siteId ? [siteId] : [],
    attack_type: null,
    log_option: 'Persistence',
    cron_config: { type: 'all' },
    expire_time: null,
    decode_before_detection: false,
    decode_methods: ['url_decode'],
    status_code: 403,
  }
}

export function applyDecodeMethods(pattern: any, methods: string[]): any {
  if (!pattern) return pattern

  // 处理 $AND 或 $OR 中的条件 items
  const applyToItems = (items: any[]): any[] => {
    const updated = items.map((item: any) => {
      // 嵌套子组（$AND/$OR inside $AND/$OR）递归处理
      if (item.$AND || item.$OR) {
        return applyDecodeMethods(item, methods)
      }
      if (item.decode_methods !== undefined) {
        return { ...item, decode_methods: methods }
      }
      return item
    })
    // 新建规则时 pattern items 不含 decode_methods，需要添加到第一个 item
    if (!updated.some((item: any) => item.decode_methods !== undefined) && updated.length > 0) {
      updated[0] = { ...updated[0], decode_methods: methods }
    }
    return updated
  }

  if (pattern.$AND) {
    return { ...pattern, $AND: applyToItems(pattern.$AND) }
  }
  if (pattern.$OR) {
    return { ...pattern, $OR: applyToItems(pattern.$OR) }
  }
  return pattern
}

export function formatCronConfig(form: any): any {
  const cc = form.cron_config
  if (!cc || cc.type === 'all') return { type: 'all' }
  if (cc.type === 'timing') {
    const range = cc.range || []
    const start_ts = range[0] ? Math.floor(new Date(range[0]).getTime() / 1000) : 0
    const end_ts = range[1] ? Math.floor(new Date(range[1]).getTime() / 1000) : 0
    return { type: 'time_range', start_timestamp: start_ts, end_timestamp: end_ts }
  }
  if (cc.type === 'period') {
    return { type: 'weekly', days: cc.weekdays || [], start: cc.start_time || '00:00', end: cc.end_time || '23:59' }
  }
  return cc
}

export function parseCronConfig(raw: any): any {
  if (!raw || raw.type === 'all') return { type: 'all' }
  if (raw.type === 'time_range') {
    const start = raw.start_timestamp ? new Date(raw.start_timestamp * 1000).toISOString() : null
    const end = raw.end_timestamp ? new Date(raw.end_timestamp * 1000).toISOString() : null
    return { type: 'timing', range: start && end ? [start, end] : [] }
  }
  if (raw.type === 'weekly') {
    return { type: 'period', weekdays: raw.days || [], start_time: raw.start || '00:00', end_time: raw.end || '23:59' }
  }
  // 兜底：兼容旧的 CMC 格式（timing/period）和未知格式
  if (raw.type === 'timing') return raw
  if (raw.type === 'period') return raw
  return raw
}
