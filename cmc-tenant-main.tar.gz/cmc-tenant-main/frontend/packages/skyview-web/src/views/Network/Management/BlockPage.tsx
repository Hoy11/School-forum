// @ts-nocheck
import { Component, Vue, Mixins, Watch } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { blockPageList, blockPageUpload, blockPageDelete, blockPageDownload } from '@/api/captain-block-page'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { BlockPageInfo } from '@/types/block-page'
import { WafSelectorMixin } from '@/mixins/wafSelector'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { isAdmin } from '@/permission'
import { format } from 'date-fns'

@Component({ components: { Grid } })
export default class BlockPage extends Mixins(WafSelectorMixin) {
  get wafId(): number { return this.effectiveWafId }

  @Watch('wafReady')
  onWafReady() { if (this.wafReady) this.$nextTick(() => (this.$refs.grid as any)?.loadData()) }

  handleWafChange() { this.showWafOfflineMessage(); (this.$refs.grid as any)?.loadData() }

  showUpload = false
  uploadForm = { comment: '' }
  uploadFile: File | null = null

  get uploadMaxSizeKB(): number {
    const selected = this.wafOptions.find(w => w.captain_instance_id === this.wafId)
    return selected?.operation_mode === WorkGroupOperationMode.HardwareTransparentBridging ? 10 : 128
  }

  clearUploadFiles() {
    const upload = this.$refs.bpUpload as any
    upload?.clearFiles?.()
  }

  openUploadDialog() {
    this.uploadForm = { comment: '' }
    this.uploadFile = null
    this.showUpload = true
    this.$nextTick(() => this.clearUploadFiles())
  }

  closeUploadDialog() {
    this.showUpload = false
    this.uploadFile = null
    this.clearUploadFiles()
  }

  formatTime(ts: string | number) {
    if (!ts) return '-'
    const numTs = typeof ts === 'string' ? parseInt(ts, 10) : ts
    if (isNaN(numTs)) return '-'
    return format(new Date(numTs * 1000), 'yyyy-MM-dd HH:mm:ss')
  }

  usageText(row: BlockPageInfo) {
    const count = row.policy_group_used_count || 0
    if (count > 0) return `在 ${count} 个防护策略中使用`
    return '未使用'
  }

  isInUse(row: BlockPageInfo): boolean {
    return (row.policy_group_used_count ?? 0) > 0
  }

  isShared(row: BlockPageInfo): boolean {
    return (row.binding_count ?? 0) > 1
  }

  isDeleteProtected(row: BlockPageInfo): boolean {
    return this.isInUse(row) || this.isShared(row)
  }

  deleteTooltip(row: BlockPageInfo): string {
    if (this.isInUse(row)) return `该拦截页面正在被 ${row.policy_group_used_count} 个防护策略使用，无法删除`
    if (this.isShared(row)) return '该拦截页面被多个租户组共享，无法删除'
    return '删除'
  }

  async adminConfirmDelete(row: BlockPageInfo): Promise<boolean> {
    if (!isAdmin()) return true
    // Only called for non-shared cases (shared goes through token flow in handleDelete)
    try { await this.$confirm('此拦截页面已绑定给租户组，确认删除？', '提示', { type: 'warning' }) } catch { return false }
    return true
  }

  handleProtectionError(e: any) {
    const errCode = e?.response?.data?.err
    const errMsg = e?.response?.data?.msg
    if (errCode === 'in_use') {
      this.$message.warning(errMsg || '该拦截页面正在被防护策略使用，无法删除')
    } else if (errCode === 'shared') {
      this.$message.warning(errMsg || '该拦截页面被多个租户组共享，无法删除')
    } else {
      this.$message.error(errMsg || '操作失败')
    }
  }

  columns: ColumnDef[] = [
    { key: 'comment', title: '文件名称', minWidth: 200, render: (h: any, row: BlockPageInfo) =>
      <span style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block">{row.comment || row.name}</span>
    },
    { key: 'usage', title: '使用情况', width: 220, render: (h: any, row: BlockPageInfo) => <span>{this.usageText(row)}</span> },
    { key: 'create_time', title: '创建时间', width: 180, render: (h: any, row: BlockPageInfo) => <span>{this.formatTime(row.create_time)}</span> },
  ]

  fetchData(offset: number, count: number, conditions: Condition[]) {
    if (!this.wafId) return Promise.resolve({ err: null, msg: 'success', data: { total: 0, items: [] } })
    if (this.isWafUnavailable) return this.emptyWafPage()
    return blockPageList(this.wafId, offset, count, conditions)
  }

  async handleUploadSubmit() {
    if (!this.ensureWafOperable()) return
    if (!this.uploadFile) {
      this.$message.warning('请选择拦截页面文件')
      return
    }
    const fd = new FormData()
    fd.append('file', this.uploadFile)
    const selected = this.wafOptions.find(w => w.captain_instance_id === this.wafId)
    if (selected?.operation_mode) {
      fd.append('operation_mode', selected.operation_mode)
    }
    if (this.uploadForm.comment) {
      fd.append('comment', this.uploadForm.comment)
    }
    try {
      await blockPageUpload(this.wafId, fd)
      this.$message.success('上传成功')
      this.closeUploadDialog()
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.$message.error(e?.response?.data?.msg || e?.message || '上传失败')
    }
  }

  async handleDelete(row: BlockPageInfo) {
    if (!this.ensureWafOperable()) return
    const adm = isAdmin()

    if (adm) {
      // Shared BP (not in_use): two-step token flow enforced by backend
      if (this.isShared(row) && !this.isInUse(row)) {
        // Step 1: probe delete — backend returns err=shared + confirm_token
        let confirmToken = ''
        let sharedGroupNames: string[] = row.shared_group_names || []
        try {
          await blockPageDelete(row.name, this.wafId)
          // Backend accepted immediately (stale list data), refresh
          this.$message.success('删除成功')
          ;(this.$refs.grid as any).loadData()
          return
        } catch (e: any) {
          if (e?.response?.data?.err === 'shared') {
            confirmToken = e.response.data.confirm_token || ''
            sharedGroupNames = e.response.data.shared_group_names || sharedGroupNames
          } else {
            this.handleProtectionError(e)
            return
          }
        }
        if (!confirmToken) {
          this.$message.error('操作失败，请重试')
          return
        }
        // Step 2: show confirm dialog with fresh shared_group_names from backend
        const total = row.binding_count ?? sharedGroupNames.length
        const nameStr = total > sharedGroupNames.length
          ? `${total} 个租户组`
          : (sharedGroupNames.length > 0 ? sharedGroupNames.join('、') : '多个租户组')
        try {
          await this.$confirm(`该拦截页面被 ${nameStr} 共享，确认删除？`, '提示', { type: 'warning' })
        } catch { return }
        // Step 3: retry with confirm_token
        try {
          await blockPageDelete(row.name, this.wafId, confirmToken)
          this.$message.success('删除成功')
          ;(this.$refs.grid as any).loadData()
        } catch (e: any) {
          this.handleProtectionError(e)
        }
        return
      }

      // Not shared or in_use: show generic confirm then delete
      const proceed = await this.adminConfirmDelete(row)
      if (!proceed) return
    } else {
      if (this.isDeleteProtected(row)) {
        this.$message.warning(this.deleteTooltip(row))
        return
      }
      await this.$confirm('确定删除该拦截页面？', '提示', { type: 'warning' })
    }

    try {
      await blockPageDelete(row.name, this.wafId)
      this.$message.success('删除成功')
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.handleProtectionError(e)
    }
  }

  handleDownload(row: BlockPageInfo) {
    if (!this.ensureWafOperable()) return
    blockPageDownload(row.name, this.wafId)
  }

  render(h: any) {
    return (
      <div>
        <div style="margin-bottom: 16px; display: flex; align-items: center; gap: 16px">
          <el-select v-model={this.selectedWafId} placeholder="选择 WAF 实例" on-change={this.handleWafChange} disabled={!this.wafReady}>
            {this.wafOptions.map(w => <el-option key={w.captain_instance_id} label={this.formatWafOptionLabel(w)} value={w.captain_instance_id} />)}
          </el-select>
          <el-button type="primary" on-click={() => { if (!this.ensureWafOperable()) return; this.openUploadDialog() }} disabled={!this.wafId || this.isWafUnavailable}>添加拦截页面</el-button>
        </div>
        {this.renderWafOfflineAlert(h)}
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 120, render: (h: any, row: BlockPageInfo) => {
          const adm = isAdmin()
          const inUseBlocked = adm && this.isInUse(row)
          const deleteProtected = !adm && this.isDeleteProtected(row)
          const delTooltip = this.deleteTooltip(row)
          const disabled = deleteProtected || inUseBlocked
          return (
            <span>
              <el-tooltip content={delTooltip} placement="top" disabled={!disabled}>
                <el-button size="mini" icon="el-icon-delete"
                  style={`width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;color:${disabled ? '#ccc' : '#666'}`}
                  nativeOn-click={() => {
                    if (inUseBlocked) {
                      this.$message.warning(`该拦截页面正在被 ${row.policy_group_used_count} 个防护策略使用，无法删除`)
                    } else if (deleteProtected) {
                      this.$message.warning(delTooltip)
                    } else {
                      this.handleDelete(row)
                    }
                  }} />
              </el-tooltip>
              <el-tooltip content="下载" placement="top">
                <el-button size="mini" icon="el-icon-download"
                  style="width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;color:#666;margin-left:8px"
                  nativeOn-click={() => this.handleDownload(row)} />
              </el-tooltip>
            </span>
          )
        }}]} fetchData={this.fetchData} />

        <el-dialog title="添加拦截页面" visible={this.showUpload} on-close={this.closeUploadDialog} width="520px">
          <el-form label-width="140px">
            <el-form-item label="拦截页面名称"><el-input v-model={this.uploadForm.comment} placeholder="请输入拦截页面名称（选填）" /></el-form-item>
            <el-form-item label="拦截页面" required>
              <el-upload {...{ props: { onChange: (f: any) => {
                if (f.raw && f.raw.size > this.uploadMaxSizeKB * 1024) {
                  this.$message.error(`自定义拦截页面最大为 ${this.uploadMaxSizeKB} KB`)
                  this.uploadFile = null
                  ;(this.$refs.bpUpload as any)?.clearFiles()
                  return
                }
                this.uploadFile = f.raw
              }, onRemove: () => { this.uploadFile = null } } }} drag action="" auto-upload={false} limit={1} ref="bpUpload">
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将拦截页面拖到此处，或<em>点击上传</em></div>
              </el-upload>
            </el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={this.closeUploadDialog}>取消</el-button>
            <el-button type="primary" on-click={this.handleUploadSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
