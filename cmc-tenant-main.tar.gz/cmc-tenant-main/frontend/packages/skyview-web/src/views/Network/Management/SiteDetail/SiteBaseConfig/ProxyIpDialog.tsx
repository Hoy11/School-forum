// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { AssetGroupType } from '@/types/website'
import { ipGroupList } from '@/api/captain-ip-group'
import AddrsField from '../../SiteForm/AddrsField'

interface ProxyIpValue {
  proxy_ip_list: string[]
  proxy_ip_groups: number[]
}

interface IpGroupOption {
  id: number
  name: string
}

@Component({ components: { AddrsField } })
export default class ProxyIpDialog extends Vue {
  @Prop() value!: ProxyIpValue
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]

  ipGroupOptions: IpGroupOption[] = []

  async mounted() {
    if (!this.captainInstanceId) return
    try {
      const resp = await ipGroupList(this.captainInstanceId, 0, 500)
      if (resp.err === null) this.ipGroupOptions = (resp.data?.items || []).map((g: any) => ({ id: g.id, name: g.name }))
    } catch { /* ignore */ }
  }

  handleIpInput(ips: string[]) {
    this.$emit('input', { ...this.value, proxy_ip_list: ips })
  }

  handleGroupInput(groups: number[]) {
    this.$emit('input', { ...this.value, proxy_ip_groups: groups })
  }

  render(h: any) {
    const v = this.value || { proxy_ip_list: [], proxy_ip_groups: [] }
    return (
      <div>
        <div style="margin-bottom:16px">
          <div style="margin-bottom:8px;font-weight:500">回源 IP 列表</div>
          <AddrsField value={v.proxy_ip_list} on-input={this.handleIpInput} bare />
        </div>
        <div>
          <div style="margin-bottom:8px;font-weight:500">IP 组</div>
          <el-select value={v.proxy_ip_groups} on-input={this.handleGroupInput} multiple style="width:100%" placeholder="选择 IP 组">
            {this.ipGroupOptions.map(g => <el-option key={g.id} label={g.name} value={g.id} />)}
          </el-select>
        </div>
      </div>
    )
  }
}
