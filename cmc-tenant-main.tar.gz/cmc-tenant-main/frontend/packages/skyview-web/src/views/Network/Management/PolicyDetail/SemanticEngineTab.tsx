// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { PolicyModel, ModuleDetectionConfig, MODULE_ORDER } from '@/types/policy'
import EngineModuleCard from './EngineModuleCard'
import FieldEditDialog from '@/components/FieldEditDialog'

type RiskLevel = 'high' | 'medium' | 'low' | 'none'
const RISK_ORDER: RiskLevel[] = ['high', 'medium', 'low']
const BLOCKING_THRESHOLD_OPTIONS = [
  { value: 'high', label: '仅拦截高危' },
  { value: 'medium', label: '拦截高/中危' },
  { value: 'low', label: '拦截全部' },
  { value: 'none', label: '仅观察' },
]
const LOGGING_THRESHOLD_OPTIONS = [
  { value: 'high', label: '高危' },
  { value: 'medium', label: '中危' },
  { value: 'low', label: '低危' },
  { value: 'none', label: '不记录' },
]
const BLOCKING_ACTION_MAP: Record<string, { high: string; medium: string; low: string }> = {
  none: { high: 'continue', medium: 'continue', low: 'continue' },
  high: { high: 'deny', medium: 'continue', low: 'continue' },
  medium: { high: 'deny', medium: 'deny', low: 'continue' },
  low: { high: 'deny', medium: 'deny', low: 'deny' },
}
const LOGGING_MAP: Record<string, { high: number; medium: number; low: number }> = {
  none: { high: 0, medium: 0, low: 0 },
  high: { high: 1, medium: 0, low: 0 },
  medium: { high: 1, medium: 1, low: 0 },
  low: { high: 1, medium: 1, low: 1 },
}

const DEFAULT_MODULE_CONFIG: ModuleDetectionConfig = {
  state: 'disabled',
  detect_config: {},
  high_risk_action: 'deny',
  medium_risk_action: 'continue',
  low_risk_action: 'continue',
  high_risk_enable_log: 1,
  medium_risk_enable_log: 0,
  low_risk_enable_log: 0,
}

@Component({ components: { EngineModuleCard, FieldEditDialog } })
export default class SemanticEngineTab extends Vue {
  @Prop({ required: true }) policy!: PolicyModel
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: false }) isEditProtected!: boolean
  @Prop({ default: '' }) editTooltip!: string

  dialogVisible = false
  editModulesState = true
  editBlockingThreshold: RiskLevel = 'high'
  editLoggingThreshold: RiskLevel = 'high'

  get orderedModules(): string[] {
    return MODULE_ORDER
  }

  get enabled(): boolean {
    if (!this.policy) return false
    if (this.policy.modules_state === false) return false
    const bmc = this.policy.base_modules_detection_config
    if (bmc && bmc.state === 'disabled') return false
    return true
  }

  get statusText(): string {
    return this.enabled ? '已启用' : '已禁用'
  }

  get globalBlockingThreshold(): RiskLevel {
    const bmc = this.policy.base_modules_detection_config
    if (!bmc) return 'high'
    if (bmc.high_risk_action === 'continue') return 'none'
    if (bmc.low_risk_action === 'deny') return 'low'
    if (bmc.medium_risk_action === 'deny') return 'medium'
    return 'high'
  }

  get globalLoggingThreshold(): RiskLevel {
    const bmc = this.policy.base_modules_detection_config
    if (!bmc) return 'high'
    if (bmc.high_risk_enable_log === 0) return 'none'
    if (bmc.low_risk_enable_log === 1) return 'low'
    if (bmc.medium_risk_enable_log === 1) return 'medium'
    return 'high'
  }

  getModuleConfig(key: string): ModuleDetectionConfig {
    return this.policy.modules_detection_config?.[key] || { ...DEFAULT_MODULE_CONFIG }
  }

  applyThresholdToAllModules(enabled: boolean, blockingThreshold: RiskLevel, loggingThreshold: RiskLevel): Record<string, ModuleDetectionConfig> {
    const newConfig: Record<string, ModuleDetectionConfig> = { ...this.policy.modules_detection_config }
    const bActions = BLOCKING_ACTION_MAP[blockingThreshold] || BLOCKING_ACTION_MAP.high
    const lLogs = LOGGING_MAP[loggingThreshold] || LOGGING_MAP.high

    for (const key of MODULE_ORDER) {
      const existing = newConfig[key] || { ...DEFAULT_MODULE_CONFIG }
      const updated = { ...existing }
      updated.state = enabled ? 'enabled' : 'disabled'
      updated.high_risk_action = bActions.high
      updated.medium_risk_action = bActions.medium
      updated.low_risk_action = bActions.low
      updated.high_risk_enable_log = lLogs.high
      updated.medium_risk_enable_log = lLogs.medium
      updated.low_risk_enable_log = lLogs.low
      newConfig[key] = updated
    }
    return newConfig
  }

  openDialog() {
    this.editModulesState = this.enabled
    this.editBlockingThreshold = this.globalBlockingThreshold
    this.editLoggingThreshold = this.globalLoggingThreshold
    this.dialogVisible = true
  }

  handleDialogClose() {
    this.dialogVisible = false
  }

  async handleDialogSubmit() {
    const newState = this.editModulesState
    const modeText = newState ? '启用防护' : '禁用防护'

    if (newState !== this.enabled) {
      try {
        await this.$confirm(
          `确认要修改防护模式为「${modeText}」吗？`,
          '切换防护模式',
          { confirmButtonText: '确定', cancelButtonText: '取消', type: 'warning' }
        )
      } catch {
        return
      }
    }

    const newModulesConfig = this.applyThresholdToAllModules(newState, this.editBlockingThreshold, this.editLoggingThreshold)
    const bActions = BLOCKING_ACTION_MAP[this.editBlockingThreshold] || BLOCKING_ACTION_MAP.high
    const lLogs = LOGGING_MAP[this.editLoggingThreshold] || LOGGING_MAP.high
    const newBaseConfig = {
      ...(this.policy.base_modules_detection_config || {}),
      state: newState ? 'enabled' : 'disabled',
      is_enable: newState,
      high_risk_action: bActions.high,
      medium_risk_action: bActions.medium,
      low_risk_action: bActions.low,
      high_risk_enable_log: lLogs.high,
      medium_risk_enable_log: lLogs.medium,
      low_risk_enable_log: lLogs.low,
    }

    this.$emit('update', {
      modules_state: newState,
      modules_detection_config: newModulesConfig,
      base_modules_detection_config: newBaseConfig,
    })
    this.$message.success('更新防护策略成功，新防护策略会在 10 秒内生效，请耐心等待')
    this.dialogVisible = false
  }

  handleModuleUpdate(moduleKey: string, updatedConfig: ModuleDetectionConfig) {
    const newModulesConfig = {
      ...this.policy.modules_detection_config,
      [moduleKey]: updatedConfig,
    }
    this.$emit('update', { modules_detection_config: newModulesConfig })
  }

  render(h: any) {
    return (
      <div>
        <div style={{
          background: '#fff',
          border: '1px solid #ebeef5',
          borderRadius: '4px',
          marginBottom: '16px',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            padding: '12px 16px',
            borderBottom: '1px solid #ebeef5',
          }}>
            <span style="font-size:14px;font-weight:500;color:#303133;flex:1">攻击检测模块</span>
            <el-tag
              size="small"
              type={this.enabled ? 'success' : 'info'}
              style="margin-right:12px"
            >
              {this.statusText}
            </el-tag>
            <el-tooltip content={this.editTooltip} placement="top" disabled={!this.isEditProtected}>
              <el-button type="text" icon="el-icon-edit" style={this.isEditProtected ? 'flex-shrink:0;padding:4px;color:#ccc' : 'flex-shrink:0;padding:4px'}
                on-click={() => this.isEditProtected ? this.$message.warning(this.editTooltip) : this.openDialog()} />
            </el-tooltip>
          </div>
          <div style="padding:12px 16px;color:#909399;font-size:13px">
            此配置将对所有引擎模块生效。如需对攻击检测模块进行详细配置，请点击对应模块进行编辑。
          </div>
        </div>

        {this.orderedModules.map(key => (
          <EngineModuleCard
            key={key}
            moduleKey={key}
            config={this.getModuleConfig(key)}
            masterEnabled={this.enabled}
            isEditProtected={this.isEditProtected}
            editTooltip={this.editTooltip}
            on-update={(cfg: ModuleDetectionConfig) => this.handleModuleUpdate(key, cfg)}
          />
        ))}

        <FieldEditDialog
          visible={this.dialogVisible}
          title="编辑 攻击检测模块"
          on-close={this.handleDialogClose}
          on-submit={this.handleDialogSubmit}
          width="560px"
        >
          <el-form label-width="140px" size="small">
            <el-form-item label="是否启用">
              <el-switch value={this.editModulesState} on-change={(v: boolean) => { this.editModulesState = v }} />
            </el-form-item>
            <el-form-item label="阻断阈值">
              <div>
                <el-slider
                  value={BLOCKING_THRESHOLD_OPTIONS.findIndex(o => o.value === this.editBlockingThreshold)}
                  min={0} max={3} step={1} show-stops
                  format-tooltip={(idx: number) => BLOCKING_THRESHOLD_OPTIONS[idx]?.label || ''}
                  on-input={(idx: number) => { this.editBlockingThreshold = BLOCKING_THRESHOLD_OPTIONS[idx].value as RiskLevel }}
                  style="width:260px"
                />
                <div style="display:flex;justify-content:space-between;width:260px;margin-top:-4px">
                  <span style="font-size:12px;color:#909399">仅拦截高危</span>
                  <span style="font-size:12px;color:#909399">拦截高/中危</span>
                  <span style="font-size:12px;color:#909399">拦截全部</span>
                  <span style="font-size:12px;color:#909399">仅观察</span>
                </div>
              </div>
            </el-form-item>
            <el-form-item label="记录日志阈值">
              <div>
                <el-slider
                  value={LOGGING_THRESHOLD_OPTIONS.findIndex(o => o.value === this.editLoggingThreshold)}
                  min={0} max={3} step={1} show-stops
                  format-tooltip={(idx: number) => LOGGING_THRESHOLD_OPTIONS[idx]?.label || ''}
                  on-input={(idx: number) => { this.editLoggingThreshold = LOGGING_THRESHOLD_OPTIONS[idx].value as RiskLevel }}
                  style="width:260px"
                />
                <div style="display:flex;justify-content:space-between;width:260px;margin-top:-4px">
                  <span style="font-size:12px;color:#909399">高危</span>
                  <span style="font-size:12px;color:#909399">中危</span>
                  <span style="font-size:12px;color:#909399">低危</span>
                  <span style="font-size:12px;color:#909399">不记录</span>
                </div>
              </div>
            </el-form-item>
          </el-form>
        </FieldEditDialog>
      </div>
    )
  }
}
