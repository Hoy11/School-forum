// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { siteDetail, sitePolicyList, siteCertList, siteAssetGroupList, siteUpdate } from '@/api/captain-site'
import { Website, SSLCertModel, PolicyModel, AssetGroupType, WebsiteHealthyCheckStatus } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import SiteBasicInfoTab from './SiteBasicInfoTab'
import SiteBaseConfigTab from './SiteBaseConfigTab'
import SiteSemanticEngineTab from './SiteSemanticEngineTab'
import SiteCookieTab from './SiteCookieTab'
import SiteRuleTab from './SiteRuleTab'
import BasicInfoPanel from './SiteDetail/BasicInfoPanel'
import PolicyPanel from './SiteDetail/PolicyPanel'
import RulePanel from './SiteDetail/RulePanel'
import SessionPanel from './SiteDetail/SessionPanel'
import RequestProcessingPanel from './SiteDetail/RequestProcessingPanel'
import DeepDetectionPanel from './SiteDetail/DeepDetectionPanel'
import { prepareWTransProxySiteForSubmit } from '@/utils/site'

const REVERSE_PROXY_MODES = new Set([
  WorkGroupOperationMode.SoftwareReverseProxy,
  WorkGroupOperationMode.HardwareReverseProxy,
  WorkGroupOperationMode.SoftwareClusterReverseProxy,
  WorkGroupOperationMode.HardwareRouterProxy,
])

@Component({ components: { SiteBasicInfoTab, SiteBaseConfigTab, SiteSemanticEngineTab, SiteCookieTab, SiteRuleTab, BasicInfoPanel, PolicyPanel, RulePanel, SessionPanel, RequestProcessingPanel, DeepDetectionPanel } })
export default class SiteDetail extends Vue {
  site: Website | null = null
  policies: PolicyModel[] = []
  certs: SSLCertModel[] = []
  assetGroups: AssetGroupType[] = []
  loading = true
  activeTab = 'basic'

  get wafId(): number { return Number(this.$route.query.waf || 0) }
  get siteId(): number { return Number(this.$route.query.id || 0) }

  get isReverseProxy() {
    return REVERSE_PROXY_MODES.has(this.site?.operation_mode as WorkGroupOperationMode)
  }

  get statusTag(): { type: string; text: string } {
    if (!this.site) return { type: 'info', text: '-' }
    if (!this.site.is_enabled) return { type: 'info', text: '禁用' }
    switch (this.site.health_check_status) {
      case WebsiteHealthyCheckStatus.unhealthy: return { type: 'danger', text: '异常' }
      case WebsiteHealthyCheckStatus.unknown: return { type: 'warning', text: '未知' }
      default: return { type: 'success', text: '正常' }
    }
  }

  async created() {
    if (!this.wafId || !this.siteId) { this.loading = false; return }
    try {
      const [siteResp, policyResp, certResp, agResp] = await Promise.all([
        siteDetail(this.siteId, this.wafId),
        sitePolicyList(this.wafId).catch(() => ({ data: [] })),
        siteCertList(this.wafId).catch(() => ({ data: [] })),
        siteAssetGroupList(this.wafId).catch(() => ({ data: [] })),
      ])
      if (siteResp.err === null) this.site = siteResp.data
      if (policyResp.err === null) this.policies = policyResp.data || []
      if (certResp.err === null) this.certs = certResp.data || []
      if (agResp.err === null) this.assetGroups = agResp.data || []
    } finally {
      this.loading = false
    }
  }

  async handleToggleEnable() {
    if (!this.site) return
    const action = this.site.is_enabled ? '禁用' : '启用'
    await this.$confirm(`确定${action}站点"${this.site.name}"吗？`, '提示', { type: 'warning' })
    try {
      const full: any = { ...this.site, is_enabled: !this.site.is_enabled, captain_instance_id: this.wafId }
      if (full.policy_rules && Array.isArray(full.policy_rules)) {
        full.policy_rules = full.policy_rules.map((r: any) => typeof r === 'object' ? r.id : r)
      }
      const payload = full.operation_mode === WorkGroupOperationMode.HardwareTransparentProxy
        ? prepareWTransProxySiteForSubmit(full, full.addrs || [])
        : full
      const resp = await siteUpdate({ ...payload, id: this.site.id, captain_instance_id: this.wafId })
      if (resp.err !== null) { this.$message.error(resp.msg || '操作失败'); return }
      this.$message.success(`已${action}`)
      const detailResp = await siteDetail(this.siteId, this.wafId)
      if (detailResp.err === null) this.site = detailResp.data
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    }
  }

  async handleSiteUpdated(updatedSite: Website) {
    this.site = updatedSite
    const certResp = await siteCertList(this.wafId).catch(() => ({ err: 1, data: [] }))
    if (certResp.err === null) this.certs = certResp.data || []
  }

  renderHeader(h: any) {
    return (
      <el-page-header on-back={() => this.$router.push({ name: 'siteManagement' })}>
        <div slot="content" style="display:flex;align-items:center;gap:8px">
          <span>{this.site!.name}</span>
          <el-tag type={this.statusTag.type} size="small">{this.statusTag.text}</el-tag>
          <div style="margin-left:auto">
            <el-button size="small" type={this.site!.is_enabled ? 'warning' : 'success'} on-click={this.handleToggleEnable}>
              {this.site!.is_enabled ? '禁用' : '启用'}
            </el-button>
          </div>
        </div>
      </el-page-header>
    )
  }

  renderReverseProxy(h: any) {
    const s = this.site!
    return (
      <el-tabs v-model={this.activeTab} style="margin-top: 16px">
        <el-tab-pane label="基本信息" name="basic">
          <SiteBasicInfoTab site={s} certs={this.certs} captainInstanceId={this.wafId} on-updated={this.handleSiteUpdated} />
        </el-tab-pane>
        <el-tab-pane label="基础配置" name="baseConfig">
          <SiteBaseConfigTab site={s} captainInstanceId={this.wafId} assetGroups={this.assetGroups} on-updated={this.handleSiteUpdated} />
        </el-tab-pane>
        {!s.ntlm_enabled && <el-tab-pane label="语义引擎防护" name="semantic">
          <SiteSemanticEngineTab site={s} policies={this.policies} captainInstanceId={this.wafId} on-updated={this.handleSiteUpdated} />
        </el-tab-pane>}
        {!s.ntlm_enabled && <el-tab-pane label="Cookie 防护策略" name="cookie">
          <SiteCookieTab site={s} captainInstanceId={this.wafId} on-updated={this.handleSiteUpdated} />
        </el-tab-pane>}
        {!s.ntlm_enabled && <el-tab-pane label="自定义规则" name="rule">
          <SiteRuleTab site={s} captainInstanceId={this.wafId} />
        </el-tab-pane>}
      </el-tabs>
    )
  }

  renderPanelMode(h: any) {
    const s = this.site!
    return (
      <div style="margin-top:16px">
        <BasicInfoPanel site={s} certs={this.certs} mode={s.operation_mode} captainInstanceId={this.wafId} on-updated={this.handleSiteUpdated} />
        <RequestProcessingPanel site={s} mode={s.operation_mode} captainInstanceId={this.wafId} on-updated={this.handleSiteUpdated} />
        {s.policy_group && <DeepDetectionPanel site={s} captainInstanceId={this.wafId} on-updated={this.handleSiteUpdated} />}
        <PolicyPanel site={s} policies={this.policies} captainInstanceId={this.wafId} on-updated={this.handleSiteUpdated} />
        {s.policy_group && !s.ntlm_enabled && <RulePanel site={s} captainInstanceId={this.wafId} />}
        {s.policy_group && !s.ntlm_enabled && <SessionPanel site={s} captainInstanceId={this.wafId} mode={s.operation_mode} on-updated={this.handleSiteUpdated} />}
      </div>
    )
  }

  render(h: any) {
    if (this.loading) return <div v-loading style="min-height: 400px" />
    if (!this.site) return <div style="text-align:center;padding:60px;color:#909399">站点不存在</div>

    return (
      <div>
        {this.renderHeader(h)}
        {this.isReverseProxy ? this.renderReverseProxy(h) : this.renderPanelMode(h)}
      </div>
    )
  }
}
