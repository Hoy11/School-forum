// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { NodeStatus, SelectedTengine, SelectedTengineType } from '@/types/website'
import { selectedTengineTypeOptions } from '@/utils/site'

@Component
export default class StepListenerTengine extends Vue {
  @Prop() value!: SelectedTengine
  @Prop({ default: () => [] }) nodes!: NodeStatus[]
  @Prop({ default: false }) ntlmEnabled!: boolean

  regexpItems: string[] = this.value.type === SelectedTengineType.regexp
    ? (this.value.tengine_list || ['']) : ['']

  get label() {
    return this.ntlmEnabled ? '转发节点' : '检测节点'
  }

  get nodeOptions() {
    return this.nodes.map(n => ({ label: n.id, value: n.id }))
  }

  handleTypeChange(type: string) {
    let tengine_list: string[] | null = null
    if (type === SelectedTengineType.selected) tengine_list = []
    if (type === SelectedTengineType.regexp) { tengine_list = ['']; this.regexpItems = [''] }
    this.$emit('input', { type, tengine_list })
  }

  handleNodeSelect(selected: string[]) {
    this.$emit('input', { ...this.value, tengine_list: selected })
  }

  addRegexpItem() {
    this.regexpItems = [...this.regexpItems, '']
    this.$emit('input', { ...this.value, tengine_list: [...this.regexpItems] })
  }

  removeRegexpItem(i: number) {
    if (this.regexpItems.length <= 1) return
    this.regexpItems = this.regexpItems.filter((_, idx) => idx !== i)
    this.$emit('input', { ...this.value, tengine_list: [...this.regexpItems] })
  }

  updateRegexpItem(i: number, v: string) {
    this.regexpItems = this.regexpItems.map((item, idx) => idx === i ? v : item)
    this.$emit('input', { ...this.value, tengine_list: [...this.regexpItems] })
  }

  render(h: any) {
    return (
      <el-form-item label={this.label}>
        <el-radio-group value={this.value.type} on-input={this.handleTypeChange}>
          {selectedTengineTypeOptions.map(opt => (
            <el-radio label={opt.value}>{opt.label}</el-radio>
          ))}
        </el-radio-group>

        {this.value.type === SelectedTengineType.selected && (
          <div style="margin-top:8px">
            <el-select value={this.value.tengine_list || []} on-input={this.handleNodeSelect}
              multiple placeholder="选择节点" style="width:100%">
              {this.nodeOptions.map(opt => (
                <el-option label={opt.label} value={opt.value} />
              ))}
            </el-select>
            <el-alert title="选中站点未包含的虚拟 IP 无法监听" type="warning" show-icon closable={false} style="margin-top:8px" />
          </div>
        )}

        {this.value.type === SelectedTengineType.regexp && (
          <div style="margin-top:8px">
            {this.regexpItems.map((item, i) => (
              <div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
                <el-input value={item} on-input={(v: string) => this.updateRegexpItem(i, v)} placeholder="参数值" style="flex:1" />
                {this.regexpItems.length > 1 && (
                  <el-button type="text" icon="el-icon-delete" on-click={() => this.removeRegexpItem(i)} />
                )}
              </div>
            ))}
            <el-button type="text" icon="el-icon-plus" on-click={this.addRegexpItem}>添加一个参数值</el-button>
            <el-alert title="输入正则表达式，正则匹配结果取各参数值并集。请手动确认正则表达式包含预期选中节点，否则防护可能不生效。"
              type="warning" show-icon closable={false} style="margin-top:8px" />
          </div>
        )}
      </el-form-item>
    )
  }
}
