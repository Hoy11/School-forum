// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, AssetGroupType } from '@/types/website'
import ProxyModeCard from './SiteDetail/SiteBaseConfig/ProxyModeCard'
import SourceIpCard from './SiteDetail/SiteBaseConfig/SourceIpCard'
import SessionCard from './SiteDetail/SiteBaseConfig/SessionCard'

@Component({ components: { ProxyModeCard, SourceIpCard, SessionCard } })
export default class SiteBaseConfigTab extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: () => [] }) assetGroups!: AssetGroupType[]

  handleUpdated(site: Website) {
    this.$emit('updated', site)
  }

  render(h: any) {
    const s = this.site
    const cid = this.captainInstanceId
    return (
      <div>
        <ProxyModeCard site={s} captainInstanceId={cid} assetGroups={this.assetGroups} on-updated={this.handleUpdated} />
        {!s.ntlm_enabled && <SourceIpCard site={s} captainInstanceId={cid} on-updated={this.handleUpdated} />}
        {!s.ntlm_enabled && <SessionCard site={s} captainInstanceId={cid} mode={s.operation_mode} on-updated={this.handleUpdated} />}
      </div>
    )
  }
}
