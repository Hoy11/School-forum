// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, PolicyModel, BackendType } from '@/types/website'
import { canEditBusiness } from '@/permission'
import { createFieldUpdater } from './SiteDetail/useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'
import PolicyDetailWidget from './SiteDetail/PolicyDetailWidget'
import { RouteName } from '@/router/names'

@Component({ components: { EditableRow, PolicyDetailWidget } })
export default class SiteSemanticEngineTab extends Vue {
  @Prop() site!: Website
  @Prop({ default: () => [] }) policies!: PolicyModel[]
  @Prop({ default: 0 }) captainInstanceId!: number

  get canEdit() { return canEditBusiness() }
  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }

  get isProxy() { return this.site.backend_config?.type === BackendType.proxy }

  get policyName(): string {
    if (!this.site.policy_group) return '不使用防护策略'
    const p = this.policies.find(x => x.id === this.site.policy_group)
    return p ? p.name : `策略 #${this.site.policy_group}`
  }

  goToPolicyDetail() {
    if (!this.site.policy_group) return
    this.$router.push({
      name: RouteName.policyDetail,
      query: { id: String(this.site.policy_group), waf: String(this.captainInstanceId) },
    })
  }

  renderDeepDetection(h: any) {
    const s = this.site
    const enabled = s.deep_detection_config?.is_enabled
    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">深度检测</div>
        <EditableRow label="深度检测" editable={this.canEdit}
          value={String(enabled || false)}
          submitFn={(v) => this.updateField({ deep_detection_config: { ...this.site.deep_detection_config, is_enabled: v === 'true' } })}
          scopedSlots={{
            default: () => enabled
              ? <el-tag type="success" size="mini">启用</el-tag>
              : <el-tag type="info" size="mini">关闭</el-tag>,
            edit: ({ value, input }) => (
              <div>
                <el-switch value={value === 'true'} on-input={(v: boolean) => input(String(v))} active-text="启用深度检测模式" />
                <el-tooltip content="开启深度检测，会对请求进行全方位的攻击检测，检出并在攻击检测日志中展示请求包含的所有攻击检测信息，请求检测处理效率会略有下降。" placement="top">
                  <i class="el-icon-question" style="margin-left:4px;color:#909399;cursor:help" />
                </el-tooltip>
              </div>
            ),
          }} />
      </el-card>
    )
  }

  renderPolicySection(h: any) {
    const s = this.site
    return (
      <el-card>
        <div slot="header" style="font-weight:bold">攻击防护策略</div>

        <EditableRow label="防护策略" editable={this.canEdit && this.isProxy}
          value={String(s.policy_group || 0)}
          submitFn={(v) => this.updateField({ policy_group: v === '0' ? null : Number(v) })}
          scopedSlots={{
            default: () => s.policy_group
              ? <span style="color:#409EFF;cursor:pointer" on-click={this.goToPolicyDetail}>{this.policyName}</span>
              : <el-tag type="warning" size="mini">不使用防护策略</el-tag>,
            edit: ({ value, input }) => (
              <el-select value={value} on-input={input} style="width:100%">
                <el-option key={0} label="不使用防护策略" value="0" />
                {this.policies.map(p => <el-option key={p.id} label={p.name} value={String(p.id)} />)}
              </el-select>
            ),
          }} />

        {!this.isProxy && (
          <el-alert title="非转发模式下不可配置以下设置" type="info" show-icon closable={false} style="margin:8px 12px" />
        )}

        {!s.policy_group && (
          <el-alert title={'防护策略为"不使用防护策略"时，无法对站点进行防护且无法调整站点相关的防护配置'} type="warning" show-icon closable={false} style="margin:8px 12px" />
        )}

        {s.policy_group && (
          <PolicyDetailWidget policyId={s.policy_group} captainInstanceId={this.captainInstanceId} />
        )}
      </el-card>
    )
  }

  render(h: any) {
    return (
      <div>
        {this.site.policy_group && this.renderDeepDetection(h)}
        {this.renderPolicySection(h)}
      </div>
    )
  }
}
