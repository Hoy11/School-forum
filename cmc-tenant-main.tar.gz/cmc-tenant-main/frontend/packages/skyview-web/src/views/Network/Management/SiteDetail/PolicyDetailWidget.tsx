// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { PolicyGroup } from '@/types/policy'
import { policyDetail } from '@/api/captain-policy'

const MODULE_NAMES: Record<string, string> = {
  m_sqli: 'SQL 注入检测模块',
  m_xss: 'XSS 检测模块',
  m_cmd_injection: '命令注入检测模块',
  m_csrf: 'CSRF 检测模块',
  m_ssrf: 'SSRF 检测模块',
  m_ssti: '模板注入检测模块',
  m_php_unserialize: 'PHP 反序列化检测模块',
  m_java_unserialize: 'Java 反序列化检测模块',
  m_php_code_injection: 'PHP 代码注入检测模块',
  m_asp_code_injection: 'ASP 代码注入检测模块',
  m_java: 'Java 代码注入检测模块',
  m_file_upload: '文件上传攻击检测模块',
  m_file_include: '文件包含攻击检测模块',
  m_scanner: '机器人检测模块',
  m_response: '服务器响应检测模块',
  m_rule: '情报模块',
}

function moduleName(key: string): string {
  return MODULE_NAMES[key] || (key.startsWith('m_') ? key.slice(2).replace(/_/g, ' ') + '检测模块' : key)
}

const DECODE_NAMES: Record<string, string> = {
  'url decode': 'URL 解码',
  'JSON': 'JSON 解析',
  'base64': 'Base64 解码',
  'hex': '16进制转换',
  'eval': '斜杠反转义',
  'XML': 'XML 解析',
  'PHP deserialize': 'PHP 序列化对象解析',
  'utf7': 'UTF-7 解码',
}

function getRiskLevel(mod: any): number {
  const high = (mod?.high_risk_action === 'deny' && 1) || 0
  const medium = (mod?.medium_risk_action === 'deny' && 2) || 0
  const low = (mod?.low_risk_action === 'deny' && 3) || 0
  return Math.max(high, medium, low, 0)
}

const RISK_LABELS = ['不阻断', '仅阻断高危', '阻断中危及高危', '阻断全部']
function riskLabel(level: number): string { return RISK_LABELS[level] || '不阻断' }

// styles
const SEC = 'padding:10px 12px;border-bottom:1px solid #ebeef5'
const SEC_TITLE = 'font-size:13px;color:#909399;margin-bottom:6px'
const GRID2 = 'display:grid;grid-template-columns:1fr 1fr;gap:4px 24px;font-size:13px;color:#303133'
const KV = 'display:flex;gap:4px'
const KV_L = 'color:#909399;white-space:nowrap'
const FULL = 'padding:10px 12px;border-bottom:1px solid #ebeef5'
const FULL_T = 'font-size:13px;color:#909399;margin-bottom:6px'

@Component
export default class PolicyDetailWidget extends Vue {
  @Prop({ default: 0 }) policyId!: number
  @Prop({ default: 0 }) captainInstanceId!: number

  policy: PolicyGroup | null = null
  loading = false
  expanded = true

  async fetchPolicy() {
    if (!this.policyId || !this.captainInstanceId) return
    this.loading = true
    try {
      const resp = await policyDetail(this.policyId, this.captainInstanceId)
      if (resp.err === null) this.policy = resp.data
    } finally {
      this.loading = false
    }
  }

  created() { this.fetchPolicy() }

  @Watch('policyId')
  onPolicyIdChange() { this.fetchPolicy() }

  toggleExpand() { this.expanded = !this.expanded }

  // simple key-value pair cell
  kv(h: any, label: string, value: any) {
    return h('div', { style: KV }, [
      h('span', { style: KV_L }, [label, '：']),
      h('span', [value ?? '-']),
    ])
  }

  // full-width section with title
  section(h: any, title: string, content: any) {
    return h('div', { style: FULL }, [
      h('div', { style: FULL_T }, title),
      content,
    ])
  }

  // decode methods
  renderDecodeMethods(h: any) {
    const misc = this.policy?.misc_detection_config
    if (!misc) return null
    const dc = misc.decode_config
    if (!dc) return null
    const methods: string[] = dc.decode_methods || dc.state?.decode_methods || []
    const names = methods.map((m: string) => DECODE_NAMES[m] || m).filter(Boolean)
    if (!names.length) return null
    const tags = names.map(t =>
      h('el-tag', { props: { size: 'mini', effect: 'plain' }, style: 'margin:0 4px 2px 0' }, [t])
    )
    return this.section(h, '解码方式', h('div', tags))
  }

  // attack detection modules — two-column table
  renderDetectModules(h: any) {
    const mdc = this.policy?.modules_detection_config
    if (!mdc || !Object.keys(mdc).length) return null
    const entries = Object.entries(mdc).filter(([k, v]) => k !== 'm_rule' && v)
    if (!entries.length) return null
    const cells = entries.map(([key, mod]) => {
      const name = moduleName(key)
      const enabled = mod?.state === 'enabled'
      const label = enabled ? riskLabel(getRiskLevel(mod)) : '已禁用'
      return h('div', { key, style: 'display:flex;justify-content:space-between;padding:2px 0' }, [
        h('span', name),
        h('span', { style: 'color:#909399' }, label),
      ])
    })
    return this.section(h, '攻击检测模块', h('div', { style: GRID2 }, cells))
  }

  // simple fields — two-column grid
  renderSimpleFields(h: any) {
    const p = this.policy
    const items: any[] = []

    const add = (label: string, value: any) => { if (value !== undefined && value !== null) items.push(this.kv(h, label, value)) }

    // forbidden page
    const fc = p?.forbidden_page_config
    add('拦截方式', fc && fc.status_code ? `阻断时返回 ${fc.status_code}` : '未配置')

    // boolean fields
    add('HTTP 响应处理', p?.response_detection_state !== undefined ? (p.response_detection_state ? '已开启' : '已关闭') : undefined)
    add('检测超时限制', p?.is_timeout_enabled !== undefined ? (p.is_timeout_enabled ? '已开启' : '已关闭') : undefined)
    add('大包绕过防护', p?.max_file_size !== undefined ? (p.max_file_size ? '已开启' : '已关闭') : undefined)
    add('Payload 分析', p?.payload_explain_state !== undefined ? (p.payload_explain_state ? '已开启' : '已关闭') : undefined)

    // numeric fields
    add('请求 Body 检测', p?.request_detection_max_body_size !== undefined ? `${p.request_detection_max_body_size} KB` : undefined)
    add('Body 记录上限', p?.req_http_body_max_size !== undefined ? `${p.req_http_body_max_size} KB` : undefined)

    if (!items.length) return null
    return h('div', { style: SEC }, [
      h('div', { style: GRID2 }, items),
    ])
  }

  // misc modules (other than decode)
  renderMiscModules(h: any) {
    const misc = this.policy?.misc_detection_config
    if (!misc) return null
    const others = Object.entries(misc).filter(([k]) => k !== 'decode_config')
    if (!others.length) return null
    const cells = others.map(([key, val]) => {
      const en = val.state === true || val.state === ModuleStatus.enabled
      return h('div', { key, style: 'display:flex;justify-content:space-between;padding:2px 0' }, [
        h('span', key),
        h('span', { style: 'color:#909399' }, en ? '启用' : '关闭'),
      ])
    })
    return this.section(h, '其他模块', h('div', { style: GRID2 }, cells))
  }

  render(h: any) {
    if (!this.policyId) return null

    return h('div', { style: 'margin:8px 12px;border:1px solid #ebeef5;border-radius:4px;overflow:hidden' }, [
      this.loading
        ? h('div', { key: 'loading', style: 'min-height:60px;display:flex;align-items:center;justify-content:center;color:#909399;font-size:13px' }, [
            h('i', { class: 'el-icon-loading', style: 'margin-right:4px' }),
            '加载中...',
          ])
        : h('div', { key: 'content' }, [
            h('div', {
              style: 'display:flex;align-items:center;justify-content:space-between;padding:8px 12px;background:#fafafa;cursor:pointer',
              on: { click: this.toggleExpand },
            }, [
              h('span', { style: 'font-size:13px;color:#606266' }, '策略详情'),
              h('i', { class: this.expanded ? 'el-icon-arrow-up' : 'el-icon-arrow-down', style: 'color:#909399' }),
            ]),
            this.expanded && this.policy ? h('div', [
              this.renderDecodeMethods(h),
              this.renderDetectModules(h),
              this.renderSimpleFields(h),
              this.renderMiscModules(h),
            ]) : null,
          ]),
    ])
  }
}
