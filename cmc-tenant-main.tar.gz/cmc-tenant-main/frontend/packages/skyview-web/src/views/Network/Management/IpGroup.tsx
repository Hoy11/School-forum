// @ts-nocheck
import { Component, Vue, Mixins } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { ipGroupList, ipGroupCreate, ipGroupUpdate, ipGroupDelete, ipGroupItemAdd } from '@/api/captain-ip-group'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'
import { IPGroup } from '@/types/ip-group'
import { WafSelectorMixin } from '@/mixins/wafSelector'

@Component({ components: { Grid } })
export default class IpGroup extends Mixins(WafSelectorMixin) {
  get wafId(): number { return this.effectiveWafId }

  handleWafChange() { (this.$refs.grid as any)?.loadData() }

  showForm = false
  editingItem: IPGroup | null = null
  form = { name: '', comment: '' }
  ipTextarea = ''
  submitting = false

  isInUse(row: IPGroup): boolean { return (row.used_count ?? 0) > 0 }
  isShared(row: IPGroup): boolean { return (row.binding_count ?? 0) > 1 }
  isEditProtected(row: IPGroup): boolean { return this.isShared(row) || (row.has_external_ref ?? false) }
  isDeleteProtected(row: IPGroup): boolean { return this.isInUse(row) || this.isShared(row) }

  deleteTooltip(row: IPGroup): string {
    if (this.isInUse(row)) return `该IP组正在被 ${row.used_count} 个防护策略引用，无法删除`
    if (this.isShared(row)) return '该IP组被多个租户组共享，无法删除'
    return '删除'
  }

  editTooltip(row: IPGroup): string {
    if (this.isShared(row)) return '该IP组被多个租户组共享，无法修改'
    if (row.has_external_ref) return '该IP组被其他租户组的策略引用，无法修改'
    return '编辑'
  }

  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'name', title: '名称' },
    { key: 'original', title: '包含IP', render: (h: any, row: IPGroup) => {
      const ips = row.original || []
      if (ips.length === 0) return <span style="color: #909399">-</span>
      const display = ips.slice(0, 3).join(', ')
      const suffix = ips.length > 3 ? ` 等${ips.length}个` : ''
      return <el-tooltip content={ips.join('\n')} placement="top"><span>{display}{suffix}</span></el-tooltip>
    }},
    { key: 'comment', title: '备注', render: (h: any, row: IPGroup) => row.comment || <span style="color: #909399">-</span> },
      ]

  fetchData(offset: number, count: number, conditions: Condition[]) {
    if (!this.wafId) return Promise.resolve({ err: null, msg: 'success', data: { total: 0, items: [] } })
    if (this.isWafUnavailable) return this.emptyWafPage()
    return ipGroupList(this.wafId, offset, count, conditions)
  }

  handleCreate() {
    if (!this.ensureWafOperable()) return
    this.editingItem = null
    this.form = { name: '', comment: '' }
    this.ipTextarea = ''
    this.showForm = true
  }

  handleEdit(row: IPGroup) {
    if (!this.ensureWafOperable()) return
    this.editingItem = row
    this.form = { name: row.name, comment: row.comment }
    this.ipTextarea = (row.original || []).join('\n')
    this.showForm = true
  }

  async handleSubmit() {
    if (!this.ensureWafOperable()) return
    if (this.submitting) return
    this.submitting = true
    try {
      if (this.editingItem) {
        const id = this.editingItem.id
        const targetIps = this.ipTextarea.split('\n').map(s => s.trim()).filter(Boolean)
        const resp = await ipGroupUpdate({ id, name: this.form.name, comment: this.form.comment, original: targetIps, captain_instance_id: this.wafId })
        if (resp.err !== null) {
          if (resp.err === 'shared' || resp.err === 'has_external_ref') {
            this.$message.warning(resp.msg || '无法修改')
          } else {
            this.$message.error(resp.msg || '更新失败')
          }
          return
        }
      } else {
        const resp = await ipGroupCreate({ ...this.form, captain_instance_id: this.wafId })
        if (resp.err !== null) {
          this.$message.error(resp.msg || '创建失败')
          return
        }
        if (resp.data?.id) {
          const ips = this.ipTextarea.split('\n').map(s => s.trim()).filter(Boolean)
          if (ips.length > 0) {
            const addResp = await ipGroupItemAdd(resp.data.id, this.wafId, ips)
            if (addResp.err !== null) { this.$message.error(addResp.msg || '添加IP失败'); return }
          }
        }
      }
      this.showForm = false
      ;(this.$refs.grid as any).loadData()
    } catch (e: any) {
      this.$message.error(e?.message || '操作失败')
    } finally {
      this.submitting = false
    }
  }

  async handleDelete(row: IPGroup) {
    if (!this.ensureWafOperable()) return
    await this.$confirm('确定删除？', '提示', { type: 'warning' })
    try {
      const resp = await ipGroupDelete(row.id, this.wafId)
      if (resp.err !== null) {
        if (resp.err === 'in_use' || resp.err === 'shared') {
          this.$message.warning(resp.msg || '无法删除')
        } else {
          this.$message.error(resp.msg || '删除失败')
        }
        return
      }
      void ((this.$refs.grid as any).loadData())
    } catch (e: any) {
      this.$message.error(e?.message || '删除失败')
    }
  }

  render(h: any) {
    const iconBtnStyle = 'width:24px;height:24px;padding:4px;background:#f5f5f5;border:none;'

    return (
      <div>
        <div style="margin-bottom: 16px; display: flex; align-items: center; gap: 16px">
          <el-select v-model={this.selectedWafId} placeholder="选择 WAF 实例" on-change={() => { this.showWafOfflineMessage(); this.handleWafChange() }} disabled={!this.wafReady}>
            {this.wafOptions.map(w => <el-option key={w.captain_instance_id} label={this.formatWafOptionLabel(w)} value={w.captain_instance_id} />)}
          </el-select>
          <el-button type="primary" on-click={this.handleCreate} disabled={!this.wafId || this.isWafUnavailable}>新建 IP 组</el-button>
        </div>
        {this.renderWafOfflineAlert(h)}
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 120, render: (h: any, row: IPGroup) => {
          const editProtected = this.isEditProtected(row)
          const deleteProtected = this.isDeleteProtected(row)
          const editStyle = editProtected ? iconBtnStyle + 'color:#ccc' : iconBtnStyle + 'color:#666'
          const delStyle = deleteProtected ? iconBtnStyle + 'color:#ccc' : iconBtnStyle + 'color:#666'

          return (
            <span>
              <el-tooltip content={this.editTooltip(row)} placement="top" disabled={!editProtected}>
                <el-button size="mini" icon="el-icon-edit" style={editStyle}
                  on-click={() => editProtected ? this.$message.warning(this.editTooltip(row)) : this.handleEdit(row)} />
              </el-tooltip>
              <el-tooltip content={this.deleteTooltip(row)} placement="top" disabled={!deleteProtected}>
                <el-button size="mini" icon="el-icon-delete" style={delStyle + ';margin-left:8px'}
                  on-click={() => deleteProtected ? this.$message.warning(this.deleteTooltip(row)) : this.handleDelete(row)} />
              </el-tooltip>
            </span>
          )
        }}]} fetchData={this.fetchData} />

        <el-dialog title={this.editingItem ? '编辑 IP 组' : '新建 IP 组'} visible={this.showForm} on-close={() => { this.showForm = false }} width="560px" top="15vh">
          <el-form label-width="80px">
            <el-form-item label="名称" required><el-input v-model={this.form.name} /></el-form-item>
            <el-form-item label="备注"><el-input v-model={this.form.comment} /></el-form-item>
            <el-form-item label="IP 地址">
              <el-input type="textarea" v-model={this.ipTextarea} rows={5}
                placeholder={'1.1.1.1\n1.1.1.1/24\n1.1.1.10 - 1.1.2.10'} />
            </el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showForm = false }}>取消</el-button>
            <el-button type="primary" loading={this.submitting} on-click={this.handleSubmit}>确定</el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
