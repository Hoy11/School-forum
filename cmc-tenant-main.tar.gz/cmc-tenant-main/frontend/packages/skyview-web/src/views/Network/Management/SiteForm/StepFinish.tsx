// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'

@Component
export default class StepFinish extends Vue {
  render(h: any) {
    return (
      <div style="text-align:center;padding:40px 0">
        <i class="el-icon-success" style="font-size:48px;color:#67C23A" />
        <p style="font-size:16px;margin-top:16px">恭喜你, 添加成功!</p>
      </div>
    )
  }
}
