// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website, SSLCertModel, WAddr } from '@/types/website'
import { WorkGroupOperationMode } from '@/types/website-enums'
import { canEditBusiness } from '@/permission'
import { createFieldUpdater } from './useSiteFieldUpdate'
import { getFilteredIps, getCertName, formatTime, getHealthTag, pathOpLabel, SSL_PROTOCOL_OPTIONS } from './SiteBasicInfoTabFields'
import EditableRow from '@/components/EditableRow'
import FieldEditDialog from '@/components/FieldEditDialog'
import UrlPathsField from '../SiteForm/UrlPathsField'
import TransProxyAddrs from '../SiteForm/TransProxyAddrs'
import AddrsField from '../SiteForm/AddrsField'
import StepListenerCert from '../SiteForm/StepListenerCert'
import { getDefaultCertSettings, uploadCertIfNeeded } from '@/utils/site'
import { CertOriginal } from '@/types/website-enums'
import { CertSettings, WorkGroupModel } from '@/types/website'
import { siteWorkGroupList, siteWorkGroupIpList } from '@/api/captain-site'

@Component({ components: { EditableRow, FieldEditDialog, UrlPathsField, TransProxyAddrs, AddrsField, StepListenerCert } })
export default class BasicInfoPanel extends Vue {
  @Prop() site!: Website
  @Prop({ default: () => [] }) certs!: SSLCertModel[]
  @Prop({ default: '' }) mode!: string
  @Prop({ default: 0 }) captainInstanceId!: number

  dialogField = ''
  dialogVisible = false
  dialogValue: any = null
  dialogSaving = false
  dialogCertSettings: CertSettings = getDefaultCertSettings()
  dialogSslCert: number | null = null
  workGroups: WorkGroupModel[] = []

  get isTransProxy() { return this.mode === WorkGroupOperationMode.HardwareTransparentProxy }
  get canEdit() { return canEditBusiness() }

  get updateField() {
    return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s))
  }

  get certName() { return getCertName(this.site, this.certs) }
  get filteredIps() { return getFilteredIps(this.site) }
  get hasSSL() { return (this.site.addrs as any[] || []).some((a: any) => a.ssl) }
  get healthTag() { return getHealthTag(this.site) }

  async mounted() {
    if (this.isTransProxy && this.captainInstanceId) {
      const resp = await siteWorkGroupList(this.captainInstanceId)
      if (resp.err === null) this.workGroups = resp.data || []
    }
  }

  get addrsDisplay() {
    const addrs = this.site.addrs
    if (!addrs || addrs.length === 0) return '-'
    if (addrs[0] && typeof addrs[0] === 'object') {
      return (addrs as any[]).map((a: any) => {
        let s = a.ip_port || ''
        if (a.ssl) s += ' [SSL'
        if (a.http2) s += ' HTTP2'
        if (a.sni) s += ' SNI'
        if (a.non_http) s += ' TCP'
        if (a.ssl) s += ']'
        return s || '-'
      })
    }
    return addrs as string[]
  }

  openDialog(field: string) {
    this.dialogField = field
    if (field === 'addrs') {
      this.dialogValue = JSON.parse(JSON.stringify(this.site.addrs || []))
    } else if (field === 'url_paths') {
      this.dialogValue = JSON.parse(JSON.stringify(this.site.url_paths || []))
    } else {
      this.dialogValue = JSON.parse(JSON.stringify(this.site[field]))
    }
    this.dialogSslCert = this.site.ssl_cert || null
    this.dialogCertSettings = this.site.ssl_cert
      ? { ...getDefaultCertSettings(), type: CertOriginal.select }
      : getDefaultCertSettings()
    this.dialogVisible = true
  }

  async handleDialogSave() {
    this.dialogSaving = true
    try {
      if (this.dialogField === 'addrs') {
        const hasSsl = this.dialogValue.some((a: any) => a.ssl)
        if (hasSsl && this.dialogCertSettings.type !== CertOriginal.select) {
          const certId = await uploadCertIfNeeded(this.captainInstanceId, this.dialogCertSettings, this.site)
          await this.updateField({ addrs: this.dialogValue, ssl_cert: certId })
        } else if (hasSsl) {
          await this.updateField({ addrs: this.dialogValue, ssl_cert: this.dialogSslCert })
        } else {
          await this.updateField({ addrs: this.dialogValue })
        }
      } else if (this.dialogField === 'url_paths') {
        await this.updateField({ url_paths: this.dialogValue })
      }
      this.dialogVisible = false
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.dialogSaving = false
    }
  }

  render(h: any) {
    const s = this.site
    const canEdit = this.canEdit
    const addrsArr = this.addrsDisplay as any[]

    return (
      <el-card header="站点基本信息" style="margin-bottom:16px">
        <EditableRow label="站点名称" value={s.name} editable={canEdit}
          submitFn={(v) => this.updateField({ name: v })}
          scopedSlots={{
            default: () => <span>{s.name || '-'}</span>,
            edit: ({ value, input }) => <el-input value={value} on-input={input} placeholder="请输入站点名称" />,
          }} />

        <EditableRow label="站点状态" value={s.is_enabled} editable={canEdit}
          submitFn={(v) => this.updateField({ is_enabled: v })}
          scopedSlots={{
            default: () => <el-tag type={this.healthTag.type} size="mini">{this.healthTag.text}</el-tag>,
            edit: ({ value, input }) => (
              <el-select value={value} on-input={input} style="width:120px">
                <el-option key="on" label="启用" value={true} />
                <el-option key="off" label="禁用" value={false} />
              </el-select>
            ),
          }} />

        {this.isTransProxy && this.workGroups.length > 0 && (
          <EditableRow label="工作组" value={s.interface} editable={canEdit}
            submitFn={(v) => this.updateField({ interface: v })}
            scopedSlots={{
              default: () => <span>{s.interface || '-'}</span>,
              edit: ({ value, input }) => (
                <el-select value={value} on-input={input} style="width:100%">
                  {this.workGroups.map(wg => <el-option key={wg.name} label={wg.name} value={wg.name} />)}
                </el-select>
              ),
            }} />
        )}

        <EditableRow label="服务器地址" editable={canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('addrs')}
          scopedSlots={{
            default: () => (
              <span>{addrsArr.length > 0 && addrsArr !== '-'
                ? addrsArr.map((a: string, i: number) => <div key={i}>{a}</div>)
                : '-'}</span>
            ),
          }} />

        <EditableRow label="域名" value={(s.server_names || []).join('\n')} editable={canEdit}
          submitFn={(v) => this.updateField({ server_names: v.split('\n').map((x: string) => x.trim()).filter(Boolean) })}
          scopedSlots={{
            default: () => <span>{(s.server_names || []).length > 0 ? s.server_names.join(', ') : '-'}</span>,
            edit: ({ value, input }) => <el-input value={value} on-input={input} type="textarea" rows={4} placeholder="每行一个域名" />,
          }} />

        <EditableRow label="生效地址" editable={canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('url_paths')}
          scopedSlots={{
            default: () => (
              <span>{(s.url_paths || []).length > 0
                ? s.url_paths.map((up: any, i: number) => <el-tag key={i} size="mini" style="margin:2px">{pathOpLabel(up.op)} {up.url_path}</el-tag>)
                : '-'}</span>
            ),
          }} />

        <EditableRow label="备注信息" value={s.remark || ''} editable={canEdit}
          submitFn={(v) => this.updateField({ remark: v })}
          scopedSlots={{
            default: () => <span>{s.remark || '-'}</span>,
            edit: ({ value, input }) => <el-input value={value} on-input={input} type="textarea" rows={2} />,
          }} />

        {this.isTransProxy && this.filteredIps.length > 0 && <EditableRow label="IP" value={this.filteredIps.join(', ')} />}
        {this.hasSSL && s.ssl_cert && (
          <EditableRow label="HTTPS 证书" editable={canEdit} mode="dialog"
            on-edit-click={() => this.openDialog('addrs')}
            scopedSlots={{ default: () => <span>{this.certName}</span> }} />
        )}
        {this.hasSSL && (s.ssl_protocols || []).length > 0 && (
          <EditableRow label="SSL 版本" value={s.ssl_protocols || []} editable={canEdit}
            submitFn={(v) => this.updateField({ ssl_protocols: v })}
            scopedSlots={{
              default: () => <span>{s.ssl_protocols.join(', ')}</span>,
              edit: ({ value, input }) => (
                <el-select value={value} on-input={input} multiple style="width:100%">
                  {SSL_PROTOCOL_OPTIONS.map(opt => <el-option key={opt.value} label={opt.label} value={opt.value} />)}
                </el-select>
              ),
            }} />
        )}
        {this.hasSSL && s.ssl_ciphers && (
          <EditableRow label="SSL 加密算法" value={s.ssl_ciphers} editable={canEdit}
            submitFn={(v) => this.updateField({ ssl_ciphers: v })}
            scopedSlots={{
              default: () => <span>{s.ssl_ciphers}</span>,
              edit: ({ value, input }) => <el-input value={value} on-input={input} type="textarea" rows={2} />,
            }} />
        )}

        <EditableRow label="创建时间" value={formatTime(s.create_time)} />
        <EditableRow label="最后更新时间" value={formatTime(s.last_update_time)} />

        <FieldEditDialog visible={this.dialogVisible}
          title={`编辑${this.dialogField === 'addrs' ? '服务器地址' : this.dialogField === 'url_paths' ? '生效地址' : ''}`}
          loading={this.dialogSaving} width="700px"
          on-close={() => { this.dialogVisible = false }}
          on-submit={this.handleDialogSave}>
          {this.dialogField === 'addrs' && this.isTransProxy && (
            <div>
              <TransProxyAddrs value={this.dialogValue} on-input={(v: WAddr[]) => { this.dialogValue = v }} bare />
              {this.dialogValue.some((a: any) => a.ssl) && (
                <StepListenerCert certSettings={this.dialogCertSettings} certs={this.certs}
                  sslCert={this.dialogSslCert}
                  on-cert-change={(v: CertSettings) => { this.dialogCertSettings = v }}
                  on-ssl-cert-change={(v: number) => { this.dialogSslCert = v }} />
              )}
            </div>
          )}
          {this.dialogField === 'addrs' && !this.isTransProxy && (
            <AddrsField value={this.dialogValue} on-input={(v: string[]) => { this.dialogValue = v }} bare />
          )}
          {this.dialogField === 'url_paths' && (
            <UrlPathsField value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} bare />
          )}
        </FieldEditDialog>
      </el-card>
    )
  }
}
