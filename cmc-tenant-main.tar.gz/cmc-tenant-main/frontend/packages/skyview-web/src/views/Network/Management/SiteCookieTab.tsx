// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { CookieSecurityProtection, CookieSecurityAttribute, CookieSecurity } from '@/types/website-security'
import { canEditBusiness } from '@/permission'
import { createFieldUpdater } from './SiteDetail/useSiteFieldUpdate'
import { pureIsEnabledConfig } from '@/utils/site/pure'
import { cookieGenerateKey } from '@/api/captain-site'
import EditableRow from '@/components/EditableRow'
import FieldEditDialog from '@/components/FieldEditDialog'

const PROT_OPTIONS = [
  { value: CookieSecurityProtection.propertyOnly, label: '仅配置Cookie属性' },
  { value: CookieSecurityProtection.signatures, label: 'Cookie签名' },
  { value: CookieSecurityProtection.encryption, label: 'Cookie加密' },
]
const ACTION_OPTIONS = [
  { value: 'dry_run', label: '观察' },
  { value: 'deny', label: '拦截' },
]
const LOG_OPTIONS = [
  { value: 'Persistence', label: '记录并储存日志' },
  { value: 'Drop', label: '不记录日志' },
]
const ATTR_OPTIONS = [
  { value: CookieSecurityAttribute.httponly, label: 'HttpOnly' },
  { value: CookieSecurityAttribute.secure, label: 'Secure' },
]
const PROT_LABEL: Record<string, string> = {
  [CookieSecurityProtection.signatures]: 'Cookie签名',
  [CookieSecurityProtection.encryption]: 'Cookie加密',
  [CookieSecurityProtection.propertyOnly]: '仅配置Cookie属性',
}
const ACTION_LABEL: Record<string, string> = { deny: '拦截', dry_run: '观察' }
const LOG_LABEL: Record<string, string> = { Persistence: '记录并储存日志', Drop: '不记录日志' }

function isPropertyOnly(p: string) { return p === CookieSecurityProtection.propertyOnly }

function freshCookieSecurity(partial?: Partial<CookieSecurity>): CookieSecurity {
  return { is_enabled: false, protection: CookieSecurityProtection.propertyOnly, action: 'dry_run',
    log_option: 'Drop', security_attribute: [], cookie: [],
    key: '', compatible_time: 0, ip_verification: false, ...partial }
}

@Component({ components: { EditableRow, FieldEditDialog } })
export default class SiteCookieTab extends Vue {
  @Prop() site!: any
  @Prop({ default: 0 }) captainInstanceId!: number

  editing = false
  saving = false
  editForm: CookieSecurity = freshCookieSecurity()

  get canEdit() { return canEditBusiness() }
  get cs(): CookieSecurity { return this.site.cookie_security || { is_enabled: false } }
  get updateField() {
    return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s))
  }

  async submitCookieSecurity(val: CookieSecurity) {
    const payload = val.is_enabled ? val : pureIsEnabledConfig(val)
    await this.updateField({ cookie_security: payload })
  }

  startEdit() {
    const cs = this.cs
    this.editForm = {
      is_enabled: cs.is_enabled || false,
      protection: cs.protection || CookieSecurityProtection.propertyOnly,
      action: cs.action || 'dry_run',
      log_option: cs.log_option || 'Drop',
      security_attribute: cs.security_attribute || [],
      cookie: cs.cookie || [],
      key: (cs as any).key || '',
      compatible_time: (cs as any).compatible_time ?? 0,
      ip_verification: (cs as any).ip_verification || false,
    }
    this.editing = true
  }

  cancelEdit() {
    this.editing = false
  }

  async saveEdit() {
    const f = this.editForm
    if (f.is_enabled && !isPropertyOnly(f.protection) && !f.key) {
      this.$message.warning('Cookie签名/加密模式需要配置密钥')
      return
    }
    this.saving = true
    try {
      await this.submitCookieSecurity(f)
      this.editing = false
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.saving = false
    }
  }

  handleFormProtectionChange(v: string) {
    const f = this.editForm
    if (v === f.protection) return
    const prevEnabled = f.is_enabled
    const prevCookie = f.cookie || []
    if (isPropertyOnly(v)) {
      f.protection = v
      f.action = 'dry_run'
      f.log_option = 'Drop'
      f.key = ''
      f.compatible_time = 0
      f.ip_verification = false
    } else {
      f.protection = v
      f.action = 'dry_run'
      f.log_option = 'Persistence'
      f.compatible_time = 0
      f.ip_verification = false
      if (!f.key) f.key = ''
    }
    f.is_enabled = prevEnabled
    f.cookie = prevCookie
  }

  async handleGenerateKey() {
    const resp = await cookieGenerateKey(this.captainInstanceId)
    if (resp.err !== null) throw new Error(resp.msg || '生成密钥失败')
    return resp.data.key
  }

  // Display helpers
  get enabledLabel() {
    const cs = this.cs
    return cs.is_enabled ? '开启' : '关闭'
  }
  get protectionLabel() { return PROT_LABEL[this.cs.protection] || '-' }
  get actionLabel() { return ACTION_LABEL[this.cs.action] || '-' }
  get compatibleTimeLabel() {
    const t = (this.cs as any).compatible_time
    return t ? new Date(t * 1000).toLocaleString() : '-'
  }

  get compatibleTimeDate() {
    const t = this.editForm.compatible_time
    return t ? new Date(t * 1000) : null
  }
  set compatibleTimeDate(v: Date | null) {
    this.editForm.compatible_time = v ? Math.floor(v.getTime() / 1000) : 0
  }

  renderReadMode(h: any) {
    const cs = this.cs
    const po = isPropertyOnly(cs.protection)
    return (
      <div>
        <EditableRow label="防护状态" value={this.enabledLabel} />
        {cs.is_enabled && <EditableRow label="防护方式" value={this.protectionLabel} />}
        {cs.is_enabled && <EditableRow label="防护响应方式" value={this.actionLabel} />}
        {cs.is_enabled && <EditableRow label="记录日志方式" value={LOG_LABEL[cs.log_option] || '-'} />}
        {cs.is_enabled && !po && <EditableRow label="Cookie 兼容时间" value={this.compatibleTimeLabel} />}
      </div>
    )
  }

  renderEditForm(h: any) {
    const f = this.editForm
    const po = isPropertyOnly(f.protection)

    return (
      <el-form label-width="130px" size="small" style="padding: 16px 0">
        <el-form-item label="启用 Cookie 防护">
          <el-switch value={f.is_enabled} on-input={(v: boolean) => { f.is_enabled = v }} />
        </el-form-item>

        {f.is_enabled && [
          <el-form-item label="防护方式" required>
            <el-select value={f.protection} on-input={this.handleFormProtectionChange} style="width:100%">
              {PROT_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
            </el-select>
          </el-form-item>,

          !po && <el-form-item label="密钥" required>
            <div style="display:flex;gap:8px;align-items:center">
              <el-input value={f.key} on-input={(v: string) => { f.key = v }} placeholder="32位十六进制密钥" style="flex:1" />
              <el-button size="mini" on-click={async () => {
                try { const k = await this.handleGenerateKey(); f.key = k } catch (e: any) { this.$message.error(e.message) }
              }}>快速生成密钥</el-button>
            </div>
          </el-form-item>,

          <el-form-item label="防护响应方式">
            {po
              ? <el-select value="dry_run" disabled style="width:100%"><el-option label="观察" value="dry_run" /></el-select>
              : <el-select value={f.action} on-input={(v: string) => { f.action = v }} style="width:100%">
                  {ACTION_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
                </el-select>}
          </el-form-item>,

          <el-form-item label="记录日志方式">
            <el-select value={f.log_option} on-input={(v: string) => { f.log_option = v }} style="width:100%" disabled={po}>
              {LOG_OPTIONS.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
            </el-select>
          </el-form-item>,

          !po && <el-form-item>
            <span slot="label">
              Cookie 兼容时间{' '}
              <el-tooltip effect="dark" placement="top" style="cursor:help">
                <div slot="content" style="max-width:300px;line-height:1.6">开启 cookie 防护之前，Web 客户端可能已存在原先未经防护处理的 cookie，为了保证启用策略前后 cookie 的兼容性，配置防护兼容的时间。</div>
                <i class="el-icon-question" style="color:#909399" />
              </el-tooltip>
            </span>
            <el-date-picker
              value={this.compatibleTimeDate}
              on-input={(v: Date) => { this.compatibleTimeDate = v }}
              type="datetime"
              placeholder="选择日期时间"
              style="width:100%"
              picker-options={{ disabledDate: (d: Date) => d < new Date(new Date().setHours(0, 0, 0, 0)) }}
            />
          </el-form-item>,

          <el-form-item label="安全属性">
            <el-checkbox-group value={f.security_attribute || []} on-input={(v: string[]) => { f.security_attribute = v }}>
              {ATTR_OPTIONS.map(o => <el-checkbox key={o.value} label={o.value}>{o.label}</el-checkbox>)}
            </el-checkbox-group>
            {!po && <el-checkbox value={f.ip_verification || false}
              on-input={(v: boolean) => { f.ip_verification = v }}
              style="margin-top:8px">IP 校验</el-checkbox>}
          </el-form-item>,

          <el-form-item label="Cookie 名称">
            <el-select value={f.cookie || []} on-input={(v: string[]) => { f.cookie = v }}
              multiple allow-create filterable default-first-option style="width:100%"
              placeholder="输入 Cookie 名称后回车添加" />
          </el-form-item>,
        ]}
      </el-form>
    )
  }

  render(h: any) {
    if (!this.site.cookie_security && !this.site.id) {
      return <div style="color:#909399;padding:20px">无 Cookie 防护策略配置</div>
    }

    return (
      <el-card>
        <div slot="header" style="display:flex;align-items:center;justify-content:space-between">
          <span style="font-weight:bold">Cookie 防护策略</span>
          {!this.editing && this.canEdit && (
            <el-button type="text" icon="el-icon-edit" on-click={this.startEdit}>编辑</el-button>
          )}
          {this.editing && (
            <span style="display:flex;gap:8px">
              <el-button size="small" type="primary" loading={this.saving} on-click={this.saveEdit}>保存</el-button>
              <el-button size="small" on-click={this.cancelEdit}>取消</el-button>
            </span>
          )}
        </div>
        {this.editing ? this.renderEditForm(h) : this.renderReadMode(h)}
      </el-card>
    )
  }
}
