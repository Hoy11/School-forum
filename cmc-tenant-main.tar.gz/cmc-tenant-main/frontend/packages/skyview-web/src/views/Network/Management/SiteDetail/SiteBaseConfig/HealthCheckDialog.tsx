// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { healthCheckTypeOptions, healthCheckCodeOptions, healthCheckMethodOptions } from './constants'

@Component
export default class HealthCheckDialog extends Vue {
  @Prop() value!: any

  get v() { return this.value || {} }
  get enabled() { return !!this.v.is_enabled }
  get isHttp() { return this.v.check_type === 'http' }

  emit(v: any) { this.$emit('input', v) }

  render(h: any) {
    const v = this.v, en = this.enabled, isHttp = this.isHttp
    return (
      <el-form label-width="130px" size="small">
        <el-form-item label="启用健康检查">
          <el-switch value={!!v.is_enabled} on-input={(val: boolean) => this.emit({ ...v, is_enabled: val })} />
        </el-form-item>
        {en && [
          <el-form-item label="健康检查协议">
            <el-select value={v.check_type || 'tcp'} on-input={(val: string) => this.emit({ ...v, check_type: val })}>
              {healthCheckTypeOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
            </el-select>
          </el-form-item>,
          <el-form-item label="检查间隔">
            <el-input-number value={v.interval || 1000} on-input={(val: number) => this.emit({ ...v, interval: val })} min={1000} controls={false} style="width:200px" />
            <span style="margin-left:8px;color:#909399;font-size:12px">ms</span>
          </el-form-item>,
          <el-form-item label="响应超时时间">
            <el-input-number value={v.timeout || 3000} on-input={(val: number) => this.emit({ ...v, timeout: val })} min={1000} max={300000} controls={false} style="width:200px" />
            <span style="margin-left:8px;color:#909399;font-size:12px">ms</span>
          </el-form-item>,
          <el-form-item label="不健康阈值">
            <el-input-number value={v.fall || 3} on-input={(val: number) => this.emit({ ...v, fall: val })} min={1} max={10} controls={false} style="width:200px" />
            <span style="margin-left:8px;color:#909399;font-size:12px">次</span>
          </el-form-item>,
          <el-form-item label="健康阈值">
            <el-input-number value={v.rise || 2} on-input={(val: number) => this.emit({ ...v, rise: val })} min={1} max={10} controls={false} style="width:200px" />
            <span style="margin-left:8px;color:#909399;font-size:12px">次</span>
          </el-form-item>,
          isHttp && <el-form-item label="检查域名">
            <el-input value={v.host || ''} on-input={(val: string) => this.emit({ ...v, host: val })} style="width:300px" placeholder="默认使用业务服务器域名" />
          </el-form-item>,
          isHttp && <el-form-item label="检查端口">
            <el-input-number value={v.port} on-input={(val: number) => this.emit({ ...v, port: val })} min={1} max={65535} controls={false} style="width:200px" placeholder="默认使用业务服务器端口" />
          </el-form-item>,
          isHttp && <el-form-item label="检查路径">
            <el-input value={v.path || ''} on-input={(val: string) => this.emit({ ...v, path: val })} style="width:300px" placeholder="请输入以 / 开头的检查路径" />
          </el-form-item>,
          isHttp && <el-form-item label="检查状态码">
            <el-select value={v.check_http_expect_alive || []} on-input={(val: string[]) => this.emit({ ...v, check_http_expect_alive: val })} multiple style="width:300px">
              {healthCheckCodeOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
            </el-select>
          </el-form-item>,
          isHttp && <el-form-item label="HTTP 请求方式">
            <el-select value={v.method || 'GET'} on-input={(val: string) => this.emit({ ...v, method: val })} style="width:200px">
              {healthCheckMethodOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
            </el-select>
          </el-form-item>,
          v.check_type === 'ssl_hello' && <el-alert type="warning" closable={false} style="margin-bottom:12px" description="HTTPS 健康检查仅支持开启 sslv3 协议的服务器，若禁用 sslv3，请采用其他健康检查方式" />,
        ]}
      </el-form>
    )
  }
}
