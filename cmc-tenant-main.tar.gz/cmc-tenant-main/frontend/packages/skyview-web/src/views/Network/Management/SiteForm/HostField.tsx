// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'

@Component
export default class HostField extends Vue {
  @Prop({ default: () => [] }) value!: string[]
  @Prop({ default: false }) bare!: boolean

  get displayValue() {
    return this.value?.join(',') || ''
  }

  handleInput(v: string) {
    this.$emit('input', v.split(',').map((s: string) => s.trim()).filter(Boolean))
  }

  render(h: any) {
    const input = <el-input value={this.displayValue} on-input={this.handleInput}
      placeholder="可使用 * 通配, 多个域名之间用逗号隔开" />
    if (this.bare) return input
    return <el-form-item label="域名" required>{input}</el-form-item>
  }
}
