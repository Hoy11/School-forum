// @ts-nocheck
import { Component, Prop, Vue } from 'vue-property-decorator'
import { Website } from '@/types/website'
import { WorkGroupOperationMode, LogOption } from '@/types/website-enums'
import { ConnectionConfig } from '@/types/website-security'
import { canEditBusiness } from '@/permission'
import { createFieldUpdater } from './useSiteFieldUpdate'
import EditableRow from '@/components/EditableRow'
import FieldEditDialog from '@/components/FieldEditDialog'
import HeadersDialog from './SiteBaseConfig/HeadersDialog'
import IgnoreTypesDialog from './SiteBaseConfig/IgnoreTypesDialog'
import CustomConfigDialog from './SiteBaseConfig/CustomConfigDialog'
import { connectionConfigOptions, logOptionOptions } from './SiteBaseConfig/constants'

const isTransProxy = (m: string) => m === WorkGroupOperationMode.HardwareTransparentProxy

function connText(site: any): string {
  const cfg = site.backend_config
  const opt = connectionConfigOptions.find((o: any) => o.value === cfg?.keepalive_config)
  const label = opt?.label || cfg?.keepalive_config || '-'
  if (cfg?.keepalive_config === ConnectionConfig.custom) return `${label} (keepalive: ${cfg.keepalive ?? '-'}, timeout: ${cfg.keepalive_timeout ?? '-'})`
  return label
}

function accessLogText(al: any): string {
  if (!al) return '-'
  const label = logOptionOptions.find((o: any) => o.value === al.log_option)?.label || al.log_option || '-'
  const extras: string[] = []
  if (al.log_option !== LogOption.drop) {
    if (al.req_body) extras.push('请求Body')
    if (al.rsp_body) extras.push('响应Body')
  }
  return extras.length ? `${label} (${extras.join('，')})` : label
}

function headersText(headers: any[]): string {
  if (!headers || !headers.length) return '暂无内容'
  return headers.map(h => `${h.name}(${h.action === 'set' ? '设置' : '隐藏'})`).join('，')
}

function ignoreTypesText(types: string[]): string {
  if (!types || !types.length) return '暂无内容'
  return types.join('，')
}

function customConfigText(custom: Record<string, string>): string {
  if (!custom || !Object.keys(custom).length) return '暂无内容'
  return Object.entries(custom).map(([k, v]) => `${k} ${v}`).join('，')
}

@Component({ components: { EditableRow, FieldEditDialog, HeadersDialog, IgnoreTypesDialog, CustomConfigDialog } })
export default class RequestProcessingPanel extends Vue {
  @Prop() site!: Website
  @Prop({ default: 0 }) captainInstanceId!: number
  @Prop({ default: '' }) mode!: string

  dialogVisible = false
  dialogField = ''
  dialogValue: any = null
  dialogSaving = false

  get canEdit() { return canEditBusiness() }
  get tp() { return isTransProxy(this.mode) }
  get updateField() { return createFieldUpdater(this.site, this.captainInstanceId, (s) => this.$emit('updated', s)) }

  get cfg() { return this.site.backend_config || {} as any }
  get log() { return this.site.access_log }

  openDialog(field: string) {
    this.dialogField = field
    if (field === 'headers') {
      this.dialogValue = JSON.parse(JSON.stringify(this.cfg.header_config || []))
    } else if (field === 'ignoreTypes') {
      this.dialogValue = JSON.parse(JSON.stringify(this.cfg.custom_config?.ignore_types || []))
    } else if (field === 'customConfig') {
      const custom = this.cfg.custom_config?.custom || {}
      this.dialogValue = Object.entries(custom).map(([key, value]) => ({ key, value }))
    }
    this.dialogVisible = true
  }

  async handleDialogSave() {
    this.dialogSaving = true
    try {
      if (this.dialogField === 'headers') {
        await this.updateField({ backend_config: { ...this.cfg, header_config: this.dialogValue } })
      } else if (this.dialogField === 'ignoreTypes') {
        await this.updateField({ backend_config: { ...this.cfg, custom_config: { ...this.cfg.custom_config, ignore_types: this.dialogValue } } })
      } else if (this.dialogField === 'customConfig') {
        const custom: Record<string, string> = {}
        for (const item of this.dialogValue) {
          if (item.key) custom[item.key] = item.value
        }
        await this.updateField({ backend_config: { ...this.cfg, custom_config: { ...this.cfg.custom_config, custom } } })
      }
      this.dialogVisible = false
    } catch (e: any) {
      this.$message.error(e?.message || '保存失败')
    } finally {
      this.dialogSaving = false
    }
  }

  renderKeepaliveEdit({ value, input }: any) {
    const p = JSON.parse(value || '{}')
    const isCustom = p.keepalive_config === ConnectionConfig.custom
    return (
      <div>
        <el-select value={p.keepalive_config} on-input={(v: string) => {
          if (v === ConnectionConfig.custom) input(JSON.stringify({ ...p, keepalive_config: v, keepalive: p.keepalive || '32', keepalive_timeout: p.keepalive_timeout || '65' }))
          else input(JSON.stringify({ ...p, keepalive_config: v }))
        }} style="width:100%;margin-bottom:8px">
          {connectionConfigOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
        </el-select>
        {isCustom && (
          <div style="display:flex;gap:8px">
            <el-input-number value={Number(p.keepalive) || 32} on-input={(v: number) => input(JSON.stringify({ ...p, keepalive: v }))} min={32} controls={false} style="flex:1" placeholder="保持连接数" />
            <el-input-number value={Number(p.keepalive_timeout) || 65} on-input={(v: number) => input(JSON.stringify({ ...p, keepalive_timeout: v }))} min={8} max={1024} controls={false} style="flex:1" placeholder="保持时间(秒)" />
          </div>
        )}
      </div>
    )
  }

  renderAccessLogEdit({ value, input }: any) {
    const p = JSON.parse(value || '{}')
    const isDrop = p.log_option === LogOption.drop
    return (
      <div>
        <el-select value={p.log_option} on-input={(v: string) => input(JSON.stringify({ ...p, log_option: v, is_enabled: v !== LogOption.drop, req_body: v === LogOption.drop ? false : p.req_body, rsp_body: v === LogOption.drop ? false : p.rsp_body }))} style="width:100%;margin-bottom:8px">
          {logOptionOptions.map(o => <el-option key={o.value} label={o.label} value={o.value} />)}
        </el-select>
        {!isDrop && (
          <div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
              <span style="font-size:12px;color:#909399;width:100px">记录请求Body</span>
              <el-switch value={!!p.req_body} on-input={(v: boolean) => input(JSON.stringify({ ...p, req_body: v }))} />
            </div>
            <div style="display:flex;align-items:center;gap:8px">
              <span style="font-size:12px;color:#909399;width:100px">记录响应Body</span>
              <el-switch value={!!p.rsp_body} on-input={(v: boolean) => input(JSON.stringify({ ...p, rsp_body: v }))} />
            </div>
          </div>
        )}
        {isDrop && <el-alert type="info" closable={false} style="margin-top:4px" description="选择不记录后，将不再保存任何访问日志" />}
      </div>
    )
  }

  renderDialogContent(h: any) {
    if (this.dialogField === 'headers') {
      return <HeadersDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />
    }
    if (this.dialogField === 'ignoreTypes') {
      return <IgnoreTypesDialog value={this.dialogValue} on-input={(v: string[]) => { this.dialogValue = v }} />
    }
    if (this.dialogField === 'customConfig') {
      return <CustomConfigDialog value={this.dialogValue} on-input={(v: any) => { this.dialogValue = v }} />
    }
    return null
  }

  render(h: any) {
    if (!this.log && !this.tp) {
      return (
        <el-card style="margin-bottom:16px">
          <div slot="header" style="font-weight:bold">请求处理方式</div>
          <div style="color:#909399;text-align:center;padding:16px">当前模式无请求处理配置</div>
        </el-card>
      )
    }
    const cfg = this.cfg
    const log = this.log

    return (
      <el-card style="margin-bottom:16px">
        <div slot="header" style="font-weight:bold">请求处理方式</div>

        {this.tp && <EditableRow label="保持连接配置" editable={this.canEdit}
          value={JSON.stringify({ keepalive_config: cfg.keepalive_config, keepalive: cfg.keepalive, keepalive_timeout: cfg.keepalive_timeout })}
          submitFn={(v) => { const p = JSON.parse(v); return this.updateField({ backend_config: { ...cfg, keepalive_config: p.keepalive_config, keepalive: p.keepalive, keepalive_timeout: p.keepalive_timeout } }) }}
          scopedSlots={{ default: () => <span>{connText(this.site)}</span>, edit: (scope) => this.renderKeepaliveEdit(scope) }} />}

        {log && <EditableRow label="记录访问日志" editable={this.canEdit}
          value={JSON.stringify({ is_enabled: log.is_enabled, log_option: log.log_option, req_body: log.req_body, rsp_body: log.rsp_body })}
          submitFn={(v) => { const p = JSON.parse(v); const isDrop = p.log_option === LogOption.drop; return this.updateField({ access_log: { ...log, log_option: p.log_option, req_body: isDrop ? false : p.req_body, rsp_body: isDrop ? false : p.rsp_body, is_enabled: !isDrop } }) }}
          scopedSlots={{ default: () => <span>{accessLogText(log)}</span>, edit: (scope) => this.renderAccessLogEdit(scope) }} />}

        {this.tp && <EditableRow label="HTTP 头设置" editable={this.canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('headers')}
          scopedSlots={{ default: () => { const t = headersText(cfg.header_config); return t === '暂无内容' ? <span style="color:#909399">{t}</span> : <span>{t}</span> } }} />}

        {this.tp && <EditableRow label="忽略特定 content_type" editable={this.canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('ignoreTypes')}
          scopedSlots={{ default: () => { const t = ignoreTypesText(cfg.custom_config?.ignore_types); return t === '暂无内容' ? <span style="color:#909399">{t}</span> : <span>{t}</span> } }} />}

        {this.tp && <EditableRow label="代理服务器详细配置" editable={this.canEdit} mode="dialog"
          on-edit-click={() => this.openDialog('customConfig')}
          scopedSlots={{ default: () => { const t = customConfigText(cfg.custom_config?.custom); return t === '暂无内容' ? <span style="color:#909399">{t}</span> : <span>{t}</span> } }} />}

        {this.tp && <EditableRow label="源端口透传" editable={this.canEdit}
          value={String(cfg.preserve_source_port || false)}
          submitFn={(v) => this.updateField({ backend_config: { ...cfg, preserve_source_port: v === 'true' } })}
          scopedSlots={{
            default: () => <span>{cfg.preserve_source_port ? '开启' : '关闭'}</span>,
            edit: ({ value, input }) => (
              <el-select value={value} on-input={input} style="width:120px">
                <el-option label="开启" value="true" />
                <el-option label="关闭" value="false" />
              </el-select>
            ),
          }} />}

        <FieldEditDialog visible={this.dialogVisible}
          title={`编辑${this.dialogField === 'headers' ? 'HTTP 头设置' : this.dialogField === 'ignoreTypes' ? '忽略特定 content_type' : '代理服务器详细配置'}`}
          loading={this.dialogSaving} width="700px"
          on-close={() => { this.dialogVisible = false }}
          on-submit={this.handleDialogSave}>
          {this.renderDialogContent(h)}
        </FieldEditDialog>
      </el-card>
    )
  }
}
