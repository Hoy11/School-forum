// @ts-nocheck
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import Sortable from 'sortablejs'
import { PolicyRule } from '@/types/policy'
import { ACTION_MAP, ACTION_TAG_TYPE, formatTimestamp, formatDate } from '../ruleConstants'

@Component
export default class RuleTable extends Vue {
  @Prop({ default: () => [] }) rules!: PolicyRule[]
  @Prop({ default: false }) loading!: boolean
  @Prop({ default: false }) canEdit!: boolean
  @Prop({ default: true }) showAlert!: boolean
  @Prop({ default: false }) sortable!: boolean

  sortableInstance: any = null

  mounted() {
    if (this.sortable && this.canEdit) this.tryInitSortable()
  }

  @Watch('rules')
  onRulesChange() {
    if (this.sortable && this.canEdit) this.tryInitSortable()
  }

  beforeDestroy() {
    this.destroySortable()
  }

  destroySortable() {
    if (this.sortableInstance) { this.sortableInstance.destroy(); this.sortableInstance = null }
  }

  tryInitSortable() {
    this.destroySortable()
    this.$nextTick(() => {
      const el = this.$el as HTMLElement
      const tbody = el?.querySelector('.el-table__body-wrapper tbody') as HTMLElement
      if (!tbody) return
      this.sortableInstance = Sortable.create(tbody, {
        draggable: '> .el-table__row',
        handle: '.rule-drag-handle',
        onEnd: (evt: any) => {
          if (evt.oldIndex === evt.newIndex) return
          const moved = this.rules[evt.oldIndex]
          const reordered = [...this.rules]
          reordered.splice(evt.oldIndex, 1)
          reordered.splice(evt.newIndex, 0, moved)
          this.$emit('sort-change', reordered.map((r: PolicyRule) => r.id))
        },
      })
    })
  }

  colOrder(h: any) {
    if (!this.sortable || !this.canEdit) return null
    return h('el-table-column', {
      props: { width: 80 },
      scopedSlots: {
        default: () => h('i', { class: 'rule-drag-handle el-icon-rank', style: 'cursor:grab;color:#909399' }),
        header: () => h('span', [
          '顺序',
          h('el-tooltip', { props: { content: '请求将从上往下进行规则的匹配和动作的执行，通过拖动可调整位置', placement: 'top' } }, [
            h('i', { class: 'el-icon-question', style: 'margin-left:4px;color:#909399;cursor:pointer' }),
          ]),
        ]),
      },
    })
  }

  colStatus(h: any) {
    return h('el-table-column', { props: { label: '状态', width: 80 }, scopedSlots: { default: ({ row }) => {
      if (!row.is_enabled) return h('el-tag', { props: { size: 'mini', type: 'info' } }, ['禁用'])
      if (row.is_expired) return h('el-tag', { props: { size: 'mini', type: 'warning' } }, ['过期'])
      return h('el-tag', { props: { size: 'mini', type: 'success' } }, ['启用'])
    }}})
  }

  colRuleId(h: any) {
    return h('el-table-column', { props: { prop: 'id', label: '规则 ID', width: 80, 'show-overflow-tooltip': true } })
  }

  colAction(h: any) {
    return h('el-table-column', {
      props: { width: 85 },
      scopedSlots: {
        default: ({ row }) => {
          const label = ACTION_MAP[row.action] || row.action
          const type = ACTION_TAG_TYPE[row.action] || 'info'
          return h('el-tag', { props: { size: 'mini', type } }, [label])
        },
        header: () => h('span', [
          '动作',
          h('el-tooltip', { props: { content: '请求触发自定义规则的拦截、放行动作后，将不再继续进行自定义规则的匹配和引擎检测，进行放行或拦截。触发观察动作后，将继续进行自定义规则的匹配和引擎检测。触发检测模块控制动作后，将在后续引擎检测时对检测模块进行相应的动作。', placement: 'top' } }, [
            h('i', { class: 'el-icon-question', style: 'margin-left:4px;color:#E6A23C;cursor:pointer' }),
          ]),
        ]),
      },
    })
  }

  colComment(h: any) {
    return h('el-table-column', { props: { label: '备注', 'show-overflow-tooltip': true }, scopedSlots: { default: ({ row }) => {
      return row.comment ? h('span', row.comment) : h('span', { style: 'color:#909399' }, ['-'])
    }}})
  }

  colExpireTime(h: any) {
    return h('el-table-column', { props: { label: '过期时间', width: 180, 'show-overflow-tooltip': true }, scopedSlots: { default: ({ row }) => {
      return h('span', [formatDate(row.expire_time)])
    }}})
  }

  colCreateTime(h: any) {
    return h('el-table-column', { props: { label: '创建时间', width: 180, 'show-overflow-tooltip': true }, scopedSlots: { default: ({ row }) => {
      return h('span', [formatTimestamp(row.create_time)])
    }}})
  }

  colLastModifyTime(h: any) {
    return h('el-table-column', { props: { label: '最后修改时间', width: 180, 'show-overflow-tooltip': true }, scopedSlots: { default: ({ row }) => {
      return h('span', [row.last_update_time ? formatTimestamp(row.last_update_time) : '从未修改'])
    }}})
  }

  colOperations(h: any) {
    if (!this.canEdit) return null
    return h('el-table-column', { props: { label: '操作', width: 80 }, scopedSlots: { default: ({ row }) => {
      return h('span', { style: 'display:inline-flex;align-items:center;gap:8px' }, [
        h('el-tooltip', { props: { content: '查看日志信息', placement: 'top' } }, [
          h('el-button', {
            props: { type: 'text', size: 'mini', icon: 'el-icon-search' },
            on: { click: (e: Event) => { e.stopPropagation(); this.$emit('view-log', row) } },
          }),
        ]),
        h('el-tooltip', { props: { content: '删除', placement: 'top' } }, [
          h('el-button', {
            props: { type: 'text', size: 'mini', icon: 'el-icon-delete' },
            style: 'color:#F56C6C',
            on: { click: (e: Event) => {
              e.stopPropagation()
              this.$confirm(`确认删除规则"${row.comment || row.id}"吗？`, '提示', { type: 'warning' })
                .then(() => this.$emit('delete', row))
                .catch(() => {})
            }},
          }),
        ]),
      ])
    }}})
  }

  render(h: any) {
    return h('div', [
      this.showAlert ? h('el-alert', {
        props: { title: '该功能配置过程中，可能会因为匹配规则问题导致拦截正常业务或生成过多日志（磁盘使用率过高），请在观察后上线', type: 'info', closable: false, 'show-icon': true },
        style: 'margin-bottom:12px',
      }) : null,

      this.canEdit ? h('div', { style: 'margin-bottom:12px;display:flex;justify-content:flex-end;gap:8px' }, [
        h('el-button', { props: { type: 'primary', size: 'small', icon: 'el-icon-plus' }, on: { click: () => this.$emit('create') } }, ['添加自定义规则']),
      ]) : null,

      this.rules.length === 0 && !this.loading ? h('div', { style: 'color:#909399;text-align:center;padding:24px' }, ['无关联自定义规则']) : null,

      this.rules.length > 0 ? h('el-table', {
        props: { data: this.rules, size: 'small' },
        style: 'width:100%',
        directives: this.loading ? [{ name: 'loading', value: true }] : [],
        ref: 'table',
      }, [
        this.colOrder(h),
        this.colStatus(h),
        this.colRuleId(h),
        this.colAction(h),
        this.colComment(h),
        this.colExpireTime(h),
        this.colCreateTime(h),
        this.colLastModifyTime(h),
        this.colOperations(h),
      ]) : null,
    ])
  }
}
