// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { userList } from '@/api/user'
import { tenantGroupList } from '@/api/tenant-group'
import { wafBindingList } from '@/api/binding'

@Component
export default class Dashboard extends Vue {
  userCount = 0
  groupCount = 0
  wafCount = 0
  siteCount = 0
  loading = false

  created() {
    this.loadStats()
  }

  async loadStats() {
    this.loading = true
    try {
      const [users, groups, wafs] = await Promise.all([
        userList(0, 1),
        tenantGroupList(0, 1),
        wafBindingList(0, 1000),
      ])
      this.userCount = users.err === null ? users.data.total : 0
      this.groupCount = groups.err === null ? groups.data.total : 0
      this.wafCount = wafs.err === null
        ? new Set(wafs.data.items.map((w: any) => w.captain_instance_id)).size
        : 0
    } catch {
      // silently fail
    } finally {
      this.loading = false
    }
  }

  render(h: any) {
    return (
      <div class="dashboard" v-loading={this.loading}>
        <h2>总览</h2>
        <el-row gutter={20}>
          <el-col span={6}>
            <el-card><div class="stat-value">{this.userCount}</div><div class="stat-label">用户数</div></el-card>
          </el-col>
          <el-col span={6}>
            <el-card><div class="stat-value">{this.groupCount}</div><div class="stat-label">租户组数</div></el-card>
          </el-col>
          <el-col span={6}>
            <el-card><div class="stat-value">{this.wafCount}</div><div class="stat-label">WAF 数</div></el-card>
          </el-col>
          <el-col span={6}>
            <el-card><div class="stat-value">{this.siteCount}</div><div class="stat-label">站点数</div></el-card>
          </el-col>
        </el-row>
      </div>
    )
  }
}
