// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import Grid from '@/components/Grid'
import { apiTokenCreate, apiTokenList, apiTokenDelete } from '@/api/api-token'
import { ColumnDef } from '@/components/Grid'
import { Condition } from '@/types/common'

@Component({ components: { Grid } })
export default class ApiToken extends Vue {
  showCreate = false
  tokenName = ''
  createdToken = ''
  columns: ColumnDef[] = [
    { key: 'id', title: 'ID', width: 80 },
    { key: 'name', title: '名称' },
    { key: 'created_at', title: '创建时间' },
  ]

  fetchData = (offset: number, count: number, conditions: Condition[]) => apiTokenList(offset, count, conditions)

  async handleCreate() {
    const resp = await apiTokenCreate(this.tokenName)
    if (resp.err === null) {
      this.createdToken = resp.data.token
      this.showCreate = false;
      (this.$refs.grid as any).loadData()
    }
  }

  async handleDelete(row: { id: number }) {
    await apiTokenDelete(row.id);
    (this.$refs.grid as any).loadData()
  }

  render(h: any) {
    return (
      <div>
        <el-button type="primary" style="margin-bottom: 16px" on-click={() => { this.tokenName = ''; this.createdToken = ''; this.showCreate = true }}>创建 Token</el-button>
        <Grid ref="grid" columns={[...this.columns, { key: 'actions', title: '操作', width: 100, render: (h: any, row: any) => (
          <el-button type="text" style="color: red" on-click={() => this.handleDelete(row)}>删除</el-button>
        )}]} fetchData={this.fetchData} />
        <el-dialog title="创建 API Token" visible={this.showCreate} on-close={() => { this.showCreate = false }}>
          <el-form label-width="80px">
            <el-form-item label="名称"><el-input v-model={this.tokenName} /></el-form-item>
          </el-form>
          <div slot="footer">
            <el-button on-click={() => { this.showCreate = false }}>取消</el-button>
            <el-button type="primary" on-click={this.handleCreate}>创建</el-button>
          </div>
        </el-dialog>
        {this.createdToken && (
          <el-dialog title="Token 已创建" visible={!!this.createdToken} on-close={() => { this.createdToken = '' }} width="500px">
            <el-alert title="请立即保存此 Token，关闭后将无法再次查看" type="warning" show-icon closable={false} style="margin-bottom: 16px" />
            <el-input value={this.createdToken} readonly type="textarea" rows={3} />
          </el-dialog>
        )}
      </div>
    )
  }
}
