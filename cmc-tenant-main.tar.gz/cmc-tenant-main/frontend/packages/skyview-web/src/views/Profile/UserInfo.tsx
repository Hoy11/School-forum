// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'

@Component
export default class UserInfo extends Vue {
  get user() {
    return this.$store.getters['user/currentUser']
  }

  render(h: any) {
    if (!this.user) return <div>未登录</div>
    const rows: [string, any][] = [
      ['用户名', this.user.username],
      ['角色', this.user.role],
      ['租户组', this.user.tenant_group_name || '-'],
      ['备注', this.user.remark || '-'],
    ]
    return (
      <div style="max-width: 600px">
        <h3>用户信息</h3>
        <div style="border: 1px solid #EBEEF5">
          {rows.map(([label, value]) => (
            <div style="display:flex;border-bottom:1px solid #EBEEF5;padding:12px 16px;line-height:24px">
              <div style="width:120px;flex-shrink:0;color:#909399;font-size:14px">{label}</div>
              <div style="flex:1;font-size:14px">{value}</div>
            </div>
          ))}
        </div>
      </div>
    )
  }
}
