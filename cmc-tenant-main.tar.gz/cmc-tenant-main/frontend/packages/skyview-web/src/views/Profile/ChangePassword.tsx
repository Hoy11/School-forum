// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { changePassword } from '@/api/current-user'

@Component
export default class ChangePassword extends Vue {
  oldPassword = ''
  newPassword = ''
  confirmPassword = ''
  saving = false
  errorMsg = ''

  async handleSubmit() {
    if (this.newPassword !== this.confirmPassword) {
      this.errorMsg = '两次密码输入不一致'
      return
    }
    this.saving = true
    this.errorMsg = ''
    try {
      const resp = await changePassword(this.oldPassword, this.newPassword, this.confirmPassword)
      if (resp.err !== null) {
        this.errorMsg = resp.msg
        return
      }
      this.$message.success('密码修改成功，请重新登录')
      this.$store.commit('user/clearUser')
      this.$router.push('/login')
    } catch (err) {
      this.errorMsg = err instanceof Error ? err.message : '修改失败'
    } finally {
      this.saving = false
    }
  }

  render(h: any) {
    return (
      <div style="max-width: 500px">
        <h3>修改密码</h3>
        <el-form label-width="120px">
          <el-form-item label="当前密码"><el-input v-model={this.oldPassword} type="password" /></el-form-item>
          <el-form-item label="新密码"><el-input v-model={this.newPassword} type="password" /></el-form-item>
          <el-form-item label="确认密码"><el-input v-model={this.confirmPassword} type="password" /></el-form-item>
          {this.errorMsg && <el-alert title={this.errorMsg} type="error" show-icon closable={false} style="margin-bottom: 16px" />}
          <el-form-item><el-button type="primary" loading={this.saving} on-click={this.handleSubmit}>修改密码</el-button></el-form-item>
        </el-form>
      </div>
    )
  }
}
