// @ts-nocheck
import { Component, Vue } from 'vue-property-decorator'
import { login } from '@/api/auth'
import { changePassword } from '@/api/current-user'

@Component
export default class Login extends Vue {
  username = ''
  password = ''
  loading = false
  errorMsg = ''
  showChangePwd = false
  newPwd = ''
  confirmPwd = ''
  changePwdLoading = false

  async handleLogin() {
    if (!this.username || !this.password) {
      this.errorMsg = '请输入用户名和密码'
      return
    }
    this.loading = true
    this.errorMsg = ''
    try {
      const resp = await login({ username: this.username, password: this.password })
      if (resp.err !== null) {
        this.errorMsg = resp.msg
        return
      }
      const data = resp.data
      const user = { id: data.id, username: data.username, role: data.role }
      const needChangePassword = !!data.need_change_password
      this.$store.commit('user/setUser', { user, needChangePassword })
      if (needChangePassword) {
        this.showChangePwd = true
        return
      }
      this.$router.push({ name: 'detectLog' })
    } catch (err) {
      this.errorMsg = err instanceof Error ? err.message : '登录失败'
    } finally {
      this.loading = false
    }
  }

  async handleChangePwd() {
    if (!this.newPwd || this.newPwd !== this.confirmPwd) {
      this.errorMsg = '密码不匹配'
      return
    }
    this.changePwdLoading = true
    try {
      const resp = await changePassword(this.password, this.newPwd, this.confirmPwd)
      if (resp.err !== null) {
        this.errorMsg = resp.msg
        return
      }
      this.showChangePwd = false
      this.errorMsg = ''
      this.$store.commit('user/setUser', {
        user: this.$store.getters['user/currentUser'],
        needChangePassword: false
      })
      this.$router.push({ name: 'detectLog' })
    } catch (err) {
      this.errorMsg = err instanceof Error ? err.message : '修改密码失败'
    } finally {
      this.changePwdLoading = false
    }
  }

  render(h: any) {
    return (
      <div class="login-page">
        <div class="login-box">
          <h2 class="login-title">CMC 多租户管理平台</h2>
          <el-form on-submit-native-prevent={this.handleLogin}>
            <el-form-item>
              <el-input v-model={this.username} placeholder="用户名" prefix-icon="el-icon-user" />
            </el-form-item>
            <el-form-item>
              <el-input v-model={this.password} type="password" placeholder="密码" prefix-icon="el-icon-lock" />
            </el-form-item>
            {this.errorMsg && <div class="login-error">{this.errorMsg}</div>}
            <el-form-item>
              <el-button type="primary" loading={this.loading} on-click={this.handleLogin} style="width: 100%">
                登录
              </el-button>
            </el-form-item>
          </el-form>
        </div>
        <el-dialog title="首次登录，请修改密码" visible={this.showChangePwd} on-close={() => { this.showChangePwd = false }} width="400px">
          <el-form>
            <el-form-item label="新密码">
              <el-input v-model={this.newPwd} type="password" />
            </el-form-item>
            <el-form-item label="确认密码">
              <el-input v-model={this.confirmPwd} type="password" />
            </el-form-item>
          </el-form>
          <div slot="footer">
            <el-button type="primary" loading={this.changePwdLoading} on-click={this.handleChangePwd}>
              确认修改
            </el-button>
          </div>
        </el-dialog>
      </div>
    )
  }
}
