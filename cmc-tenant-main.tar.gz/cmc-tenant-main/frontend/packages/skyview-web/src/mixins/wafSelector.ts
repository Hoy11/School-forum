import { Vue } from 'vue-property-decorator'
import { wafBindingList } from '@/api/binding'
import { WafBindingWithInfo } from '@/types/tenant'

const OPERABLE_STATUSES = ['HEALTHY', 'UNHEALTHY', 'ONLINE']
const OFFLINE_STATUSES = ['OFFLINE', 'DOWN']
const emptyPageResp = { err: null, msg: 'success', data: { total: 0, items: [] } }

function normalizeWafStatus(status?: string): string {
  return String(status || '').trim().toUpperCase().replace(/[\s_-]+/g, '')
}

export function isWafStatusOffline(status?: string): boolean {
  const normalized = normalizeWafStatus(status)
  return OFFLINE_STATUSES.includes(normalized)
}

export function isWafStatusOperable(status?: string): boolean {
  return OPERABLE_STATUSES.includes(normalizeWafStatus(status))
}

function isActiveWafBinding(waf: WafBindingWithInfo): boolean {
  if (waf.status && waf.status !== 'active') return false
  return !!waf.instance_name && !!waf.instance_host
}

export const WafSelectorMixin = Vue.extend({
  data() {
    return {
      selectedWafId: 0 as number,
      wafOptions: [] as WafBindingWithInfo[],
      wafReady: false,
      offlineWarnedWafId: 0 as number,
    }
  },
  computed: {
    effectiveWafId(): number {
      return this.selectedWafId
    },
    selectedWaf(): WafBindingWithInfo | null {
      return this.wafOptions.find(w => w.captain_instance_id === this.selectedWafId) || null
    },
    isWafOffline(): boolean {
      return isWafStatusOffline(this.selectedWaf?.instance_status)
    },
    isWafDisabled(): boolean {
      return this.selectedWaf?.is_enabled === false || normalizeWafStatus(this.selectedWaf?.instance_status) === ''
    },
    isWafUnavailable(): boolean {
      const waf = this.selectedWaf
      if (!waf) return false
      return this.isWafDisabled || !isWafStatusOperable(waf.instance_status)
    },
    wafOfflineMessage(): string {
      const waf = this.selectedWaf
      const name = waf?.instance_name || '当前 WAF'
      if ((this as any).isWafDisabled) return `${name} 处于禁用状态，无法操作`
      if ((this as any).isWafOffline) return `${name} 处于离线状态，无法操作`
      const status = waf?.instance_status || '未知'
      return `${name} 状态为 ${status}，无法操作`
    },
  },
  methods: {
    emptyWafPage() {
      return Promise.resolve(emptyPageResp)
    },
    showWafOfflineMessage() {
      if (!(this as any).isWafUnavailable || !this.selectedWafId) return
      if (this.offlineWarnedWafId === this.selectedWafId) return
      this.offlineWarnedWafId = this.selectedWafId
      const self = this as any
      self.$message.warning(self.wafOfflineMessage)
    },
    ensureWafOperable(): boolean {
      if (!(this as any).isWafUnavailable) return true
      const self = this as any
      self.$message.warning(self.wafOfflineMessage)
      return false
    },
    renderWafOfflineAlert(h: any) {
      if (!(this as any).isWafUnavailable) return null
      return h('el-alert', {
        props: {
          title: (this as any).wafOfflineMessage,
          type: 'warning',
          closable: false,
          showIcon: true,
        },
        style: { marginBottom: '16px' },
      })
    },
    formatWafOptionLabel(waf: WafBindingWithInfo): string {
      const status = waf.is_enabled === false
        ? ' - 禁用'
        : isWafStatusOperable(waf.instance_status)
          ? ''
          : ` - ${waf.instance_status || '禁用'}`
      return `${waf.instance_name} (${waf.instance_host})${status}`
    },
  },
  async created() {
    const resp = await wafBindingList(0, 1000)
    if (resp.err === null) {
      this.wafOptions = resp.data.items.filter(
        (w, i, arr) => isActiveWafBinding(w) && arr.findIndex(x => x.captain_instance_id === w.captain_instance_id) === i
      )
      const routeWaf = Number((this as any).$route.query.waf || 0)
      if (routeWaf > 0 && this.wafOptions.some(w => w.captain_instance_id === routeWaf)) {
        this.selectedWafId = routeWaf
      } else if (this.wafOptions.length > 0) {
        this.selectedWafId = this.wafOptions[0].captain_instance_id
      }
      this.wafReady = true
      // After WAF is selected, reload grid data
      this.$nextTick(() => {
        const self = this as any
        self.showWafOfflineMessage()
        const grid = self.$refs.grid
        if (grid) grid.loadData()
      })
    }
  },
  watch: {
    selectedWafId() {
      this.offlineWarnedWafId = 0
    },
  },
})
