import { listQuery, listQueryGet, post, del, get, put } from '@/api'
import { SocConfig, CreateSocReq, UpdateSocReq } from '@/types/soc'
import { PasswordConfig, LoginSecurityConfig, HighlightTag } from '@/types/system'
import { Condition, PageResult } from '@/types/common'

export function socList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<SocConfig>('/api/system/soc/list', offset, count, conditions)
}

export function socCreate(data: CreateSocReq) {
  return post<SocConfig>('/api/system/soc/create', data)
}

export function socUpdate(data: UpdateSocReq) {
  return put<null>('/api/system/soc/update', data)
}

export function socDelete(id: number) {
  return del<null>('/api/system/soc/delete', { id })
}

export function socTest(id: number) {
  return post<null>('/api/system/soc/test', { id })
}

export function captainConfigGet() {
  return get<{ host: string; api_token: string; source: string }>('/api/system/captain')
}

export function auditList(offset: number, count: number, conditions: Condition[] = []) {
  return listQuery<unknown>('/api/system/audit/list', offset, count, conditions)
}

export function passwordConfigGet() {
  return get<PasswordConfig>('/api/system/password-config')
}

export function passwordConfigUpdate(data: PasswordConfig) {
  return put<null>('/api/system/password-config', data)
}

export function loginSecurityGet() {
  return get<LoginSecurityConfig>('/api/system/login-security')
}

export function loginSecurityUpdate(data: LoginSecurityConfig) {
  return put<null>('/api/system/login-security', data)
}

export function highlightTagGet() {
  return get<HighlightTag[]>('/api/system/highlight-tag')
}

export function highlightTagUpdate(tags: HighlightTag[]) {
  return put<null>('/api/system/highlight-tag', { tags })
}
