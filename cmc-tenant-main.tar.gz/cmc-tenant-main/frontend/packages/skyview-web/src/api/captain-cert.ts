import { post, del, upload, get, put } from '@/api'
import { Condition, PageResult } from '@/types/common'

export interface CertWebsite {
  id: number
  name: string
  server_names?: string[]
  create_time?: string
}

export interface CertDetailInfo {
  serial: string
  issuer: string
  domains: string[]
  not_valid_before: number
  not_valid_after: number
}

export interface CertInfo {
  id: number
  name: string
  captain_instance_id: number
  binding_count: number
  info: CertDetailInfo
  websites: CertWebsite[]
  is_mgt_api_cert: boolean
  create_time: number
  type: number
  file_names: string[]
  signature: string
  password: string
  has_external_ref?: boolean
  source?: string
  is_system_cert?: boolean
  shared_group_names?: string[]
}

export function certList(captainInstanceId: number, offset: number, count: number, conditions: Condition[] = []) {
  return get<PageResult<CertInfo>>('/api/captain/cert/list', {
    captain_instance_id: captainInstanceId,
    offset,
    count,
    conditions: JSON.stringify(conditions),
  })
}

export function certDetail(id: number, captainInstanceId: number) {
  return get<CertInfo>('/api/captain/cert/detail', { id, captain_instance_id: captainInstanceId })
}

export function certUpload(captainInstanceId: number, formData: FormData) {
  formData.append('captain_instance_id', String(captainInstanceId))
  return upload<CertInfo>(`/api/captain/cert/upload?captain_instance_id=${captainInstanceId}`, formData)
}

export function certUpdate(data: { id: number; captain_instance_id: number; name?: string; comment?: string }) {
  return put<null>('/api/captain/cert/update', data)
}

export function certEdit(captainInstanceId: number, formData: FormData) {
  formData.append('captain_instance_id', String(captainInstanceId))
  return upload<CertInfo>(`/api/captain/cert/edit?captain_instance_id=${captainInstanceId}`, formData)
}

export function certDelete(id: number, captainInstanceId: number) {
  return del<null>('/api/captain/cert/delete', { id, captain_instance_id: captainInstanceId })
}
