import { listQuery, post, del, put } from '@/api'
import { User, CreateUserReq, UpdateUserReq, CredentialResp } from '@/types/users'
import { Condition, PageResult } from '@/types/common'

export function userList(offset: number, count: number, conditions: Condition[] = []) {
  return listQuery<User>('/api/user/list', offset, count, conditions)
}

export function userCreate(data: CreateUserReq) {
  return post<User>('/api/user/create', data)
}

export function userUpdate(data: UpdateUserReq) {
  return put<null>('/api/user/update', data)
}

export function userEnable(id: number) {
  return put<null>('/api/user/enable', { id })
}

export function userDisable(id: number) {
  return put<null>('/api/user/disable', { id })
}

export function userCredential(id: number) {
  return put<CredentialResp>('/api/user/credential', { id })
}

export function userUnlock(id: number) {
  return put<null>('/api/user/unlock', { ids: [id] })
}

export function userDelete(id: number) {
  return del<null>('/api/user/delete', { id })
}
