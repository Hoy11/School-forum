const captainPathMap: Record<string, string> = {
  '/api/SoftwareReverseProxyWebsiteAPI': '/api/captain/site/list',
  '/api/IPGroupAPI': '/api/captain/ip-group/list',
  '/api/CertAPI': '/api/captain/cert/list',
  '/api/PolicyGroupAPI': '/api/captain/policy/list',
  '/api/CustomRuleAPI': '/api/captain/policy-rule/list',
  '/api/DetectLogAPI': '/api/captain/detect-log/list',
  '/api/AclLogAPI': '/api/captain/acl-log/list',
  '/api/BotLogRecordAPI': '/api/captain/bot-log/record/list',
  '/api/BotLogResultAPI': '/api/captain/bot-log/result/list',
  '/api/LogTaskAPI': '/api/captain/log-task/list',
  '/api/FlagAPI': '/api/captain/mark_flag',
  '/api/FilterAPI': '/api/captain/filter/list',
  '/api/GlobalPolicyConfigAPI': '/api/captain/policy/global-config',
}

export function captainPath(originalPath: string): string {
  return captainPathMap[originalPath] || originalPath
}
