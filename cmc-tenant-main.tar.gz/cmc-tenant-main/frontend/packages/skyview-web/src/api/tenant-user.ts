import { listQuery, post, put, del } from '@/api'
import { User, CredentialResp } from '@/types/users'
import { Condition, PageResult } from '@/types/common'

export function tenantUserList(offset: number, count: number, conditions: Condition[] = []) {
  return listQuery<User>('/api/tenant/user/list', offset, count, conditions)
}

export function tenantUserCreate(data: { username: string; password: string; remark?: string }) {
  return post<User>('/api/tenant/user/create', data)
}

export function tenantUserEnable(id: number) {
  return put<null>('/api/tenant/user/enable', { id })
}

export function tenantUserDisable(id: number) {
  return put<null>('/api/tenant/user/disable', { id })
}

export function tenantUserCredential(id: number) {
  return put<CredentialResp>('/api/tenant/user/credential', { id })
}

export function tenantUserUnlock(id: number) {
  return put<null>('/api/tenant/user/unlock', { ids: [id] })
}

export function tenantUserDelete(id: number) {
  return del<null>('/api/tenant/user/delete', { id })
}
