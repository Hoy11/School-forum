import { post, put, del, get } from '@/api'
import { IPGroup } from '@/types/ip-group'
import { Condition, PageResult } from '@/types/common'

export function ipGroupList(captainInstanceId: number, offset: number, count: number, conditions: Condition[] = []) {
  return get<PageResult<IPGroup>>('/api/captain/ip-group/list', {
    captain_instance_id: captainInstanceId,
    offset,
    count,
    conditions: JSON.stringify(conditions),
  })
}

export function ipGroupCreate(data: { name: string; comment?: string; captain_instance_id: number }) {
  return post<IPGroup>('/api/captain/ip-group/create', data)
}

export function ipGroupUpdate(data: { id: number; name?: string; comment?: string; captain_instance_id: number }) {
  return put<null>('/api/captain/ip-group/update', data)
}

export function ipGroupDelete(id: number, captainInstanceId: number) {
  return del<null>('/api/captain/ip-group/delete', { id, captain_instance_id: captainInstanceId })
}

export function ipGroupItemAdd(id: number, captainInstanceId: number, targets: string[]) {
  return post<IPGroup>('/api/captain/ip-group/item/add', { id, captain_instance_id: captainInstanceId, targets })
}

export function ipGroupItemDelete(id: number, captainInstanceId: number, targets: string[]) {
  return post<null>('/api/captain/ip-group/item/delete', { id, captain_instance_id: captainInstanceId, targets })
}
