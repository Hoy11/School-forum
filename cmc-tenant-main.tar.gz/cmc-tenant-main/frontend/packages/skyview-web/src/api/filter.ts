import { listQueryGet, post, put, del } from '@/api'
import { FilterSave } from '@/types/filter'
import { Condition, PageResult } from '@/types/common'

export function filterList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<FilterSave>('/api/captain/filter/list', offset, count, conditions)
}

export function filterCreate(data: { name: string; filter: unknown }) {
  return post<FilterSave>('/api/captain/filter/create', data)
}

export function filterUpdate(data: { id: number; name?: string; filter?: unknown }) {
  return put<null>('/api/captain/filter/update', data)
}

export function filterDelete(id: number) {
  return del<null>('/api/captain/filter/delete', { id })
}
