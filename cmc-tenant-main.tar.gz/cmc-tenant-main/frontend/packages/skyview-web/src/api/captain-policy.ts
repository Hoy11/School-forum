import { listQueryGet, post, del, get, put } from '@/api'
import { PolicyModel, PolicyGroup, GlobalPolicyConfig, PolicyModuleConfig } from '@/types/policy'
import { Condition, PageResult } from '@/types/common'

export function policyList(captainInstanceId: number, offset: number, count: number, conditions: Condition[] = []) {
  return get<PageResult<PolicyGroup>>('/api/captain/policy/list', {
    captain_instance_id: captainInstanceId,
    offset,
    count,
    conditions: JSON.stringify(conditions),
  })
}

export function policyDetail(id: number, captainInstanceId: number) {
  return get<PolicyModel>('/api/captain/policy/detail', { id, captain_instance_id: captainInstanceId })
}

export function policyCreate(data: { name: string; comment?: string; captain_instance_id: number }) {
  return post<PolicyGroup>('/api/captain/policy/create', data)
}

export function policyUpdate(data: PolicyModel & { captain_instance_id: number }) {
  return put<null>('/api/captain/policy/update', data)
}

export function policyDelete(id: number, captainInstanceId: number) {
  return del<null>('/api/captain/policy/delete', { id, captain_instance_id: captainInstanceId })
}

export function globalPolicyConfigGet(captainInstanceId: number) {
  return get<GlobalPolicyConfig>('/api/captain/policy/global-config', { captain_instance_id: captainInstanceId })
}

export function globalPolicyConfigUpdate(captainInstanceId: number, config: GlobalPolicyConfig) {
  return put<null>('/api/captain/policy/global-config', { captain_instance_id: captainInstanceId, ...config })
}
