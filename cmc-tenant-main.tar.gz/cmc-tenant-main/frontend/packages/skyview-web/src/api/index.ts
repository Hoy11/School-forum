import { request } from './client'
import { HttpResponse } from './client/resp'
import { Condition, PageResult } from '@/types/common'

export function get<T = unknown>(url: string, params?: Record<string, unknown>): Promise<HttpResponse<T>> {
  return request<T>({ method: 'GET', url, params })
}

export function post<T = unknown>(url: string, data?: unknown): Promise<HttpResponse<T>> {
  return request<T>({ method: 'POST', url, data })
}

export function put<T = unknown>(url: string, data?: unknown): Promise<HttpResponse<T>> {
  return request<T>({ method: 'PUT', url, data })
}

export function del<T = unknown>(url: string, data?: unknown): Promise<HttpResponse<T>> {
  return request<T>({ method: 'DELETE', url, data })
}

export function upload<T = unknown>(url: string, formData: FormData): Promise<HttpResponse<T>> {
  return request<T>({
    method: 'POST',
    url,
    data: formData,
    headers: { 'Content-Type': 'multipart/form-data' }
  })
}

export async function download(url: string, params?: Record<string, unknown>): Promise<void> {
  const resp = await request<Blob>({
    method: 'POST',
    url,
    params,
    responseType: 'blob'
  })
  if (resp.data instanceof Blob) {
    const blobUrl = URL.createObjectURL(resp.data)
    const a = document.createElement('a')
    a.href = blobUrl
    a.download = 'download'
    a.click()
    URL.revokeObjectURL(blobUrl)
  }
}

export function listQuery<T = unknown>(
  url: string,
  offset: number,
  count: number,
  conditions: Condition[] = []
): Promise<HttpResponse<PageResult<T>>> {
  return post<PageResult<T>>(url, { offset, count, conditions })
}

export function listQueryGet<T = unknown>(
  url: string,
  offset: number,
  count: number,
  conditions: Condition[] = []
): Promise<HttpResponse<PageResult<T>>> {
  return get<PageResult<T>>(url, { offset, count, conditions: JSON.stringify(conditions) })
}
