import { listQueryGet, post, del, put, get, upload } from '@/api'
import { Website, CreateWebsiteReq, SSLCertModel, PolicyModel, NodeStatus, AssetGroupType, WorkGroupModel } from '@/types/website'
import { Condition, PageResult } from '@/types/common'

// === Site CRUD ===

export function siteList(captainInstanceId: number, offset: number, count: number, conditions: Condition[] = []) {
  return get<PageResult<Website>>('/api/captain/site/list', {
    captain_instance_id: captainInstanceId,
    offset,
    count,
    conditions: JSON.stringify(conditions),
  })
}

export function siteDetail(id: number, captainInstanceId: number) {
  return get<Website>('/api/captain/site/detail', { id, captain_instance_id: captainInstanceId })
}

export function siteCreate(data: CreateWebsiteReq) {
  return post<Website>('/api/captain/site', data)
}

export function siteUpdate(data: Partial<Website> & { id: number; captain_instance_id: number }) {
  return put<null>('/api/captain/site', data)
}

export function siteDelete(id: number, captainInstanceId: number) {
  return del<null>('/api/captain/site', { id__in: [id], captain_instance_id: captainInstanceId })
}

export function siteBatchDelete(ids: number[], captainInstanceId: number) {
  return del<null>('/api/captain/site', { id__in: ids, captain_instance_id: captainInstanceId })
}

// === Auxiliary Data ===

export function sitePolicyList(captainInstanceId: number) {
  return get<PolicyModel[]>('/api/captain/site/aux/policy-list', { captain_instance_id: captainInstanceId })
}

export function siteCertList(captainInstanceId: number) {
  return get<SSLCertModel[]>('/api/captain/site/aux/cert-list', { captain_instance_id: captainInstanceId })
}

export function siteNodeList(captainInstanceId: number) {
  return get<NodeStatus[]>('/api/captain/site/aux/node-list', { captain_instance_id: captainInstanceId })
}

export function siteAssetGroupList(captainInstanceId: number) {
  return get<AssetGroupType[]>('/api/captain/site/aux/asset-group-list', { captain_instance_id: captainInstanceId })
}

export function siteWorkGroupList(captainInstanceId: number) {
  return get<WorkGroupModel[]>('/api/captain/site/aux/work-group-list', { captain_instance_id: captainInstanceId })
}

export function siteWorkGroupIpList(captainInstanceId: number, workGroupName: string) {
  return get<{ addr: string }[]>('/api/captain/site/aux/work-group-ips', {
    captain_instance_id: captainInstanceId,
    name: workGroupName,
  })
}

export function siteLinkIpList(captainInstanceId: number) {
  return get<any[]>('/api/captain/site/aux/link-ip-list', {
    captain_instance_id: captainInstanceId,
  })
}

// === File Upload ===

export function siteCertUpload(captainInstanceId: number, formData: FormData) {
  formData.append('captain_instance_id', String(captainInstanceId))
  return upload<{ id: number }>(`/api/captain/site/cert-upload?captain_instance_id=${captainInstanceId}`, formData)
}

export function siteResponseUpload(captainInstanceId: number, formData: FormData) {
  formData.append('captain_instance_id', String(captainInstanceId))
  return upload<{ path: string }>(`/api/captain/site/response-upload?captain_instance_id=${captainInstanceId}`, formData)
}

export function cookieGenerateKey(captainInstanceId: number) {
  return get<{ key: string }>('/api/captain/site/cookie/generate-key', { captain_instance_id: captainInstanceId })
}
