import { post, put, del, get } from '@/api'
import { PolicyRule, AntiTamperRule } from '@/types/policy'
import { Condition, PageResult } from '@/types/common'

export function ruleList(captainInstanceId: number, offset: number, count: number, conditions: Condition[] = [], ruleType?: string) {
  const params: any = {
    captain_instance_id: captainInstanceId,
    is_global: 'false',
    offset,
    count,
    conditions: JSON.stringify(conditions),
  }
  if (ruleType) params.rule_type = ruleType
  return get<PageResult<PolicyRule>>('/api/captain/policy-rule/list', params)
}

export function ruleCreate(data: Partial<PolicyRule> & { captain_instance_id: number }) {
  return post<PolicyRule>('/api/captain/policy-rule/create', data)
}

export function ruleUpdate(data: Partial<PolicyRule> & { id: number; captain_instance_id: number }) {
  return put<null>('/api/captain/policy-rule/update', data)
}

export function ruleDelete(id: number, captainInstanceId: number) {
  return del<null>('/api/captain/policy-rule/delete', { id, captain_instance_id: captainInstanceId })
}

export function ruleEnable(ids: number[], captainInstanceId: number, action: 'enable' | 'disable') {
  return put<null>('/api/captain/policy-rule/enable', { ids, captain_instance_id: captainInstanceId, action })
}

export function ruleModule(id: number, captainInstanceId: number, module: string) {
  return post<null>('/api/captain/policy-rule/module', { id, captain_instance_id: captainInstanceId, module })
}

export function ruleSkynetRule(id: number, captainInstanceId: number, body: any) {
  return put<null>('/api/captain/policy-rule/skynet-rule', { id, captain_instance_id: captainInstanceId, ...body })
}

export function rulePriority(captainInstanceId: number, website: number | null, policyRuleIds: number[]) {
  return put<null>('/api/captain/policy-rule/priority', { captain_instance_id: captainInstanceId, website, policy_rule_ids: policyRuleIds })
}

export function ruleBind(captainInstanceId: number, website: number, policyRuleIds: number[]) {
  return put<null>('/api/captain/policy-rule/bind', { captain_instance_id: captainInstanceId, website, policy_rule_ids: policyRuleIds })
}

export function ruleUnbind(captainInstanceId: number, website: number, policyRule: number) {
  return del<null>('/api/captain/policy-rule/unbind', { captain_instance_id: captainInstanceId, website, policy_rule: policyRule })
}

export function getDetectionModules(captainInstanceId: number) {
  return get<any>('/api/captain/policy-rule/detection-modules', { captain_instance_id: captainInstanceId })
}

export function getSkynetRules(captainInstanceId: number) {
  return get<any[]>('/api/captain/policy-rule/skynet-rules', { captain_instance_id: captainInstanceId })
}

export function antiTamperRuleList(captainInstanceId: number, offset = 0, count = 100, conditions: Condition[] = []) {
  return get<PageResult<AntiTamperRule>>('/api/captain/anti-tamper/list', {
    captain_instance_id: captainInstanceId,
    offset,
    count,
    conditions: JSON.stringify(conditions),
  })
}
