import { post } from '@/api'

export function socReport(data: { log_type: string; log_id: string | number }) {
	return post<null>('/api/soc/report', data)
}
