import { listQueryGet, post, del, get } from '@/api'
import { WafBindingWithInfo, SiteBindingWithInfo, AvailableWaf, AvailableSite } from '@/types/tenant'
import { Condition, PageResult } from '@/types/common'

export function wafBindingList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<WafBindingWithInfo>('/api/binding/waf/list', offset, count, conditions)
}

export function wafBindingCreate(data: { tenant_group_id: number; captain_instance_ids: number[] }) {
  return post<null>('/api/binding/waf/create', data)
}

export function wafBindingDelete(id: number) {
  return del<null>('/api/binding/waf/delete', { ids: [id] })
}

export function wafBindingAvailable(tenantGroupId: number) {
  return get<AvailableWaf[]>('/api/binding/waf/available', { tenant_group_id: tenantGroupId })
}

export function siteBindingList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<SiteBindingWithInfo>('/api/binding/site/list', offset, count, conditions)
}

export function siteBindingCreate(data: { tenant_group_id: number; captain_instance_id: number; site_ids: number[] }) {
  return post<null>('/api/binding/site/create', data)
}

export function siteBindingDelete(id: number) {
  return del<null>('/api/binding/site/delete', { ids: [id] })
}

export function siteBindingAvailable(tenantGroupId: number, captainInstanceId: number) {
  return get<AvailableSite[]>('/api/binding/site/available', {
    tenant_group_id: tenantGroupId,
    captain_instance_id: captainInstanceId
  })
}

export function siteBindingResync(bindingId: number) {
  return post<{ synced: number }>('/api/binding/site/resync_one', { id: bindingId })
}
