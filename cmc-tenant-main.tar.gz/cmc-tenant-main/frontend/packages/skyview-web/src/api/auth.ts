import { post, get } from '@/api'
import { LoginReq, LoginResp, User } from '@/types/users'

export function login(data: LoginReq) {
  return post<LoginResp>('/api/auth/login', data)
}

export function logout() {
  return post<null>('/api/auth/logout')
}

export function current() {
  return get<User>('/api/auth/current')
}
