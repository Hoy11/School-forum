import { put } from '@/api'

export function changePassword(oldPassword: string, newPassword: string, dupPassword: string) {
  return put<null>('/api/user/current/password', {
    old_password: oldPassword,
    new_password: newPassword,
    dup_password: dupPassword
  })
}
