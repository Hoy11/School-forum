import { listQueryGet, post, del, put } from '@/api'
import client from '@/api/client'
import { LogTask, DownloadLogOptions } from '@/types/log'
import { Condition, PageResult } from '@/types/common'

export function logTaskCreate(data: DownloadLogOptions) {
  return post<null>('/api/captain/log-task/create', data)
}

export function logTaskList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<LogTask>('/api/captain/log-task/list', offset, count, conditions)
}

export function logTaskCancel(id: number) {
  return put<null>(`/api/captain/log-task/${id}/cancel`)
}

export function logTaskDelete(ids: number[]) {
  return del<null>('/api/captain/log-task/delete', { ids })
}

export async function logTaskDownload(id: number): Promise<Blob> {
  const resp = await client.post(`/api/captain/log-task/${id}/download`, undefined, {
    responseType: 'blob',
  })
  return resp.data
}
