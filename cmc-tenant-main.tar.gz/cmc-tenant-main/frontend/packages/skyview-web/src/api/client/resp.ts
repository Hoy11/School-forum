export interface HttpResponse<T = unknown> {
  err: string | null
  msg: string
  data: T
}

export type SuccessResp<T = unknown> = HttpResponse<T> & { err: null }

export interface ErrorResp {
  err: string
  msg: string
  data: string
}
