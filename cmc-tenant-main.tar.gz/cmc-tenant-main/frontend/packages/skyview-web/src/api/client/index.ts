import axios, { AxiosInstance, AxiosRequestConfig } from 'axios'
import { HttpResponse } from './resp'
import { networkError } from './processer'

let isRedirecting = false

const client: AxiosInstance = axios.create({
  baseURL: '/',
  withCredentials: true,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

client.interceptors.response.use(
  (response) => response,
  async (err) => {
    if (err.response && err.response.status === 401) {
      if (window.location.pathname !== '/login' && !isRedirecting) {
        isRedirecting = true
        try {
          const { current } = await import('@/api/auth')
          const resp = await current()
          if (resp.err === null) {
            const store = (await import('@/store')).default
            store.commit('user/setUser', { user: resp.data, needChangePassword: false })
            // Only retry once to prevent infinite loop
            if (!err.config.__isRetry) {
              err.config.__isRetry = true
              isRedirecting = false
              return client.request(err.config)
            }
          } else {
            window.location.href = '/login'
          }
        } catch {
          window.location.href = '/login'
        }
        isRedirecting = false
        return Promise.reject(err)
      }
      return Promise.reject(err)
    }
    return Promise.reject(err)
  }
)

export async function request<T = unknown>(config: AxiosRequestConfig): Promise<HttpResponse<T>> {
  try {
    const resp = await client.request<HttpResponse<T>>(config)
    return resp.data
  } catch (err) {
    const error = new Error(networkError(err)) as Error & { response?: unknown }
    if (err && typeof err === 'object' && 'response' in err) {
      error.response = (err as { response: unknown }).response
    }
    throw error
  }
}

export default client
