import { HttpResponse } from './resp'

export function success<T>(resp: HttpResponse<T>): resp is HttpResponse<T> & { err: null } {
  return resp.err === null
}

export function error(resp: HttpResponse): string {
  return resp.msg || resp.err || '未知错误'
}

export function networkError(err: unknown): string {
  if (err && typeof err === 'object' && 'response' in err) {
    const resp = (err as { response: { status: number; headers?: Record<string, string>; data?: { msg?: string } } }).response
    if (resp.status === 429) {
      const retryAfter = resp.headers?.['retry-after']
      const secs = retryAfter ? parseInt(retryAfter, 10) : 30
      return `操作过于频繁，请 ${secs}s 后重试`
    }
    return resp.data?.msg || `请求失败 (${resp.status})`
  }
  return '网络错误，请检查网络连接'
}
