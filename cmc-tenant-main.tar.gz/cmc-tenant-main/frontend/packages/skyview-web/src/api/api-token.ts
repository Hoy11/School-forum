import { post, listQueryGet, del } from '@/api'
import { Condition, PageResult } from '@/types/common'

export interface ApiToken {
  id: number
  name: string
  token: string
  created_at: string
}

export function apiTokenCreate(name: string) {
  return post<ApiToken>('/api/user/api_token/create', { name })
}

export function apiTokenList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<ApiToken>('/api/user/api_token/list', offset, count, conditions)
}

export function apiTokenDelete(id: number) {
  return del<null>('/api/user/api_token/delete', { id })
}
