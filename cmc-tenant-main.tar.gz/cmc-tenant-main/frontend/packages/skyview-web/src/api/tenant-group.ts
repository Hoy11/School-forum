import { listQueryGet, post, put, del } from '@/api'
import { TenantGroup, CreateTenantGroupReq } from '@/types/tenant'
import { Condition, PageResult } from '@/types/common'

export function tenantGroupList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<TenantGroup>('/api/tenant-group/list', offset, count, conditions)
}

export function tenantGroupCreate(data: CreateTenantGroupReq) {
  return post<TenantGroup>('/api/tenant-group/create', data)
}

export function tenantGroupUpdate(data: { id: number; name?: string; comment?: string }) {
  return put<null>('/api/tenant-group/update', data)
}

export function tenantGroupDelete(id: number) {
  return del<null>('/api/tenant-group/delete', { ids: [id] })
}
