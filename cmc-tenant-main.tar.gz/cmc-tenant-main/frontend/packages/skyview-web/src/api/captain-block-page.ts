import { get, del, upload } from '@/api'
import { Condition, PageResult } from '@/types/common'
import { BlockPageInfo } from '@/types/block-page'

export function blockPageList(captainInstanceId: number, offset: number, count: number, conditions: Condition[] = []) {
  return get<PageResult<BlockPageInfo>>('/api/captain/block-page/list', {
    captain_instance_id: captainInstanceId,
    offset,
    count,
    conditions: JSON.stringify(conditions),
  })
}

export function blockPageUpload(captainInstanceId: number, formData: FormData) {
  formData.append('captain_instance_id', String(captainInstanceId))
  return upload<{ path: string }>(`/api/captain/block-page/upload?captain_instance_id=${captainInstanceId}`, formData)
}

export function blockPageDelete(name: string, captainInstanceId: number, confirmToken?: string) {
  const url = confirmToken
    ? `/api/captain/block-page/delete?confirm_token=${encodeURIComponent(confirmToken)}`
    : '/api/captain/block-page/delete'
  return del<null>(url, {
    name,
    captain_instance_id: captainInstanceId,
  })
}

export function blockPageDownload(name: string, captainInstanceId: number) {
  window.open(`/api/captain/block-page/download?name=${encodeURIComponent(name)}&captain_instance_id=${captainInstanceId}`, '_blank')
}
