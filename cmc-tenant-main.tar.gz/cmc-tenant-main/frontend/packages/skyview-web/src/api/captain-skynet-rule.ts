import { put, get } from '@/api'
import { SkynetRule } from '@/types/policy'
import { PageResult } from '@/types/common'

export function skynetRuleList(captainInstanceId: number, offset: number, count: number, policyGroupId?: number) {
  const params: Record<string, any> = {
    captain_instance_id: captainInstanceId,
    offset,
    count,
  }
  if (policyGroupId != null) {
    params.policy_group__in = policyGroupId
  }
  return get<PageResult<SkynetRule>>('/api/captain/skynet-rule/list', params)
}

export function skynetRuleUpdate(data: Partial<SkynetRule> & { id: number; captain_instance_id: number }) {
  return put<null>('/api/captain/skynet-rule/update', data)
}
