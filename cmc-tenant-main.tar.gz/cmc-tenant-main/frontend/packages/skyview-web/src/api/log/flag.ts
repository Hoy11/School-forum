import { get, put } from '@/api'
import { Flag } from '@/types/flag'

export function markFlagGet() {
  return get<Flag[]>('/api/captain/mark_flag')
}

export function markFlagUpdate(flags: Flag[]) {
  return put<null>('/api/captain/mark_flag', { flags })
}
