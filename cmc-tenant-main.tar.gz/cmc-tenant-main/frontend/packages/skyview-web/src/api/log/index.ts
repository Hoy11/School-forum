import { listQuery, post, get } from '@/api'
import { DetectLog, DetectLogDetail } from '@/types/detect'
import { AclLog, ACLRuleExecutionLogSrcIP } from '@/types/acl'
import { Condition, PageResult } from '@/types/common'
import { DownloadLogOptions, LogDownLoadType } from '@/types/log'
import { logTaskCreate } from '@/api/log-task'

export { LogDownLoadType, DownloadLogOptions } from '@/types/log'

export function detectLogList(offset: number, count: number, conditions: Condition[] = []) {
  return listQuery<DetectLog>('/api/captain/detect-log/list', offset, count, conditions)
}

export function detectLogDetail(id: string | number) {
  return get<DetectLogDetail>('/api/captain/detect-log/detail', { id })
}

export function detectLogMark(data: { ids: number[]; flag: string }) {
  return post<null>('/api/captain/detect-log/mark', data)
}

export function aclLogList(offset: number, count: number, conditions: Condition[] = []) {
  return listQuery<AclLog>('/api/captain/acl-log/list', offset, count, conditions)
}

export function aclLogDetail(id: string | number, captain_instance_id: string | number, count?: string | number) {
  return get<AclLog>('/api/captain/acl-log/detail', { id, captain_instance_id, count })
}

export interface AclSrcIPDetailParams {
  captain_instance_id: number | string
  scope: string
  acl_rules_matched__iexact: string
  timestamp__exact: number
}

export function aclLogSrcIPDetail(params: AclSrcIPDetailParams) {
  return get<ACLRuleExecutionLogSrcIP[]>('/api/captain/acl-log/src-ip-detail', {
    captain_instance_id: params.captain_instance_id,
    scope: params.scope,
    acl_rules_matched__iexact: params.acl_rules_matched__iexact,
    timestamp__exact: params.timestamp__exact,
  })
}

export function getPageFilters() {
  return get<unknown[]>('/api/captain/filter/pages')
}

export function downloadLogAPI(options: DownloadLogOptions) {
  return logTaskCreate(options)
}
