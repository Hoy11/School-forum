import { listQuery, get } from '@/api'
import { BotRecordLog, BotResultLog, BotLogDetail } from '@/types/bot'
import { Condition, PageResult } from '@/types/common'

export function botRecordList(offset: number, count: number, conditions: Condition[] = []) {
  return listQuery<BotRecordLog>('/api/captain/bot-log/record/list', offset, count, conditions)
}

export function botRecordDetail(id: string | number) {
  return get<BotLogDetail>('/api/captain/bot-log/record/detail', { id })
}

export function botResultList(offset: number, count: number, conditions: Condition[] = []) {
  return listQuery<BotResultLog>('/api/captain/bot-log/result/list', offset, count, conditions)
}

export function botResultDetail(id: string | number) {
  return get<BotLogDetail>('/api/captain/bot-log/result/detail', { id })
}
