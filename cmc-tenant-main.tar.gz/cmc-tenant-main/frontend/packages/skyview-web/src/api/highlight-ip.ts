import { listQueryGet, post, put, del } from '@/api'
import { HighlightIP, CreateHighlightIPReq, UpdateHighlightIPReq, DeleteHighlightIPReq } from '@/types/highlight-ip'
import { Condition, PageResult } from '@/types/common'

export function highlightIPList(offset: number, count: number, conditions: Condition[] = []) {
  return listQueryGet<HighlightIP>('/api/highlight-ip/list', offset, count, conditions)
}

export function highlightIPCreate(data: CreateHighlightIPReq) {
  return post<HighlightIP>('/api/highlight-ip/create', data)
}

export function highlightIPUpdate(data: UpdateHighlightIPReq) {
  return put<null>('/api/highlight-ip/update', data)
}

export function highlightIPDelete(data: DeleteHighlightIPReq) {
  return del<null>('/api/highlight-ip/delete', data)
}
