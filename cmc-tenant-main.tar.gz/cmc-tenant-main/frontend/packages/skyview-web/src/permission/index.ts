import store from '@/store'
import { Role } from '@/types/users'

export function getRole(): Role | null {
  return store.getters['user/role'] || null
}

export function isAdmin(): boolean {
  return store.getters['user/isAdmin'] === true
}

export function isTenantAdmin(): boolean {
  return store.getters['user/isTenantAdmin'] === true
}

export function isTenant(): boolean {
  return store.getters['user/isTenant'] === true
}

export function canManage(): boolean {
  return isAdmin() || isTenantAdmin()
}

export function canEditBusiness(): boolean {
  return isAdmin() || isTenantAdmin() || isTenant()
}

export function canAccessSystem(): boolean {
  return isAdmin()
}
