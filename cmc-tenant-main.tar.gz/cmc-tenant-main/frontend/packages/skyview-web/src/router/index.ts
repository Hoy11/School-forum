import Vue from 'vue'
import Router from 'vue-router'
import { RouteName } from './names'
import { beforeEach } from './guard'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  routes: [
    { path: '/login', name: RouteName.login, component: () => import('@/views/Login') },
    {
      path: '/',
      name: RouteName.app,
      component: () => import('@/components/Wrapper'),
      children: [
        { path: '', redirect: { name: RouteName.detectLog } },

        // Protection
        { path: 'protection/wafs', name: RouteName.wafList, component: () => import('@/views/Network/Management/WafList') },
        { path: 'protection/sites', name: RouteName.siteManagement, component: () => import('@/views/Network/Management') },
        { path: 'protection/sites/detail', name: RouteName.siteDetail, component: () => import('@/views/Network/Management/SiteDetail') },
        { path: 'protection/site-rule', name: RouteName.siteRule, component: () => import('@/views/Network/Management/SiteRule') },
        { path: 'protection/ip-group', name: RouteName.ipGroup, component: () => import('@/views/Network/Management/IpGroup') },
        { path: 'protection/ssl-cert', name: RouteName.sslCert, component: () => import('@/views/Network/Management/SslCert') },
        { path: 'protection/ssl-cert/detail', name: RouteName.sslCertDetail, component: () => import('@/views/Network/Management/SslCertDetail') },
        { path: 'protection/block-page', name: RouteName.blockPage, component: () => import('@/views/Network/Management/BlockPage') },
        { path: 'protection/policy', name: RouteName.policy, component: () => import('@/views/Network/Management/Policy') },
        { path: 'protection/policy/detail', name: RouteName.policyDetail, component: () => import('@/views/Network/Management/PolicyDetail') },
        { path: 'protection/policy-rule', name: RouteName.policyRule, component: () => import('@/views/Network/Management/PolicyRule') },

        // Threat
        { path: 'threat/detect-log', name: RouteName.detectLog, component: () => import('@/views/Log/Detect') },
        { path: 'threat/detect-log/detail', name: RouteName.detectLogDetail, component: () => import('@/views/Log/Detect/detail') },
        { path: 'threat/acl-log', name: RouteName.aclLog, component: () => import('@/views/Log/Acl') },
        { path: 'threat/bot-log', name: RouteName.botLog, component: () => import('@/views/Log/Bot') },
        { path: 'threat/bot-record-detail', name: RouteName.botRecordDetail, component: () => import('@/views/Log/Bot/RecordDetail') },
        { path: 'threat/bot-result-detail', name: RouteName.botResultDetail, component: () => import('@/views/Log/Bot/ResultDetail') },
        { path: 'threat/log-download', name: RouteName.logDownload, component: () => import('@/views/Log/Download') },

        // Tenant (admin)
        { path: 'tenant/groups', name: RouteName.tenantGroupList, component: () => import('@/views/Tenant/GroupList') },
        { path: 'tenant/users', name: RouteName.userList, component: () => import('@/views/Tenant/UserList') },
        { path: 'tenant/waf-binding', name: RouteName.wafBinding, component: () => import('@/views/Tenant/WafBinding') },
        { path: 'tenant/site-binding', name: RouteName.siteBinding, component: () => import('@/views/Tenant/SiteBinding') },

        // Tenant admin
        { path: 'my/users', name: RouteName.tenantUserList, component: () => import('@/views/TenantUser/UserList') },

        // System (admin)
        { path: 'system/integration', name: RouteName.integrationConfig, component: () => import('@/views/System/IntegrationConfig') }, // 合并原 system/soc + system/captain
        { path: 'system/highlight-ip', name: RouteName.highlightIp, component: () => import('@/views/System/HighlightIp') },
        { path: 'system/audit', name: RouteName.auditLog, component: () => import('@/views/System/AuditLog') },
        { path: 'system/password-config', name: RouteName.passwordConfig, component: () => import('@/views/System/PasswordConfig') },
        { path: 'system/login-security', name: RouteName.loginSecurity, component: () => import('@/views/System/LoginSecurity') },

        // Profile
        { path: 'profile/password', name: RouteName.changePassword, component: () => import('@/views/Profile/ChangePassword') },
        { path: 'profile/info', name: RouteName.userInfo, component: () => import('@/views/Profile/UserInfo') },
        { path: 'profile/api-token', name: RouteName.apiToken, component: () => import('@/views/Profile/ApiToken') },
      ]
    }
  ]
})

router.beforeEach(beforeEach)

export default router
