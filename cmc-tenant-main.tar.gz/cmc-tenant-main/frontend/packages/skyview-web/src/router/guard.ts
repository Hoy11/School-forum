import store from '@/store'
import { RouteName } from './names'
import { Route } from 'vue-router'

type RouteNameType = typeof RouteName[keyof typeof RouteName]

const adminOnly: RouteNameType[] = [
  RouteName.tenantGroupList,
  RouteName.userList,
  RouteName.wafBinding,
  RouteName.siteBinding,
  RouteName.integrationConfig, // 合并原 socConfig + captainConfig
  RouteName.highlightIp,
  RouteName.auditLog,
  RouteName.passwordConfig,
  RouteName.loginSecurity,
]

const tenantAdminOnly: RouteNameType[] = [
  RouteName.tenantUserList,
]

export function beforeEach(to: Route, _from: Route, next: (path?: string) => void) {
  const user = store.getters['user/currentUser']
  const role = store.getters['user/role']

  if (to.name === RouteName.login) {
    next()
    return
  }

  if (!user) {
    next('/login')
    return
  }

  const targetName = to.name as RouteNameType

  if (adminOnly.includes(targetName) && role !== 'admin') {
    next('/')
    return
  }

  if (tenantAdminOnly.includes(targetName) && role !== 'tenant_admin' && role !== 'admin') {
    next('/')
    return
  }

  next()
}
