export const RouteName = {
  login: 'login',
  app: 'app',
  dashboard: 'dashboard',

  // Protection
  wafList: 'wafList',
  siteManagement: 'siteManagement',
  siteDetail: 'siteDetail',
  siteRule: 'siteRule',
  ipGroup: 'ipGroup',
  sslCert: 'sslCert',
  sslCertDetail: 'sslCertDetail',
  blockPage: 'blockPage',
  policy: 'policy',
  policyDetail: 'policyDetail',
  policyRule: 'policyRule',

  // Threat
  detectLog: 'detectLog',
  detectLogDetail: 'detectLogDetail',
  aclLog: 'aclLog',
  botLog: 'botLog',
  botRecordDetail: 'botRecordDetail',
  botResultDetail: 'botResultDetail',
  logDownload: 'logDownload',

  // Tenant (admin)
  tenantGroupList: 'tenantGroupList',
  userList: 'userList',
  wafBinding: 'wafBinding',
  siteBinding: 'siteBinding',

  // Tenant admin
  tenantUserList: 'tenantUserList',

  // System (admin)
  integrationConfig: 'integrationConfig', // 合并原 socConfig + captainConfig
  highlightIp: 'highlightIp',
  auditLog: 'auditLog',
  highlightTag: 'highlightTag',
  passwordConfig: 'passwordConfig',
  loginSecurity: 'loginSecurity',

  // Profile
  changePassword: 'changePassword',
  userInfo: 'userInfo',
  apiToken: 'apiToken',
} as const

export type RouteNameType = typeof RouteName[keyof typeof RouteName]
