import { BackendType } from '@/types/website'

type ValidateCallback = (error?: Error) => void
type ValidatorFn = (rule: any, value: any, callback: ValidateCallback) => void

export const siteNameRules: any[] = [
  { required: true, message: '请输入站点名称' },
]

export const portRules: any[] = [
  { required: true, message: '请输入端口号' },
  { type: 'number', min: 1, max: 65535, message: '端口号范围 1-65535' },
]

export const redirectStatusRules: any[] = [
  { required: true, message: '请输入状态码' },
  {
    validator: (_rule: any, value: number, callback: ValidateCallback) => {
      if (value < 300 || value > 399) {
        callback(new Error('请输入 300 ~ 399 的整数'))
      } else {
        callback()
      }
    },
  },
]

export const customResponseStatusRules: any[] = [
  { required: true, message: '请输入状态码' },
  {
    validator: (_rule: any, value: number, callback: ValidateCallback) => {
      if (!((value >= 200 && value <= 299) || (value >= 400 && value <= 599))) {
        callback(new Error('请输入 200-299 或 400-599 的整数'))
      } else {
        callback()
      }
    },
  },
]

export const cookieMaxAgeRules: any[] = [
  {
    validator: (_rule: any, value: number | null, callback: ValidateCallback) => {
      if (value !== null && (value < 60 || value > 86400)) {
        callback(new Error('Cookie 保持时长为 1 分钟 ～ 24 小时'))
      } else {
        callback()
      }
    },
  },
]

export const serverNameRules: any[] = [
  { required: true, message: '请输入域名' },
]

export const workGroupRules: any[] = [
  { required: true, message: '请选择工作组' },
]

export const setRealIpFromRules: any[] = [
  {
    validator: (_rule: any, value: string, callback: ValidateCallback) => {
      if (!value) { callback(); return }
      const parts = value.split(',').map(s => s.trim()).filter(Boolean)
      const ipCidrRe = /^(\d{1,3}\.){3}\d{1,3}(\/\d{1,2})?$/
      if (!parts.every(p => ipCidrRe.test(p))) {
        callback(new Error('请输入正确的 IP 或 CIDR 格式'))
      } else {
        callback()
      }
    },
  },
]

export function validateBackendConfig(form: any): string | null {
  const bc = form.backend_config
  if (!bc) return null

  if (bc.type === BackendType.proxy) {
    const enabledServers = bc.servers?.filter((s: any) => s.is_enabled) || []
    if (enabledServers.length === 0) return '至少需要一个启用的业务服务器'
    const hasEmptyHost = enabledServers.some((s: any) => !s.host)
    if (hasEmptyHost) return '业务服务器地址不能为空'
  }

  if (bc.type === BackendType.redirect) {
    if (!bc.path) return '请输入重定向地址'
    if (bc.status_code === null) return '请输入状态码'
  }

  if (bc.type === BackendType.response) {
    if (bc.status_code === null) return '请输入状态码'
  }

  return null
}

export function validateCertSettings(cert: any): string | null {
  if (!cert) return null

  if (cert.type === 'upload') {
    if (!cert.cert) return '请上传证书文件'
    if (!cert.key && !cert.certWithKey) return '请上传私钥文件'
    if (!cert.certName) return '请输入证书名称'
  }

  if (cert.type === 'encrypt') {
    if (!cert.cert) return '请上传签名证书'
    if (!cert.key) return '请上传签名私钥'
    if (!cert.enc_cert) return '请上传加密证书'
    if (!cert.enc_key) return '请上传加密私钥'
    if (!cert.certName) return '请输入证书名称'
  }

  return null
}

export function validatePort(port: any): string | null {
  if (!port.port || port.port < 1 || port.port > 65535) {
    return '端口号范围 1-65535'
  }
  return null
}
