import { BackendType, Backends, ProxyBackendConfig, Website } from '@/types/website'
import { SessionType } from '@/types/website-security'
import { pureIsEnabledConfig } from './pure'

function clearProxyHeader(h: any): any {
  if (h.action === 'hide') return { action: h.action, context: h.context, name: h.name }
  return { action: h.action, context: h.context, name: h.name, value: h.value }
}

function clearServers(servers: Backends[]): Backends[] {
  return servers.map(i => ({ ...i, weight: i.weight || 1 }))
}

function clearProxyBackendConfig(bc: ProxyBackendConfig): void {
  bc.servers = clearServers(bc.servers)
  bc.header_config = (bc.header_config || []).map(clearProxyHeader)
  if (bc.health_check_config) {
    bc.health_check_config.port = bc.health_check_config.port || 0
    bc.health_check_config = pureIsEnabledConfig(bc.health_check_config) as any
  }
}

export function clearSite<T extends Pick<Website, 'ports' | 'backend_config' | 'policy_group' | 'session_method' | 'cookie_security' | 'bot_config'>>(site: T): T {
  const bc = site.backend_config as any
  if (bc.type !== BackendType.proxy) {
    site.policy_group = null
    site.session_method = { type: SessionType.off, param: '' }
    site.ports = site.ports.map(x => x.ssl ? x : { ...x, http2: false })
  } else {
    clearProxyBackendConfig(bc)
  }

  if (site.cookie_security) {
    site.cookie_security = pureIsEnabledConfig(site.cookie_security) as any
  }

  if (site.bot_config) {
    const bot = site.bot_config as any
    bot.include_rule = pureIsEnabledConfig(bot.include_rule)
    bot.exclude_rule = pureIsEnabledConfig(bot.exclude_rule)
    if (bot.include_rule.is_enabled && !(bot.include_rule.pattern?.$AND?.length)) {
      bot.include_rule.pattern = {}
    }
    if (bot.exclude_rule.is_enabled && !(bot.exclude_rule.pattern?.$AND?.length)) {
      bot.exclude_rule.pattern = {}
    }
    site.bot_config = pureIsEnabledConfig(bot) as any
  }

  if (!bc.session_sticky_cookie_max_age) {
    delete bc.session_sticky_cookie_max_age
  }

  if (bc.keepalive === '' || bc.keepalive_timeout === '') {
    bc.keepalive = '0'
    bc.keepalive_timeout = '0'
  }

  return site
}

export function clearCreateSite(site: Website): Website {
  const bc = site.backend_config as any
  if (bc.type === BackendType.proxy) {
    delete bc.health_check_config
    delete bc.header_config
  }
  if (!bc.session_sticky_cookie_max_age) {
    delete bc.session_sticky_cookie_max_age
  }
  return clearSite(site)
}

export function clearWTransProxySite(site: Website): Website {
  const bc = site.backend_config as any
  if (bc.type !== BackendType.proxy) {
    site.policy_group = null
    site.session_method = { type: SessionType.off, param: '' }
  } else {
    bc.header_config = (bc.header_config || []).map(clearProxyHeader)
  }
  return site
}
