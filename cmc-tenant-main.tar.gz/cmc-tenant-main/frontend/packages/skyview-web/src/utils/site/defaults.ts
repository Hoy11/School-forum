import {
  BackendType, LoadBalancePolicy, ForwardAction, ConnectionConfig,
  Backends, ProxyBackendConfig, HealthyCheckConfig, HealthyCheckType,
  HealthyCheckCode, HTTPMethod, ProxyHeadersConfig,
} from '@/types/website'
import {
  WebsiteHealthyCheckStatus, OperationModeKind, WorkGroupOperationMode, FallbackType,
  AntiTamperStatus, SelectedTengineType, HashSelectIpMethod,
  CertOriginal,
} from '@/types/website-enums'
import {
  SessionType, LogOption, WebsiteAccessLogSettings,
} from '@/types/website-security'
import {
  WebsitePort, WebsiteUrlPath, WAddr, CertSettings,
  RealIPConfig, Website,
} from '@/types/website'

export function getDefaultPort(): WebsitePort {
  return { port: 80, ssl: false, non_http: false, http2: false, sni: false, proxy_protocol: false }
}

export function getDefaultBackend(): Backends {
  return {
    host: '', port: 80, protocol: 'http',
    is_enabled: true, weight: '', health_check_status: WebsiteHealthyCheckStatus.unknown,
  }
}

export function getDefaultWebsiteURLPath(): WebsiteUrlPath {
  return { op: 'pre', url_path: '/' }
}

export function getDefaultHealthyCheckConfig(): HealthyCheckConfig {
  return {
    check_http_expect_alive: [HealthyCheckCode.http200, HealthyCheckCode.http300],
    interval: 30000, is_enabled: false, host: '', port: 80, path: '/',
    timeout: 1000, fall: 2, rise: 5, method: HTTPMethod.get, check_type: HealthyCheckType.http,
  }
}

export function getDefaultForwardBackendConfig(): ProxyBackendConfig {
  return {
    type: BackendType.proxy,
    servers: [getDefaultBackend()],
    header_config: [],
    load_balance_policy: LoadBalancePolicy.roundBin,
    x_forwarded_for_action: ForwardAction.append,
    health_check_config: getDefaultHealthyCheckConfig(),
    session_sticky_cookie_max_age: null,
    keepalive_config: ConnectionConfig.default,
    keepalive: '', keepalive_timeout: '',
    custom_config: { ignore_types: [], custom: {}, custom_web: [] },
    slow_attack: { is_enabled: false },
  }
}

export function getDefaultDirectiveConfig(
  type: BackendType.redirect | BackendType.response,
) {
  return { type, path: '', status_code: null }
}

export function getDefaultBackendConfig(type: BackendType) {
  switch (type) {
    case BackendType.proxy: return getDefaultForwardBackendConfig()
    default: return getDefaultDirectiveConfig(type as BackendType.redirect | BackendType.response)
  }
}

export function getDefaultSession() {
  return { param: '', type: SessionType.off }
}

export function getDefaultAccessLogSettings(): WebsiteAccessLogSettings {
  return {
    is_enabled: true, log_request_header: false, log_response_header: false,
    log_option: LogOption.drop, req_body: false, rsp_body: false,
  }
}

export function getDefaultResolverConfig() {
  return { valid: 0, resolver_timeout: 30 }
}

export function getDefaultDynamicResolveConfig() {
  return {
    is_enabled: false, dynamic_resolve_fallback: FallbackType.next,
    dynamic_resolve_fail_timeout: 10, resolver_config: getDefaultResolverConfig(),
  }
}

export function getDefaultRealIPConfig(): RealIPConfig {
  return { set_real_ip_from: '', real_ip_header: 'proxy_protocol' }
}

export function getDefaultCertSettings(): CertSettings {
  return {
    cert: null, key: null, enc_cert: null, enc_key: null,
    type: CertOriginal.upload, certWithKey: false, certPassword: '', certName: '',
  }
}

export function getDefaultWAddr(): WAddr {
  return { ip_port: '', ssl: false, http2: false, sni: false, non_http: false }
}

export function getDefaultReverseProxySite(): Website {
  return {
    id: 0, is_enabled: false, name: '', server_names: [],
    url_paths: [getDefaultWebsiteURLPath()],
    ports: [getDefaultPort()],
    create_time: 0, last_update_time: 0,
    policy_group: null,
    session_method: getDefaultSession(),
    detector_ip_source: ['Socket'], proxy_ip_list: [], proxy_ip_groups: [],
    access_log: getDefaultAccessLogSettings(),
    remark: '', ssl_cert: null, ip: [], ssl_protocols: [], ssl_ciphers: '',
    backend_config: getDefaultForwardBackendConfig(),
    health_check_status: WebsiteHealthyCheckStatus.healthy, flag: null,
    dynamic_resolve_upstream_config: getDefaultDynamicResolveConfig(),
    deep_detection_config: { is_enabled: false },
    anti_tamper_status: AntiTamperStatus.notEnabled,
    anti_tamper_rules: [],
    proxy_bind_config: {
      enable: false, hash_select_ip_method: HashSelectIpMethod.remoteAddrAndPort,
      proxy_bind_ip_list: [],
    },
    bot_config: {
      id: 0, is_enabled: false, enable_time: 0, protection: 2 as any,
      expire_period: 0, include_rule: { is_enabled: false, pattern: {} },
      exclude_rule: { is_enabled: false, pattern: {} }, log_option: 'Drop' as any,
      exclude_known_bot: [], websites: [],
    },
    bot_configs: [], ntlm_enabled: false,
    selected_tengine: { type: SelectedTengineType.all, tengine_list: null },
    proxy_protocol: false, realip_config_enable: false,
    realip_config: getDefaultRealIPConfig(),
    asset_group: 1, interface: '', operation_mode: WorkGroupOperationMode.SoftwareReverseProxy,
  }
}
