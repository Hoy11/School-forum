import { LoadBalancePolicy, BackendType, ForwardAction } from '@/types/website'
import { SessionType } from '@/types/website-security'
import { LogOption } from '@/types/website-enums'

export function translateLoadBalancePolicy(v: LoadBalancePolicy): string {
  const map: Record<LoadBalancePolicy, string> = {
    [LoadBalancePolicy.roundBin]: '加权轮询法',
    [LoadBalancePolicy.leastConn]: '最小连接数法',
    [LoadBalancePolicy.ipHash]: '源地址哈希法',
    [LoadBalancePolicy.sessionSticky]: '会话保持',
    [LoadBalancePolicy.hash]: '一致性哈希',
    [LoadBalancePolicy.ntlm]: 'NTLM',
  }
  return map[v] || v
}

export function translateBackendType(v: BackendType): string {
  const map: Record<BackendType, string> = {
    [BackendType.proxy]: '转发',
    [BackendType.redirect]: '重定向',
    [BackendType.response]: '自定义响应',
  }
  return map[v] || v
}

export function translateForwardAction(v: ForwardAction): string {
  const map: Record<ForwardAction, string> = {
    [ForwardAction.append]: '追加',
    [ForwardAction.cover]: '覆盖',
    [ForwardAction.noAction]: '不设置',
  }
  return map[v] || v
}

export function translateSessionMethod(v: SessionType): string {
  const map: Record<string, string> = {
    [SessionType.off]: '不使用',
    [SessionType.safelineSession]: 'WAF 用户系统',
    [SessionType.custom]: '从请求中提取用户 ID',
    [SessionType.srcIP]: '源 IP',
    [SessionType.cookie]: 'Cookie',
    [SessionType.urlQuery]: 'GET 参数',
    [SessionType.bodyForm]: 'POST 参数',
    [SessionType.header]: 'HTTP 头',
  }
  return map[v] || v
}

export function translateLogOption(v: LogOption): string {
  const map: Record<LogOption, string> = {
    [LogOption.persistence]: '持久化',
    [LogOption.nonPersistence]: '非持久化',
    [LogOption.drop]: '不记录',
  }
  return map[v] || v
}
