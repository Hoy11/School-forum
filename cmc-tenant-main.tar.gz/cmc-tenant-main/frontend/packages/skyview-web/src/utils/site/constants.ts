import { LoadBalancePolicy, BackendType, ForwardAction } from '@/types/website'
import { CertOriginal } from '@/types/website-enums'

export const loadBalancePolicyOptions = [
  { label: '加权轮询法', value: LoadBalancePolicy.roundBin, tooltip: '将请求按权重轮流分配到后端服务器' },
  { label: '最小连接数法', value: LoadBalancePolicy.leastConn, tooltip: '将请求发送到当前连接数最少的服务器' },
  { label: '源地址哈希法', value: LoadBalancePolicy.ipHash, tooltip: '根据客户端 IP 计算哈希值分配服务器' },
  { label: '会话保持', value: LoadBalancePolicy.sessionSticky, tooltip: '使用 Cookie 实现会话保持，同一客户端请求发送到同一服务器' },
  { label: '一致性哈希', value: LoadBalancePolicy.hash, tooltip: '使用一致性哈希算法分配服务器，减少节点变化时的映射变动' },
  { label: 'NTLM', value: LoadBalancePolicy.ntlm, tooltip: 'NTLM 认证模式，保持连接亲和性' },
]

export const backendTypeOptions = [
  { label: '转发', value: BackendType.proxy },
  { label: '重定向', value: BackendType.redirect },
  { label: '自定义响应', value: BackendType.response },
]

export const xForwardedForOptions = [
  { label: '追加', value: ForwardAction.append },
  { label: '覆盖', value: ForwardAction.cover },
  { label: '不设置', value: ForwardAction.noAction },
]

export const urlPathOpOptions = [
  { label: '前缀匹配', value: 'pre', tooltip: '同域名生效地址中的第二优先级匹配类型，匹配所有以该前缀开头的路径' },
  { label: '正则匹配', value: 'reg', tooltip: '同域名生效地址中的第三优先级匹配类型，使用正则表达式匹配路径' },
  { label: '完全匹配', value: 'exact', tooltip: '同域名生效地址中的第一优先级匹配类型，精确匹配指定路径' },
]

export const certOriginalOptions = [
  { label: '上传新证书', value: CertOriginal.upload },
  { label: '选择已有证书', value: CertOriginal.select },
  { label: '上传国密证书', value: CertOriginal.encrypt },
]

export const sessionTypeOptions = [
  { label: '不使用', value: 'off' },
  { label: 'WAF 用户系统', value: 'internal_session' },
  { label: '从请求中提取用户 ID', value: 'custom' },
]

export const sessionLocationOptions = [
  { label: 'Cookie', value: 'cookie' },
  { label: 'POST 参数', value: 'body_form' },
  { label: 'HTTP 头', value: 'header' },
  { label: 'GET 参数', value: 'url_query' },
]

export const selectedTengineTypeOptions = [
  { label: '全部节点', value: 'all' },
  { label: '节点列表', value: 'selected' },
  { label: '正则匹配', value: 'regexp' },
]

export const siteStatusOptions = [
  { label: '启用', value: true },
  { label: '禁用', value: false },
]
