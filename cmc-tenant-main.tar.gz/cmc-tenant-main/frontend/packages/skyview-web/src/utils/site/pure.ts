export function pureIsEnabledConfig<T extends { is_enabled: boolean }>(value: T): T | { is_enabled: false } {
  return value.is_enabled ? value : { is_enabled: false }
}

export function pureEnableConfig<T extends { enable: boolean }>(value: T): T | { enable: false } {
  return value.enable ? value : { enable: false }
}
