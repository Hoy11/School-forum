import { siteCertUpload, siteResponseUpload } from '@/api/captain-site'
import { CertOriginal, WorkGroupOperationMode } from '@/types/website-enums'
import { SessionType } from '@/types/website-security'
import { CertSettings, Website, WAddr } from '@/types/website'
import { clearCreateSite, clearWTransProxySite } from './clear'

const ADDR_BASED_MODES = new Set([
  WorkGroupOperationMode.HardwareTransparentBridging,
  WorkGroupOperationMode.HardwarePortMirroring,
])

const CLUSTER_MODES = new Set([
  WorkGroupOperationMode.SoftwareClusterReverseProxy,
  WorkGroupOperationMode.SoftwarePortMirroring,
])

export async function uploadCertIfNeeded(
  captainInstanceId: number,
  certSettings: CertSettings,
  form: Website,
): Promise<number | null> {
  if (certSettings.type === CertOriginal.upload || certSettings.type === CertOriginal.encrypt) {
    const fd = new FormData()
    fd.append('name', certSettings.certName)
    if (certSettings.type === CertOriginal.upload) {
      if (certSettings.cert) fd.append('cert', certSettings.cert)
      if (certSettings.key) fd.append('key', certSettings.key)
      fd.append('type', 'common')
    } else {
      if (certSettings.cert) fd.append('sign_cert', certSettings.cert)
      if (certSettings.key) fd.append('sign_key', certSettings.key)
      if (certSettings.enc_cert) fd.append('enc_cert', certSettings.enc_cert)
      if (certSettings.enc_key) fd.append('enc_key', certSettings.enc_key)
      fd.append('type', 'encrypt')
    }
    const resp = await siteCertUpload(captainInstanceId, fd)
    if (resp.err !== null) throw new Error(resp.err || '证书上传失败')
    return resp.data?.id || null
  }
  return form.ssl_cert
}

export async function uploadResponseFileIfNeeded(
  captainInstanceId: number,
  responseFile: File | null,
  currentPath: string,
): Promise<string> {
  if (responseFile) {
    const fd = new FormData()
    fd.append('file', responseFile)
    const resp = await siteResponseUpload(captainInstanceId, fd)
    if (resp.err !== null) throw new Error(resp.err || '响应文件上传失败')
    return resp.data?.path || currentPath
  }
  return currentPath
}

export function processProxyProtocol(form: Website): void {
  form.proxy_protocol = !!form.ports?.find(p => p.proxy_protocol)
  form.ports?.forEach(port => {
    if (port.proxy_protocol) {
      if (form.realip_config_enable) {
        port.realip_config = { ...form.realip_config }
      } else {
        port.realip_config = { real_ip_header: 'proxy_protocol' } as any
      }
    } else {
      delete port.realip_config
    }
  })
  if (!form.realip_config_enable) {
    form.realip_config = { set_real_ip_from: '', real_ip_header: 'proxy_protocol' }
  }
}

export function processPolicyGroup(form: Website): void {
  const bc = form.backend_config as any
  if (bc?.type !== 'proxy') {
    form.policy_group = null
  }
  if (form.policy_group === 'none' as any) {
    form.policy_group = null
  }
}

export function prepareSiteForSubmit(form: Website, isCreate = true): Website {
  const data = { ...form }
  const mode = data.operation_mode as unknown as WorkGroupOperationMode

  // C/D 型：保留 ports，删除非必要字段
  if (CLUSTER_MODES.has(mode)) {
    if (data.policy_group === 'none' as any) data.policy_group = null
    delete (data as any).backend_config
    delete (data as any).ssl_cert
    delete (data as any).ssl_protocols
    delete (data as any).ssl_ciphers
    delete (data as any).selected_tengine
    delete (data as any).proxy_bind_config
    delete (data as any).dynamic_resolve_upstream_config
    delete (data as any).anti_tamper_status
    delete (data as any).anti_tamper_rules
    delete (data as any).ntlm_enabled
    delete (data as any).health_check_status
    delete (data as any).ip
    delete (data as any).realip_config_enable
    delete (data as any).realip_config
    delete (data as any).proxy_protocol
    // D 型额外清理
    if (mode === WorkGroupOperationMode.SoftwarePortMirroring) {
      data.session_method = { type: SessionType.off, param: '' }
      delete (data as any).cookie_security
      delete (data as any).bot_config
    }
    return data
  }

  // Addr-based modes (TransBridge, PortMirroring) don't have ports/backend_config/ssl
  if (ADDR_BASED_MODES.has(mode)) {
    if (data.policy_group === 'none' as any) data.policy_group = null
    delete (data as any).ports
    delete (data as any).backend_config
    delete (data as any).ssl_cert
    delete (data as any).selected_tengine
    delete (data as any).realip_config_enable
    delete (data as any).realip_config
    delete (data as any).proxy_protocol
    return data
  }

  processProxyProtocol(data)
  processPolicyGroup(data)

  if (!data.ports?.some(p => p.ssl)) {
    data.ssl_cert = null
  }

  if (isCreate) {
    return clearCreateSite(data)
  }
  return data
}

export function validateWTransProxySiteForSubmit(form: Website, addrs: WAddr[]): void {
  if (!form.name?.trim()) {
    throw new Error('站点名称必填')
  }
  if (!form.interface?.trim()) {
    throw new Error('工作组必填')
  }
  if (!form.server_names || form.server_names.length === 0) {
    throw new Error('绑定域名必填')
  }
  if (!addrs || addrs.length === 0) {
    throw new Error('服务器地址必填')
  }

  const first = addrs[0]
  if (!first?.ip_port?.trim()) {
    throw new Error('服务器地址必填')
  }
  const base = {
    ssl: !!first.ssl,
    sni: !!first.sni,
    http2: !!first.http2,
    non_http: !!first.non_http,
  }

  addrs.forEach((addr, index) => {
    if (!addr.ip_port?.trim()) {
      throw new Error(`第 ${index + 1} 个服务器地址必填`)
    }
    if (addr.http2 && !addr.ssl) {
      throw new Error('HTTP2 必须与 SSL 一起启用')
    }
    if (!!addr.ssl !== base.ssl) {
      throw new Error('同一透明代理站点内不允许混用不同 SSL 配置')
    }
    if (!!addr.sni !== base.sni) {
      throw new Error('同一透明代理站点内不允许混用不同 SNI 配置')
    }
    if (!!addr.http2 !== base.http2) {
      throw new Error('同一透明代理站点内不允许混用不同 HTTP2 配置')
    }
    if (!!addr.non_http !== base.non_http) {
      throw new Error('同一透明代理站点内不允许混用不同 TCP 流量转发配置')
    }
  })

  if (base.ssl && !form.ssl_cert) {
    throw new Error('启用 SSL 时必须选择证书')
  }
}

export function prepareWTransProxySiteForSubmit(form: Website, addrs: any[]): Website {
  validateWTransProxySiteForSubmit(form, addrs)
  const data: Website = {
    ...form,
    addrs,
    operation_mode: WorkGroupOperationMode.HardwareTransparentProxy,
  }
  data.backend_config = {
    ...(data.backend_config as any),
    preserve_source_port: !!(data.backend_config as any)?.preserve_source_port,
  } as any
  if (data.policy_group === 'none' as any) {
    data.policy_group = null
  }
  if (!addrs.some((a: any) => a.ssl)) {
    data.ssl_cert = null
  }
  if (addrs.some((a: any) => a.non_http)) {
    data.url_paths = [{ op: 'pre', url_path: '/' }]
  }
  delete (data as any).ports
  delete (data as any).selected_tengine
  delete (data as any).proxy_bind_config
  delete (data as any).dynamic_resolve_upstream_config
  delete (data as any).realip_config_enable
  delete (data as any).realip_config
  delete (data as any).proxy_protocol
  delete (data as any).health_check_status
  delete (data as any).ip
  return clearWTransProxySite(data)
}
