export enum ActionValue {
  allow = 0,
  deny = 1,
  observe = 2,
  forward = 4,
}

export enum RiskLevelNum {
  low = 1,
  medium = 2,
  high = 3,
}

function pad2(n: number): string {
  return String(n).padStart(2, '0')
}

function formatDate(d: Date): string {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())} ${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`
}

export function formatTimestamp(ts: string | number): string {
  if (!ts) return '-'
  return formatDate(new Date(Number(ts) * 1000))
}

export function formatTimestampMs(ts: number): string {
  if (!ts) return '-'
  return formatDate(new Date(ts))
}

export function formatMicroseconds(us: number | null): string {
  if (us == null) return '-'
  if (us < 1000) return `${us} μs`
  if (us < 1000000) return `${(us / 1000).toFixed(2)} ms`
  return `${(us / 1000000).toFixed(2)} s`
}

export function actionToType(action: { value: number }): string {
  switch (action.value) {
    case ActionValue.allow: return 'success'
    case ActionValue.deny: return 'danger'
    case ActionValue.observe: return 'info'
    case ActionValue.forward: return 'warning'
    default: return 'info'
  }
}

export function riskLevelToType(num: number): string {
  switch (num) {
    case RiskLevelNum.high: return 'danger'
    case RiskLevelNum.medium: return 'warning'
    case RiskLevelNum.low: return 'info'
    default: return 'info'
  }
}

export function translateEffective(v: number): string {
  const map: Record<number, string> = {
    0: '无效攻击',
    1: '未知',
    2: '疑似有效',
    3: '有效攻击',
  }
  return map[v] ?? '-'
}

export function formatDecodePath(path: string): string {
  if (!path) return '-'
  return path.split(' ').join(' → ')
}

export function formatGeo(country: string, province: string): string {
  return [country, province].filter(Boolean).join(' - ') || '-'
}

export function formatHostPort(port: string | number): string {
  if (!port || port === '0') return '-'
  return String(port)
}
