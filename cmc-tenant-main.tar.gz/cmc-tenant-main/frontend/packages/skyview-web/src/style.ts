import 'reset.css'

const style = document.createElement('style')
style.textContent = `
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    font-size: 14px;
    color: #303133;
    background: #f5f7fa;
  }
  #app { height: 100%; min-width: 1024px; }

  /* Login */
  .login-page {
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #1d2b64, #2d4a7a);
  }
  .login-box {
    width: 400px;
    padding: 40px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 8px 24px rgba(0,0,0,.15);
  }
  .login-title {
    text-align: center;
    margin-bottom: 30px;
    font-size: 22px;
    color: #303133;
  }
  .login-error {
    color: #f56c6c;
    font-size: 13px;
    margin-bottom: 16px;
    line-height: 1.4;
  }

  /* Layout */
  .layout {
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  .top-nav__bar {
    height: 48px;
    display: flex;
    align-items: center;
    background: #052F58;
    flex-shrink: 0;
  }
  .top-nav__logo {
    width: 180px;
    padding: 0 16px;
    font-weight: 600;
    font-size: 15px;
    color: #fff;
    white-space: nowrap;
    flex-shrink: 0;
  }
  .top-nav__bar > .el-menu {
    flex: 1;
    border-bottom: none;
    background: transparent;
    white-space: nowrap;
    overflow: visible;
  }
  .top-nav__bar > .el-menu > .el-menu-item {
    height: 48px;
    line-height: 48px;
    color: rgba(255,255,255,0.8);
    border-bottom: none;
    font-size: 14px;
  }
  .top-nav__bar > .el-menu > .el-menu-item:hover {
    color: #fff;
    background: #021B33;
  }
  .top-nav__bar > .el-menu > .el-menu-item.is-active {
    color: #fff;
    background: #021B33;
    border-bottom: none;
  }
  .top-nav__user {
    margin-right: 16px;
    flex-shrink: 0;
  }
  .top-nav__username {
    cursor: pointer;
    font-size: 14px;
    color: rgba(255,255,255,0.8);
  }
  .top-nav__username:hover {
    color: #fff;
  }
  .layout__body {
    flex: 1;
    display: flex;
    overflow: hidden;
  }
  .layout__sidebar {
    width: 180px;
    border-right: 1px solid #e8e8e8;
    background: #fff;
    overflow-y: auto;
    flex-shrink: 0;
  }
  .layout__sidebar > .el-menu {
    border-right: none;
  }
  .layout__sidebar .el-menu-item {
    height: 48px;
    line-height: 48px;
    color: #919191;
    font-size: 13px;
  }
  .layout__sidebar .el-menu-item:hover {
    color: #333;
    background: #F5F5F5;
  }
  .layout__sidebar .el-menu-item.is-active {
    color: #333;
    background: #F5F5F5;
  }
  .layout__content {
    flex: 1;
    padding: 20px;
    overflow-y: auto;
  }

  /* Dashboard */
  .dashboard h2 { margin-bottom: 20px; }
  .stat-value {
    font-size: 32px;
    font-weight: 600;
    color: #409eff;
    text-align: center;
    padding: 20px 0 4px;
  }
  .stat-label {
    text-align: center;
    color: #909399;
    font-size: 13px;
    padding-bottom: 12px;
  }

  /* Grid area */
  .grid { margin-bottom: 16px; }
  .audit-log-page,
  .audit-log-page .grid,
  .audit-log-page .el-table,
  .audit-log-page .el-table__header-wrapper,
  .audit-log-page .el-table__body-wrapper {
    width: 100%;
  }
  .el-pagination { margin-top: 16px; text-align: right; }

  /* Condition filter — aligned with Captain-2 @splat/filter */
  .condition-filter {
    background: #fff;
    box-shadow: inset 0 0 2px 0 rgba(0,0,0,0.10);
    border-radius: 4px;
    padding: 10px 14px 0;
    margin-bottom: 16px;
  }
  .condition-filter__items {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
  }
  .condition-filter__item {
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    gap: 0;
    background: #F5F5F5;
    border: 1px dashed #F5F5F5;
    border-radius: 4px;
    padding: 0;
    margin-bottom: 10px;
    transition: background 0.2s;
  }
  .condition-filter__item:hover { background: #E9E9E9; border-color: #E9E9E9; }
  .condition-filter__item--active { border-color: #E9E9E9; }
  .condition-filter__item--active .el-input__inner,
  .condition-filter__item--active .el-select .el-input__inner { color: #0b71bb; }
  .condition-filter__item:not(.condition-filter__item--active) .el-select .el-input__inner { color: #999; }
  /* Field selector: left section with padding */
  .condition-filter__item > .el-select:first-child .el-input__inner {
    border: none;
    background: transparent;
    padding-right: 20px;
  }
  /* Value inputs inside tag: borderless, transparent bg */
  .condition-filter__item .el-input__inner {
    border: none;
    background: transparent;
  }
  .condition-filter__item .el-select .el-input__inner {
    border: none;
    background: transparent;
  }
  .condition-filter__sub-item {
    display: inline-flex;
    align-items: center;
    gap: 0;
  }
  .condition-filter__item-remove {
    color: #999;
    font-size: 12px;
    cursor: pointer;
    margin-left: 2px;
  }
  .condition-filter__item-remove:hover { color: #F56C6C; }
  .condition-filter__add-item {
    color: #0B71BB;
    font-size: 14px;
    cursor: pointer;
    margin-left: 4px;
  }
  .condition-filter__add-item:hover { color: #409eff; }
  .condition-filter__remove {
    display: flex;
    align-items: center;
    justify-content: center;
    background: #F5F5F5;
    border-left: 1px solid #E9E9E9;
    border-radius: 0 4px 4px 0;
    height: 32px;
    width: 28px;
    color: #666;
    padding: 0;
    margin-left: 0;
    font-size: 16px;
    cursor: pointer;
    transition: background 0.2s;
  }
  .condition-filter__remove:hover { background: #E9E9E9; color: #F56C6C; }
  .condition-filter__actions {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 0;
    margin-bottom: 10px;
    padding-top: 0;
  }
  .condition-filter__actions .el-button--text {
    color: #0B71BB;
  }
  .condition-filter__actions .el-button--text:hover {
    color: #409eff;
  }

  /* ACL expand row radio — match Captain-2 @splat/radio border style (white bg, no shadow) */
  .acl-expand-radio .el-radio.is-bordered {
    background: #fff;
    box-shadow: none;
    border-color: #DCDFE6;
  }
  .acl-expand-radio .el-radio.is-bordered.is-checked {
    border-color: #0b71bb;
  }

  /* Highlight tag */
  .highlight-tag { display: inline-flex; align-items: center; gap: 4px; }
  .highlight-tag__icon { color: #e6a23c; }

  /* Detail panel */
  .detail-panel__section { margin-bottom: 16px; }
  .detail-panel__label { color: #909399; font-size: 13px; margin-bottom: 4px; }
  .detail-panel__value { word-break: break-all; }

  /* Http content */
  .http-content { background: #f5f7fa; padding: 12px; border-radius: 4px; font-family: monospace; font-size: 13px; white-space: pre-wrap; word-break: break-all; overflow: hidden; }
  .http-content__body { white-space: pre-wrap; word-break: break-all; overflow-x: auto; margin: 0; }

  /* MutableFormItem */
  .mutable-form-item { margin-bottom: 12px; }
  .mutable-form-item__label { color: #909399; font-size: 13px; margin-bottom: 2px; }
  .mutable-form-item__value { word-break: break-all; font-size: 14px; }

  /* Text ellipsis */
  .text-ellipsis { display: inline-block; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: middle; }

  /* General */
  .el-card { margin-bottom: 0; }
  .el-dialog__body { padding: 20px; }
  h3 { margin-bottom: 16px; font-size: 16px; }

  /* el-table border 样式微调 — 与雷池视觉风格一致 */
  .el-table--border .el-table__cell { border-right: 1px solid #E6E6E6; }
  .el-table--border th.el-table__cell { border-right: 1px solid #E6E6E6; }
  .el-table--border { border-right: 1px solid #E6E6E6; }

  /* Action tooltip */
  .action-tooltip { white-space: pre-line; }

  /* ========== ConditionEditor 虚线连接 ========== */
  .ce-wrapper { display: flex; }
  .ce-logic-col {
    width: 88px;
    flex-shrink: 0;
    position: relative;
    z-index: 1;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding-top: 0;
  }
  .ce-logic-col::after {
    content: '';
    display: inline-block;
    position: absolute;
    left: 50%;
    bottom: 6px;
    width: 1px;
    height: calc(100% - 32px);
    transform: translate(-50%, 0);
    background: linear-gradient(#d9d9d9 0%, #d9d9d9 50%, transparent 50%, transparent 100%) 0 0 / 1px 3px repeat-y;
  }
  .ce-conditions-col { flex: 1; min-width: 0; }
  .ce-row {
    position: relative;
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 8px;
    flex-wrap: nowrap;
  }
  .ce-row::after {
    content: '';
    display: inline-block;
    position: absolute;
    left: 0;
    top: 50%;
    transform: translate(-100%, -50%);
    width: 38px;
    height: 1px;
    background: linear-gradient(to left, #d9d9d9 0%, #d9d9d9 50%, transparent 50%, transparent 100%) 0 0 / 3px 1px repeat-x;
  }
  .ce-row-fields { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
  .ce-row-actions { display: flex; flex-direction: row; align-items: center; gap: 4px; flex-shrink: 0; }
  .ce-action-icon {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    border-radius: 50%;
    font-size: 10px;
    cursor: pointer;
    transition: all 0.2s;
  }
  .ce-add-pattern-icon {
    background: transparent;
    color: #666;
  }
  .ce-add-pattern-icon:hover {
    background: #e6e6e6;
    color: #333;
  }
  .ce-delete-icon {
    background: #666;
    color: #fff;
  }
  .ce-delete-icon:hover {
    background: #F56C6C;
  }
  .ce-group { margin-bottom: 8px; border: 1px dotted #d9d9d9; border-radius: 4px; padding: 14px; }
  .ce-group .ce-logic-col { align-items: center; }
  .ce-group .ce-row-actions .ce-add-pattern-icon { display: none; }
  .ce-add-btn { margin-top: 4px; }

  /* ========== 内置规则下拉长名换行 ========== */
  .skynet-rule-select {
    max-width: 280px !important;
  }
  .skynet-rule-select .el-select-dropdown__item {
    white-space: normal !important;
    overflow-wrap: break-word !important;
    height: auto !important;
    line-height: 18px !important;
    padding: 9px 14px !important;
  }
`
document.head.appendChild(style)
