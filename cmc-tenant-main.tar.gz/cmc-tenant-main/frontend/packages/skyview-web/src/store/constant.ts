export const UserMutations = {
  SetUser: 'user/setUser',
  ClearUser: 'user/clearUser',
} as const

export const UserGetters = {
  Role: 'user/role',
  IsAdmin: 'user/isAdmin',
  IsTenantAdmin: 'user/isTenantAdmin',
  IsTenant: 'user/isTenant',
} as const

export const TenantMutations = {
  SetTenant: 'tenant/setTenant',
  ClearTenant: 'tenant/clearTenant',
} as const

export const TenantGetters = {
  TenantGroupID: 'tenant/tenantGroupID',
  AllowedWafIDs: 'tenant/allowedWafIDs',
  AllowedSites: 'tenant/allowedSites',
} as const
