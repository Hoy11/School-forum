export interface TenantState {
  tenantGroupID: number | null
  tenantGroupName: string
  allowedWafIDs: number[]
  allowedSites: number[]
}

export const state: TenantState = {
  tenantGroupID: null,
  tenantGroupName: '',
  allowedWafIDs: [],
  allowedSites: []
}

export const getters = {
  tenantGroupID: (s: TenantState) => s.tenantGroupID,
  tenantGroupName: (s: TenantState) => s.tenantGroupName,
  allowedWafIDs: (s: TenantState) => s.allowedWafIDs,
  allowedSites: (s: TenantState) => s.allowedSites,
}

export const mutations = {
  setTenant(s: TenantState, payload: { id: number; name: string; wafIDs: number[]; siteIDs: number[] }) {
    s.tenantGroupID = payload.id
    s.tenantGroupName = payload.name
    s.allowedWafIDs = payload.wafIDs
    s.allowedSites = payload.siteIDs
  },
  clearTenant(s: TenantState) {
    s.tenantGroupID = null
    s.tenantGroupName = ''
    s.allowedWafIDs = []
    s.allowedSites = []
  }
}
