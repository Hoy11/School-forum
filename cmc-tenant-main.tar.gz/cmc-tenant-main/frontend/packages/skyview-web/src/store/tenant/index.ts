import { TenantState, state, getters, mutations } from './state'
import { Module } from 'vuex'

const tenantModule: Module<TenantState, unknown> = {
  namespaced: true,
  state,
  getters,
  mutations
}

export default tenantModule
