import { User, Role } from '@/types/users'

export interface UserState {
  currentUser: User | null
  needChangePassword: boolean
}

export const state: UserState = {
  currentUser: null,
  needChangePassword: false
}

export const getters = {
  currentUser: (s: UserState) => s.currentUser,
  role: (s: UserState): Role | null => s.currentUser?.role || null,
  isAdmin: (s: UserState): boolean => s.currentUser?.role === 'admin',
  isTenantAdmin: (s: UserState): boolean => s.currentUser?.role === 'tenant_admin',
  isTenant: (s: UserState): boolean => s.currentUser?.role === 'tenant',
  needChangePassword: (s: UserState): boolean => s.needChangePassword,
}

export const mutations = {
  setUser(s: UserState, payload: { user: User; needChangePassword: boolean }) {
    s.currentUser = payload.user
    s.needChangePassword = payload.needChangePassword
  },
  clearUser(s: UserState) {
    s.currentUser = null
    s.needChangePassword = false
  }
}
