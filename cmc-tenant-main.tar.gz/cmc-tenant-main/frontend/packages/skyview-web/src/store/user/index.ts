import { UserState, state, getters, mutations } from './state'
import { Module } from 'vuex'

const userModule: Module<UserState, unknown> = {
  namespaced: true,
  state,
  getters,
  mutations
}

export default userModule
