import Vue from 'vue'
import Vuex from 'vuex'
import user from './user'
import tenant from './tenant'

Vue.use(Vuex)

export default new Vuex.Store({
  modules: {
    user,
    tenant
  }
})
