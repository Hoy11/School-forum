// === Enums shared across website types ===

export enum WebsiteHealthyCheckStatus {
  healthy = 'HEALTHY',
  unhealthy = 'UNHEALTHY',
  unknown = 'UNKNOWN',
  notEnabled = ''
}

export enum OperationModeKind {
  reverse = 'Reverse Proxy',
  hardwareReverseProxy = 'Hardware Reverse Proxy',
  hardwareTransparentProxy = 'Hardware Transparent Proxy',
  hardwareTransparentBridging = 'Hardware Transparent Bridging',
  hardwarePortMirroring = 'Hardware Port Mirroring',
  softwareReverseProxy = 'Software Reverse Proxy',
}

export enum WorkGroupOperationMode {
  HardwareReverseProxy = 'Hardware Reverse Proxy',
  HardwareTransparentProxy = 'Hardware Transparent Proxy',
  HardwareTransparentBridging = 'Hardware Transparent Bridging',
  HardwarePortMirroring = 'Hardware Port Mirroring',
  SoftwareReverseProxy = 'Software Reverse Proxy',
  HardwareRouterProxy = 'Hardware Router Proxy',
  SoftwareClusterReverseProxy = 'Software Cluster Reverse Proxy',
  SoftwarePortMirroring = 'Software Port Mirroring',
}

export enum CertOriginal {
  upload = 'upload',
  select = 'select',
  encrypt = 'encrypt'
}

export enum SiteFromStep {
  listener = 0,
  proxy = 1,
  policy = 2,
  finish = 3
}

export enum SSLProtocol {
  sslv3 = 'SSLv3',
  tlsv1 = 'TLSv1',
  tlsv11 = 'TLSv1.1',
  tlsv12 = 'TLSv1.2',
  tlsv13 = 'TLSv1.3'
}

export enum LogOption {
  persistence = 'Persistence',
  nonPersistence = 'Non-Persistence',
  drop = 'Drop'
}

export enum FallbackType {
  stale = 'stale',
  next = 'next',
  shutdown = 'shutdown'
}

export enum AntiTamperStatus {
  normal = 'normal',
  abnormal = 'abnormal',
  notEnabled = 'not_enabled'
}

export enum SelectedTengineType {
  all = 'all',
  selected = 'selected',
  regexp = 'regexp'
}

export enum HashSelectIpMethod {
  remoteAddr = 'remote_addr',
  remoteAddrAndPort = 'remote_addr_and_port'
}

// === DNS Resolve ===

export interface ResolverConfig {
  valid: number
  resolver_timeout: number
}

export interface DynamicResolveConfig {
  is_enabled: boolean
  dynamic_resolve_fallback: FallbackType
  dynamic_resolve_fail_timeout: number
  resolver_config: ResolverConfig
}

// === Proxy Bind ===

export interface ProxyBindIpList {
  id: string
  ips?: string[]
  ip_group?: number | null
}

export interface ProxyBindConfig {
  enable: boolean
  hash_select_ip_method: HashSelectIpMethod
  proxy_bind_ip_list: ProxyBindIpList[]
}

// === Tengine Selection ===

export interface SelectedTengine {
  type: SelectedTengineType
  tengine_list: string[] | null
}

// === SSL Cert (for dropdown) ===

export interface SSLCertModel {
  id: number
  name: string
  info: {
    serial: string
    issuer: string
    domains: string[]
    not_valid_after: string
    not_valid_before: string
  }
}

// === Policy (for dropdown) ===

export interface PolicyModel {
  id: number
  name: string
  is_default: boolean
}

// === Node (for tengine selection) ===

export interface NodeStatus {
  id: string
  node: {
    status: string
    link_addrs: string[]
  }
  services: { name: string }[]
}

// === Asset Group ===

export interface AssetGroupType {
  id?: number
  name: string
  comment: string
  priority?: number
}

// === Work Group ===

export interface WorkGroupModel {
  name: string
  comment: string
  operation_mode?: WorkGroupOperationMode
}
