export interface FilterSave {
  id: number
  name: string
  filter: unknown
  created_at: string
}
