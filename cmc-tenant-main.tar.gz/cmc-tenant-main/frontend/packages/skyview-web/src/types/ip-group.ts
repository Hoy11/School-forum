export interface IPGroup {
  id: number
  name: string
  comment: string
  reference: number
  is_global: boolean
  original: string[]
  binding_count: number
  used_count: number
  source: 'created' | 'inherited'
  has_external_ref: boolean
}

export interface IPGroupItem {
  id: number
  ip_group_id: number
  ip: string
  comment: string
}
