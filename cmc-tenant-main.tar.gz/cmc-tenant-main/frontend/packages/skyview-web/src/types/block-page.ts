export interface BlockPageInfo {
  id: number
  name: string
  comment: string
  policy_group_used_count: number
  work_group_used_count: number
  create_time: string
  binding_count: number
  source?: string
  shared_group_names?: string[]
}
