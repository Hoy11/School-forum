export interface LogTask {
  id: number
  name: string
  status: string
  type: string
  task_log_name: string
  file_name: string
  start_time: string
  end_time: string
  created_at: string
  consumed_time: string
}

export type LogType = 'detect_log' | 'acl_log' | 'bot_record_log' | 'bot_result_log'

export type LogDownLoadType = 'json' | 'csv'

export interface DownloadLogOptions {
  name: string
  type: LogDownLoadType
  all: boolean
  ids: (string | number)[]
  conditions?: import('@/types/common').Condition[]
}
