export interface HighlightIP {
  id: number
  ip: string
  color: string
  comment: string
  created_at: string
  updated_at: string
}

export interface CreateHighlightIPReq {
  ip: string
  color?: string
  comment?: string
}

export interface UpdateHighlightIPReq {
  id: number
  ip?: string
  color?: string
  comment?: string
}

export interface DeleteHighlightIPReq {
  ids?: number[]
  all?: boolean
}
