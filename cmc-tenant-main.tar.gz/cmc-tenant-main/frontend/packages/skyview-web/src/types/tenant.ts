export interface TenantGroup {
  id: number
  name: string
  comment: string
  admin_user_id: number
  admin_username: string
  created_at: string
  updated_at: string
}

export interface WafBinding {
  id: number
  tenant_group_id: number
  captain_instance_id: number
  created_at: string
}

export interface WafBindingWithInfo extends WafBinding {
  tenant_group_name: string
  instance_name: string
  instance_host: string
  instance_status: string
  status?: 'active' | 'invalid' | 'unknown'
  is_enabled?: boolean
  version?: string
  operation_mode?: string
  bound_tenant_groups?: string
}

export interface SiteBinding {
  id: number
  tenant_group_id: number
  captain_instance_id: number
  site_id: number
  created_at: string
}

export interface SiteBindingWithInfo extends SiteBinding {
  tenant_group_name: string
  instance_name: string
  site_name: string
  status?: 'active' | 'invalid' | 'unknown'
}

export interface CreateTenantGroupReq {
  name: string
  comment?: string
  admin_username: string
  admin_password: string
}

export interface CreateWafBindingReq {
  tenant_group_id: number
  captain_instance_ids: number[]
}

export interface CreateSiteBindingReq {
  tenant_group_id: number
  captain_instance_id: number
  site_ids: number[]
}

export interface AvailableWaf {
  captain_instance_id: number
  instance_name: string
  instance_host: string
  instance_status: string
  version?: string
}

export interface AvailableSite {
  site_id: number
  site_name: string
  server_names: string[]
}
