import { ConnectionConfig } from './website-security'

// === Backend Type ===

export enum BackendType {
  proxy = 'proxy',
  redirect = 'redirect',
  response = 'response'
}

export enum LoadBalancePolicy {
  roundBin = 'Round Robin',
  leastConn = 'Least Connected',
  ipHash = 'IP Hash',
  sessionSticky = 'Session Sticky',
  hash = 'Hash',
  ntlm = 'Ntlm'
}

export enum ForwardAction {
  append = 'append',
  cover = 'cover',
  noAction = 'no_action'
}

export enum HealthyCheckType {
  tcp = 'tcp',
  http = 'http',
  https = 'ssl_hello'
}

export enum HealthyCheckCode {
  http200 = 'http_2xx',
  http300 = 'http_3xx',
  http400 = 'http_4xx',
  http500 = 'http_5xx'
}

export enum HTTPMethod {
  get = 'GET',
  head = 'HEAD'
}

// === Backend Servers ===

export interface Backends {
  host: string
  port: number
  protocol: string
  is_enabled: boolean
  weight: number | ''
  health_check_status: string
}

// === Health Check ===

export interface HealthyCheckConfig {
  is_enabled: boolean
  check_type: HealthyCheckType
  host: string
  port: number
  path: string
  check_http_expect_alive: HealthyCheckCode[]
  interval: number
  timeout: number
  fall: number
  rise: number
  method: HTTPMethod
}

// === Proxy Headers ===

export interface ProxyHeadersConfig {
  name: string
  context: 'request' | 'response'
  action: 'set' | 'hide'
  value?: string
}

// === Custom Config ===

export interface CustomWeb {
  key: string
  value: string
}

export interface CustomConfig {
  ignore_types: string[]
  custom: Record<string, string>
  custom_web: CustomWeb[]
}

// === Backend Configs ===

export interface ProxyBackendConfig {
  type: BackendType.proxy
  load_balance_policy: LoadBalancePolicy
  servers: Backends[]
  header_config?: ProxyHeadersConfig[]
  preserve_source_port?: boolean
  x_forwarded_for_action: ForwardAction
  health_check_config?: HealthyCheckConfig
  session_sticky_cookie_max_age?: number | null
  keepalive_config: ConnectionConfig
  keepalive: string
  keepalive_timeout: string
  custom_config: CustomConfig
  slow_attack: {
    is_enabled: boolean
    isAuto?: boolean
    client_header_timeout?: number
    client_body_timeout?: number
  }
}

export interface RedirectBackendConfig {
  type: BackendType.redirect
  status_code: number | null
  path: string
}

export interface ResponseBackendConfig {
  type: BackendType.response
  status_code: number | null
  path: string
}

export type BackendConfig = ProxyBackendConfig | RedirectBackendConfig | ResponseBackendConfig
