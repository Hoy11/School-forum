export type Role = 'admin' | 'tenant_admin' | 'tenant'

export interface User {
  id: number
  username: string
  role: Role
  tenant_group_id: number | null
  tenant_group_name: string
  remark: string
  is_enabled: boolean
  role_locked: boolean
  password_set: boolean
  is_deleted: boolean
  created_at: string
  updated_at: string
}

export interface LoginReq {
  username: string
  password: string
}

export interface LoginResp {
  id: number
  username: string
  role: Role
  need_change_password?: boolean
}

export interface CreateUserReq {
  username: string
  password: string
  role: Role
  tenant_group_id?: number
  remark?: string
}

export interface UpdateUserReq {
  id: number
  username?: string
  role?: Role
  tenant_group_id?: number
  remark?: string
  is_enabled?: boolean
}

export interface CredentialResp {
  user_id: number
  username: string
  password: string
}
