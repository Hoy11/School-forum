export interface AclRuleTemplate {
  name: string
  match_method: {
    scope: string
    scheme?: string
    policy?: string
    target_type?: string
  }
  action: { kind: string }
  dry_run: boolean
  status: string
}

export interface ACLRuleExecutionLogSrcIP {
  id: number
  acl_rules_matched: string
  src_ip: string
  timestamp: string
  count: number
}

export interface AclLog {
  id: number
  acl_rule_id: number
  acl_rule_template_id: number
  acl_rule_template_version: number
  timestamp: number
  count: number
  acl_rule_target: string
  acl_rule_ip_group: string
  acl_rule_template: AclRuleTemplate | null
  waf_id: number
  waf_name: string
  waf_deleted: boolean
  origin_id: number
  isDesc?: boolean
  acl_rule_execution_log_src_ip?: ACLRuleExecutionLogSrcIP[]
}
