export interface ActionTranslation {
  value: number
  translation: string
}

export interface DetectLog {
  id: string
  event_id: string
  action: ActionTranslation
  website: string
  website_name: string
  src_ip: string
  attack_type: string
  attack_type_value: number
  risk_level: string
  risk_level_num: number
  timestamp: string
  url_path: string
  src_port: string
  dst_ip: string
  dst_port: string
  http_host_port: string
  method: string
  status_code: number
  country: string
  province: string
  scheme: string
  module: string
  reason: string
  payload: string
  effective: number
  flag: string | null
  waf_name: string
  waf_id: number
  captain_instance_id: number
  site_id: number
  soc_reported?: boolean
  is_highlighted: boolean
  highlight_comment: string
  highlight_color: string
}

export interface DetectLogDetail extends DetectLog {
  req_header: string
  req_body: string
  rsp_header: string
  rsp_body: string
  resp_header: string
  resp_body: string
  decode_path: string
  location: string
  session: string
  x_forwarded_for: string
  socket_ip: string
  upstream_addr: string
  detector_ip_source: string
  req_attack_type: string
  rsp_attack_type: string
  req_risk_level: string
  rsp_risk_level: string
  req_risk_level_num: number
  rsp_risk_level_num: number
  req_rule_id: string
  rsp_rule_id: string
  req_decode_path: string
  rsp_decode_path: string
  req_location: string
  rsp_location: string
  req_payload: string
  rsp_payload: string
  req_start_time: number
  rsp_start_time: number
  req_detect_time: number | null
  rsp_detect_time: number | null
  http_body_is_abandoned: boolean
  inner_vlan_id: number
  outer_vlan_id: number
}
