// === Session ===

export enum SessionType {
  off = 'off',
  cookie = 'cookie',
  urlQuery = 'url_query',
  bodyForm = 'body_form',
  header = 'header',
  safelineSession = 'internal_session',
  custom = 'custom',
  srcIP = 'src_ip'
}

export interface Session {
  type: SessionType
  param: string
}

// === Access Log ===

export enum LogOption {
  persistence = 'Persistence',
  nonPersistence = 'Non-Persistence',
  drop = 'Drop'
}

export interface WebsiteAccessLogSettings {
  is_enabled: boolean
  log_request_header: boolean
  log_response_header: boolean
  log_option: LogOption
  req_body: boolean
  rsp_body: boolean
}

// === Cookie Security ===

export enum CookieSecurityProtection {
  signatures = 'sign',
  encryption = 'sign_and_encrypt',
  propertyOnly = 'propertyOnly'
}

export enum CookieSecurityAttribute {
  httponly = 'HttpOnly',
  secure = 'Secure'
}

export interface CookieSecurity {
  is_enabled: boolean
  protection: CookieSecurityProtection
  key?: string
  action?: string
  log_option?: string
  compatible_time?: number
  security_attribute: CookieSecurityAttribute[]
  ip_verification?: boolean
  cookie: string[]
}

// === Bot Security ===

export enum BotSecurityType {
  code = 2,
  js = 1
}

export interface BotRule {
  is_enabled: boolean
  pattern: { $AND?: any[] }
}

export enum BotLogOption {
  persistence = 'Persistence',
  drop = 'Drop'
}

export interface BotConfig {
  id: number
  is_enabled: boolean
  enable_time: number
  protection: BotSecurityType
  expire_period: number
  include_rule: BotRule
  exclude_rule: BotRule
  log_option: BotLogOption
  exclude_known_bot: string[]
  websites: number[]
}

// === Connection Config ===

export enum ConnectionConfig {
  default = 'default_keepalive_config',
  custom = 'custom_keepalive_config',
  unTcp = 'no_keepalive'
}
