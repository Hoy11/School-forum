export interface SocConfig {
  id: number
  name: string
  brokers: string
  topic: string
  username?: string
  password?: string
  sasl_mechanism?: string
  endpoint?: string
  api_key?: string
  is_enabled: boolean
  created_at: string
  updated_at: string
}

export interface CreateSocReq {
  name: string
  brokers: string
  topic: string
  username?: string
  password?: string
  sasl_mechanism?: string
  is_enabled?: boolean
}

export interface UpdateSocReq {
  id: number
  name?: string
  brokers?: string
  topic?: string
  username?: string
  password?: string
  sasl_mechanism?: string
  is_enabled?: boolean
}
