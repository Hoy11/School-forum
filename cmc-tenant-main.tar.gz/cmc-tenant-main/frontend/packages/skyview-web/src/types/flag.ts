export type Flag = string

export interface MarkFlag {
  flag: Flag
  log_ids: number[]
}
