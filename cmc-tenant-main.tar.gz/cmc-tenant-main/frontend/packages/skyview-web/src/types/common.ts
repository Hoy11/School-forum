export interface PageResult<T> {
  total: number
  items: T[]
}

export type Oper =
  | 'like'
  | 'not like'
  | 'in'
  | 'not in'
  | '='
  | '!='
  | '<>'
  | '<'
  | '<='
  | '>'
  | '>='
  | 'range'
  | 'before'
  | 'after'
  | 'exact'
  | 'not_exact'
  | 'contains'
  | 'not_contains'
  | 'not_in'
  | 'lt'
  | 'lte'
  | 'gt'
  | 'gte'
  | 'regex'
  | 'not regex'
  | 'not_regex'
  | 'net_contained_or_equal'
  | 'not_net_contained_or_equal'
  | 'incidr'
  | 'inequalcidr'
  | 'containscidr'
  | 'containsequalcidr'

export type FilterFieldType = 'text' | 'number' | 'choice' | 'multi_choice' | 'time' | 'time_range' | 'flag'

export interface FilterFieldOption {
  label: string
  value: string
  type: FilterFieldType
  operators?: { label: string; value: Oper }[]
  defaultOper?: Oper
  choices?: { label: string; value: string }[]
  placeholder?: string
}

export interface ConditionItem {
  oper: Oper
  value: string | number | boolean | (string | number | boolean)[]
}

export interface Condition {
  target: string
  items: ConditionItem[]
}

export interface ApiResponse<T> {
  err: string | null
  msg: string
  data: T
}
