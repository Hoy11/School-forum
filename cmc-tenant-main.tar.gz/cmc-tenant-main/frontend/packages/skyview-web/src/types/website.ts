import { BackendConfig } from './website-backend'
import {
  WebsiteHealthyCheckStatus,
  OperationModeKind,
  SSLProtocol,
  AntiTamperStatus,
  DynamicResolveConfig,
  ProxyBindConfig,
  SelectedTengine,
  SSLCertModel,
  PolicyModel,
  NodeStatus,
  AssetGroupType,
  WorkGroupModel,
  CertOriginal,
  SiteFromStep,
  WorkGroupOperationMode,
} from './website-enums'
import {
  Session,
  SessionType,
  WebsiteAccessLogSettings,
  CookieSecurity,
  BotConfig,
} from './website-security'

// === Port & Path ===

export interface RealIPConfig {
  set_real_ip_from: string
  real_ip_header: 'proxy_protocol'
}

export interface WebsitePort {
  port: number
  ssl: boolean
  non_http: boolean
  http2: boolean
  sni: boolean
  proxy_protocol?: boolean
  realip_config?: RealIPConfig
}

export interface WebsiteUrlPath {
  op: string // 'pre' | 'reg' | 'exact'
  url_path: string
}

// === Trans Proxy Address ===

export interface WAddr {
  ip_port: string
  ssl: boolean
  http2: boolean
  sni: boolean
  non_http: boolean
}

// === Cert Settings (form state) ===

export interface CertSettings {
  cert: File | null
  key: File | null
  enc_cert: File | null
  enc_key: File | null
  type: CertOriginal
  certWithKey: boolean
  certPassword: string
  certName: string
}

// === Website ===

export interface Website {
  id: number
  is_enabled: boolean
  name: string
  interface: string | 'virtual'
  operation_mode: WorkGroupOperationMode
  server_names: string[]
  url_paths: WebsiteUrlPath[]
  ports: WebsitePort[]
  create_time: number
  last_update_time: number
  policy_group: number | null
  session_method: Session
  detector_ip_source: string[]
  proxy_ip_list: string[]
  proxy_ip_groups: number[]
  access_log: WebsiteAccessLogSettings
  remark: string
  ssl_cert: number | null
  ip: string[]
  ssl_protocols: SSLProtocol[]
  ssl_ciphers: string
  backend_config: BackendConfig
  health_check_status: WebsiteHealthyCheckStatus
  flag?: string | null
  dynamic_resolve_upstream_config: DynamicResolveConfig
  deep_detection_config: { is_enabled: boolean }
  anti_tamper_status: AntiTamperStatus
  anti_tamper_rules: any[]
  proxy_bind_config: ProxyBindConfig
  bot_config: BotConfig
  bot_configs: number[]
  ntlm_enabled: boolean
  selected_tengine: SelectedTengine
  proxy_protocol: boolean
  realip_config_enable: boolean
  realip_config: RealIPConfig
  asset_group: number
  cookie_security?: CookieSecurity
  captain_instance_id?: number
  addrs?: WAddr[]
}

// === Create Request ===

export interface CreateWebsiteReq {
  captain_instance_id: number
  [key: string]: any
}

// Re-export for convenience
export {
  BackendConfig,
  ProxyBackendConfig,
  RedirectBackendConfig,
  ResponseBackendConfig,
  Backends,
  BackendType,
  LoadBalancePolicy,
  ForwardAction,
  HealthyCheckConfig,
  HealthyCheckType,
  HealthyCheckCode,
  HTTPMethod,
  ProxyHeadersConfig,
  CustomConfig,
} from './website-backend'

export {
  SessionType,
  LogOption,
  CookieSecurityProtection,
  CookieSecurityAttribute,
  ConnectionConfig,
} from './website-security'

export {
  WebsiteHealthyCheckStatus,
  OperationModeKind,
  SSLProtocol,
  FallbackType,
  AntiTamperStatus,
  SelectedTengineType,
  HashSelectIpMethod,
  SSLCertModel,
  PolicyModel,
  NodeStatus,
  AssetGroupType,
  WorkGroupModel,
  CertOriginal,
  SiteFromStep,
  WorkGroupOperationMode,
} from './website-enums'
