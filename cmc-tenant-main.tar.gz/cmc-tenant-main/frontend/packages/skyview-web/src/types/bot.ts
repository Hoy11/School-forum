export interface BotLog {
  id: string
  bot_config_id: string
  bot_config_name: string
  site_uuid: string
  website_name: string
  src_ip: string
  verify_mode: { value: number, translation: string }
  challenge_id: string
  event_id: string
  log_id: string
  waf_id: number
  waf_name: string
  waf_deleted: boolean
  timestamp: string
  is_bot: number
  country: string
  province: string
  detector: string
  dest_ip: string
  dest_port: number
  src_port: number
}

export interface BotLogDetail extends BotLog {
  req_header: string
  req_body: string
  website: string
}

export type BotRecordLog = BotLog
export type BotResultLog = BotLog
