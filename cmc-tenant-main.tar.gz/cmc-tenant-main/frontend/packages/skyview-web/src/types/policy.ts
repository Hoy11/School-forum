// === Policy Model (matches Captain API PolicyModel) ===

export type ModuleState = 'enabled' | 'disabled'
export type RiskAction = 'deny' | 'continue'

export interface ModuleDetectionConfig {
  state: ModuleState
  detect_config: Record<string, unknown>
  low_risk_action: RiskAction
  medium_risk_action: RiskAction
  high_risk_action: RiskAction
  low_risk_enable_log: 0 | 1
  medium_risk_enable_log: 0 | 1
  high_risk_enable_log: 0 | 1
}

export interface BaseModulesDetectionConfig {
  state: ModuleState
  is_enable: boolean
  low_risk_action: RiskAction
  medium_risk_action: RiskAction
  high_risk_action: RiskAction
  low_risk_enable_log: 0 | 1
  medium_risk_enable_log: 0 | 1
  high_risk_enable_log: 0 | 1
}

export interface ForbiddenPageConfig {
  path: string
  action: string
  status_code: number
}

export interface MiscDetectionConfig {
  decode_config: Record<string, unknown>
  [key: string]: unknown
}

export interface TenginePageConfigItem {
  path: string
  status_code: number
}

export interface ForbiddenPageModel {
  id: number
  name: string
  comment: string
  create_time: string
  policy_group_used_count: number
  work_group_used_count: number
}

export interface PolicyModel {
  id: number
  name: string
  create_time: number | string
  last_update_time: number | string
  is_default: boolean
  binding_count: number
  site_count: number
  source: 'created' | 'inherited' | ''
  has_external_ref: boolean
  shared_group_names?: string[]
  referenced_site_names?: string[]
  modules_state: boolean
  response_detection_state: boolean
  response_detection_max_body_size: number
  response_detection_generate_log: boolean
  request_detection_max_body_size: number
  detection_timeout_threshold: number
  log_detection_timeout_event: boolean
  is_timeout_enabled: boolean
  forbidden_page_config: ForbiddenPageConfig
  tengine_page_config: TenginePageConfigItem[]
  modules_detection_config: Record<string, ModuleDetectionConfig>
  base_modules_detection_config: BaseModulesDetectionConfig
  misc_detection_config: MiscDetectionConfig
  payload_explain_state: boolean
  req_http_body_max_size: number
  rsp_http_body_max_size: number
  max_file_size: number
}

// === Module display constants ===

export const MODULE_NAMES: Record<string, string> = {
  m_sqli: 'SQL注入检测模块',
  m_xss: 'XSS检测模块',
  m_csrf: 'CSRF检测模块',
  m_ssrf: 'SSRF检测模块',
  m_php_unserialize: 'PHP序列化对象解析检测模块',
  m_asp_code_injection: 'ASP注入检测模块',
  m_ssti: '模板注入检测模块',
  m_java_unserialize: 'Java反序列化检测模块',
  m_file_upload: '文件上传检测模块',
  m_file_include: '文件包含检测模块',
  m_php_code_injection: 'PHP注入检测模块',
  m_java: 'Java注入检测模块',
  m_cmd_injection: '命令注入检测模块',
  m_response: '服务端响应检测模块',
  m_scanner: '扫描器检测模块',
  m_http: 'HTTP协议合规检测模块',
}

export const MODULE_ORDER: string[] = [
  'm_sqli', 'm_xss', 'm_csrf', 'm_ssrf',
  'm_php_unserialize', 'm_asp_code_injection', 'm_ssti', 'm_java_unserialize',
  'm_file_upload', 'm_file_include', 'm_php_code_injection', 'm_java',
  'm_cmd_injection', 'm_response', 'm_scanner', 'm_http',
]

// === Legacy types (used by Policy list page, to be migrated) ===

/** @deprecated Use PolicyModel instead */
export interface PolicyGroup {
  id: number
  name: string
  comment: string
  is_global: boolean
  is_default: boolean
  binding_count: number
  site_count: number
  source: 'created' | 'inherited' | ''
  has_external_ref: boolean
  shared_group_names?: string[]
  referenced_site_names?: string[]
  modules: Record<string, PolicyModuleConfig>
}

/** @deprecated Use ModuleDetectionConfig instead */
export interface PolicyModuleConfig {
  is_enabled: boolean
  config: Record<string, unknown>
}

export interface PolicyRule {
  id: number
  name: string
  comment: string
  is_global: boolean
  is_enabled: boolean
  action: string
  attack_type: number
  risk_level: number
  pattern: Record<string, unknown>
  website: number | null
  websites: number[]
  policy_group: number | null
  target: string
  log_option: string
  delay: number
  percentage: number
  cron_config: { type: string }
  forbidden_page_config: unknown
  is_expired: boolean
  expire_time: string | null
  create_time: number
  last_update_time: number
  captain_instance_id: number
  binding_count?: number
  site_names?: string[]
  has_external_ref?: boolean
  source?: string
  shared_group_names?: string[]
}

export interface SkynetRule {
  id: number
  is_enabled: boolean
  enable_log: boolean
  action: string
  risk_level: number
  comment: string
  policy_group: number
  create_time: string
  last_update_time: string
  skynet_rule_id: number
  ruleid: number
  name: string
  description: string
  tag: string[]
  is_built_in: boolean
  is_obsolete: boolean
  attack_type: number
  pattern: Record<string, unknown>
}

export interface AntiTamperRule {
  id: number
  comment: string
  is_enabled: boolean
  create_time: number
  last_update_time: number
  websites: number[]
  path: string
  path_mode: 'string' | 'regex'
  host: string
  protocol: string
  anti_tamper_status: string
}

export interface GlobalPolicyConfig {
  is_enabled: boolean
  modules: Record<string, PolicyModuleConfig>
}
