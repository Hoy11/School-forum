export interface PasswordConfig {
  min_length: number
  has_upper: boolean
  has_lower: boolean
  has_num: boolean
  has_symbol: boolean
  is_forced: boolean
  update_days: number
}

export interface LoginSecurityConfig {
  max_retry: number
  lock_minutes: number
  retry_window: number
  single_sign_on: boolean
}

export interface HighlightTag {
  key: string
  color: string
  comment: string
}
