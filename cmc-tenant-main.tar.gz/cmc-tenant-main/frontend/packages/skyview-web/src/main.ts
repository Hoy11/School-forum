import '@/elementSetup'
import '@/style'
import router from '@/router'
import store from '@/store'
import 'core-js/features/string'
import 'core-js/modules/es.object.values'
import Vue from 'vue'

Vue.config.productionTip = false

async function initAuth() {
  const user = store.getters['user/currentUser']
  if (user) return

  try {
    const { current } = await import('@/api/auth')
    const resp = await current()
    if (resp.err === null) {
      store.commit('user/setUser', { user: resp.data, needChangePassword: false })
    }
  } catch {
    // Not authenticated, route guard will redirect to login
  }
}

initAuth().then(() => {
  const app = new Vue({
    router,
    store,
    template: '<router-view/>',
    mounted() {
      const node = document.querySelector('#launch-loader')
      if (node && Object.prototype.hasOwnProperty.call(node, 'remove')) {
        node.remove()
      }
    }
  })
  app.$mount('#app')
})
