import { captainPath } from '@/api/captain'

describe('captainPath', () => {
  it('maps known paths', () => {
    expect(captainPath('/api/SoftwareReverseProxyWebsiteAPI')).toBe('/api/captain/site/list')
    expect(captainPath('/api/IPGroupAPI')).toBe('/api/captain/ip-group/list')
    expect(captainPath('/api/CertAPI')).toBe('/api/captain/cert/list')
    expect(captainPath('/api/PolicyGroupAPI')).toBe('/api/captain/policy/list')
    expect(captainPath('/api/CustomRuleAPI')).toBe('/api/captain/policy-rule/list')
    expect(captainPath('/api/DetectLogAPI')).toBe('/api/captain/detect-log/list')
    expect(captainPath('/api/AclLogAPI')).toBe('/api/captain/acl-log/list')
  })

  it('returns original path for unknown paths', () => {
    expect(captainPath('/api/SomeUnknownAPI')).toBe('/api/SomeUnknownAPI')
  })
})
