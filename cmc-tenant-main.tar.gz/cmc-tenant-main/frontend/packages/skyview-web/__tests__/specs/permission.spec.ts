import { isAdmin, isTenantAdmin, isTenant, canManage, canAccessSystem } from '@/permission'
import store from '@/store'
import { User } from '@/types/users'

function makeUser(role: 'admin' | 'tenant_admin' | 'tenant'): User {
  return {
    id: 1, username: 'test', role, tenant_group_id: null,
    tenant_group_name: '', remark: '', is_enabled: true,
    password_set: true, is_deleted: false, created_at: '', updated_at: ''
  }
}

describe('permission', () => {
  afterEach(() => {
    store.commit('user/clearUser')
  })

  it('isAdmin returns true for admin', () => {
    store.commit('user/setUser', { user: makeUser('admin'), needChangePassword: false })
    expect(isAdmin()).toBe(true)
    expect(isTenantAdmin()).toBe(false)
    expect(isTenant()).toBe(false)
  })

  it('isTenantAdmin returns true for tenant_admin', () => {
    store.commit('user/setUser', { user: makeUser('tenant_admin'), needChangePassword: false })
    expect(isAdmin()).toBe(false)
    expect(isTenantAdmin()).toBe(true)
    expect(isTenant()).toBe(false)
  })

  it('isTenant returns true for tenant', () => {
    store.commit('user/setUser', { user: makeUser('tenant'), needChangePassword: false })
    expect(isAdmin()).toBe(false)
    expect(isTenantAdmin()).toBe(false)
    expect(isTenant()).toBe(true)
  })

  it('canManage returns true for admin and tenant_admin', () => {
    store.commit('user/setUser', { user: makeUser('admin'), needChangePassword: false })
    expect(canManage()).toBe(true)
    store.commit('user/setUser', { user: makeUser('tenant_admin'), needChangePassword: false })
    expect(canManage()).toBe(true)
    store.commit('user/setUser', { user: makeUser('tenant'), needChangePassword: false })
    expect(canManage()).toBe(false)
  })

  it('canAccessSystem returns true only for admin', () => {
    store.commit('user/setUser', { user: makeUser('admin'), needChangePassword: false })
    expect(canAccessSystem()).toBe(true)
    store.commit('user/setUser', { user: makeUser('tenant_admin'), needChangePassword: false })
    expect(canAccessSystem()).toBe(false)
  })

  it('returns false when no user', () => {
    expect(isAdmin()).toBe(false)
    expect(isTenantAdmin()).toBe(false)
    expect(isTenant()).toBe(false)
  })
})
