import store from '@/store'
import { User } from '@/types/users'

function makeUser(role: 'admin' | 'tenant_admin' | 'tenant'): User {
  return {
    id: 1, username: 'test', role, tenant_group_id: null,
    tenant_group_name: '', remark: '', is_enabled: true,
    password_set: true, is_deleted: false, created_at: '', updated_at: ''
  }
}

describe('store/user', () => {
  afterEach(() => {
    store.commit('user/clearUser')
  })

  it('setUser sets currentUser via getter', () => {
    const user = makeUser('admin')
    store.commit('user/setUser', { user, needChangePassword: false })
    expect(store.getters['user/currentUser']).toEqual(user)
    expect(store.getters['user/needChangePassword']).toBe(false)
  })

  it('setUser sets needChangePassword', () => {
    const user = makeUser('admin')
    store.commit('user/setUser', { user, needChangePassword: true })
    expect(store.getters['user/needChangePassword']).toBe(true)
  })

  it('clearUser resets state', () => {
    const user = makeUser('admin')
    store.commit('user/setUser', { user, needChangePassword: true })
    store.commit('user/clearUser')
    expect(store.getters['user/currentUser']).toBeNull()
    expect(store.getters['user/needChangePassword']).toBe(false)
  })

  it('getters return correct role values', () => {
    const user = makeUser('tenant_admin')
    store.commit('user/setUser', { user, needChangePassword: false })
    expect(store.getters['user/role']).toBe('tenant_admin')
    expect(store.getters['user/isAdmin']).toBe(false)
    expect(store.getters['user/isTenantAdmin']).toBe(true)
    expect(store.getters['user/isTenant']).toBe(false)
  })
})
