import { shallowMount } from '@vue/test-utils'
import Dashboard from '@/views/Dashboard'

jest.mock('@/api/user', () => ({
  userList: jest.fn().mockResolvedValue({ err: null, data: { total: 5, items: [] } })
}))
jest.mock('@/api/tenant-group', () => ({
  tenantGroupList: jest.fn().mockResolvedValue({ err: null, data: { total: 3, items: [] } })
}))
jest.mock('@/api/binding', () => ({
  wafBindingList: jest.fn().mockResolvedValue({ err: null, data: { total: 2, items: [] } })
}))

describe('Dashboard', () => {
  it('loads stats on created', async () => {
    const wrapper = shallowMount(Dashboard, {
      stubs: { 'el-row': true, 'el-col': true, 'el-card': true }
    })
    await new Promise(r => setTimeout(r, 100))
    await wrapper.vm.$nextTick()
    expect((wrapper.vm as any).userCount).toBe(5)
    expect((wrapper.vm as any).groupCount).toBe(3)
    expect((wrapper.vm as any).wafCount).toBe(2)
  })
})
