import { beforeEach } from '@/router/guard'
import store from '@/store'
import { User } from '@/types/users'
import { Route } from 'vue-router'

function makeUser(role: 'admin' | 'tenant_admin' | 'tenant'): User {
  return {
    id: 1, username: 'test', role, tenant_group_id: null,
    tenant_group_name: '', remark: '', is_enabled: true,
    password_set: true, is_deleted: false, created_at: '', updated_at: ''
  }
}

function makeRoute(name: string): Route {
  return { name, path: '/', matched: [], fullPath: '/', hash: '', params: {}, query: {}, meta: {} } as Route
}

describe('router guard', () => {
  afterEach(() => {
    store.commit('user/clearUser')
  })

  it('allows login page without auth', () => {
    const next = jest.fn()
    beforeEach(makeRoute('login'), makeRoute(''), next)
    expect(next).toHaveBeenCalledWith()
  })

  it('redirects to login when not authenticated', () => {
    const next = jest.fn()
    beforeEach(makeRoute('dashboard'), makeRoute(''), next)
    expect(next).toHaveBeenCalledWith('/login')
  })

  it('allows all users to access dashboard', () => {
    store.commit('user/setUser', { user: makeUser('tenant'), needChangePassword: false })
    const next = jest.fn()
    beforeEach(makeRoute('dashboard'), makeRoute(''), next)
    expect(next).toHaveBeenCalledWith()
  })

  it('blocks non-admin from admin routes', () => {
    store.commit('user/setUser', { user: makeUser('tenant'), needChangePassword: false })
    const next = jest.fn()
    beforeEach(makeRoute('tenantGroupList'), makeRoute(''), next)
    expect(next).toHaveBeenCalledWith('/')
  })

  it('allows admin to access admin routes', () => {
    store.commit('user/setUser', { user: makeUser('admin'), needChangePassword: false })
    const next = jest.fn()
    beforeEach(makeRoute('tenantGroupList'), makeRoute(''), next)
    expect(next).toHaveBeenCalledWith()
  })

  it('blocks tenant from tenant_admin routes', () => {
    store.commit('user/setUser', { user: makeUser('tenant'), needChangePassword: false })
    const next = jest.fn()
    beforeEach(makeRoute('tenantUserList'), makeRoute(''), next)
    expect(next).toHaveBeenCalledWith('/')
  })
})
