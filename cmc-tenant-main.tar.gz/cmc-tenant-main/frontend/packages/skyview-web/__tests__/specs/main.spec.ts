import { shallowMount } from '@vue/test-utils'
import App from '@/App'

describe('App', () => {
  it('renders without errors', () => {
    const wrapper = shallowMount(App, {
      stubs: ['router-view']
    })
    expect(wrapper.find('#app').exists()).toBe(true)
  })
})
