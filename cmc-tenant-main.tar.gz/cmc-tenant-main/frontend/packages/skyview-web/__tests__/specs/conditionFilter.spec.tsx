import { shallowMount } from '@vue/test-utils'
import ConditionFilter from '@/components/ConditionFilter'
import { Condition } from '@/types/common'

describe('ConditionFilter', () => {
  it('renders initial conditions', () => {
    const conditions: Condition[] = [
      { target: 'username', items: [{ oper: 'like', value: 'test' }] }
    ]
    const wrapper = shallowMount(ConditionFilter, {
      propsData: { conditions }
    })
    expect(wrapper.findAll('.condition-filter__item').length).toBe(1)
  })

  it('emits change when adding condition', () => {
    const wrapper = shallowMount(ConditionFilter, {
      propsData: { conditions: [] }
    })
    wrapper.vm.addCondition()
    expect(wrapper.emitted('change')).toBeTruthy()
    expect(wrapper.emitted('change')![0][0]).toHaveLength(1)
  })

  it('emits change when removing condition', () => {
    const conditions: Condition[] = [
      { target: 'username', items: [{ oper: 'like', value: 'test' }] }
    ]
    const wrapper = shallowMount(ConditionFilter, {
      propsData: { conditions }
    })
    wrapper.vm.removeCondition(0)
    expect(wrapper.emitted('change')![0][0]).toHaveLength(0)
  })

  it('emits search when clicking search button', () => {
    const conditions: Condition[] = [
      { target: 'role', items: [{ oper: '=', value: 'admin' }] }
    ]
    const wrapper = shallowMount(ConditionFilter, {
      propsData: { conditions }
    })
    wrapper.vm.handleSearch()
    expect(wrapper.emitted('search')).toBeTruthy()
    expect(wrapper.emitted('search')![0][0]).toEqual(conditions)
  })
})
