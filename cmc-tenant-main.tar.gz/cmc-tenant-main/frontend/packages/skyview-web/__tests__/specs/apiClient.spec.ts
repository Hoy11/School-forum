import { success, error, networkError } from '@/api/client/processer'
import { HttpResponse } from '@/api/client/resp'

describe('API client processer', () => {
  describe('success', () => {
    it('returns true for null err', () => {
      const resp: HttpResponse<string> = { err: null, msg: 'ok', data: 'test' }
      expect(success(resp)).toBe(true)
    })

    it('returns false for non-null err', () => {
      const resp: HttpResponse<string> = { err: 'bad_request', msg: '参数错误', data: '' }
      expect(success(resp)).toBe(false)
    })
  })

  describe('error', () => {
    it('returns msg when available', () => {
      const resp: HttpResponse = { err: 'bad_request', msg: '参数错误', data: '' }
      expect(error(resp)).toBe('参数错误')
    })

    it('returns err when msg is empty', () => {
      const resp: HttpResponse = { err: 'bad_request', msg: '', data: '' }
      expect(error(resp)).toBe('bad_request')
    })
  })

  describe('networkError', () => {
    it('handles 429 rate limit', () => {
      const err = {
        response: {
          status: 429,
          headers: { 'retry-after': '30' },
          data: {}
        }
      }
      expect(networkError(err)).toContain('操作过于频繁')
    })

    it('handles general HTTP error', () => {
      const err = {
        response: {
          status: 500,
          data: { msg: '服务器错误' }
        }
      }
      expect(networkError(err)).toContain('服务器错误')
    })

    it('handles network failure', () => {
      expect(networkError(new Error('Network Error'))).toContain('网络错误')
    })
  })
})
