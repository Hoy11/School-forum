import { shallowMount } from '@vue/test-utils'
import Grid from '@/components/Grid'
import { ColumnDef } from '@/components/Grid'

const columns: ColumnDef[] = [
  { key: 'name', title: '名称' },
  { key: 'role', title: '角色' },
]

const mockFetchData = jest.fn().mockResolvedValue({
  err: null,
  msg: 'success',
  data: { total: 2, items: [{ name: 'admin', role: 'admin' }, { name: 'user', role: 'tenant' }] }
})

describe('Grid', () => {
  it('calls fetchData on mount', async () => {
    mockFetchData.mockClear()
    const wrapper = shallowMount(Grid, {
      propsData: { columns, fetchData: mockFetchData }
    })
    await (wrapper.vm as any).$nextTick()
    expect(mockFetchData).toHaveBeenCalledWith(0, 20, [])
  })

  it('computes offset correctly', () => {
    const vm = new Grid({
      propsData: { columns, fetchData: mockFetchData }
    })
    ;(vm as any).currentPage = 3
    ;(vm as any).pageSize = 20
    expect((vm as any).offset).toBe(40)
  })
})
