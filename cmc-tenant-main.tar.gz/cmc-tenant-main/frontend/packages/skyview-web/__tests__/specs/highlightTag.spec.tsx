import { shallowMount } from '@vue/test-utils'
import HighlightTag from '@/components/HighlightTag'

describe('HighlightTag', () => {
  it('renders nothing when not highlighted', () => {
    const wrapper = shallowMount(HighlightTag, {
      propsData: { isHighlighted: false }
    })
    expect(wrapper.find('el-tag-stub').exists()).toBe(false)
  })

  it('renders tag when highlighted', () => {
    const wrapper = shallowMount(HighlightTag, {
      propsData: { isHighlighted: true, comment: 'suspicious IP' }
    })
    expect(wrapper.find('eltag-stub').exists() || wrapper.text()).toBeTruthy()
  })
})
