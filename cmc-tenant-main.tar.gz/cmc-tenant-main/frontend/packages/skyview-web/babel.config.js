module.exports = {
  presets: [
    [
      '@babel/preset-env',
      {
        targets: {
          node: 'current'
        },
        modules: 'auto',
        useBuiltIns: 'usage',
        corejs: 3
      }
    ],
    '@babel/preset-typescript'
  ],
  plugins: [
    '@babel/plugin-syntax-dynamic-import',
    'jsx-v-model',
    'transform-vue-jsx',
    '@babel/plugin-transform-block-scoping',
    ['@babel/plugin-proposal-decorators', { version: "legacy" }],
    ...(() => {
      return process.env.NODE_ENV === 'test'
        ? [
          '@babel/plugin-proposal-class-properties',
          ['@babel/plugin-transform-classes', { 'loose': true }],
        ]
        : [
          ['@babel/plugin-transform-classes', { 'loose': true }],
          '@babel/plugin-proposal-class-properties',
        ]
    })(),
    '@babel/plugin-transform-modules-commonjs',
    '@babel/plugin-proposal-nullish-coalescing-operator',
    '@babel/plugin-proposal-optional-chaining',
    '@babel/plugin-proposal-object-rest-spread'
  ]
}
