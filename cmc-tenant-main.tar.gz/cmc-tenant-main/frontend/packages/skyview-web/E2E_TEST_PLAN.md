# CMC Tenant E2E 自动化测试

## 前置条件

1. 开发服务器运行: `npm run dev`
2. Playwright 通过 skill 插件提供（`NODE_PATH` 自动配置）

## 运行方式

```bash
# 运行全部 E2E 测试
node e2e/run.js

# 运行单个测试
NODE_PATH=~/.claude/plugins/cache/playwright-skill/playwright-skill/4.1.0/skills/playwright-skill/node_modules \
  node e2e/protection.spec.js

# 指定目标地址
TARGET_URL=http://localhost:8080 node e2e/run.js
```

## 测试文件

| 文件 | 范围 | 用例数 |
|---|---|---|
| `e2e/helpers.js` | 共享工具函数 | - |
| `e2e/login.spec.js` | 登录流程 | 6 |
| `e2e/navigation.spec.js` | 导航与权限 | 7 |
| `e2e/dashboard.spec.js` | 总览页 | 3 |
| `e2e/crud.spec.js` | CRUD 页面 | 8 |
| `e2e/logs.spec.js` | 日志与监测 | 5 |
| `e2e/protection.spec.js` | 防护管理（含新增页面） | 12 |
| `e2e/log-detail.spec.js` | 日志详情页（新增） | 5 |
| `e2e/filters-forms.spec.js` | 筛选器与表单增强（新增） | 11 |
| `e2e/profile.spec.js` | 个人设置 | 5 |
| `e2e/errors.spec.js` | 错误处理 | 3 |
| `e2e/run.js` | 全量执行入口 | - |

**合计: 65 个 E2E 用例**

## 测试策略

- **API Mock**: 所有后端 API 通过 `page.route()` 拦截并返回 Mock 数据，无需后端运行
- **角色切换**: 通过 `loginAsRole(page, role)` 模拟 admin/tenant_admin/tenant 登录
- **客户端导航**: 使用 `navigateToPage(page, path)` 通过 Vue Router 跳转，保持认证状态
- **Playwright 依赖**: 通过 `NODE_PATH` 指向 skill 插件的 `node_modules`，无需本地安装

## 新增测试覆盖

### 防护管理 (protection.spec.js)
- IP 组列表 + 新建对话框
- SSL 证书列表 + 上传对话框
- 防护策略列表 + 详情页（模块开关）
- 自定义规则列表 + 新建对话框
- 站点规则列表
- WAF 列表
- 站点管理 + 新建/编辑表单
- 租户管理员权限控制

### 日志详情 (log-detail.spec.js)
- 检测日志详情页（基本信息 + HTTP 内容）
- SOC 上报按钮
- Bot 记录详情页
- Bot 结果详情页
- 返回导航

### 筛选器与表单增强 (filters-forms.spec.js)
- 6 个列表页 ConditionFilter 渲染
- 条件添加与填写交互
- WAF 绑定下拉选择（替代手动输入 ID）
- 站点绑定下拉选择
- SOC 配置编辑按钮
- 日志下载时间范围选择器
- 租户用户列表筛选器
