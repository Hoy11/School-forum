# 前端项目关键信息

## 技术栈

| 类别 | 技术 | 版本 |
|---|---|---|
| 框架 | Vue 2 | 2.6.14 |
| 语言 | TypeScript | 4.6.2 |
| 组件写法 | vue-class-component + TSX | 7.2.6 / 9.1.2 |
| UI 库 | Element UI | 2.15.2 |
| 状态管理 | Vuex 3 | 3.6.0 |
| 路由 | Vue Router 3 | 3.5.2 |
| HTTP | Axios | 0.21.1 |
| 构建 | Webpack 4 | 4.46.0 |
| 包管理 | pnpm workspace + lerna | - |
| 测试 | Jest + @vue/test-utils | - |
| E2E | Playwright (via playwright-skill) | - |

## 注意事项

- Webpack 4 + Node.js >= 17 需设置 `NODE_OPTIONS=--openssl-legacy-provider`
- 视图文件使用 `// @ts-nocheck` 规避 Vue 2 TSX 类型推断问题
- `render()` 方法必须接收 `h` 参数: `render(h: any)`，否则运行时报 "h is not defined"
- npm 包从内部 registry (`npm.in.chaitin.net`) 安装，`@splat/*`/`@safeline-2/*` 需要 NPM_TOKEN
- 开发服务器端口 3000，API 代理到 `http://localhost:8080`

## 目录结构

```
frontend/
├── .npmrc                    # 内部 registry 配置
├── lerna.json
├── package.json
├── pnpm-workspace.yaml
└── packages/skyview-web/
    ├── package.json
    ├── tsconfig.json
    ├── babel.config.js
    ├── jest.config.js
    ├── build/                 # Webpack 构建配置
    ├── config/                # dev/build 环境配置
    ├── index.html
    ├── e2e/                   # Playwright E2E 测试（10 个套件）
    ├── src/
    │   ├── main.ts            # 入口（含 initAuth 认证恢复）
    │   ├── style.ts           # 全局样式（登录/布局/侧边栏/卡片）
    │   ├── App.tsx
    │   ├── api/               # API 层（25 个模块）
    │   │   ├── client/        #   Axios 实例 + 拦截器（401/429）
    │   │   ├── index.ts       #   get/post/put/del/upload/download
    │   │   ├── captain.ts     #   captainPath() 路径映射（13条）
    │   │   ├── auth.ts / user.ts / tenant-user.ts / api-token.ts / ...
    │   │   ├── captain-site.ts / captain-rule.ts / captain-ip-group.ts / ...
    │   │   ├── captain-cert.ts / captain-policy.ts / ...
    │   │   ├── log/ / system.ts / soc.ts / filter.ts / ...
    │   ├── types/             # 类型定义（15 个）
    │   ├── store/             # Vuex（user + tenant 模块）
    │   ├── router/            # 路由表 + 守卫（33 条路由）
    │   ├── permission/        # 角色判断函数
    │   ├── components/        # 通用组件（10 个）
    │   ├── mixins/            # 共享 mixins（WafSelectorMixin）
    │   └── views/             # 页面视图（31 个）
    └── __tests__/specs/       # Jest 单元测试（10 个文件）
```

## 核心模块

### API 层（25 个模块）

| 模块 | 文件 | 说明 |
|---|---|---|
| 客户端 | `client/index.ts` | Axios 实例，401 跳转 + 429 提示拦截器 |
| 通用方法 | `index.ts` | get/post/put/del/upload/download/listQuery |
| 路径映射 | `captain.ts` | 纵横 API 路径 → CMC 代理路径（13 条映射） |
| 认证 | `auth.ts` | login / logout / current |
| 全局用户 | `user.ts` | CRUD + Enable/Disable/Credential/Unlock |
| 租户用户 | `tenant-user.ts` | CRUD + Enable/Disable/Credential/Unlock |
| API Token | `api-token.ts` | create / list / delete |
| 当前用户 | `current-user.ts` | changePassword |
| 租户组 | `tenant-group.ts` | CRUD |
| 绑定 | `binding.ts` | WAF/站点 绑定 + 可用列表 |
| 高亮 IP | `highlight-ip.ts` | CRUD |
| 纵横站点 | `captain-site.ts` | list（自动注入 captain_instance_id）/ CRUD |
| 纵横规则 | `captain-rule.ts` | list（注入 is_global=false）/ CRUD + 优先级/启用/模块 |
| 纵横 IP 组 | `captain-ip-group.ts` | CRUD + itemAdd/itemDelete |
| 纵横证书 | `captain-cert.ts` | list/Detail/Upload/Update/Delete |
| 纵横策略 | `captain-policy.ts` | CRUD + globalConfig |
| 检测日志 | `log/index.ts` | list/Detail/Mark + getPageFilters |
| Bot 日志 | `log/bot.ts` | record/result List/Detail |
| 标记 | `log/flag.ts` | markFlagGet/Update |
| 日志任务 | `log-task.ts` | create/List/Cancel/Delete/Download |
| 筛选保存 | `filter.ts` | CRUD |
| 系统管理 | `system.ts` | SOC + 纵横配置 + 审计 + 密码策略 + 登录安全 + 标记 |
| SOC 上报 | `soc.ts` | socReport |

### 类型定义（15 个文件）

`common.ts` `users.ts` `tenant.ts` `highlight-ip.ts` `soc.ts` `website.ts` `ip-group.ts` `policy.ts` `detect.ts` `bot.ts` `acl.ts` `log.ts` `flag.ts` `filter.ts` `system.ts`

核心类型：`PageResult<T>`, `Condition`, `ApiResponse<T>`, `User`, `TenantGroup`, `WafBinding`, `SiteBinding`

### Vuex Store（2 个模块）

| 模块 | 命名空间 | 状态 |
|---|---|---|
| user | `user/` | currentUser, needChangePassword |
| tenant | `tenant/` | tenantGroupID, tenantGroupName, allowedWafIDs, allowedSites |

### 路由（33 条，全部已实现）

| 路径 | 角色 | 说明 |
|---|---|---|
| `/login` | public | 登录 |
| `/` | all | 总览 |
| `/protection/wafs` | all | WAF 列表 |
| `/protection/sites` | all | 站点管理（新建/编辑/删除） |
| `/protection/site-rule` | all | 站点规则（按 WAF+站点过滤） |
| `/protection/ip-group` | all | IP 组管理（CRUD + 条目） |
| `/protection/ssl-cert` | all | SSL 证书（上传/删除） |
| `/protection/ssl-cert/detail` | all | SSL 证书详情 |
| `/protection/policy` | all | 防护策略列表 |
| `/protection/policy/detail` | all | 策略详情（模块开关 + 全局配置） |
| `/protection/policy-rule` | all | 自定义规则（CRUD + 优先级 + 启用） |
| `/threat/detect-log` | all | 检测日志（筛选 + SOC 上报） |
| `/threat/detect-log/detail` | all | 检测日志详情（HTTP 内容 + SOC 上报） |
| `/threat/acl-log` | all | 频率控制日志（筛选） |
| `/threat/acl-log/detail` | all | 频率控制日志详情 |
| `/threat/bot-log` | all | Bot 日志（记录/结果双 Tab + 筛选） |
| `/threat/bot-record-detail` | all | Bot 记录详情 |
| `/threat/bot-result-detail` | all | Bot 结果详情 |
| `/threat/log-download` | all | 日志下载（时间范围选择） |
| `/tenant/groups` | admin | 租户组 |
| `/tenant/users` | admin | 用户管理（筛选） |
| `/tenant/waf-binding` | admin | WAF 绑定（下拉选择） |
| `/tenant/site-binding` | admin | 站点绑定（下拉选择） |
| `/my/users` | tenant_admin+ | 组内用户（筛选） |
| `/system/soc` | admin | SOC 配置（编辑 + 测试） |
| `/system/captain` | admin | 纵横配置 |
| `/system/highlight-ip` | admin | 高亮 IP |
| `/system/audit` | admin | 审计日志（筛选） |
| `/system/highlight-tag` | admin | 标记管理 |
| `/system/password-config` | admin | 密码策略 |
| `/system/login-security` | admin | 登录安全 |
| `/profile/password` | all | 修改密码 |
| `/profile/info` | all | 用户信息 |
| `/profile/api-token` | all | API Token |

### 通用组件（10 个）

| 组件 | 说明 |
|---|---|
| Grid | 分页表格（el-table + el-pagination + 条件筛选） |
| DetailPanel | 右侧抽屉详情（el-drawer） |
| FormPanel | 表单面板（el-dialog） |
| ConditionFilter | 条件数组筛选（like/in/=/range），fields prop 自定义字段 |
| HighlightTag | 高亮 IP 标签 |
| ConfirmDialog | 确认弹窗 |
| ResizeBox | 可调整大小容器 |
| HttpContent | HTTP 内容展示（自动格式化 JSON） |
| SideNav | 侧边栏（按角色过滤菜单） |
| Wrapper | 主布局（SideNav + header + content） |

### 页面视图（31 个）

| 模块 | 页面 |
|---|---|
| Login | 登录 + 首次改密弹窗 |
| Dashboard | 统计卡片（用户/组/WAF/站点数） |
| Tenant (4) | GroupList / UserList（筛选） / WafBinding（下拉） / SiteBinding（下拉） |
| TenantUser (1) | UserList（筛选） |
| Network (8) | WafList（筛选+导航入口） / SiteManagement（新建/编辑） / IpGroup（条目管理） / SslCert / SslCertDetail / Policy / PolicyDetail / PolicyRule |
| Log (8) | DetectLog（筛选+SOC上报+详情跳转） / DetectLogDetail / AclLog（筛选+详情跳转） / AclLogDetail / BotLog（筛选+详情跳转） / BotRecordDetail / BotResultDetail / LogDownload（WAF选择+时间范围+下载） |
| System (7) | SocConfig（编辑） / CaptainConfig / HighlightIp / AuditLog（筛选） / HighlightTag / PasswordConfig / LoginSecurity |
| Profile (3) | ChangePassword / UserInfo / ApiToken |

## 测试覆盖

### Jest 单元测试（10 个文件，35 个用例）

| 文件 | 覆盖范围 |
|---|---|
| `main.spec.ts` | App 渲染 |
| `captainPath.spec.ts` | 路径映射正确性 |
| `apiClient.spec.ts` | 429 拦截、错误处理 |
| `permission.spec.ts` | 角色判断函数 |
| `routerGuard.spec.ts` | 登录检查 + 角色守卫 |
| `store/user.spec.ts` | setUser/clearUser + getters |
| `grid.spec.tsx` | Grid fetchData + offset |
| `highlightTag.spec.tsx` | 高亮标签渲染 |
| `conditionFilter.spec.tsx` | 条件增删查 |
| `dashboard.spec.tsx` | 统计数据加载 |

### Playwright E2E 测试（10 个套件，71 个用例）

| 套件 | 用例数 | 覆盖范围 |
|---|---|---|
| Login Flow | 7 | 渲染/验证/登录/错误/改密/退出/退出调API |
| Navigation & Permissions | 7 | 三级角色菜单/路由守卫/导航 |
| Dashboard | 3 | 渲染/统计数据/默认页 |
| CRUD Pages | 8 | 租户组/用户/绑定/系统配置 |
| Log & Monitoring | 5 | 检测/ACL/Bot/下载/分页 |
| Protection Management | 15 | IP组/SSL/策略/规则/站点管理/权限控制/模块切换/SSL详情编辑 |
| Log Detail Pages | 5 | 检测详情/Bot详情/SOC上报/返回导航 |
| Filter & Form Enhancements | 13 | ConditionFilter/下拉选择/编辑/时间选择/标记按钮/高亮IP只读 |
| Profile Pages | 5 | 改密/用户信息/Token |
| Error Handling | 3 | 429/网络错误/offset |

## 开发命令

```bash
# 启动开发服务器
cd frontend/packages/skyview-web && npm run dev

# 生产构建
NODE_OPTIONS=--openssl-legacy-provider npm run build

# 单元测试
NODE_OPTIONS=--openssl-legacy-provider npm run test

# E2E 测试（需先启动 dev server）
node e2e/run.js

# 单个 E2E 测试
NODE_PATH=~/.claude/plugins/cache/playwright-skill/playwright-skill/4.1.0/skills/playwright-skill/node_modules \
  node e2e/<spec-file>
```

## 核心改造点（相对纵横）

1. **API 调用**: `proxyGet(proxyPost)` → `get(post)` + `captain_instance_id` 参数
2. **路径映射**: 纵横 `/api/XxxAPI` → `/api/captain/xxx/*`（`captain.ts` 集中映射）
3. **去掉全局规则**: 自定义规则强制 `is_global=false`
4. **429 频率限制**: Axios 拦截器提示
5. **高亮 IP**: HighlightTag 组件渲染
6. **SOC 上报**: 批量选择 + 上报按钮
7. **认证持久化**: `main.ts` 启动时调用 `/api/auth/current` 恢复会话
8. **全局样式**: `style.ts` 纯 CSS 实现登录/布局/侧边栏/仪表盘样式
9. **ConditionFilter**: 通用筛选组件，fields prop 自定义字段，接入 6 个列表页
10. **下拉选择**: WAF/站点绑定改用 el-select + API 加载可选项
11. **站点管理**: 新建/编辑表单（名称/域名/端口/备注）
12. **WafSelectorMixin**: 共享 mixin，无 query.waf 时自动加载 WAF 下拉选择
13. **WAF 导航入口**: WAF 列表页操作列直接跳转站点/IP组/SSL/策略/规则
14. **IP 组条目管理**: dialog 内 el-tag 展示已有条目，支持逐条删除
15. **日志下载补全**: WAF 选择 + captain_instance_id 传入 + 下载按钮
16. **日志列表详情跳转**: 检测/ACL/Bot 列表操作列增加"详情"按钮
17. **PolicyDetail 模块切换**: 修复 policyUpdate 未传 modules 参数的 bug
18. **SslCert 详情+编辑**: 列表操作列增加详情跳转和编辑弹窗（certUpdate）
19. **退出登录调 API**: handleLogout 调用 logout() 清除服务端 session
20. **检测日志标记**: detectLogMark + markFlagGet 接入，支持批量打标记
21. **高亮 IP 只读**: 非 admin 用户隐藏新建/编辑/删除按钮
