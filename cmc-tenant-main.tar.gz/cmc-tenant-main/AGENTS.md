# AGENTS.md

This file provides guidance to Codex (Codex.ai/code) when working with code in this repository.

## Project Overview

CMC Tenant — 多租户管理平台。基于纵横（Captain-2）v24.06.001_r25 的 API 二次包装，增加多租户能力。所有 WAF 操作经纵横中转，认证体系独立。

## Tech Stack

- **Backend**: Go 1.21+ / Gin / GORM / PostgreSQL 15 / Redis 7
- **Frontend**: Vue 2.6 + TypeScript / vue-class-component + TSX / @splat/* + @safeline-2/* + Element UI 2.x / Webpack 4 / Vuex 3
- **Deploy**: Docker Compose / Nginx

> 前端与纵横同技术栈，最大化复用纵横已有业务实现。npm 包从内部 registry 安装。

## Repository Structure

- `requirements/` — 需求文档
- `spec/` — 架构设计文档（新建 spec 时参考 `spec/SPEC.example.md`）
- `cmc_rpc/` — 纵横 API 接口提取文档（17个分类，开发时查阅）
- `frontend/` — Vue 2 前端代码
- `gateway/` — Go 后端代码
- `deploy/` — Docker Compose 部署配置与工具

## Design Principles

### 后端统一屏蔽 Captain API 差异

后端是前端与纵横（Captain-2）之间的适配层，必须屏蔽 Captain API 的各种差异，对前端暴露一致的接口契约。前端不应感知 Captain API 的特殊性。

**核心规则：差异在 handler 层消化，前端无需适配。**

具体差异及处理方式：

| 差异类型 | 示例 | 后端处理 |
|---|---|---|
| 分页参数 | detect_log 用 `target_page`，其他用 `offset` | handler 自动转换（如 `convertOffsetToTargetPage`） |
| 响应格式 | `msg: null` / `msg: ""` / 无 msg 字段 | `wrapCaptainResp` 统一为 `msg: "success"` |
| 列表格式 | 裸数组 `{"data": [...]}` vs 分页 `{"data": {"total", "items"}}` | `wrapListAsPage` 统一为分页格式 |
| 字段命名 | PascalCase（`Name`, `ID`）vs snake_case | handler 层按需转换 |
| 代理方式 | 防护管理需 InstanceID/Proxy 头，日志查询不需要 | handler 各自选择正确的 Captain 请求方式 |
| 无效参数 | 前端发的 `conditions` 不被日志 API 识别 | handler 自动删除 |

**新开发 Captain 代理接口时，必须遵循：**
1. 前端调用方式与本地 API 一致（统一的 `listQuery` / `get` / `post` 模式）
2. Captain 特有参数（如 `target_page`、`Proxy` 头）由 handler 层注入/转换
3. 响应必须经 `wrapCaptainResp` / `wrapListAsPage` 处理后再返回前端
4. 前端不应因 Captain API 的特殊性而写特殊逻辑

## Architecture

### 三级角色

- `admin` — 全量数据，租户管理 + 系统管理 + 业务权限
- `tenant_admin` — 组内用户管理 + 本组业务权限
- `tenant` — 仅本组业务权限

### 后端分层

```
apis/handler → domain/business → domain/model
                    ↓
           pkg/captain (纵横代理层)
           pkg/risk_guard (风险检查)
           pkg/database / jwt
```

### 中间件链

Recovery → Logger → Auth(JWT/API-Token) → Permission → TenantContext → Audit

### 租户隔离方式

| 资源类型 | 隔离方式 |
|---|---|
| 日志查询 | 注入 log_id 过滤条件 |
| 站点管理 | instance_id + site_id 校验 |
| 自定义规则 | `captain_policy_rule_bindings` 映射表 |
| IP组 | `captain_ip_group_bindings` 映射表 |
| SSL证书 | `captain_cert_bindings` 映射表 |
| 防护策略 | `captain_policy_bindings` 映射表 |
| 日志下载 | `captain_log_tasks` 映射表 |

### 风险检查（仅站点管理触发）

- IP:Port 冲突检测 — 不同租户组不可在同一 WAF 创建相同 IP:Port 站点
- WAF 操作频率限制 — 同一 WAF 两次写操作最小间隔 30s（可配置）

> IP组/SSL证书/防护策略/自定义规则的写操作不触发频率检查。

### 前端布局与导航

横版顶部导航（与纵横一致），三层布局：
1. **TopNav** — 深蓝顶部栏（`#052F58`）：Logo + 水平一级菜单 + 用户下拉
2. **左侧子菜单** — 白底侧栏：当前一级菜单的二级菜单项
3. **内容区** — `router-view`

Wrapper.tsx 管理菜单状态（activeGroup）和路由联动，TopNav.tsx 是纯展示组件。

- API 调用：纵横 `proxyGet(proxyPost)` 改为 `get/post` + `captain_instance_id` 参数
- 路径映射：纵横 `/api/XxxAPI` → 本平台 `/api/captain/xxx/*`（`api/captain.ts` 集中映射）
- 去掉全局规则：自定义规则仅保留站点级别，强制 `is_global=false`
- 新增：429 频率限制处理、高亮 IP 渲染、SOC 上报按钮

## Database

本地 PostgreSQL 16 张表，核心映射表：

- `waf_bindings` — 租户组 ↔ WAF 设备
- `site_bindings` — 租户组 ↔ WAF 站点（UNIQUE captain_instance_id + site_id）
- `captain_ip_group_bindings` — 租户组 ↔ IP组
- `captain_cert_bindings` — 租户组 ↔ SSL证书
- `captain_policy_bindings` — 租户组 ↔ 防护策略
- `captain_policy_rule_bindings` — 租户组 ↔ 自定义规则
- `captain_log_tasks` — 租户组 ↔ 日志下载任务

纵横侧 ID（captain_instance_id / site_id 等）不做本地 FK，由业务层保证一致性。

## Development

```bash
# 启动依赖
docker compose up postgres redis

# 后端开发（需 air）
cd gateway && air

# 前端开发
cd frontend/packages/skyview-web && npm install && npm run dev
```

### Config

后端配置：`config/production.json` + 环境变量覆盖（`PG_HOST`, `REDIS_ADDR`, `JWT_SECRET` 等）。

前端 `.npmrc`：指向内部 registry（`npm.in.chaitin.net` / `git.in.chaitin.net`）。

### Spec 文档

| 文件 | 内容 |
|---|---|
| spec/01 | 核心数据模型（16张表） |
| spec/02-1 | 认证与用户 API（约定 + 角色矩阵 + 认证/用户/Token/个人设置） |
| spec/02-2 | 租户组与业务绑定（租户组 + WAF/站点绑定 + 高亮IP） |
| spec/02-3 | 纵横代理 API（站点/日志/IP组/SSL/策略/自定义规则） |
| spec/02-4 | 系统管理与 SOC（SOC配置 + 纵横配置 + 审计 + 标记 + SOC上报） |
| spec/03 | 认证与权限（JWT + API Token + 三级角色 + 强制改密） |
| spec/04-1 | 代理架构与过滤（架构 + CaptainClient + 租户过滤 + 响应增强 + 站点按WAF维度） |
| spec/04-2 | 风险检查与熔断（IP:Port冲突 + 频率限制 + 熔断状态机） |
| spec/04-3 | 代理接口映射（全部代理接口映射表） |
| spec/05 | 后端架构（目录结构 + 分层 + 配置 + 熔断） |
| spec/06-1 | 前端目录结构与复用策略（技术选型 + 目录 + API映射 + 去Proxy改造 + 工作量） |
| spec/06-2 | 前端路由与菜单（侧边栏菜单 + 路由结构） |
| spec/07 | 部署架构（Docker Compose + Nginx + 安全检查清单） |
| spec/08 | 多租户局限性（纵横 API 在多租户场景下的局限及应对） |
