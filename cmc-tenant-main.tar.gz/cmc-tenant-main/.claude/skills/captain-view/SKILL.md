# Captain-2 页面查看

通过 Playwright 登录纵横(Captain-2)实例，截图或交互查看页面实现。用于参考纵横 UI 设计 CMC Tenant 页面。

## 连接信息

- URL: `https://10.2.102.76/`
- 用户名: `admin`
- 密码: `gc3VknP7`
- Playwright 路径: `~/.claude/plugins/cache/playwright-skill/playwright-skill/4.1.0/skills/playwright-skill/node_modules`
- 启动参数: `{ headless: true, ignoreHTTPSErrors: true, viewport: { width: 1440, height: 900 } }`

## 步骤

### 1. 登录

```js
const { chromium } = require('playwright')
const browser = await chromium.launch({ headless: true })
const page = await browser.newPage({ ignoreHTTPSErrors: true, viewport: { width: 1440, height: 900 } })

await page.goto('https://10.2.102.76/login', { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.waitForTimeout(2000)
await page.locator('input[type="text"], input:not([type])').first().fill('admin')
await page.locator('input[type="password"]').first().fill('gc3VknP7')
await page.locator('button').first().click()
await page.waitForTimeout(5000)
```

### 2. 导航到目标页面

纵横使用顶部导航 + ProxyView(iframe) 布局。关键导航项：

| 导航项 | 英文名 | 路由前缀 |
|--------|--------|----------|
| 全局感知 | Statistics | /statistic/ |
| 威胁监测 | Threat Monitoring | /log/ |
| Website Protection | Website Protection | /detect/asset |
| 系统管理 | System Configurations | /system/ |

点击顶部导航：
```js
await page.locator('text=Website Protection').first().click()
await page.waitForTimeout(5000)
```

### 3. 访问 iframe 内的内容

纵横右侧内容区是 `<iframe id="caption-iframe">`，加载 WAF 自带 UI（端口 50000）：

```js
const frame = page.frames().find(f => f.url().includes('50000'))
```

### 4. 清理注入的 CSS（关键步骤）

纵横的 CMC 外壳在 iframe 中注入了 CSS，把侧边栏菜单项隐藏（`width:0; height:0`）。**每次导航后都需要重新清理**：

```js
await frame.evaluate(() => {
  document.querySelectorAll('style').forEach(s => s.remove())
})
```

### 5. 侧边栏菜单导航

纵横 WAF 的侧边栏使用自定义组件（`sl-id-menu-item`），不是 Element UI 的 `el-menu`。菜单有可展开的子菜单：

```js
// 点击一级菜单项（如 Rule）
await frame.evaluate(() => {
  document.querySelectorAll('.sl-id-menu-item').forEach(item => {
    if (item.textContent?.trim() === 'Rule') item.click()
  })
})

// 点击子菜单项（如 Site-level Custom Rules）
await frame.evaluate(() => {
  document.querySelectorAll('.sl-id-SubMenuItem').forEach(item => {
    if (item.textContent?.includes('Site-level')) item.click()
  })
})
```

### 6. 对话框操作

纵横使用自定义对话框组件（`sl-id-dialog__container`），不是 `el-dialog`。获取对话框内容：

```js
const text = await frame.evaluate(() => {
  const dialogs = document.querySelectorAll('.sl-id-dialog__container')
  for (const dialog of dialogs) {
    if (dialog.getBoundingClientRect().width > 0) return dialog.textContent
  }
  return 'no dialog'
})
```

### 7. 折叠区/Advanced 的点击

纵横表单的折叠区（如 Advanced）使用自定义组件，直接 DOM `click()` 可能不触发状态更新。**必须使用 Playwright 原生 locator click**：

```js
// 不生效
await frame.evaluate(() => document.querySelector('.f1m8lmko').click())

// 生效
await frame.locator('span:has-text("Advanced")').first().click({ force: true })
```

### 8. 站点详情页

导航到站点详情（需要先进入 Website Protection，再通过 URL 跳转）：

```js
// 先进入 Website Protection 设置 tree 状态
await page.locator('text=Website Protection').first().click()
await page.waitForTimeout(5000)

// 跳转到站点详情（id 参数为 WAF 内站点 ID 的 tree node id）
await page.goto('https://10.2.102.76/detect/asset?path=detect%2Fasset%2Fsite%2Flist%3Fview%3Ddetail%26pid%3D1%26id%3D1_1_1%26label%3Dtest&curCheckedId=1_1_1&instance_id=1')
await page.waitForTimeout(5000)
```

### 9. 截图

```js
await page.screenshot({ path: '/tmp/captain-screenshot.png', fullPage: true })
```

### 10. 关闭

```js
await browser.close()
```

## 注意事项

- NODE_PATH 必须设置: `NODE_PATH=~/.claude/plugins/cache/playwright-skill/playwright-skill/4.1.0/skills/playwright-skill/node_modules`
- 运行命令示例: `NODE_PATH=/tmp/node_modules node -e "..."`
- 纵横登录页是英文界面（Enter an account / Enter a password / Log On）
- iframe 内的页面也是英文界面
- 纵横有 SSL 证书警告，需要 `ignoreHTTPSErrors: true`
- **每次导航（点击菜单、切换 Tab）后，都需要重新清理注入的 CSS**
- **折叠区/Advanced 必须用 Playwright locator click，不能用 evaluate 中的 DOM click**
- **子菜单项是 `sl-id-SubMenuItem`，不是 `el-tabs__item`**
- 表单组件使用 `sl-id-*` 前缀（如 `sl-id-select-container`、`sl-id-switch`、`sl-id-radio`），不是 Element UI 的 `el-*`
