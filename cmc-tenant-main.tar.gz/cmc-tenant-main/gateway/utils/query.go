// Package utils provides HTTP query and response helpers.
package utils

import (
	"strconv"

	"github.com/gin-gonic/gin"
)

// ParsePagination extracts offset and count from query parameters.
func ParsePagination(c *gin.Context) (offset, count int) {
	count = intQuery(c, "count", 20)
	offset = intQuery(c, "offset", 0)
	return
}

func intQuery(c *gin.Context, key string, defaultVal int) int {
	v := c.Query(key)
	if v == "" {
		return defaultVal
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return defaultVal
	}
	return n
}
