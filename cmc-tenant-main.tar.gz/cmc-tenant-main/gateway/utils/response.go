// Package utils provides HTTP query and response helpers.
package utils

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// Success writes a 200 JSON response with data.
func Success(c *gin.Context, data interface{}) {
	c.JSON(http.StatusOK, gin.H{
		"err": nil,
		"msg": "success",
		"data": data,
	})
}

// Error writes a JSON error response with the given status code and messages.
func Error(c *gin.Context, code int, err string, msg string) {
	c.JSON(code, gin.H{
		"err":  err,
		"msg":  msg,
		"data": "",
	})
}

// ErrorBadRequest writes a 400 bad request error response.
func ErrorBadRequest(c *gin.Context, msg string) {
	Error(c, http.StatusBadRequest, "bad_request", msg)
}

// ErrorUnauthorized writes a 401 unauthorized error response.
func ErrorUnauthorized(c *gin.Context, msg string) {
	Error(c, http.StatusUnauthorized, "unauthorized", msg)
}

// ErrorForbidden writes a 403 forbidden error response.
func ErrorForbidden(c *gin.Context, msg string) {
	Error(c, http.StatusForbidden, "forbidden", msg)
}

// ErrorNotFound writes a 404 not found error response.
func ErrorNotFound(c *gin.Context, msg string) {
	Error(c, http.StatusNotFound, "not_found", msg)
}

// ErrorInternal writes a 500 internal error response.
func ErrorInternal(c *gin.Context, msg string) {
	Error(c, http.StatusInternalServerError, "internal_error", msg)
}
