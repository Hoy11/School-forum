package risk_guard

import "testing"

func TestExtractRequestIPPortsSupportsTransparentProxyAddrs(t *testing.T) {
	body := map[string]interface{}{
		"addrs": []interface{}{
			map[string]interface{}{"ip_port": "192.168.1.10:443"},
			map[string]interface{}{"ip_port": "[2001:db8::1]:8443"},
		},
	}

	targets := extractRequestIPPorts(body)
	if len(targets) != 2 {
		t.Fatalf("len(targets)=%d want 2", len(targets))
	}
	if targets[0].IP != "192.168.1.10" || targets[0].Port != 443 {
		t.Fatalf("targets[0]=%+v", targets[0])
	}
	if targets[1].IP != "2001:db8::1" || targets[1].Port != 8443 {
		t.Fatalf("targets[1]=%+v", targets[1])
	}
}

func TestExtractRequestIPPortsKeepsLegacyIPPortBody(t *testing.T) {
	body := map[string]interface{}{
		"ip":   "10.0.0.1",
		"port": float64(80),
	}

	targets := extractRequestIPPorts(body)
	if len(targets) != 1 {
		t.Fatalf("len(targets)=%d want 1", len(targets))
	}
	if targets[0].IP != "10.0.0.1" || targets[0].Port != 80 {
		t.Fatalf("targets[0]=%+v", targets[0])
	}
}

func TestParseCaptainSiteIPPortsSupportsTransparentProxySiteShape(t *testing.T) {
	body := []byte(`{
		"data": [
			{
				"id": 12,
				"addrs": [{"ip_port": "192.168.4.14:80"}],
				"ports": [{"port": "192.168.4.15:443"}]
			}
		]
	}`)

	sites, err := parseCaptainSiteIPPorts(body)
	if err != nil {
		t.Fatalf("parseCaptainSiteIPPorts error: %v", err)
	}
	if len(sites) != 2 {
		t.Fatalf("len(sites)=%d want 2", len(sites))
	}
	if sites[0].SiteID != 12 || sites[0].IP != "192.168.4.14" || sites[0].Port != 80 {
		t.Fatalf("sites[0]=%+v", sites[0])
	}
	if sites[1].SiteID != 12 || sites[1].IP != "192.168.4.15" || sites[1].Port != 443 {
		t.Fatalf("sites[1]=%+v", sites[1])
	}
}

func TestParseCaptainSiteIPPortsSupportsPagedSiteShape(t *testing.T) {
	body := []byte(`{
		"data": {
			"items": [
				{"id": 13, "addrs": [{"ip_port": "192.168.5.14:80"}]}
			]
		}
	}`)

	sites, err := parseCaptainSiteIPPorts(body)
	if err != nil {
		t.Fatalf("parseCaptainSiteIPPorts error: %v", err)
	}
	if len(sites) != 1 {
		t.Fatalf("len(sites)=%d want 1", len(sites))
	}
	if sites[0].SiteID != 13 || sites[0].IP != "192.168.5.14" || sites[0].Port != 80 {
		t.Fatalf("sites[0]=%+v", sites[0])
	}
}
