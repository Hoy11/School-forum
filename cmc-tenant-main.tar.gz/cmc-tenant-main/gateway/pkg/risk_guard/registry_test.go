package risk_guard

import (
	"testing"
)

func TestPassResult(t *testing.T) {
	r := Pass()
	if !r.Pass {
		t.Error("Pass() should return pass=true")
	}
}

func TestRejectResult(t *testing.T) {
	r := Reject(403, "forbidden")
	if r.Pass {
		t.Error("Reject() should return pass=false")
	}
	if r.Code != 403 {
		t.Errorf("code = %d, want 403", r.Code)
	}
	if r.Message != "forbidden" {
		t.Errorf("message = %s, want forbidden", r.Message)
	}
}

func TestRegistryRunAllPass(t *testing.T) {
	checks = nil
	Register(&mockCheck{name: "always-pass", result: Pass()})

	r := RunAll(1, 1, nil)
	if !r.Pass {
		t.Error("should pass when all checks pass")
	}
}

func TestRegistryRunAllReject(t *testing.T) {
	checks = nil
	Register(&mockCheck{name: "always-pass", result: Pass()})
	Register(&mockCheck{name: "reject", result: Reject(403, "conflict")})

	r := RunAll(1, 1, nil)
	if r.Pass {
		t.Error("should reject when a check fails")
	}
	if r.Code != 403 {
		t.Errorf("code = %d, want 403", r.Code)
	}
}

type mockCheck struct {
	name   string
	result *RiskCheckResult
}

func (m *mockCheck) Name() string { return m.name }
func (m *mockCheck) Check(_ int, _ uint, _ map[string]interface{}) *RiskCheckResult {
	return m.result
}
