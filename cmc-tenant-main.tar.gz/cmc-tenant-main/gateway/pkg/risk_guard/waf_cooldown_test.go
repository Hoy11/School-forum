package risk_guard

import (
	"fmt"
	"testing"
	"time"
)

func TestWAFCooldownCheckNoRecord(t *testing.T) {
	check := &WAFCooldownCheck{cooldownSec: 30}
	r := check.Check(999, 1, nil)
	if !r.Pass {
		t.Errorf("should pass when no record, got: %s", r.Message)
	}
}

func TestWAFCooldownRejectDuringCooldown(t *testing.T) {
	check := &WAFCooldownCheck{cooldownSec: 30}
	key := cooldownKey(1)
	lastOp := time.Now().Format(time.RFC3339)

	result := check.checkWithLastOp(key, lastOp)
	if result.Pass {
		t.Error("should reject during cooldown")
	}
	if result.Code != 429 {
		t.Errorf("code = %d, want 429", result.Code)
	}
}

func TestWAFCooldownAllowsAfterCooldown(t *testing.T) {
	check := &WAFCooldownCheck{cooldownSec: 0}
	key := cooldownKey(1)
	lastOp := time.Now().Add(-1 * time.Second).Format(time.RFC3339)

	result := check.checkWithLastOp(key, lastOp)
	if !result.Pass {
		t.Error("should allow after cooldown expires")
	}
}

func cooldownKey(instanceID int) string {
	return fmt.Sprintf("waf_last_op:%d", instanceID)
}
