package risk_guard

// RiskCheck is the interface for WAF operation risk checks.
type RiskCheck interface {
	Name() string
	Check(instanceID int, tenantGroupID uint, body map[string]interface{}) *RiskCheckResult
}

var checks []RiskCheck

// Register adds a RiskCheck to the global registry.
func Register(c RiskCheck) {
	checks = append(checks, c)
}

// RunAll executes all registered checks and returns the first rejection.
func RunAll(instanceID int, tenantGroupID uint, body map[string]interface{}) *RiskCheckResult {
	for _, c := range checks {
		result := c.Check(instanceID, tenantGroupID, body)
		if !result.Pass {
			return result
		}
	}
	return Pass()
}
