package risk_guard

import "sync"

var wafOperationLocks = struct {
	mu    sync.Mutex
	locks map[int]*sync.Mutex
}{locks: make(map[int]*sync.Mutex)}

// WithWAFOperationLock runs fn while holding the per-WAF operation lock.
func WithWAFOperationLock(instanceID int, fn func()) {
	lock := getWAFOperationLock(instanceID)
	lock.Lock()
	defer lock.Unlock()
	fn()
}

func getWAFOperationLock(instanceID int) *sync.Mutex {
	wafOperationLocks.mu.Lock()
	defer wafOperationLocks.mu.Unlock()

	lock, ok := wafOperationLocks.locks[instanceID]
	if !ok {
		lock = &sync.Mutex{}
		wafOperationLocks.locks[instanceID] = lock
	}
	return lock
}
