package risk_guard

import (
	"encoding/json"
	"net"
	"strconv"
	"strings"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

// IPPortConflictCheck detects IP:Port conflicts across tenant groups on the same WAF.
type IPPortConflictCheck struct {
	client *captain.CaptainClient
}

type siteIPPort struct {
	SiteID int    `json:"id"`
	IP     string `json:"ip"`
	Port   int    `json:"port"`
}

type requestIPPort struct {
	IP   string
	Port int
}

// NewIPPortConflictCheck creates an IPPortConflictCheck with the given client.
func NewIPPortConflictCheck(client *captain.CaptainClient) *IPPortConflictCheck {
	return &IPPortConflictCheck{client: client}
}

// Name returns the check name.
func (c *IPPortConflictCheck) Name() string { return "ip_port_conflict" }

// Check validates that the IP:Port in body does not conflict with other groups.
func (c *IPPortConflictCheck) Check(instanceID int, tenantGroupID uint, body map[string]interface{}) *RiskCheckResult {
	targets := extractRequestIPPorts(body)
	if len(targets) == 0 {
		return Pass()
	}

	sites, err := c.getSites(instanceID, body)
	if err != nil {
		return Pass()
	}

	ownSiteIDs := c.getOwnSiteIDs(instanceID, tenantGroupID)

	for _, s := range sites {
		for _, target := range targets {
			if s.IP == target.IP && s.Port == target.Port {
				if _, own := ownSiteIDs[s.SiteID]; !own {
					msg := "IP:Port 冲突，请联系管理员处理"
					if c.siteBoundToOtherGroup(s.SiteID, tenantGroupID) {
						msg = "该站点已被其他业务占用，请联系管理员处理"
					}
					return Reject(403, msg)
				}
			}
		}
	}

	return Pass()
}

func (c *IPPortConflictCheck) getSites(instanceID int, body map[string]interface{}) ([]siteIPPort, error) {
	instanceIDUint := uint(instanceID)
	paths := siteListPathsForBody(body)
	var lastErr error
	for _, path := range paths {
		resp, err := c.client.Do(&captain.CaptainRequest{
			Method:     "GET",
			Path:       path,
			InstanceID: &instanceIDUint,
		})
		if err != nil {
			lastErr = err
			continue
		}

		sites, err := parseCaptainSiteIPPorts(resp.Body)
		if err != nil {
			lastErr = err
			continue
		}
		return sites, nil
	}
	return nil, lastErr
}

func siteListPathsForBody(body map[string]interface{}) []string {
	if mode, _ := body["operation_mode"].(string); mode == "Hardware Transparent Proxy" {
		return []string{"/api/HardwareTransparentProxyWebsiteAPI", "/api/SiteAPI"}
	}
	return []string{"/api/SiteAPI"}
}

func parseCaptainSiteIPPorts(body []byte) ([]siteIPPort, error) {
	var result struct {
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return nil, err
	}
	items, err := parseCaptainSiteItems(result.Data)
	if err != nil {
		return nil, err
	}
	sites := make([]siteIPPort, 0, len(items))
	for _, item := range items {
		siteID := extractInt(item["id"])
		if siteID == 0 {
			siteID = extractInt(item["ID"])
		}
		if siteID == 0 {
			continue
		}
		if ip, _ := item["ip"].(string); ip != "" {
			if port := extractInt(item["port"]); port > 0 {
				sites = append(sites, siteIPPort{SiteID: siteID, IP: ip, Port: port})
			}
		}
		for _, target := range extractSiteItemIPPorts(item) {
			sites = append(sites, siteIPPort{SiteID: siteID, IP: target.IP, Port: target.Port})
		}
	}
	return sites, nil
}

func parseCaptainSiteItems(raw json.RawMessage) ([]map[string]interface{}, error) {
	var items []map[string]interface{}
	if err := json.Unmarshal(raw, &items); err == nil {
		return items, nil
	}
	var page struct {
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(raw, &page); err != nil {
		return nil, err
	}
	return page.Items, nil
}

func (c *IPPortConflictCheck) getOwnSiteIDs(instanceID int, tenantGroupID uint) map[int]bool {
	var siteIDs []int
	database.DB.Model(&bindingmodel.SiteBinding{}).
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck("site_id", &siteIDs)

	m := make(map[int]bool, len(siteIDs))
	for _, id := range siteIDs {
		m[id] = true
	}
	return m
}

func (c *IPPortConflictCheck) siteBoundToOtherGroup(siteID int, tenantGroupID uint) bool {
	var count int64
	database.DB.Model(&bindingmodel.SiteBinding{}).
		Where("site_id = ? AND tenant_group_id != ?", siteID, tenantGroupID).
		Count(&count)
	return count > 0
}

func extractInt(v interface{}) int {
	switch n := v.(type) {
	case float64:
		return int(n)
	case int:
		return n
	case json.Number:
		i, _ := n.Int64()
		return int(i)
	case string:
		i, _ := strconv.Atoi(n)
		return i
	default:
		return 0
	}
}

func extractPort(body map[string]interface{}) int {
	return extractInt(body["port"])
}

func extractRequestIPPorts(body map[string]interface{}) []requestIPPort {
	var targets []requestIPPort
	if ip, _ := body["ip"].(string); ip != "" {
		if port := extractPort(body); port > 0 {
			targets = append(targets, requestIPPort{IP: ip, Port: port})
		}
	}

	addrs, _ := body["addrs"].([]interface{})
	for _, raw := range addrs {
		addr, ok := raw.(map[string]interface{})
		if !ok {
			continue
		}
		ipPort, _ := addr["ip_port"].(string)
		if target, ok := parseIPPort(ipPort); ok {
			targets = append(targets, target)
		}
	}
	return targets
}

func extractSiteItemIPPorts(item map[string]interface{}) []requestIPPort {
	var targets []requestIPPort
	if addrs, ok := item["addrs"].([]interface{}); ok {
		for _, raw := range addrs {
			addr, ok := raw.(map[string]interface{})
			if !ok {
				continue
			}
			ipPort, _ := addr["ip_port"].(string)
			if target, ok := parseIPPort(ipPort); ok {
				targets = append(targets, target)
			}
		}
	}
	if ports, ok := item["ports"].([]interface{}); ok {
		for _, raw := range ports {
			port, ok := raw.(map[string]interface{})
			if !ok {
				continue
			}
			ipPort, _ := port["port"].(string)
			if target, ok := parseIPPort(ipPort); ok {
				targets = append(targets, target)
			}
		}
	}
	return targets
}

func parseIPPort(ipPort string) (requestIPPort, bool) {
	ipPort = strings.TrimSpace(ipPort)
	if ipPort == "" {
		return requestIPPort{}, false
	}
	host, portStr, err := net.SplitHostPort(ipPort)
	if err != nil {
		idx := strings.LastIndex(ipPort, ":")
		if idx <= 0 || idx == len(ipPort)-1 {
			return requestIPPort{}, false
		}
		host = ipPort[:idx]
		portStr = ipPort[idx+1:]
	}
	port, err := strconv.Atoi(portStr)
	if err != nil || port <= 0 {
		return requestIPPort{}, false
	}
	return requestIPPort{IP: strings.Trim(host, "[]"), Port: port}, true
}
