package risk_guard

import (
	"context"
	"fmt"
	"time"

	"github.com/chaitin/cmc-tenant/config"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

// WAFCooldownCheck enforces a cooldown period between WAF write operations.
type WAFCooldownCheck struct {
	cooldownSec int
}

var defaultCooldownSec = 10

// NewWAFCooldownCheck creates a WAFCooldownCheck with the given config.
func NewWAFCooldownCheck(cfg *config.RiskGuardConfig) *WAFCooldownCheck {
	sec := cfg.WAFCooldownSec
	if sec == 0 {
		sec = 10
	}
	defaultCooldownSec = sec
	return &WAFCooldownCheck{cooldownSec: sec}
}

// Name returns the check name.
func (c *WAFCooldownCheck) Name() string { return "waf_cooldown" }

// Check validates that enough time has passed since the last WAF operation.
func (c *WAFCooldownCheck) Check(instanceID int, _ uint, _ map[string]interface{}) *RiskCheckResult {
	if database.RDB == nil {
		return Pass()
	}

	key := fmt.Sprintf("waf_last_op:%d", instanceID)
	val, err := database.RDB.Get(context.Background(), key).Result()
	if err != nil {
		return Pass()
	}

	return c.checkWithLastOp(key, val)
}

func (c *WAFCooldownCheck) checkWithLastOp(_, lastOpStr string) *RiskCheckResult {
	lastOp, err := time.Parse(time.RFC3339, lastOpStr)
	if err != nil {
		return Pass()
	}

	elapsed := time.Since(lastOp)
	if elapsed.Seconds() < float64(c.cooldownSec) {
		remaining := c.cooldownSec - int(elapsed.Seconds())
		return Reject(429, fmt.Sprintf("操作过于频繁，请 %ds 后重试", remaining))
	}

	return Pass()
}

// RecordWAFOperation records the timestamp of a WAF write operation.
func RecordWAFOperation(instanceID int) {
	if database.RDB == nil {
		return
	}
	key := fmt.Sprintf("waf_last_op:%d", instanceID)
	database.RDB.Set(context.Background(), key, time.Now().Format(time.RFC3339), time.Duration(defaultCooldownSec*2)*time.Second)
}
