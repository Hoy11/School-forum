// Package risk_guard provides risk checking for WAF operations.
package risk_guard

import (
	"github.com/chaitin/cmc-tenant/config"
	"github.com/chaitin/cmc-tenant/pkg/captain"
)

// Init registers all built-in risk checks.
func Init(client *captain.CaptainClient, cfg *config.RiskGuardConfig) {
	Register(NewIPPortConflictCheck(client))
	Register(NewWAFCooldownCheck(cfg))
}
