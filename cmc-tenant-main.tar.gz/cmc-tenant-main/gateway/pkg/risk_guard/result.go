package risk_guard

// RiskCheckResult holds the outcome of a risk check.
type RiskCheckResult struct {
	Pass    bool
	Code    int
	Message string
}

// Pass returns a passing result.
func Pass() *RiskCheckResult {
	return &RiskCheckResult{Pass: true}
}

// Reject returns a rejection result with code and message.
func Reject(code int, msg string) *RiskCheckResult {
	return &RiskCheckResult{Pass: false, Code: code, Message: msg}
}
