package captain

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"net/url"
	"strconv"
	"time"
)

// CaptainClient is an HTTP client for the Captain-2 API.
//
//nolint:revive // captain prefix avoids ambiguity with http.Client
type CaptainClient struct {
	Host     string
	APIToken string
	Client   *http.Client
	Retry    int
}

// CaptainRequest describes a request to the Captain-2 API.
//
//nolint:revive // captain prefix avoids ambiguity with http.Request
type CaptainRequest struct {
	Method     string
	Path       string
	Query      string
	Body       interface{}
	Form       []*FormUnit
	InstanceID *uint
}

// FormUnit represents a multipart form entry.
type FormUnit struct {
	FieldName string
	FileName  string
	Data      []byte
	IsFile    bool // true = file (CreateFormFile), false = text (WriteField)
}

// CaptainResponse wraps the HTTP response from a Captain-2 API call.
//
//nolint:revive // captain prefix avoids ambiguity with http.Response
type CaptainResponse struct {
	StatusCode int
	Body       []byte
}

// NewCaptainClient creates a Captain-2 API client with the given host, token, timeout, and retry count.
func NewCaptainClient(host, apiToken string, timeoutSec, retry int) *CaptainClient {
	return &CaptainClient{
		Host:     host,
		APIToken: apiToken,
		Client: &http.Client{
			Timeout: time.Duration(timeoutSec) * time.Second,
			Transport: &http.Transport{
				TLSClientConfig: tlsSkipVerify(),
			},
		},
		Retry: retry,
	}
}

// Do sends a request to the Captain-2 API with retry logic.
func (c *CaptainClient) Do(req *CaptainRequest) (*CaptainResponse, error) {
	// Multipart uploads go through the WAF proxy port because Captain's
	// Proxy-header middleware does not support multipart uploads.
	var proxyPort int
	if len(req.Form) > 0 && req.InstanceID != nil {
		var err error
		proxyPort, err = c.ensureProxyPort(*req.InstanceID)
		if err != nil {
			return nil, fmt.Errorf("open proxy port: %w", err)
		}
	}

	httpReq, err := c.buildRequest(req, proxyPort)
	if err != nil {
		return nil, fmt.Errorf("build request: %w", err)
	}

	resp, err := c.doWithRetry(httpReq)
	if err != nil {
		return nil, fmt.Errorf("send request: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("read response: %w", err)
	}

	return &CaptainResponse{StatusCode: resp.StatusCode, Body: body}, nil
}

// ensureProxyPort calls Captain's /api/instance/proxy to open the WAF proxy port
// for the given instance and returns the port number.
func (c *CaptainClient) ensureProxyPort(instanceID uint) (int, error) {
	reqBody, _ := json.Marshal(map[string]uint{"instance_id": instanceID})
	httpReq, err := http.NewRequest("POST", c.Host+"/api/instance/proxy", bytes.NewReader(reqBody))
	if err != nil {
		return 0, err
	}
	httpReq.Header.Set("Content-Type", "application/json")
	httpReq.AddCookie(&http.Cookie{Name: "API-Token", Value: c.APIToken})

	resp, err := c.Client.Do(httpReq)
	if err != nil {
		return 0, fmt.Errorf("request failed: %w", err)
	}
	defer func() { _ = resp.Body.Close() }()

	respBody, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 {
		return 0, fmt.Errorf("captain returned %d: %s", resp.StatusCode, string(respBody))
	}

	var result struct {
		Data struct {
			Port int `json:"port"`
		} `json:"data"`
	}
	if err := json.Unmarshal(respBody, &result); err != nil {
		return 0, fmt.Errorf("parse proxy port response: %w", err)
	}
	if result.Data.Port == 0 {
		return 0, fmt.Errorf("captain returned empty port")
	}
	return result.Data.Port, nil
}

func (c *CaptainClient) buildRequest(req *CaptainRequest, proxyPort int) (*http.Request, error) {
	// Multipart uploads use the WAF proxy port directly because Captain's
	// Proxy-header middleware does not support multipart uploads.
	// Non-multipart requests continue to use the Proxy header as before.
	useProxyPort := len(req.Form) > 0 && req.InstanceID != nil

	var reqURL string
	if useProxyPort {
		parsed, _ := url.Parse(c.Host)
		parsed.Host = parsed.Hostname() + ":" + strconv.Itoa(proxyPort)
		reqURL = parsed.String() + req.Path
	} else {
		reqURL = c.Host + req.Path
	}
	if req.Query != "" {
		reqURL += "?" + req.Query
	}

	var bodyReader io.Reader
	var contentType string

	if len(req.Form) > 0 {
		buf := &bytes.Buffer{}
		w := multipart.NewWriter(buf)
		for _, f := range req.Form {
			if f.IsFile {
				pw, _ := w.CreateFormFile(f.FieldName, f.FileName)
				_, _ = pw.Write(f.Data)
			} else {
				_ = w.WriteField(f.FieldName, string(f.Data))
			}
		}
		_ = w.Close()
		bodyReader = buf
		contentType = w.FormDataContentType()
	} else if req.Body != nil {
		data, err := json.Marshal(req.Body)
		if err != nil {
			return nil, err
		}
		bodyReader = bytes.NewReader(data)
		contentType = "application/json"
	}

	httpReq, err := http.NewRequest(req.Method, reqURL, bodyReader)
	if err != nil {
		return nil, err
	}

	if contentType != "" {
		httpReq.Header.Set("Content-Type", contentType)
	}
	httpReq.AddCookie(&http.Cookie{Name: "API-Token", Value: c.APIToken})

	if !useProxyPort && req.InstanceID != nil {
		httpReq.Header.Set("Proxy", strconv.FormatUint(uint64(*req.InstanceID), 10))
		httpReq.Header.Set("ProxyPage", "off")
	}

	return httpReq, nil
}

func (c *CaptainClient) doWithRetry(req *http.Request) (*http.Response, error) {
	var lastErr error
	attempts := c.Retry + 1

	for i := 0; i < attempts; i++ {
		resp, err := c.Client.Do(req)
		if err != nil {
			lastErr = err
			continue
		}
		if resp.StatusCode >= 500 {
			lastErr = fmt.Errorf("captain returned %d", resp.StatusCode)
			_ = resp.Body.Close()
			continue
		}
		if resp.StatusCode == 401 {
			_ = resp.Body.Close()
			log.Printf("[WARN] captain returned 401, token may be invalid")
			return nil, &ErrCaptainUnauthorized{}
		}
		return resp, nil
	}

	return nil, fmt.Errorf("after %d attempts: %w", attempts, lastErr)
}

// ErrCaptainUnauthorized indicates the Captain-2 API rejected the token.
type ErrCaptainUnauthorized struct{}

func (e *ErrCaptainUnauthorized) Error() string { return "captain unauthorized: token invalid" }
