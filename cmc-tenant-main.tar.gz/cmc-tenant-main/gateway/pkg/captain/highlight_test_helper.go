package captain

import (
	"net"
	"time"
)

type netIPNet = net.IPNet

var netParseCIDR = net.ParseCIDR

func fakeExpiry() time.Time {
	return time.Now().Add(1 * time.Hour)
}
