package captain

import (
	"encoding/json"
	"testing"

	socreportmodel "github.com/chaitin/cmc-tenant/domain/soc_report/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func TestHighlightCacheMatch(t *testing.T) {
	cache := &HighlightCache{
		networks: []highlightNet{
			{comment: "内网", color: "#FF0000", cidr: mustParseCIDR("192.168.0.0/16")},
			{comment: "DMZ", color: "#00CC00", cidr: mustParseCIDR("10.0.0.0/8")},
		},
		expiry: fakeExpiry(),
	}

	matched, comment, color := cache.Match("192.168.1.100")
	if !matched || comment != "内网" || color != "#FF0000" {
		t.Errorf("192.168.1.100: matched=%v comment=%s color=%s", matched, comment, color)
	}

	matched, _, _ = cache.Match("10.0.5.5")
	if !matched {
		t.Error("10.0.5.5 should match")
	}

	matched, _, _ = cache.Match("8.8.8.8")
	if matched {
		t.Error("8.8.8.8 should not match")
	}
}

func TestHighlightCacheSingleIP(t *testing.T) {
	cache := &HighlightCache{
		networks: []highlightNet{
			{comment: "gateway", color: "#FF8800", cidr: mustParseCIDR("1.2.3.4/32")},
		},
		expiry: fakeExpiry(),
	}

	matched, _, _ := cache.Match("1.2.3.4")
	if !matched {
		t.Error("1.2.3.4 should match /32")
	}

	matched, _, _ = cache.Match("1.2.3.5")
	if matched {
		t.Error("1.2.3.5 should not match /32")
	}
}

func TestEnhanceLogResponse(t *testing.T) {
	defaultCache.networks = []highlightNet{
		{comment: "内网", color: "#FF0000", cidr: mustParseCIDR("192.168.0.0/16")},
	}
	defaultCache.expiry = fakeExpiry()

	input := map[string]interface{}{
		"err": nil,
		"msg": "success",
		"data": map[string]interface{}{
			"total": 1,
			"items": []map[string]interface{}{
				{"id": 1, "src_ip": "192.168.1.1"},
			},
		},
	}
	body, _ := json.Marshal(input)

	result := EnhanceLogResponse(body)

	var resp map[string]interface{}
	_ = json.Unmarshal(result, &resp)

	data := resp["data"].(map[string]interface{})
	items := data["items"].([]interface{})
	item := items[0].(map[string]interface{})

	if item["is_highlighted"] != true {
		t.Error("should be highlighted")
	}
	if item["highlight_comment"] != "内网" {
		t.Errorf("comment = %v, want 内网", item["highlight_comment"])
	}
	if item["highlight_color"] != "#FF0000" {
		t.Errorf("color = %v, want #FF0000", item["highlight_color"])
	}
}

func TestEnhanceLogResponseNoMatch(t *testing.T) {
	defaultCache.networks = []highlightNet{
		{comment: "内网", cidr: mustParseCIDR("192.168.0.0/16")},
	}
	defaultCache.expiry = fakeExpiry()

	input := map[string]interface{}{
		"err": nil,
		"data": map[string]interface{}{
			"items": []map[string]interface{}{
				{"id": 1, "src_ip": "8.8.8.8"},
			},
		},
	}
	body, _ := json.Marshal(input)

	result := EnhanceLogResponse(body)
	if string(result) != string(body) {
		t.Error("should return original body when no match")
	}
}

func TestEnhanceSocReportStatusByLogID(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&socreportmodel.SocReportedLog{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	database.DB = db
	if err := db.Create(&socreportmodel.SocReportedLog{LogID: "log-1", SrcIP: "10.0.0.1", LogType: "detect"}).Error; err != nil {
		t.Fatalf("create reported log: %v", err)
	}

	input := map[string]interface{}{
		"err": nil,
		"data": map[string]interface{}{
			"items": []map[string]interface{}{
				{"id": "log-1", "src_ip": "10.0.0.1"},
				{"id": "log-2", "src_ip": "10.0.0.1"},
			},
		},
	}
	body, _ := json.Marshal(input)

	result := EnhanceSocReportStatus(body)

	var resp map[string]interface{}
	_ = json.Unmarshal(result, &resp)
	data := resp["data"].(map[string]interface{})
	items := data["items"].([]interface{})
	first := items[0].(map[string]interface{})
	second := items[1].(map[string]interface{})
	if first["soc_reported"] != true {
		t.Fatalf("log-1 soc_reported = %v, want true", first["soc_reported"])
	}
	if second["soc_reported"] != false {
		t.Fatalf("log-2 soc_reported = %v, want false", second["soc_reported"])
	}
}

func TestNormalizeToCIDR(t *testing.T) {
	tests := []struct {
		input string
		want  string
	}{
		{"192.168.0.0/16", "192.168.0.0/16"},
		{"10.0.0.1", "10.0.0.1/32"},
	}
	for _, tt := range tests {
		got := normalizeToCIDR(tt.input)
		if got != tt.want {
			t.Errorf("normalizeToCIDR(%q) = %q, want %q", tt.input, got, tt.want)
		}
	}
}

func mustParseCIDR(s string) *netIPNet {
	_, ipNet, err := netParseCIDR(s)
	if err != nil {
		panic(err)
	}
	return ipNet
}
