package captain

var defaultClient *CaptainClient
var defaultBreaker *Breaker

// SetDefault sets the global default Captain client.
func SetDefault(c *CaptainClient)       { defaultClient = c }

// SetDefaultBreaker sets the global default circuit breaker.
func SetDefaultBreaker(b *Breaker)      { defaultBreaker = b }

// GetDefault returns the global default Captain client.
func GetDefault() *CaptainClient        { return defaultClient }

// GetDefaultBreaker returns the global default circuit breaker.
func GetDefaultBreaker() *Breaker       { return defaultBreaker }
