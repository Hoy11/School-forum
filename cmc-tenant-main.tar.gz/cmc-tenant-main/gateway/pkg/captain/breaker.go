// Package captain provides an HTTP client and circuit breaker for the Captain-2 API.
package captain

import (
	"fmt"
	"sync"
	"time"
)

// State represents the circuit breaker state.
type State int

// Circuit breaker states: Closed allows requests, Open rejects, HalfOpen probes.
const (
	Closed   State = iota
	Open
	HalfOpen
)

// Breaker implements a circuit breaker for Captain API calls.
type Breaker struct {
	mu          sync.Mutex
	state       State
	failCount   int
	maxFail     int
	timeout     time.Duration
	lastFailure time.Time
}

// NewBreaker creates a circuit breaker with the given failure threshold and timeout.
func NewBreaker(maxFail int, timeoutSec int) *Breaker {
	return &Breaker{
		state:   Closed,
		maxFail: maxFail,
		timeout: time.Duration(timeoutSec) * time.Second,
	}
}

// Allow checks whether a request is permitted under the current breaker state.
func (b *Breaker) Allow() error {
	b.mu.Lock()
	defer b.mu.Unlock()

	switch b.state {
	case Closed:
		return nil
	case Open:
		if time.Since(b.lastFailure) > b.timeout {
			b.state = HalfOpen
			return nil
		}
		return fmt.Errorf("breaker open, retry after %v", b.timeout-time.Since(b.lastFailure))
	case HalfOpen:
		return nil
	}
	return nil
}

// RecordSuccess resets the breaker to the closed state.
func (b *Breaker) RecordSuccess() {
	b.mu.Lock()
	defer b.mu.Unlock()

	b.failCount = 0
	b.state = Closed
}

// RecordFailure increments the failure count and may trip the breaker open.
func (b *Breaker) RecordFailure() {
	b.mu.Lock()
	defer b.mu.Unlock()

	b.failCount++
	b.lastFailure = time.Now()

	if b.state == HalfOpen {
		b.state = Open
		return
	}

	if b.failCount >= b.maxFail {
		b.state = Open
	}
}

// State returns the current breaker state.
func (b *Breaker) State() State {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.state
}
