package captain

import (
	"testing"
)

func TestInjectLogFilter(t *testing.T) {
	body := map[string]interface{}{}
	InjectLogFilter(body, []int{1, 2, 3})

	filter, ok := body["log_id"].([]map[string]interface{})
	if !ok {
		t.Fatal("log_id not injected")
	}
	target, _ := filter[0]["target"].([]string)
	if len(target) != 3 || target[0] != "1" {
		t.Errorf("target = %v, want [1 2 3]", target)
	}
}

func TestInjectLogFilterIntersectsExistingLogIDFilter(t *testing.T) {
	body := map[string]interface{}{
		"log_id": []interface{}{
			map[string]interface{}{
				"oper":   "in",
				"target": []interface{}{"2", "3", "9"},
			},
		},
	}

	InjectLogFilter(body, []int{1, 2, 3})

	filter, ok := body["log_id"].([]map[string]interface{})
	if !ok {
		t.Fatal("log_id not injected")
	}
	target, _ := filter[0]["target"].([]string)
	if len(target) != 2 || target[0] != "2" || target[1] != "3" {
		t.Errorf("target = %v, want [2 3]", target)
	}
}

func TestInjectLogFilterEmptyIntersection(t *testing.T) {
	body := map[string]interface{}{
		"log_id": []interface{}{
			map[string]interface{}{
				"oper":   "in",
				"target": []interface{}{"9"},
			},
		},
	}

	InjectLogFilter(body, []int{1, 2, 3})

	filter, ok := body["log_id"].([]map[string]interface{})
	if !ok {
		t.Fatal("log_id not injected")
	}
	target, _ := filter[0]["target"].([]string)
	if len(target) != 0 {
		t.Errorf("target = %v, want empty intersection", target)
	}
}

func TestInjectLogFilterExcludesExistingLogIDFilter(t *testing.T) {
	body := map[string]interface{}{
		"log_id": []interface{}{
			map[string]interface{}{
				"oper":   "not_in",
				"target": []interface{}{"2", "9"},
			},
		},
	}

	InjectLogFilter(body, []int{1, 2, 3})

	filter, ok := body["log_id"].([]map[string]interface{})
	if !ok {
		t.Fatal("log_id not injected")
	}
	target, _ := filter[0]["target"].([]string)
	if len(target) != 2 || target[0] != "1" || target[1] != "3" {
		t.Errorf("target = %v, want [1 3]", target)
	}
}

func TestInjectLogFilterIntersectsAndExcludesExistingLogIDFilter(t *testing.T) {
	body := map[string]interface{}{
		"log_id": []interface{}{
			map[string]interface{}{"oper": "in", "target": []interface{}{"1", "2", "3", "9"}},
			map[string]interface{}{"oper": "not_exact", "target": "2"},
		},
	}

	InjectLogFilter(body, []int{1, 2, 3})

	filter, ok := body["log_id"].([]map[string]interface{})
	if !ok {
		t.Fatal("log_id not injected")
	}
	target, _ := filter[0]["target"].([]string)
	if len(target) != 2 || target[0] != "1" || target[1] != "3" {
		t.Errorf("target = %v, want [1 3]", target)
	}
}

func TestInjectDetectLogSiteFilter(t *testing.T) {
	body := map[string]interface{}{}
	InjectDetectLogSiteFilter(body, []int{10, 20})

	filter, ok := body["site_uuid"].([]map[string]interface{})
	if !ok {
		t.Fatal("site_uuid not injected")
	}
	if len(filter) != 2 || filter[0]["oper"] != "=" || filter[0]["target"] != 10 || filter[1]["target"] != 20 {
		t.Errorf("filter = %#v, want equality filters for [10 20]", filter)
	}
}

func TestInjectDetectLogSiteFilterEmpty(t *testing.T) {
	body := map[string]interface{}{}
	InjectDetectLogSiteFilter(body, []int{})

	filter, ok := body["site_uuid"].([]map[string]interface{})
	if !ok {
		t.Fatal("site_uuid not injected")
	}
	if len(filter) != 1 || filter[0]["target"] != -1 {
		t.Errorf("filter = %#v, want impossible site filter", filter)
	}
}

func TestInjectDetectLogSiteFilterIntersectsExistingFilter(t *testing.T) {
	body := map[string]interface{}{
		"site_uuid": []interface{}{
			map[string]interface{}{"oper": "=", "target": 20},
			map[string]interface{}{"oper": "=", "target": 99},
		},
	}

	InjectDetectLogSiteFilter(body, []int{10, 20})

	filter, ok := body["site_uuid"].([]map[string]interface{})
	if !ok {
		t.Fatal("site_uuid not injected")
	}
	if len(filter) != 1 || filter[0]["target"] != 20 {
		t.Errorf("filter = %#v, want only site 20", filter)
	}
}

func TestInjectBotLogSiteFilter(t *testing.T) {
	body := map[string]interface{}{}
	InjectBotLogSiteFilter(body, []int{5})

	filter, ok := body["site_uuid"].([]map[string]interface{})
	if !ok {
		t.Fatal("site_uuid not injected")
	}
	if len(filter) != 1 || filter[0]["target"] != 5 {
		t.Errorf("filter = %#v, want equality filter for 5", filter)
	}
}

func TestInjectLogTaskFilterDetectLog(t *testing.T) {
	body := map[string]interface{}{}
	InjectLogTaskFilter(body, []int{1}, "detect_log")

	filter, ok := body["detect_log_filter"].(map[string]interface{})
	if !ok {
		t.Fatal("detect_log_filter not injected")
	}
	if _, ok := filter["log_id"]; !ok {
		t.Fatal("log_id not injected")
	}
	if _, ok := body["acl_log_filter"]; ok {
		t.Error("acl_log_filter should not be set")
	}
}

func TestInjectLogTaskFilterMergesExistingFilter(t *testing.T) {
	body := map[string]interface{}{
		"detect_log_filter": map[string]interface{}{
			"attack_type": []interface{}{map[string]interface{}{"oper": "=", "target": "sqli"}},
			"log_id": []interface{}{
				map[string]interface{}{"oper": "in", "target": []interface{}{"2", "9"}},
			},
		},
	}

	InjectLogTaskFilter(body, []int{1, 2}, "detect_log")

	filter, ok := body["detect_log_filter"].(map[string]interface{})
	if !ok {
		t.Fatal("detect_log_filter not injected")
	}
	if _, ok := filter["attack_type"]; !ok {
		t.Fatal("existing attack_type filter was overwritten")
	}
	if _, ok := filter["log_id"]; !ok {
		t.Fatal("log_id not injected")
	}
	logIDFilter, _ := filter["log_id"].([]map[string]interface{})
	target, _ := logIDFilter[0]["target"].([]string)
	if len(target) != 1 || target[0] != "2" {
		t.Errorf("target = %v, want [2]", target)
	}
}

func TestInjectLogTaskFilterExcludesExistingLogIDFilter(t *testing.T) {
	body := map[string]interface{}{
		"detect_log_filter": map[string]interface{}{
			"log_id": []interface{}{
				map[string]interface{}{"oper": "not_in", "target": []interface{}{"2"}},
			},
		},
	}

	InjectLogTaskFilter(body, []int{1, 2, 3}, "detect_log")

	filter, ok := body["detect_log_filter"].(map[string]interface{})
	if !ok {
		t.Fatal("detect_log_filter not injected")
	}
	logIDFilter, _ := filter["log_id"].([]map[string]interface{})
	target, _ := logIDFilter[0]["target"].([]string)
	if len(target) != 2 || target[0] != "1" || target[1] != "3" {
		t.Errorf("target = %v, want [1 3]", target)
	}
}

func TestInjectLogTaskFilterACLLog(t *testing.T) {
	body := map[string]interface{}{}
	InjectLogTaskFilter(body, []int{1}, "acl_log")

	if _, ok := body["acl_log_filter"]; !ok {
		t.Fatal("acl_log_filter not injected")
	}
}

func TestInjectLogTaskFilterBotLog(t *testing.T) {
	body := map[string]interface{}{}
	InjectLogTaskFilter(body, []int{1}, "bot_record_log")

	if _, ok := body["bot_log_filter"]; !ok {
		t.Fatal("bot_log_filter not injected")
	}
}

func TestInjectLogTaskFilterBotResultLog(t *testing.T) {
	body := map[string]interface{}{}
	InjectLogTaskFilter(body, []int{1}, "bot_result_log")

	if _, ok := body["bot_log_filter"]; !ok {
		t.Fatal("bot_log_filter not injected")
	}
}

func TestFormatLogIDs(t *testing.T) {
	result := formatLogIDs([]int{100, 200})
	if len(result) != 2 || result[0] != "100" || result[1] != "200" {
		t.Errorf("result = %v, want [100 200]", result)
	}
}
