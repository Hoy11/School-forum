package captain

import (
	"strconv"
)

// InjectLogFilter adds a log_id filter for tenant-isolated log queries.
func InjectLogFilter(body map[string]interface{}, allowedWafIDs []int) {
	logIDs := mergeAllowedLogIDs(body["log_id"], formatLogIDs(allowedWafIDs))
	body["log_id"] = []map[string]interface{}{
		{"oper": "in", "target": logIDs},
	}
}

// InjectDetectLogSiteFilter adds a site_uuid filter for detect log queries.
func InjectDetectLogSiteFilter(body map[string]interface{}, allowedSiteIDs []int) {
	body["site_uuid"] = siteIDFilters(mergeAllowedSiteIDs(body["site_uuid"], allowedSiteIDs))
}

// InjectBotLogSiteFilter adds a site_uuid filter for bot log queries.
func InjectBotLogSiteFilter(body map[string]interface{}, allowedSiteIDs []int) {
	body["site_uuid"] = siteIDFilters(mergeAllowedSiteIDs(body["site_uuid"], allowedSiteIDs))
}

// InjectLogTaskFilter adds a log_id filter for log download task queries.
func InjectLogTaskFilter(body map[string]interface{}, allowedWafIDs []int, logType string) {
	var filterKey string
	switch logType {
	case "detect_log":
		filterKey = "detect_log_filter"
	case "acl_log":
		filterKey = "acl_log_filter"
	case "bot_record_log", "bot_result_log":
		filterKey = "bot_log_filter"
	default:
		return
	}

	filter, _ := body[filterKey].(map[string]interface{})
	if filter == nil {
		filter = make(map[string]interface{})
	}
	logIDs := mergeAllowedLogIDs(filter["log_id"], formatLogIDs(allowedWafIDs))
	logIDFilter := []map[string]interface{}{
		{"oper": "in", "target": logIDs},
	}
	filter["log_id"] = logIDFilter
	body[filterKey] = filter
}

func formatLogIDs(ids []int) []string {
	result := make([]string, len(ids))
	for i, id := range ids {
		result[i] = strconv.Itoa(id)
	}
	return result
}

func siteIDFilters(ids []int) []map[string]interface{} {
	if len(ids) == 0 {
		return []map[string]interface{}{{"oper": "=", "target": -1}}
	}
	result := make([]map[string]interface{}, 0, len(ids))
	for _, id := range ids {
		result = append(result, map[string]interface{}{"oper": "=", "target": id})
	}
	return result
}

func mergeAllowedSiteIDs(existing interface{}, allowed []int) []int {
	if existing == nil {
		return dedupeInts(allowed)
	}

	requested, excluded, ok := extractRequestedSiteIDs(existing)
	if !ok {
		return dedupeInts(allowed)
	}

	allowedSet := make(map[int]struct{}, len(allowed))
	for _, id := range allowed {
		allowedSet[id] = struct{}{}
	}
	excludedSet := make(map[int]struct{}, len(excluded))
	for _, id := range excluded {
		excludedSet[id] = struct{}{}
	}

	base := allowed
	if len(requested) > 0 {
		base = requested
	}

	result := make([]int, 0, len(base))
	seen := make(map[int]struct{}, len(base))
	for _, id := range base {
		if _, exists := allowedSet[id]; !exists {
			continue
		}
		if _, exists := excludedSet[id]; exists {
			continue
		}
		if _, exists := seen[id]; exists {
			continue
		}
		seen[id] = struct{}{}
		result = append(result, id)
	}
	return result
}

func extractRequestedSiteIDs(existing interface{}) (requested []int, excluded []int, ok bool) {
	items := filterItems(existing)
	if len(items) == 0 {
		return nil, nil, false
	}

	for _, item := range items {
		oper, _ := item["oper"].(string)
		switch oper {
		case "=", "exact", "in":
			requested = append(requested, intValues(item["target"])...)
		case "<>", "!=", "not_exact", "not in", "not_in":
			excluded = append(excluded, intValues(item["target"])...)
		}
	}
	return dedupeInts(requested), dedupeInts(excluded), len(requested) > 0 || len(excluded) > 0
}

func intValues(value interface{}) []int {
	switch v := value.(type) {
	case []int:
		return v
	case []interface{}:
		result := make([]int, 0, len(v))
		for _, item := range v {
			result = append(result, intValues(item)...)
		}
		return result
	case int:
		return []int{v}
	case float64:
		return []int{int(v)}
	case string:
		if v == "" {
			return nil
		}
		n, err := strconv.Atoi(v)
		if err != nil {
			return nil
		}
		return []int{n}
	default:
		return nil
	}
}

func dedupeInts(ids []int) []int {
	result := make([]int, 0, len(ids))
	seen := make(map[int]struct{}, len(ids))
	for _, id := range ids {
		if _, exists := seen[id]; exists {
			continue
		}
		seen[id] = struct{}{}
		result = append(result, id)
	}
	return result
}

func mergeAllowedLogIDs(existing interface{}, allowed []string) []string {
	if existing == nil {
		return allowed
	}

	requested, excluded, ok := extractRequestedLogIDs(existing)
	if !ok {
		return allowed
	}

	allowedSet := make(map[string]struct{}, len(allowed))
	for _, id := range allowed {
		allowedSet[id] = struct{}{}
	}
	excludedSet := make(map[string]struct{}, len(excluded))
	for _, id := range excluded {
		excludedSet[id] = struct{}{}
	}

	base := allowed
	if len(requested) > 0 {
		base = requested
	}

	result := make([]string, 0, len(base))
	seen := make(map[string]struct{}, len(base))
	for _, id := range base {
		if _, exists := allowedSet[id]; !exists {
			continue
		}
		if _, exists := excludedSet[id]; exists {
			continue
		}
		if _, exists := seen[id]; exists {
			continue
		}
		seen[id] = struct{}{}
		result = append(result, id)
	}
	return result
}

func extractRequestedLogIDs(existing interface{}) (requested []string, excluded []string, ok bool) {
	items := filterItems(existing)
	if len(items) == 0 {
		return nil, nil, false
	}

	for _, item := range items {
		oper, _ := item["oper"].(string)
		switch oper {
		case "in", "=", "exact":
			requested = append(requested, stringifyLogIDValues(item["target"])...)
		case "<>", "!=", "not_exact", "not in", "not_in":
			excluded = append(excluded, stringifyLogIDValues(item["target"])...)
		}
	}
	return dedupeStrings(requested), dedupeStrings(excluded), len(requested) > 0 || len(excluded) > 0
}

func filterItems(existing interface{}) []map[string]interface{} {
	switch v := existing.(type) {
	case []map[string]interface{}:
		return v
	case []interface{}:
		result := make([]map[string]interface{}, 0, len(v))
		for _, item := range v {
			if m, ok := item.(map[string]interface{}); ok {
				result = append(result, m)
			}
		}
		return result
	default:
		return nil
	}
}

func stringifyLogIDValues(value interface{}) []string {
	switch v := value.(type) {
	case []string:
		return v
	case []interface{}:
		result := make([]string, 0, len(v))
		for _, item := range v {
			result = append(result, stringifyLogIDValues(item)...)
		}
		return result
	case string:
		if v == "" {
			return nil
		}
		return []string{v}
	case int:
		return []string{strconv.Itoa(v)}
	case float64:
		return []string{strconv.Itoa(int(v))}
	default:
		return nil
	}
}

func dedupeStrings(values []string) []string {
	result := make([]string, 0, len(values))
	seen := make(map[string]struct{}, len(values))
	for _, value := range values {
		if _, exists := seen[value]; exists {
			continue
		}
		seen[value] = struct{}{}
		result = append(result, value)
	}
	return result
}
