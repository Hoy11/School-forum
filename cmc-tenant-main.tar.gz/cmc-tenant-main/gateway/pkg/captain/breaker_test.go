package captain

import (
	"testing"
	"time"
)

func TestBreakerClosedAllows(t *testing.T) {
	b := NewBreaker(3, 30)
	if err := b.Allow(); err != nil {
		t.Errorf("closed breaker should allow, got %v", err)
	}
}

func TestBreakerOpensAfterMaxFail(t *testing.T) {
	b := NewBreaker(3, 30)
	b.RecordFailure()
	b.RecordFailure()
	b.RecordFailure()

	if err := b.Allow(); err == nil {
		t.Error("should reject after max failures")
	}
	if b.State() != Open {
		t.Errorf("state = %v, want Open", b.State())
	}
}

func TestBreakerHalfOpenAfterTimeout(t *testing.T) {
	b := NewBreaker(3, 0)
	b.RecordFailure()
	b.RecordFailure()
	b.RecordFailure()

	if b.State() != Open {
		t.Fatalf("state = %v, want Open", b.State())
	}

	time.Sleep(10 * time.Millisecond)
	if err := b.Allow(); err != nil {
		t.Error("should allow after timeout (half-open)")
	}
	if b.State() != HalfOpen {
		t.Errorf("state = %v, want HalfOpen", b.State())
	}
}

func TestBreakerHalfOpenSuccessCloses(t *testing.T) {
	b := NewBreaker(3, 0)
	b.RecordFailure()
	b.RecordFailure()
	b.RecordFailure()

	time.Sleep(10 * time.Millisecond)
	_ = b.Allow()
	b.RecordSuccess()

	if b.State() != Closed {
		t.Errorf("state = %v, want Closed", b.State())
	}
}

func TestBreakerHalfOpenFailureReopens(t *testing.T) {
	b := NewBreaker(3, 0)
	b.RecordFailure()
	b.RecordFailure()
	b.RecordFailure()

	time.Sleep(10 * time.Millisecond)
	_ = b.Allow()
	b.RecordFailure()

	if b.State() != Open {
		t.Errorf("state = %v, want Open", b.State())
	}
}

func TestBreakerResetsOnSuccess(t *testing.T) {
	b := NewBreaker(3, 30)
	b.RecordFailure()
	b.RecordFailure()
	b.RecordSuccess()
	b.RecordFailure()

	if err := b.Allow(); err != nil {
		t.Error("fail count should reset on success")
	}
}
