package captain

import (
	"encoding/json"
	"fmt"
	"net"
	"sync"
	"time"

	hipmodel "github.com/chaitin/cmc-tenant/domain/highlight_ip/model"
	socreportmodel "github.com/chaitin/cmc-tenant/domain/soc_report/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

// HighlightCache caches highlight IP networks with TTL-based refresh.
type HighlightCache struct {
	mu       sync.RWMutex
	networks []highlightNet
	expiry   time.Time
	ttl      time.Duration
}

type highlightNet struct {
	cidr    *net.IPNet
	comment string
	color   string
}

var defaultCache = &HighlightCache{ttl: 5 * time.Minute}

// InvalidateCache forces the highlight cache to reload on next access.
func InvalidateCache() {
	defaultCache.mu.Lock()
	defer defaultCache.mu.Unlock()
	defaultCache.expiry = time.Time{}
}

func (c *HighlightCache) load() {
	c.mu.Lock()
	defer c.mu.Unlock()

	if time.Since(c.expiry) < 0 {
		return
	}

	var records []hipmodel.HighlightIP
	database.DB.Find(&records)

	nets := make([]highlightNet, 0, len(records))
	for _, r := range records {
		_, ipNet, err := net.ParseCIDR(normalizeToCIDR(r.IP))
		if err != nil {
			continue
		}
		nets = append(nets, highlightNet{cidr: ipNet, comment: r.Comment, color: r.Color})
	}

	c.networks = nets
	c.expiry = time.Now().Add(c.ttl)
}

// Match checks whether an IP is highlighted and returns its comment and color.
func (c *HighlightCache) Match(ipStr string) (bool, string, string) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	ip := net.ParseIP(ipStr)
	if ip == nil {
		return false, "", ""
	}

	for _, n := range c.networks {
		if n.cidr.Contains(ip) {
			return true, n.comment, n.color
		}
	}
	return false, "", ""
}

// EnhanceLogResponse adds highlight information to a log API response.
func EnhanceLogResponse(body []byte) []byte {
	defaultCache.load()

	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	enhanced := enhanceDataField(dataRaw)
	if enhanced == nil {
		return body
	}

	resp["data"] = enhanced
	result, err := json.Marshal(resp)
	if err != nil {
		return body
	}
	return result
}

// EnhanceSocReportStatus adds SOC report status to log list responses.
func EnhanceSocReportStatus(body []byte) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	enhanced := enhanceSocReportDataField(dataRaw)
	if enhanced == nil {
		return body
	}

	resp["data"] = enhanced
	result, err := json.Marshal(resp)
	if err != nil {
		return body
	}
	return result
}

func enhanceDataField(dataRaw json.RawMessage) json.RawMessage {
	var data map[string]json.RawMessage
	if err := json.Unmarshal(dataRaw, &data); err != nil {
		return nil
	}

	itemsRaw, ok := data["items"]
	if !ok {
		return nil
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(itemsRaw, &items); err != nil {
		return nil
	}

	changed := false
	for i, item := range items {
		srcIP, _ := item["src_ip"].(string)
		if srcIP == "" {
			continue
		}
		matched, comment, color := defaultCache.Match(srcIP)
		if matched {
			item["is_highlighted"] = true
			item["highlight_comment"] = comment
			item["highlight_color"] = color
			items[i] = item
			changed = true
		}
	}

	if !changed {
		return nil
	}

	itemsRaw, _ = json.Marshal(items)
	data["items"] = itemsRaw
	result, _ := json.Marshal(data)
	return result
}

func enhanceSocReportDataField(dataRaw json.RawMessage) json.RawMessage {
	var data map[string]json.RawMessage
	if err := json.Unmarshal(dataRaw, &data); err != nil {
		return nil
	}

	itemsRaw, ok := data["items"]
	if !ok {
		return nil
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(itemsRaw, &items); err != nil {
		return nil
	}

	logIDSet := make(map[string]struct{})
	for _, item := range items {
		logID := logIDFromItem(item)
		if logID != "" {
			logIDSet[logID] = struct{}{}
		}
	}
	if len(logIDSet) == 0 {
		return nil
	}

	logIDs := make([]string, 0, len(logIDSet))
	for logID := range logIDSet {
		logIDs = append(logIDs, logID)
	}

	var records []socreportmodel.SocReportedLog
	if err := database.DB.Where("log_id IN ?", logIDs).Find(&records).Error; err != nil {
		return nil
	}

	reported := make(map[string]bool, len(records))
	for _, record := range records {
		reported[record.LogID] = true
	}

	changed := false
	for i, item := range items {
		logID := logIDFromItem(item)
		if logID == "" {
			continue
		}
		item["soc_reported"] = reported[logID]
		items[i] = item
		changed = true
	}
	if !changed {
		return nil
	}

	itemsRaw, _ = json.Marshal(items)
	data["items"] = itemsRaw
	result, _ := json.Marshal(data)
	return result
}

func logIDFromItem(item map[string]interface{}) string {
	if id, ok := item["id"]; ok {
		return interfaceToString(id)
	}
	if id, ok := item["log_id"]; ok {
		return interfaceToString(id)
	}
	return ""
}

func interfaceToString(v interface{}) string {
	switch value := v.(type) {
	case string:
		return value
	case float64:
		return fmt.Sprintf("%.0f", value)
	case int:
		return fmt.Sprintf("%d", value)
	case int64:
		return fmt.Sprintf("%d", value)
	default:
		return ""
	}
}

func normalizeToCIDR(ip string) string {
	parsed := net.ParseIP(ip)
	if parsed != nil {
		if parsed.To4() != nil {
			return ip + "/32"
		}
		return ip + "/128"
	}
	return ip
}
