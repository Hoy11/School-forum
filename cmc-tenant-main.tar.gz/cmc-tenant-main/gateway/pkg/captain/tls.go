package captain

import "crypto/tls"

func tlsSkipVerify() *tls.Config {
	return &tls.Config{InsecureSkipVerify: true}
}
