// Package database initializes PostgreSQL and Redis connections.
package database

import (
	"context"

	"github.com/chaitin/cmc-tenant/config"
	"github.com/redis/go-redis/v9"
)

// RDB is the global Redis client instance.
var RDB *redis.Client

// InitRedis creates and verifies a Redis connection.
func InitRedis(cfg *config.RedisConfig) error {
	rdb := redis.NewClient(&redis.Options{
		Addr:     cfg.Addr,
		Password: cfg.Password,
		DB:       cfg.DB,
	})

	if err := rdb.Ping(context.Background()).Err(); err != nil {
		return err
	}

	RDB = rdb
	return nil
}
