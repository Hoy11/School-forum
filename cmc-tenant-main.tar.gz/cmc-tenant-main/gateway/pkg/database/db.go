// Package database initializes PostgreSQL and Redis connections.
package database

import (
	"database/sql"
	"fmt"
	"log"

	"github.com/chaitin/cmc-tenant/config"
	"gorm.io/driver/postgres"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
)

// DB is the global GORM database instance.
var DB *gorm.DB

// InitPG opens a PostgreSQL connection and auto-migrates the given models.
func InitPG(cfg *config.PGConfig, models ...interface{}) error {
	db, err := gorm.Open(postgres.Open(cfg.DSN()), &gorm.Config{
		Logger: logger.Default.LogMode(logger.Silent),
	})
	if err != nil {
		return err
	}

	if err := db.AutoMigrate(models...); err != nil {
		return err
	}

	DB = db
	return nil
}

// RunPostMigrations executes post-auto-migrate SQL migrations.
func RunPostMigrations() error {
	migrations := []func(*sql.DB) error{
		createGiSTIndex,
		migrateIPGroupBindingIndex,
		migrateCertBindingIndex,
		migratePolicyBindingIndex,
		migratePolicyRuleBindingIndex,
		migrateBlockPageBindingIndex,
		addBindingSourceColumns,
	}

	sqlDB, err := DB.DB()
	if err != nil {
		return err
	}
	for _, m := range migrations {
		if err := m(sqlDB); err != nil {
			return err
		}
	}
	return nil
}

func createGiSTIndex(db *sql.DB) error {
	idx := "idx_highlight_ips_ip_gist"
	var count int
	row := db.QueryRow("SELECT COUNT(*) FROM pg_indexes WHERE indexname = $1", idx)
	if err := row.Scan(&count); err != nil {
		return err
	}
	if count > 0 {
		return nil
	}
	_, err := db.Exec(fmt.Sprintf(
		"CREATE INDEX CONCURRENTLY %s ON highlight_ips USING GIST (ip inet_ops)", idx,
	))
	return err
}

func migrateIPGroupBindingIndex(db *sql.DB) error {
	const oldIdx = "idx_ipg_instance_group"
	current, err := getIndexColumns(db, "captain_ip_group_bindings", oldIdx)
	if err != nil {
		log.Printf("[DEBUG] migrateIPGroupBindingIndex: %v, skip", err)
		return nil
	}
	log.Printf("[DEBUG] migrateIPGroupBindingIndex: current=%s expected={captain_instance_id,ip_group_id,tenant_group_id}", current)
	if current == "{captain_instance_id,ip_group_id,tenant_group_id}" {
		return nil
	}
	if _, err := db.Exec(fmt.Sprintf("DROP INDEX IF EXISTS %s", oldIdx)); err != nil {
		return fmt.Errorf("drop old index %s: %w", oldIdx, err)
	}
	log.Printf("[DEBUG] migrateIPGroupBindingIndex: dropped old, creating new")
	_, err2 := db.Exec(fmt.Sprintf(
		"CREATE UNIQUE INDEX %s ON captain_ip_group_bindings (captain_instance_id, ip_group_id, tenant_group_id)",
		oldIdx,
	))
	if err2 != nil {
		log.Printf("[DEBUG] migrateIPGroupBindingIndex: create failed: %v", err2)
	}
	return err2
}

func migrateBindingIndex(db *sql.DB, table, idxName, resourceCol string) error {
	current, err := getIndexColumns(db, table, idxName)
	if err != nil {
		log.Printf("[DEBUG] migrateBindingIndex %s: %v, skip", idxName, err)
		return nil
	}
	expected := fmt.Sprintf("{captain_instance_id,%s,tenant_group_id}", resourceCol)
	log.Printf("[DEBUG] migrateBindingIndex %s: current=%s expected=%s", idxName, current, expected)
	if current == expected {
		return nil
	}
	if _, err := db.Exec(fmt.Sprintf("DROP INDEX IF EXISTS %s", idxName)); err != nil {
		return fmt.Errorf("drop old index %s: %w", idxName, err)
	}
	log.Printf("[DEBUG] migrateBindingIndex %s: dropped old, creating new", idxName)
	_, err2 := db.Exec(fmt.Sprintf(
		"CREATE UNIQUE INDEX %s ON %s (captain_instance_id, %s, tenant_group_id)",
		idxName, table, resourceCol,
	))
	if err2 != nil {
		log.Printf("[DEBUG] migrateBindingIndex %s: create failed: %v", idxName, err2)
	}
	return err2
}

// getIndexColumns returns the ordered column names of an index as a PostgreSQL array string.
func getIndexColumns(db *sql.DB, table, idxName string) (string, error) {
	var columns string
	err := db.QueryRow(
		`SELECT array_agg(a.attname ORDER BY x.n)
		 FROM pg_index i
		 JOIN pg_class c ON c.oid = i.indexrelid
		 JOIN pg_namespace n ON n.oid = c.relnamespace
		 JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
		 JOIN unnest(i.indkey) WITH ORDINALITY AS x(attnum, n) ON x.attnum = a.attnum
		 WHERE i.indrelid = $1::regclass AND c.relname = $2`,
		table, idxName,
	).Scan(&columns)
	return columns, err
}

func migrateCertBindingIndex(db *sql.DB) error {
	return migrateBindingIndex(db, "captain_cert_bindings", "idx_cert_instance_cert", "cert_id")
}

func migratePolicyBindingIndex(db *sql.DB) error {
	return migrateBindingIndex(db, "captain_policy_bindings", "idx_policy_instance_policy", "policy_id")
}

func migratePolicyRuleBindingIndex(db *sql.DB) error {
	return migrateBindingIndex(db, "captain_policy_rule_bindings", "idx_rule_instance_rule", "rule_id")
}

func migrateBlockPageBindingIndex(db *sql.DB) error {
	return migrateBindingIndex(db, "captain_block_page_bindings", "idx_bp_instance_bp", "block_page_id")
}

func addBindingSourceColumns(db *sql.DB) error {
	tables := []string{
		"captain_ip_group_bindings",
		"captain_cert_bindings",
		"captain_policy_bindings",
		"captain_policy_rule_bindings",
		"captain_block_page_bindings",
	}
	for _, table := range tables {
		_, err := db.Exec(fmt.Sprintf(
			"ALTER TABLE %s ADD COLUMN IF NOT EXISTS source VARCHAR(16) NOT NULL DEFAULT 'created'", table,
		))
		if err != nil {
			return fmt.Errorf("add source column to %s: %w", table, err)
		}
	}
	return nil
}

