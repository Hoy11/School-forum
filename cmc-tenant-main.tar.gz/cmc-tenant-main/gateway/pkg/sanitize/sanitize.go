// Package sanitize provides utilities for masking sensitive fields in JSON payloads.
package sanitize

import (
	"encoding/json"
	"strings"
)

var sensitiveFields = map[string]struct{}{
	"password":       {},
	"old_password":   {},
	"new_password":   {},
	"dup_password":   {},
	"admin_password": {},
}

const mask = "******"

// JSON masks sensitive fields in a JSON string.
// If parsing fails, it returns the original string.
func JSON(raw string) string {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return raw
	}

	var data interface{}
	if err := json.Unmarshal([]byte(trimmed), &data); err != nil {
		return raw
	}

	sanitizeValue(data)

	b, err := json.Marshal(data)
	if err != nil {
		return raw
	}
	return string(b)
}

func sanitizeValue(v interface{}) {
	switch val := v.(type) {
	case map[string]interface{}:
		for k, vv := range val {
			if _, ok := sensitiveFields[k]; ok {
				val[k] = mask
				continue
			}
			sanitizeValue(vv)
		}
	case []interface{}:
		for _, item := range val {
			sanitizeValue(item)
		}
	}
}
