package jwt

import (
	"testing"
)

func TestSignAndParse(t *testing.T) {
	secret := "test-secret"
	token, err := Sign(secret, 1, "admin", "admin", nil, 24, "test-session")
	if err != nil {
		t.Fatalf("sign: %v", err)
	}

	claims, err := Parse(secret, token)
	if err != nil {
		t.Fatalf("parse: %v", err)
	}
	if claims.UserID != 1 {
		t.Errorf("userID = %d, want 1", claims.UserID)
	}
	if claims.Username != "admin" {
		t.Errorf("username = %s, want admin", claims.Username)
	}
	if claims.Role != "admin" {
		t.Errorf("role = %s, want admin", claims.Role)
	}
	if claims.TenantGroupID != nil {
		t.Errorf("tenantGroupID should be nil")
	}
	if claims.ID != "test-session" {
		t.Errorf("sessionID = %s, want test-session", claims.ID)
	}
}

func TestParseWithTenantGroup(t *testing.T) {
	secret := "test-secret"
	tgID := uint(5)
	token, _ := Sign(secret, 2, "user1", "tenant", &tgID, 24, "test-session")

	claims, err := Parse(secret, token)
	if err != nil {
		t.Fatalf("parse: %v", err)
	}
	if claims.TenantGroupID == nil || *claims.TenantGroupID != 5 {
		t.Errorf("tenantGroupID = %v, want 5", claims.TenantGroupID)
	}
}

func TestParseInvalidToken(t *testing.T) {
	_, err := Parse("secret", "invalid-token")
	if err == nil {
		t.Error("should fail on invalid token")
	}
}

func TestParseWrongSecret(t *testing.T) {
	token, _ := Sign("secret-a", 1, "admin", "admin", nil, 24, "test-session")
	_, err := Parse("secret-b", token)
	if err == nil {
		t.Error("should fail with wrong secret")
	}
}

func TestShouldRefresh(t *testing.T) {
	secret := "test-secret"
	token, _ := Sign(secret, 1, "admin", "admin", nil, 24, "test-session")
	claims, _ := Parse(secret, token)

	if ShouldRefresh(claims, 24) {
		t.Error("new token should not need refresh")
	}
}

func TestExpiredToken(t *testing.T) {
	secret := "test-secret"
	token, _ := Sign(secret, 1, "admin", "admin", nil, -1, "test-session")
	_, err := Parse(secret, token)
	if err == nil {
		t.Error("expired token should fail")
	}
}
