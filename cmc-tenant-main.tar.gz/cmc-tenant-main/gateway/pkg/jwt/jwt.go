// Package jwt provides JWT token signing, parsing, and refresh logic.
package jwt

import (
	"errors"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// Claims represents the JWT payload for authenticated users.
type Claims struct {
	UserID         uint  `json:"user_id"`
	Username       string `json:"username"`
	Role           string `json:"role"`
	TenantGroupID  *uint  `json:"tenant_group_id"`
	jwt.RegisteredClaims
}

// Sign creates a signed JWT token string for the given user. sessionID is stored in the
// standard jti claim and is used to enforce single sign-on (one active session per user).
func Sign(secret string, userID uint, username, role string, tenantGroupID *uint, expireHours int, sessionID string) (string, error) {
	now := time.Now()
	claims := Claims{
		UserID:        userID,
		Username:      username,
		Role:          role,
		TenantGroupID: tenantGroupID,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(now.Add(time.Duration(expireHours) * time.Hour)),
			IssuedAt:  jwt.NewNumericDate(now),
			ID:        sessionID,
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	return token.SignedString([]byte(secret))
}

// Parse validates a JWT token string and returns its claims.
func Parse(secret string, tokenStr string) (*Claims, error) {
	token, err := jwt.ParseWithClaims(tokenStr, &Claims{}, func(t *jwt.Token) (interface{}, error) {
		if _, ok := t.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, errors.New("unexpected signing method")
		}
		return []byte(secret), nil
	})
	if err != nil {
		return nil, err
	}
	claims, ok := token.Claims.(*Claims)
	if !ok || !token.Valid {
		return nil, errors.New("invalid token")
	}
	return claims, nil
}

// ShouldRefresh returns true if the token should be refreshed (less than 1/3 TTL remaining).
func ShouldRefresh(claims *Claims, expireHours int) bool {
	if claims.ExpiresAt == nil {
		return false
	}
	total := time.Duration(expireHours) * time.Hour
	remaining := time.Until(claims.ExpiresAt.Time)
	return remaining < total/3
}
