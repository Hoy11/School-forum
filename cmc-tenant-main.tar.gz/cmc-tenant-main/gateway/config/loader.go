// Package config holds all application configuration types and loading logic.
package config

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"os"

	"github.com/spf13/viper"
)

// Load reads configuration for the given environment and returns a Config.
func Load(env string) *Config {
	v := viper.New()

	v.SetConfigName(env)
	v.SetConfigType("json")
	v.AddConfigPath("config")

	setDefaults(v)
	bindEnv(v)

	if err := v.ReadInConfig(); err != nil {
		fmt.Fprintf(os.Stderr, "read config: %v\n", err)
	}

	var cfg Config
	if err := v.Unmarshal(&cfg); err != nil {
		fmt.Fprintf(os.Stderr, "unmarshal config: %v\n", err)
		os.Exit(1)
	}

	if cfg.JWT.Secret == "" {
		b := make([]byte, 32)
		rand.Read(b)
		cfg.JWT.Secret = hex.EncodeToString(b)
		fmt.Printf("JWT_SECRET not configured, generated: %s\n", cfg.JWT.Secret)
	}

	return &cfg
}

func setDefaults(v *viper.Viper) {
	v.SetDefault("server.port", 8080)
	v.SetDefault("pg.host", "localhost")
	v.SetDefault("pg.port", 5432)
	v.SetDefault("pg.user", "cmc")
	v.SetDefault("pg.dbname", "cmc_tenant")
	v.SetDefault("pg.sslmode", "disable")
	v.SetDefault("redis.addr", "localhost:6379")
	v.SetDefault("jwt.expire_hours", 24)
	v.SetDefault("login_security.max_retry", 5)
	v.SetDefault("login_security.lock_minutes", 30)
	v.SetDefault("login_security.retry_window_seconds", 300)
	v.SetDefault("captain.request_timeout_seconds", 10)
	v.SetDefault("captain.retry_count", 1)
	v.SetDefault("captain.breaker_max_fail_count", 3)
	v.SetDefault("captain.breaker_timeout_seconds", 30)
	v.SetDefault("risk_guard.waf_cooldown_seconds", 10)
	v.SetDefault("resync.secret_key", "")
	v.SetDefault("resync.batch_size", 5)
	v.SetDefault("resync.batch_interval", 2)
	v.SetDefault("resync.rate_limit_minutes", 30)
	v.SetDefault("log.level", "info")
}

func bindEnv(v *viper.Viper) {
	envMap := map[string]string{
		"pg.host":                         "PG_HOST",
		"pg.port":                         "PG_PORT",
		"pg.user":                         "PG_USER",
		"pg.password":                     "PG_PASSWORD",
		"pg.dbname":                       "PG_DBNAME",
		"redis.addr":                      "REDIS_ADDR",
		"redis.password":                  "REDIS_PASSWORD",
		"jwt.secret":                      "JWT_SECRET",
		"jwt.expire_hours":                "JWT_EXPIRE_HOURS",
		"risk_guard.waf_cooldown_seconds": "RISK_GUARD_WAF_COOLDOWN_SECONDS",
		"captain.host":                    "CAPTAIN_HOST",
		"captain.api_token":               "CAPTAIN_API_TOKEN",
		"resync.secret_key":               "RESYNC_SECRET_KEY",
		"resync.batch_size":               "RESYNC_BATCH_SIZE",
		"resync.batch_interval":           "RESYNC_BATCH_INTERVAL",
		"resync.rate_limit_minutes":       "RESYNC_RATE_LIMIT_MINUTES",
	}
	for key, env := range envMap {
		_ = v.BindEnv(key, env)
	}
}
