// Package config holds all application configuration types and loading logic.
package config

import (
	"strconv"
)

// Config holds all application configuration.
type Config struct {
	Server        ServerConfig        `mapstructure:"server"`
	PG            PGConfig            `mapstructure:"pg"`
	Redis         RedisConfig         `mapstructure:"redis"`
	JWT           JWTConfig           `mapstructure:"jwt"`
	LoginSecurity LoginSecurityConfig `mapstructure:"login_security"`
	Captain       CaptainConfig       `mapstructure:"captain"`
	RiskGuard     RiskGuardConfig     `mapstructure:"risk_guard"`
	Resync        ResyncConfig        `mapstructure:"resync"`
	Log           LogConfig           `mapstructure:"log"`
}

// ServerConfig holds HTTP server settings.
type ServerConfig struct {
	Port int `mapstructure:"port"`
}

// PGConfig holds PostgreSQL connection settings.
type PGConfig struct {
	Host     string `mapstructure:"host"`
	Port     int    `mapstructure:"port"`
	User     string `mapstructure:"user"`
	Password string `mapstructure:"password"`
	DBName   string `mapstructure:"dbname"`
	SSLMode  string `mapstructure:"sslmode"`
}

// DSN returns the PostgreSQL data source name string.
func (c PGConfig) DSN() string {
	return "host=" + c.Host + " port=" + strconv.Itoa(c.Port) +
		" user=" + c.User + " password=" + c.Password +
		" dbname=" + c.DBName + " sslmode=" + c.SSLMode
}

// RedisConfig holds Redis connection settings.
type RedisConfig struct {
	Addr     string `mapstructure:"addr"`
	Password string `mapstructure:"password"`
	DB       int    `mapstructure:"db"`
}

// JWTConfig holds JWT authentication settings.
type JWTConfig struct {
	Secret      string `mapstructure:"secret"`
	ExpireHours int    `mapstructure:"expire_hours"`
}

// LoginSecurityConfig holds login security policy settings.
type LoginSecurityConfig struct {
	MaxRetry       int `mapstructure:"max_retry"`
	LockMinutes    int `mapstructure:"lock_minutes"`
	RetryWindowSec int `mapstructure:"retry_window_seconds"`
}

// CaptainConfig holds Captain-2 API connection settings.
type CaptainConfig struct {
	Host              string `mapstructure:"host"`
	APIToken          string `mapstructure:"api_token"`
	RequestTimeoutSec int    `mapstructure:"request_timeout_seconds"`
	RetryCount        int    `mapstructure:"retry_count"`
	BreakerMaxFail    int    `mapstructure:"breaker_max_fail_count"`
	BreakerTimeoutSec int    `mapstructure:"breaker_timeout_seconds"`
}

// RiskGuardConfig holds risk guard cooldown settings.
type RiskGuardConfig struct {
	WAFCooldownSec int `mapstructure:"waf_cooldown_seconds"`
}

// LogConfig holds logging level and stack trace settings.
type LogConfig struct {
	Level string `mapstructure:"level"`
	Stack bool   `mapstructure:"stack"`
}

// ResyncConfig holds resync (re-synchronization) fallback operation settings.
type ResyncConfig struct {
	SecretKey        string `mapstructure:"secret_key"`
	BatchSize        int    `mapstructure:"batch_size"`
	BatchInterval    int    `mapstructure:"batch_interval"`     // seconds between batches
	RateLimitMinutes int    `mapstructure:"rate_limit_minutes"` // cooldown per tenant_group_id
}
