// Package model defines the data model for system users.
package model

import (
	"time"

	"gorm.io/gorm"
)

// User represents a system user.
type User struct {
	ID            uint       `gorm:"primaryKey" json:"id"`
	Username      string     `gorm:"uniqueIndex;size:64;not null" json:"username"`
	Password      string     `gorm:"size:128;not null" json:"-"`
	Role          string     `gorm:"index;size:16;not null;default:'tenant'" json:"role"`
	TenantGroupID *uint      `gorm:"index" json:"tenant_group_id"`
	IsEnabled     bool       `gorm:"not null;default:true" json:"is_enabled"`
	IsLocked      bool       `gorm:"not null;default:false" json:"is_locked"`
	RoleLocked    bool       `gorm:"not null;default:false" json:"role_locked"`
	IsDeleted     bool       `gorm:"not null;default:false" json:"-"`
	Remark        string     `json:"remark"`
	LastLogin     *time.Time `json:"last_login"`
	LastLoginIP   string     `gorm:"size:45" json:"last_login_ip"`
	PasswordSet   bool       `gorm:"not null;default:false" json:"-"`
	PwdChangedAt  *time.Time `json:"-"`
	CreatedAt     time.Time  `gorm:"not null" json:"created_at"`
	UpdatedAt     time.Time  `gorm:"not null" json:"updated_at"`
}

// TableName returns the database table name for User.
func (User) TableName() string { return "users" }

// BeforeCreate sets default timestamps before creating a user record.
func (u *User) BeforeCreate(_ *gorm.DB) error {
	if u.CreatedAt.IsZero() {
		u.CreatedAt = time.Now()
	}
	if u.UpdatedAt.IsZero() {
		u.UpdatedAt = time.Now()
	}
	return nil
}
