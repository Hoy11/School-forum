package business

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"time"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

var (
	// ErrUserExists indicates the username is already taken.
	ErrUserExists       = errors.New("用户名已存在")
	// ErrUserNotFound indicates the user does not exist.
	ErrUserNotFound     = errors.New("用户不存在")
	// ErrWrongPassword indicates the username or password is incorrect.
	ErrWrongPassword    = errors.New("用户名或密码错误")
	// ErrUserDisabled indicates the user account is disabled.
	ErrUserDisabled     = errors.New("用户已禁用")
	// ErrUserLocked indicates the user account is locked.
	ErrUserLocked       = errors.New("用户已锁定")
	// ErrGroupHasAdmin indicates the tenant group already has an admin.
	ErrGroupHasAdmin    = errors.New("该租户组已有管理员")
	// ErrInvalidRole indicates the provided role is invalid.
	ErrInvalidRole      = errors.New("无效的角色")
	// ErrGroupRequired indicates a non-admin user must belong to a tenant group.
	ErrGroupRequired    = errors.New("非管理员用户必须指定租户组")
	// ErrRoleLocked indicates the user's role has been changed once via edit and can no longer be modified.
	ErrRoleLocked       = errors.New("角色已锁定，不可修改")
)

// UserOperator handles user CRUD and authentication operations.
type UserOperator struct{}

// NewUserOperator creates a new UserOperator.
func NewUserOperator() *UserOperator { return &UserOperator{} }

// Login authenticates a user by username and password.
func (op *UserOperator) Login(username, password string) (*usermodel.User, error) {
	var user usermodel.User
	if err := database.DB.Where("username = ? AND is_deleted = false", username).First(&user).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, ErrWrongPassword
		}
		return nil, err
	}

	if !user.IsEnabled {
		return nil, ErrUserDisabled
	}
	if user.IsLocked {
		return nil, ErrUserLocked
	}

	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password)); err != nil {
		return nil, ErrWrongPassword
	}
	return &user, nil
}

// Create adds a new user with the given credentials and role.
func (op *UserOperator) Create(username, password, role string, tenantGroupID *uint, remark string) (*usermodel.User, error) {
	if role != "admin" && role != "tenant_admin" && role != "tenant" {
		return nil, ErrInvalidRole
	}

	if role != "admin" && tenantGroupID == nil {
		return nil, ErrGroupRequired
	}

	if role == "tenant_admin" && tenantGroupID != nil {
		var count int64
		database.DB.Model(&usermodel.User{}).
			Where("tenant_group_id = ? AND role = ? AND is_deleted = false", *tenantGroupID, "tenant_admin").
			Count(&count)
		if count > 0 {
			return nil, ErrGroupHasAdmin
		}
	}

	hashed, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	user := usermodel.User{
		Username:      username,
		Password:      string(hashed),
		Role:          role,
		TenantGroupID: tenantGroupID,
		Remark:        remark,
		IsEnabled:     true,
		PasswordSet:   false,
	}

	if err := database.DB.Create(&user).Error; err != nil {
		return nil, err
	}
	return &user, nil
}

// GetByID returns a non-deleted user by ID.
func (op *UserOperator) GetByID(id uint) (*usermodel.User, error) {
	var user usermodel.User
	if err := database.DB.Where("id = ? AND is_deleted = false", id).First(&user).Error; err != nil {
		return nil, ErrUserNotFound
	}
	return &user, nil
}

// List returns paginated users with optional filters.
func (op *UserOperator) List(roles []string, tenantGroupID *uint, username string, isEnabled *bool, offset, count int) (int64, []UserWithGroupName, error) {
	q := database.DB.Model(&usermodel.User{}).Where("users.is_deleted = false")
	if len(roles) > 0 {
		q = q.Where("users.role IN ?", roles)
	}
	if tenantGroupID != nil {
		q = q.Where("users.tenant_group_id = ?", *tenantGroupID)
	}
	if username != "" {
		q = q.Where("users.username LIKE ?", "%"+username+"%")
	}
	if isEnabled != nil {
		q = q.Where("users.is_enabled = ?", *isEnabled)
	}

	var total int64
	q.Count(&total)

	var results []UserWithGroupName
	err := q.Select("users.id, users.username, users.role, users.tenant_group_id, "+
		"tenant_groups.name as tenant_group_name, users.is_enabled, users.is_locked, users.role_locked, "+
		"users.remark, users.last_login, users.created_at").
		Joins("LEFT JOIN tenant_groups ON tenant_groups.id = users.tenant_group_id").
		Offset(offset).Limit(count).Order("users.id ASC").
		Scan(&results).Error
	return total, results, err
}

// Update modifies a user's role, group, and remark.
func (op *UserOperator) Update(id uint, role string, tenantGroupID *uint, remark string) error {
	var current usermodel.User
	if err := database.DB.Where("id = ? AND is_deleted = false", id).First(&current).Error; err != nil {
		return ErrUserNotFound
	}

	roleChanging := role != "" && role != current.Role
	if roleChanging && current.RoleLocked {
		return ErrRoleLocked
	}

	if role == "tenant_admin" && tenantGroupID != nil {
		var count int64
		database.DB.Model(&usermodel.User{}).
			Where("tenant_group_id = ? AND role = ? AND is_deleted = false AND id != ?", *tenantGroupID, "tenant_admin", id).
			Count(&count)
		if count > 0 {
			return ErrGroupHasAdmin
		}
	}

	updates := map[string]interface{}{}
	if role != "" {
		updates["role"] = role
		if roleChanging {
			updates["role_locked"] = true
		}
	}
	if role == "admin" {
		updates["tenant_group_id"] = nil
	} else if tenantGroupID != nil {
		updates["tenant_group_id"] = *tenantGroupID
	}
	if remark != "" {
		updates["remark"] = remark
	}
	return database.DB.Model(&usermodel.User{}).Where("id = ? AND is_deleted = false", id).Updates(updates).Error
}

// Enable sets the enabled status for the given user IDs.
func (op *UserOperator) Enable(ids []uint, isEnabled bool) error {
	return database.DB.Model(&usermodel.User{}).
		Where("id IN ? AND is_deleted = false", ids).
		Update("is_enabled", isEnabled).Error
}

// ResetPassword generates a new random password for the user.
func (op *UserOperator) ResetPassword(id uint) (string, error) {
	newPwd := generateRandomPassword(12)
	hashed, err := bcrypt.GenerateFromPassword([]byte(newPwd), bcrypt.DefaultCost)
	if err != nil {
		return "", err
	}
	err = database.DB.Model(&usermodel.User{}).
		Where("id = ? AND is_deleted = false", id).
		Updates(map[string]interface{}{"password": string(hashed), "password_set": false, "pwd_changed_at": nil}).Error
	return newPwd, err
}

// Unlock clears the locked status for the given user IDs.
func (op *UserOperator) Unlock(ids []uint) error {
	return database.DB.Model(&usermodel.User{}).
		Where("id IN ? AND is_deleted = false", ids).
		Update("is_locked", false).Error
}

// GetUsernamesByIDs returns the usernames for the given user IDs.
func (op *UserOperator) GetUsernamesByIDs(ids []uint) ([]string, error) {
	var usernames []string
	err := database.DB.Model(&usermodel.User{}).
		Where("id IN ? AND is_deleted = false", ids).
		Pluck("username", &usernames).Error
	return usernames, err
}

// Delete soft-deletes the given user IDs.
func (op *UserOperator) Delete(ids []uint) error {
	return database.DB.Model(&usermodel.User{}).
		Where("id IN ?", ids).
		Update("is_deleted", true).Error
}

// ChangePassword updates a user's password after verifying the old one.
func (op *UserOperator) ChangePassword(id uint, oldPwd, newPwd string) error {
	var user usermodel.User
	if err := database.DB.Where("id = ? AND is_deleted = false", id).First(&user).Error; err != nil {
		return ErrUserNotFound
	}
	if err := bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(oldPwd)); err != nil {
		return ErrWrongPassword
	}
	hashed, err := bcrypt.GenerateFromPassword([]byte(newPwd), bcrypt.DefaultCost)
	if err != nil {
		return err
	}
	now := time.Now()
	return database.DB.Model(&user).Updates(map[string]interface{}{
		"password":       string(hashed),
		"password_set":   true,
		"pwd_changed_at": now,
	}).Error
}

func generateRandomPassword(length int) string {
	b := make([]byte, length)
	rand.Read(b)
	return hex.EncodeToString(b)[:length]
}
