// Package business provides user CRUD operations and DTOs.
package business

// UserWithGroupName extends user info with tenant group name for list responses.
type UserWithGroupName struct {
	ID              uint    `json:"id"`
	Username        string  `json:"username"`
	Role            string  `json:"role"`
	TenantGroupID   *uint   `json:"tenant_group_id"`
	TenantGroupName *string `json:"tenant_group_name"`
	IsEnabled       bool    `json:"is_enabled"`
	IsLocked        bool    `json:"is_locked"`
	RoleLocked      bool    `json:"role_locked"`
	Remark          string  `json:"remark"`
	LastLogin       *string `json:"last_login"`
	CreatedAt       string  `json:"created_at"`
}
