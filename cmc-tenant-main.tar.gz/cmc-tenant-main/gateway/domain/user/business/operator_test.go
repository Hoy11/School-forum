package business

import (
	"testing"

	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&usermodel.User{}, &tgmodel.TenantGroup{})
	database.DB = db
}

func createTestTenantGroup(t *testing.T) uint {
	group := tgmodel.TenantGroup{Name: "test-group", IsEnabled: true}
	if err := database.DB.Create(&group).Error; err != nil {
		t.Fatalf("create test group: %v", err)
	}
	return group.ID
}

func TestCreateAndGetUser(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()

	user, err := op.Create("testuser", "password123", "admin", nil, "test")
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if user.ID == 0 {
		t.Error("user ID should be set")
	}

	found, err := op.GetByID(user.ID)
	if err != nil {
		t.Fatalf("get: %v", err)
	}
	if found.Username != "testuser" {
		t.Errorf("username = %s, want testuser", found.Username)
	}
	if found.PasswordSet {
		t.Error("new user should have PasswordSet=false")
	}
}

func TestCreateDuplicateUsername(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()

	_, err := op.Create("dup", "pass", "admin", nil, "")
	if err != nil {
		t.Fatalf("first create: %v", err)
	}
	_, err = op.Create("dup", "pass", "admin", nil, "")
	if err == nil {
		t.Error("duplicate username should fail")
	}
}

func TestCreateTenantWithoutGroup(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()

	_, err := op.Create("nop", "pass", "tenant", nil, "")
	if err != ErrGroupRequired {
		t.Errorf("err = %v, want ErrGroupRequired", err)
	}
}

func TestLogin(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	_, _ = op.Create("loginuser", "mypass", "admin", nil, "")

	user, err := op.Login("loginuser", "mypass")
	if err != nil {
		t.Fatalf("login: %v", err)
	}
	if user.Username != "loginuser" {
		t.Errorf("username = %s", user.Username)
	}
}

func TestLoginWrongPassword(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	_, _ = op.Create("loginuser", "mypass", "admin", nil, "")

	_, err := op.Login("loginuser", "wrongpass")
	if err != ErrWrongPassword {
		t.Errorf("err = %v, want ErrWrongPassword", err)
	}
}

func TestLoginDisabled(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	user, _ := op.Create("disabled", "pass", "admin", nil, "")
	_ = op.Enable([]uint{user.ID}, false)

	_, err := op.Login("disabled", "pass")
	if err != ErrUserDisabled {
		t.Errorf("err = %v, want ErrUserDisabled", err)
	}
}

func TestChangePassword(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	user, _ := op.Create("changer", "oldpass", "admin", nil, "")

	err := op.ChangePassword(user.ID, "oldpass", "newpass")
	if err != nil {
		t.Fatalf("change password: %v", err)
	}

	_, err = op.Login("changer", "newpass")
	if err != nil {
		t.Fatalf("login with new password: %v", err)
	}
}

func TestChangePasswordWrongOld(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	user, _ := op.Create("changer", "oldpass", "admin", nil, "")

	err := op.ChangePassword(user.ID, "wrongold", "newpass")
	if err != ErrWrongPassword {
		t.Errorf("err = %v, want ErrWrongPassword", err)
	}
}

func TestEnableDisableUser(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)
	user, _ := op.Create("toggle", "pass", "tenant", &tgID, "")

	_ = op.Enable([]uint{user.ID}, false)
	found, _ := op.GetByID(user.ID)
	if found.IsEnabled {
		t.Error("should be disabled")
	}

	_ = op.Enable([]uint{user.ID}, true)
	found, _ = op.GetByID(user.ID)
	if !found.IsEnabled {
		t.Error("should be enabled")
	}
}

func TestSoftDelete(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)
	user, _ := op.Create("deleteme", "pass", "tenant", &tgID, "")

	_ = op.Delete([]uint{user.ID})
	_, err := op.GetByID(user.ID)
	if err != ErrUserNotFound {
		t.Errorf("err = %v, want ErrUserNotFound", err)
	}
}

func TestResetPassword(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	user, _ := op.Create("resetme", "oldpass", "admin", nil, "")

	newPwd, err := op.ResetPassword(user.ID)
	if err != nil {
		t.Fatalf("reset: %v", err)
	}
	if newPwd == "" {
		t.Error("should return new password")
	}

	_, err = op.Login("resetme", newPwd)
	if err != nil {
		t.Fatalf("login with reset password: %v", err)
	}
}

func TestListUsers(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)
	_, _ = op.Create("a1", "pass", "admin", nil, "")
	_, _ = op.Create("t1", "pass", "tenant", &tgID, "")

	total, users, err := op.List([]string{"tenant"}, nil, "", nil, 0, 10)
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if total != 1 {
		t.Errorf("total = %d, want 1", total)
	}
	if len(users) != 1 || users[0].Role != "tenant" {
		t.Error("should only list tenant users")
	}
}

func TestUpdateTenantAdminConflict(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)

	_, _ = op.Create("ta1", "pass", "tenant_admin", &tgID, "")
	user2, _ := op.Create("t2", "pass", "tenant", &tgID, "")

	err := op.Update(user2.ID, "tenant_admin", &tgID, "")
	if err != ErrGroupHasAdmin {
		t.Errorf("err = %v, want ErrGroupHasAdmin", err)
	}
}

func TestUpdateToAdminClearsTenantGroupID(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)

	user, _ := op.Create("ta2", "pass", "tenant_admin", &tgID, "")

	// 模拟前端切到 admin 时不传 tenant_group_id（JSON.stringify 会丢掉 undefined 字段）
	if err := op.Update(user.ID, "admin", nil, ""); err != nil {
		t.Fatalf("update: %v", err)
	}

	got, err := op.GetByID(user.ID)
	if err != nil {
		t.Fatalf("get by id: %v", err)
	}
	if got.Role != "admin" {
		t.Errorf("role = %q, want admin", got.Role)
	}
	if got.TenantGroupID != nil {
		t.Errorf("tenant_group_id = %v, want nil", *got.TenantGroupID)
	}
}

func TestUpdateNonAdminStillUpdatesTenantGroupID(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)
	otherGroup := tgmodel.TenantGroup{Name: "other-group", IsEnabled: true}
	if err := database.DB.Create(&otherGroup).Error; err != nil {
		t.Fatalf("create other group: %v", err)
	}
	otherTgID := otherGroup.ID

	user, _ := op.Create("t3", "pass", "tenant", &tgID, "")

	if err := op.Update(user.ID, "tenant", &otherTgID, ""); err != nil {
		t.Fatalf("update: %v", err)
	}

	got, err := op.GetByID(user.ID)
	if err != nil {
		t.Fatalf("get by id: %v", err)
	}
	if got.TenantGroupID == nil || *got.TenantGroupID != otherTgID {
		t.Errorf("tenant_group_id = %v, want %d", got.TenantGroupID, otherTgID)
	}
}

func TestUpdateRoleChangeLocksRole(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)

	user, _ := op.Create("locktest1", "pass", "tenant", &tgID, "")

	if err := op.Update(user.ID, "tenant_admin", &tgID, ""); err != nil {
		t.Fatalf("update: %v", err)
	}

	got, err := op.GetByID(user.ID)
	if err != nil {
		t.Fatalf("get by id: %v", err)
	}
	if got.Role != "tenant_admin" {
		t.Errorf("role = %q, want tenant_admin", got.Role)
	}
	if !got.RoleLocked {
		t.Error("expected role_locked to be true after first role change")
	}
}

func TestUpdateLockedRoleRejectsFurtherChange(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)

	user, _ := op.Create("locktest2", "pass", "tenant", &tgID, "")
	if err := op.Update(user.ID, "tenant_admin", &tgID, ""); err != nil {
		t.Fatalf("first update: %v", err)
	}

	err := op.Update(user.ID, "admin", nil, "")
	if err != ErrRoleLocked {
		t.Errorf("err = %v, want ErrRoleLocked", err)
	}

	got, _ := op.GetByID(user.ID)
	if got.Role != "tenant_admin" {
		t.Errorf("role = %q, want unchanged tenant_admin", got.Role)
	}
}

func TestUpdateSameRoleDoesNotLock(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)

	user, _ := op.Create("locktest3", "pass", "tenant", &tgID, "")

	if err := op.Update(user.ID, "tenant", &tgID, "改个备注"); err != nil {
		t.Fatalf("update: %v", err)
	}

	got, _ := op.GetByID(user.ID)
	if got.RoleLocked {
		t.Error("role_locked should stay false when role did not actually change")
	}
}

func TestUpdateLockedRoleAllowsOtherFieldChanges(t *testing.T) {
	setupTestDB(t)
	op := NewUserOperator()
	tgID := createTestTenantGroup(t)

	user, _ := op.Create("locktest4", "pass", "tenant", &tgID, "")
	if err := op.Update(user.ID, "tenant_admin", &tgID, ""); err != nil {
		t.Fatalf("first update: %v", err)
	}

	// role 传空字符串，相当于这次编辑不改角色，只改备注
	if err := op.Update(user.ID, "", nil, "新备注"); err != nil {
		t.Fatalf("second update: %v", err)
	}

	got, _ := op.GetByID(user.ID)
	if got.Role != "tenant_admin" {
		t.Errorf("role = %q, want unchanged tenant_admin", got.Role)
	}
	if got.Remark != "新备注" {
		t.Errorf("remark = %q, want 新备注", got.Remark)
	}
}
