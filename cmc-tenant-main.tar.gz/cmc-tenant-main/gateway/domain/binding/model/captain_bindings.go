package model

import "time"

// CaptainIPGroupBinding maps an IP group on a WAF instance to a tenant group.
type CaptainIPGroupBinding struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	CaptainInstanceID int       `gorm:"uniqueIndex:idx_ipg_instance_group;not null" json:"captain_instance_id"`
	IPGroupID         int       `gorm:"uniqueIndex:idx_ipg_instance_group;not null" json:"ip_group_id"`
	TenantGroupID     uint      `gorm:"uniqueIndex:idx_ipg_instance_group;not null" json:"tenant_group_id"`
	Source            string    `gorm:"type:varchar(16);not null;default:'created'" json:"source"`
	CreatedAt         time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for CaptainIPGroupBinding.
func (CaptainIPGroupBinding) TableName() string { return "captain_ip_group_bindings" }

// CaptainCertBinding maps an SSL certificate on a WAF instance to a tenant group.
type CaptainCertBinding struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	CaptainInstanceID int       `gorm:"uniqueIndex:idx_cert_instance_cert;not null" json:"captain_instance_id"`
	CertID            int       `gorm:"uniqueIndex:idx_cert_instance_cert;not null" json:"cert_id"`
	TenantGroupID     uint      `gorm:"uniqueIndex:idx_cert_instance_cert;not null" json:"tenant_group_id"`
	Source            string    `gorm:"type:varchar(16);not null;default:'created'" json:"source"`
	CreatedAt         time.Time `gorm:"not null" json:"created_at"`
}

// CaptainPolicyBinding maps a protection policy on a WAF instance to a tenant group.
type CaptainPolicyBinding struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	CaptainInstanceID int       `gorm:"uniqueIndex:idx_policy_instance_policy;not null" json:"captain_instance_id"`
	PolicyID          int       `gorm:"uniqueIndex:idx_policy_instance_policy;not null" json:"policy_id"`
	TenantGroupID     uint      `gorm:"uniqueIndex:idx_policy_instance_policy;not null" json:"tenant_group_id"`
	Source            string    `gorm:"type:varchar(16);not null;default:'created'" json:"source"`
	CreatedAt         time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for CaptainPolicyBinding.
func (CaptainPolicyBinding) TableName() string { return "captain_policy_bindings" }

// CaptainPolicyRuleBinding maps a custom rule on a WAF instance to a tenant group.
type CaptainPolicyRuleBinding struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	CaptainInstanceID int       `gorm:"uniqueIndex:idx_rule_instance_rule;not null" json:"captain_instance_id"`
	RuleID            int       `gorm:"uniqueIndex:idx_rule_instance_rule;not null" json:"rule_id"`
	TenantGroupID     uint      `gorm:"uniqueIndex:idx_rule_instance_rule;not null" json:"tenant_group_id"`
	Source            string    `gorm:"type:varchar(16);not null;default:'created'" json:"source"`
	CreatedAt         time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for CaptainPolicyRuleBinding.
func (CaptainPolicyRuleBinding) TableName() string { return "captain_policy_rule_bindings" }

// CaptainBlockPageBinding maps a block page on a WAF instance to a tenant group.
type CaptainBlockPageBinding struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	CaptainInstanceID int       `gorm:"uniqueIndex:idx_bp_instance_bp;not null" json:"captain_instance_id"`
	BlockPageID       int       `gorm:"uniqueIndex:idx_bp_instance_bp;not null" json:"block_page_id"`
	TenantGroupID     uint      `gorm:"uniqueIndex:idx_bp_instance_bp;not null" json:"tenant_group_id"`
	Source            string    `gorm:"type:varchar(16);not null;default:'created'" json:"source"`
	CreatedAt         time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for CaptainBlockPageBinding.
func (CaptainBlockPageBinding) TableName() string { return "captain_block_page_bindings" }
