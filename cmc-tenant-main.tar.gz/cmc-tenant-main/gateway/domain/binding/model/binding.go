// Package model defines the binding data models for WAF, sites, and log tasks.
package model

import "time"

// WafBinding maps a tenant group to a WAF instance.
type WafBinding struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	TenantGroupID     uint      `gorm:"uniqueIndex:idx_waf_tg_instance;not null" json:"tenant_group_id"`
	CaptainInstanceID int       `gorm:"uniqueIndex:idx_waf_tg_instance;index;not null" json:"captain_instance_id"`
	CreatedAt         time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for WafBinding.
func (WafBinding) TableName() string { return "waf_bindings" }

// SiteBinding maps a tenant group to a specific site on a WAF instance.
type SiteBinding struct {
	ID                uint      `gorm:"primaryKey" json:"id"`
	TenantGroupID     uint      `gorm:"not null" json:"tenant_group_id"`
	CaptainInstanceID int       `gorm:"uniqueIndex:idx_site_instance_site;not null" json:"captain_instance_id"`
	SiteID            int       `gorm:"uniqueIndex:idx_site_instance_site;not null" json:"site_id"`
	CreatedAt         time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for SiteBinding.
func (SiteBinding) TableName() string { return "site_bindings" }

// CaptainLogTask maps a log download task to a tenant group.
type CaptainLogTask struct {
	ID            uint      `gorm:"primaryKey" json:"id"`
	CaptainTaskID int       `gorm:"index;not null" json:"captain_task_id"`
	TenantGroupID *uint     `gorm:"index" json:"tenant_group_id"`
	CreatedAt     time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for CaptainLogTask.
func (CaptainLogTask) TableName() string { return "captain_log_tasks" }
