// Package business provides binding CRUD operations and DTOs.
package business

import (
	"errors"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

// ErrWafAlreadyBound indicates the WAF instance is already bound to another group.
var (
	ErrWafAlreadyBound     = errors.New("该 WAF 已绑定到此租户组")
	ErrSiteAlreadyBound    = errors.New("该站点已绑定到其他租户组")
	ErrWafNotBound         = errors.New("该 WAF 未绑定到此租户组")
	ErrWafHasSiteBindings  = errors.New("有站点还在使用此绑定关系")
	ErrBindingNotFound     = errors.New("绑定不存在")
	ErrTenantGroupNotFound = errors.New("租户组不存在")
	ErrEmptyWafInstanceIDs = errors.New("captain_instance_ids 不能为空")
)

// BindingOperator handles WAF and site binding operations.
type BindingOperator struct{}

// NewBindingOperator creates a new BindingOperator.
func NewBindingOperator() *BindingOperator { return &BindingOperator{} }

// CreateWafBindings binds WAF instances to a tenant group.
func (op *BindingOperator) CreateWafBindings(tenantGroupID uint, instanceIDs []int) error {
	if len(instanceIDs) == 0 {
		return ErrEmptyWafInstanceIDs
	}
	var groupCount int64
	if err := database.DB.Model(&tgmodel.TenantGroup{}).
		Where("id = ? AND is_deleted = false", tenantGroupID).
		Count(&groupCount).Error; err != nil {
		return err
	}
	if groupCount == 0 {
		return ErrTenantGroupNotFound
	}

	for _, instanceID := range instanceIDs {
		var count int64
		database.DB.Model(&bindingmodel.WafBinding{}).
			Where("tenant_group_id = ? AND captain_instance_id = ?", tenantGroupID, instanceID).Count(&count)
		if count > 0 {
			return ErrWafAlreadyBound
		}
	}

	for _, instanceID := range instanceIDs {
		binding := bindingmodel.WafBinding{
			TenantGroupID:     tenantGroupID,
			CaptainInstanceID: instanceID,
		}
		if err := database.DB.Create(&binding).Error; err != nil {
			return err
		}
	}
	return nil
}

// ListWafBindings returns paginated WAF bindings, optionally filtered by tenant group.
func (op *BindingOperator) ListWafBindings(tenantGroupID *uint, offset, count int) (int64, []bindingmodel.WafBinding, error) {
	q := database.DB.Model(&bindingmodel.WafBinding{})
	if tenantGroupID != nil {
		q = q.Where("tenant_group_id = ?", *tenantGroupID)
	}
	var total int64
	q.Count(&total)

	var bindings []bindingmodel.WafBinding
	err := q.Offset(offset).Limit(count).Order("id ASC").Find(&bindings).Error
	return total, bindings, err
}

// DeleteWafBindings removes WAF bindings by IDs. Returns ErrWafHasSiteBindings
// if any binding still has associated site bindings.
func (op *BindingOperator) DeleteWafBindings(ids []uint) error {
	var bindings []bindingmodel.WafBinding
	if err := database.DB.Where("id IN ?", ids).Find(&bindings).Error; err != nil {
		return err
	}
	for _, b := range bindings {
		if op.HasSiteBindings(b.TenantGroupID, b.CaptainInstanceID) {
			return ErrWafHasSiteBindings
		}
	}
	return database.DB.Where("id IN ?", ids).Delete(&bindingmodel.WafBinding{}).Error
}

// CreateSiteBindings binds sites under a WAF instance to a tenant group.
func (op *BindingOperator) CreateSiteBindings(tenantGroupID uint, captainInstanceID int, siteIDs []int) error {
	var wafCount int64
	database.DB.Model(&bindingmodel.WafBinding{}).
		Where("tenant_group_id = ? AND captain_instance_id = ?", tenantGroupID, captainInstanceID).
		Count(&wafCount)
	if wafCount == 0 {
		return ErrWafNotBound
	}

	for _, siteID := range siteIDs {
		var count int64
		database.DB.Model(&bindingmodel.SiteBinding{}).
			Where("captain_instance_id = ? AND site_id = ?", captainInstanceID, siteID).Count(&count)
		if count > 0 {
			return ErrSiteAlreadyBound
		}
	}

	for _, siteID := range siteIDs {
		binding := bindingmodel.SiteBinding{
			TenantGroupID:     tenantGroupID,
			CaptainInstanceID: captainInstanceID,
			SiteID:            siteID,
		}
		if err := database.DB.Create(&binding).Error; err != nil {
			return err
		}
	}
	return nil
}

// ListSiteBindings returns paginated site bindings with optional filters.
func (op *BindingOperator) ListSiteBindings(tenantGroupID *uint, captainInstanceID *int, offset, count int) (int64, []bindingmodel.SiteBinding, error) {
	q := database.DB.Model(&bindingmodel.SiteBinding{})
	if tenantGroupID != nil {
		q = q.Where("tenant_group_id = ?", *tenantGroupID)
	}
	if captainInstanceID != nil {
		q = q.Where("captain_instance_id = ?", *captainInstanceID)
	}
	var total int64
	q.Count(&total)

	var bindings []bindingmodel.SiteBinding
	err := q.Offset(offset).Limit(count).Order("id ASC").Find(&bindings).Error
	return total, bindings, err
}

// HasSiteBindings checks whether a tenant group has any site bindings under a WAF instance.
func (op *BindingOperator) HasSiteBindings(tenantGroupID uint, captainInstanceID int) bool {
	var count int64
	database.DB.Model(&bindingmodel.SiteBinding{}).
		Where("tenant_group_id = ? AND captain_instance_id = ?", tenantGroupID, captainInstanceID).
		Count(&count)
	return count > 0
}

// DeleteSiteBindings removes site bindings by IDs.
func (op *BindingOperator) DeleteSiteBindings(ids []uint) error {
	return database.DB.Where("id IN ?", ids).Delete(&bindingmodel.SiteBinding{}).Error
}

// GetBoundInstanceIDs returns WAF instance IDs bound to the given tenant group.
func (op *BindingOperator) GetBoundInstanceIDs(tenantGroupID uint) []int {
	var ids []int
	database.DB.Model(&bindingmodel.WafBinding{}).
		Where("tenant_group_id = ?", tenantGroupID).
		Pluck("captain_instance_id", &ids)
	return ids
}

// GetBoundSiteIDs returns site IDs bound to the given tenant group under a WAF instance.
func (op *BindingOperator) GetBoundSiteIDs(tenantGroupID uint, captainInstanceID int) []int {
	var ids []int
	database.DB.Model(&bindingmodel.SiteBinding{}).
		Where("tenant_group_id = ? AND captain_instance_id = ?", tenantGroupID, captainInstanceID).
		Pluck("site_id", &ids)
	return ids
}

// GetAllBoundSiteIDs returns all site IDs bound under a WAF instance, regardless of tenant group.
func (op *BindingOperator) GetAllBoundSiteIDs(captainInstanceID int) []int {
	var ids []int
	database.DB.Model(&bindingmodel.SiteBinding{}).
		Where("captain_instance_id = ?", captainInstanceID).
		Pluck("site_id", &ids)
	return ids
}
