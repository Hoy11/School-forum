package business

import (
	"testing"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupBindingTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&bindingmodel.WafBinding{}, &bindingmodel.SiteBinding{}, &tgmodel.TenantGroup{}, &usermodel.User{})
	database.DB = db
}

func createTestGroupAndWaf(_ *testing.T) (uint, int) {
	group := tgmodel.TenantGroup{Name: "test-group", IsEnabled: true}
	database.DB.Create(&group)
	return group.ID, 100
}

func createTestGroup(name string) uint {
	group := tgmodel.TenantGroup{Name: name, IsEnabled: true}
	database.DB.Create(&group)
	return group.ID
}

func TestCreateWafBinding(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)

	err := op.CreateWafBindings(tgID, []int{instanceID})
	if err != nil {
		t.Fatalf("create: %v", err)
	}

	total, bindings, _ := op.ListWafBindings(&tgID, 0, 10)
	if total != 1 {
		t.Errorf("total = %d, want 1", total)
	}
	if bindings[0].CaptainInstanceID != instanceID {
		t.Errorf("instance_id = %d, want %d", bindings[0].CaptainInstanceID, instanceID)
	}
}

func TestCreateWafBindingDuplicateAcrossGroups(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)
	otherTgID := createTestGroup("other-group")

	_ = op.CreateWafBindings(tgID, []int{instanceID})
	// Different tenant group binding same WAF should succeed
	err := op.CreateWafBindings(otherTgID, []int{instanceID})
	if err != nil {
		t.Errorf("err = %v, want nil (WAF can be shared across tenant groups)", err)
	}
}

func TestCreateWafBindingRejectsMissingTenantGroup(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()

	err := op.CreateWafBindings(999, []int{100})
	if err != ErrTenantGroupNotFound {
		t.Errorf("err = %v, want ErrTenantGroupNotFound", err)
	}
}

func TestCreateWafBindingRejectsEmptyInstanceIDs(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, _ := createTestGroupAndWaf(t)

	err := op.CreateWafBindings(tgID, []int{})
	if err != ErrEmptyWafInstanceIDs {
		t.Errorf("err = %v, want ErrEmptyWafInstanceIDs", err)
	}
}

func TestCreateWafBindingDuplicateInSameGroup(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)

	_ = op.CreateWafBindings(tgID, []int{instanceID})
	// Same tenant group binding same WAF again should fail
	err := op.CreateWafBindings(tgID, []int{instanceID})
	if err != ErrWafAlreadyBound {
		t.Errorf("err = %v, want ErrWafAlreadyBound", err)
	}
}

func TestDeleteWafBinding(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)

	_ = op.CreateWafBindings(tgID, []int{instanceID})
	_, bindings, _ := op.ListWafBindings(&tgID, 0, 10)

	_ = op.DeleteWafBindings([]uint{bindings[0].ID})
	total, _, _ := op.ListWafBindings(&tgID, 0, 10)
	if total != 0 {
		t.Errorf("total = %d, want 0 after delete", total)
	}
}

func TestCreateSiteBinding(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)
	_ = op.CreateWafBindings(tgID, []int{instanceID})

	err := op.CreateSiteBindings(tgID, instanceID, []int{1, 2})
	if err != nil {
		t.Fatalf("create: %v", err)
	}

	total, _, _ := op.ListSiteBindings(&tgID, nil, 0, 10)
	if total != 2 {
		t.Errorf("total = %d, want 2", total)
	}
}

func TestCreateSiteWithoutWafBinding(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)

	err := op.CreateSiteBindings(tgID, instanceID, []int{1})
	if err != ErrWafNotBound {
		t.Errorf("err = %v, want ErrWafNotBound", err)
	}
}

func TestCreateSiteBindingDuplicate(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)
	_ = op.CreateWafBindings(tgID, []int{instanceID})
	_ = op.CreateSiteBindings(tgID, instanceID, []int{1})

	// Same WAF instance, same site — site_binding unique on (captain_instance_id, site_id)
	// Try creating the same site again — should fail
	err := op.CreateSiteBindings(tgID, instanceID, []int{1})
	if err != ErrSiteAlreadyBound {
		t.Errorf("err = %v, want ErrSiteAlreadyBound", err)
	}
}

func TestDeleteSiteBinding(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)
	_ = op.CreateWafBindings(tgID, []int{instanceID})
	_ = op.CreateSiteBindings(tgID, instanceID, []int{1})

	_, bindings, _ := op.ListSiteBindings(&tgID, nil, 0, 10)
	_ = op.DeleteSiteBindings([]uint{bindings[0].ID})

	total, _, _ := op.ListSiteBindings(&tgID, nil, 0, 10)
	if total != 0 {
		t.Errorf("total = %d, want 0 after delete", total)
	}
}

func TestDeleteWafBindingWithSiteBindings(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)
	_ = op.CreateWafBindings(tgID, []int{instanceID})
	_ = op.CreateSiteBindings(tgID, instanceID, []int{1})

	_, bindings, _ := op.ListWafBindings(&tgID, 0, 10)
	err := op.DeleteWafBindings([]uint{bindings[0].ID})
	if err != ErrWafHasSiteBindings {
		t.Errorf("err = %v, want ErrWafHasSiteBindings", err)
	}
}

func TestDeleteWafBindingAfterSiteUnbind(t *testing.T) {
	setupBindingTestDB(t)
	op := NewBindingOperator()
	tgID, instanceID := createTestGroupAndWaf(t)
	_ = op.CreateWafBindings(tgID, []int{instanceID})
	_ = op.CreateSiteBindings(tgID, instanceID, []int{1})

	_, siteBindings, _ := op.ListSiteBindings(&tgID, nil, 0, 10)
	_ = op.DeleteSiteBindings([]uint{siteBindings[0].ID})

	_, wafBindings, _ := op.ListWafBindings(&tgID, 0, 10)
	err := op.DeleteWafBindings([]uint{wafBindings[0].ID})
	if err != nil {
		t.Errorf("err = %v, want nil after site unbind", err)
	}
}
