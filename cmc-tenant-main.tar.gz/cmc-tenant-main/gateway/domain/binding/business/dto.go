// Package business provides binding CRUD operations and DTOs.
package business

// WafBindingWithInfo extends WafBinding with instance details.
type WafBindingWithInfo struct {
	ID                uint   `json:"id"`
	TenantGroupID     uint   `json:"tenant_group_id"`
	TenantGroupName   string `json:"tenant_group_name"`
	CaptainInstanceID int    `json:"captain_instance_id"`
	InstanceName      string `json:"instance_name"`
	InstanceHost      string `json:"instance_host"`
	InstanceStatus    string `json:"instance_status"`
	Status            string `json:"status"` // "active", "invalid" (not found in Captain), or "unknown" (Captain query failed)
	IsEnabled         *bool  `json:"is_enabled,omitempty"`
	OperationMode     string `json:"operation_mode"`
	Version           string `json:"version"`
	BoundTenantGroups string `json:"bound_tenant_groups,omitempty"`
	CreatedAt         string `json:"created_at"`
}

// SiteBindingWithInfo extends SiteBinding with instance and site details.
type SiteBindingWithInfo struct {
	ID                uint   `json:"id"`
	TenantGroupID     uint   `json:"tenant_group_id"`
	TenantGroupName   string `json:"tenant_group_name"`
	CaptainInstanceID int    `json:"captain_instance_id"`
	InstanceName      string `json:"instance_name"`
	SiteID            int    `json:"site_id"`
	SiteName          string `json:"site_name"`
	Status            string `json:"status"` // "active", "invalid" (site deleted from Captain), or "unknown" (Captain query failed)
	CreatedAt         string `json:"created_at"`
}
