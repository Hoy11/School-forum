// Package model defines the SOC configuration data model.
package model

import "time"

// SocConfig represents a SOC reporting target configuration.
type SocConfig struct {
	ID            uint      `gorm:"primaryKey" json:"id"`
	Name          string    `gorm:"uniqueIndex;size:128;not null" json:"name"`
	Endpoint      string    `gorm:"size:512;not null" json:"endpoint"`
	APIKey        string    `gorm:"size:256" json:"api_key"`
	Brokers       string    `gorm:"size:512" json:"brokers"`
	Topic         string    `gorm:"size:256" json:"topic"`
	Username      string    `gorm:"size:128" json:"username"`
	Password      string    `gorm:"size:256" json:"password"`
	SASLMechanism string    `gorm:"size:32" json:"sasl_mechanism"`
	IsEnabled     bool      `gorm:"not null;default:true" json:"is_enabled"`
	CreatedAt     time.Time `gorm:"not null" json:"created_at"`
	UpdatedAt     time.Time `gorm:"not null" json:"updated_at"`
}

// TableName returns the database table name for SocConfig.
func (SocConfig) TableName() string { return "soc_configs" }
