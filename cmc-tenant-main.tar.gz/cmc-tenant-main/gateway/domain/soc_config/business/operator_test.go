package business

import (
	"testing"

	socmodel "github.com/chaitin/cmc-tenant/domain/soc_config/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupSocTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&socmodel.SocConfig{})
	database.DB = db
}

func TestSocConfigCRUD(t *testing.T) {
	setupSocTestDB(t)
	op := NewSocConfigOperator()

	cfg := &socmodel.SocConfig{
		Name: "SOC-1", Endpoint: "127.0.0.1:9092", APIKey: "detect-log", Brokers: "127.0.0.1:9092", Topic: "detect-log", IsEnabled: true,
	}
	if err := op.Create(cfg); err != nil {
		t.Fatalf("create: %v", err)
	}
	if cfg.ID == 0 {
		t.Fatal("expected ID after create")
	}

	list, err := op.List()
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if len(list) != 1 || list[0].Name != "SOC-1" {
		t.Errorf("list = %v, want 1 SOC-1", list)
	}

	cfg.Name = "SOC-Updated"
	if err := op.Update(cfg); err != nil {
		t.Fatalf("update: %v", err)
	}

	enabled, _ := op.GetEnabled()
	if len(enabled) != 1 {
		t.Errorf("enabled = %d, want 1", len(enabled))
	}

	if err := op.Delete(cfg.ID); err != nil {
		t.Fatalf("delete: %v", err)
	}

	list, _ = op.List()
	if len(list) != 0 {
		t.Errorf("list after delete = %d, want 0", len(list))
	}
}

func TestSocConfigDisabledNotInEnabled(t *testing.T) {
	setupSocTestDB(t)
	op := NewSocConfigOperator()

	_ = op.Create(&socmodel.SocConfig{Name: "ON", Endpoint: "127.0.0.1:9092", APIKey: "detect-log", Brokers: "127.0.0.1:9092", Topic: "detect-log", IsEnabled: true})

	enabled, _ := op.GetEnabled()
	if len(enabled) != 1 || enabled[0].Name != "ON" {
		t.Errorf("enabled = %v, want only ON", enabled)
	}
}
