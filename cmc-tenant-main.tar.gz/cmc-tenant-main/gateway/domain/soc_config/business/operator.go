// Package business provides SOC configuration CRUD and reporting operations.
package business

import (
	"fmt"
	"strings"
	"time"

	"github.com/IBM/sarama"
	socmodel "github.com/chaitin/cmc-tenant/domain/soc_config/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/gorm"
)

// SocConfigOperator handles SOC configuration CRUD and reporting.
type SocConfigOperator struct{}

// NewSocConfigOperator creates a new SocConfigOperator.
func NewSocConfigOperator() *SocConfigOperator { return &SocConfigOperator{} }

// List returns all SOC configurations ordered by ID.
func (o *SocConfigOperator) List() ([]socmodel.SocConfig, error) {
	var list []socmodel.SocConfig
	err := database.DB.Order("id ASC").Find(&list).Error
	return list, err
}

// Create persists a new SOC configuration.
func (o *SocConfigOperator) Create(cfg *socmodel.SocConfig) error {
	return database.DB.Create(cfg).Error
}

// Update saves an existing SOC configuration.
func (o *SocConfigOperator) Update(cfg *socmodel.SocConfig) error {
	return database.DB.Save(cfg).Error
}

// Delete removes a SOC configuration by ID.
func (o *SocConfigOperator) Delete(id uint) error {
	return database.DB.Delete(&socmodel.SocConfig{}, id).Error
}

// Test verifies connectivity to a SOC endpoint by ID.
func (o *SocConfigOperator) Test(id uint) error {
	var cfg socmodel.SocConfig
	if err := database.DB.First(&cfg, id).Error; err != nil {
		return fmt.Errorf("SOC 配置不存在")
	}
	return testKafkaConfig(cfg)
}

// GetEnabled returns all enabled SOC configurations.
func (o *SocConfigOperator) GetEnabled() ([]socmodel.SocConfig, error) {
	var list []socmodel.SocConfig
	err := database.DB.Where("is_enabled = ?", true).Find(&list).Error
	return list, err
}

func testKafkaConfig(cfg socmodel.SocConfig) error {
	brokers := kafkaBrokers(cfg)
	if len(brokers) == 0 {
		return fmt.Errorf("kafka brokers 不能为空")
	}
	if kafkaTopic(cfg) == "" {
		return fmt.Errorf("kafka topic 不能为空")
	}

	client, err := sarama.NewClient(brokers, kafkaClientConfig(cfg))
	if err != nil {
		return fmt.Errorf("连接 Kafka 失败: %w", err)
	}
	defer func() { _ = client.Close() }()
	return nil
}

// ReportLogs sends log data to a SOC Kafka topic.
func (o *SocConfigOperator) ReportLogs(cfg socmodel.SocConfig, payload []byte) error {
	brokers := kafkaBrokers(cfg)
	if len(brokers) == 0 {
		return fmt.Errorf("kafka brokers 不能为空")
	}
	topic := kafkaTopic(cfg)
	if topic == "" {
		return fmt.Errorf("kafka topic 不能为空")
	}

	producer, err := sarama.NewSyncProducer(brokers, kafkaClientConfig(cfg))
	if err != nil {
		return fmt.Errorf("创建 Kafka Producer 失败: %w", err)
	}
	defer func() { _ = producer.Close() }()

	_, _, err = producer.SendMessage(&sarama.ProducerMessage{
		Topic:     topic,
		Key:       sarama.StringEncoder("cmc-tenant-soc-report"),
		Value:     sarama.ByteEncoder(payload),
		Timestamp: time.Now(),
	})
	if err != nil {
		return fmt.Errorf("发送 Kafka 消息失败: %w", err)
	}
	return nil
}

func kafkaBrokers(cfg socmodel.SocConfig) []string {
	raw := cfg.Brokers
	if raw == "" {
		raw = cfg.Endpoint
	}
	parts := strings.Split(raw, ",")
	brokers := make([]string, 0, len(parts))
	for _, part := range parts {
		broker := strings.TrimSpace(part)
		if broker != "" {
			brokers = append(brokers, broker)
		}
	}
	return brokers
}

func kafkaTopic(cfg socmodel.SocConfig) string {
	if cfg.Topic != "" {
		return strings.TrimSpace(cfg.Topic)
	}
	return strings.TrimSpace(cfg.APIKey)
}

func kafkaClientConfig(cfg socmodel.SocConfig) *sarama.Config {
	conf := sarama.NewConfig()
	conf.ClientID = "cmc-tenant"
	conf.Net.DialTimeout = 10 * time.Second
	conf.Net.ReadTimeout = 10 * time.Second
	conf.Net.WriteTimeout = 10 * time.Second
	conf.Producer.RequiredAcks = sarama.WaitForAll
	conf.Producer.Return.Successes = true
	conf.Producer.Retry.Max = 3

	if cfg.Username != "" || cfg.Password != "" {
		conf.Net.SASL.Enable = true
		conf.Net.SASL.User = cfg.Username
		conf.Net.SASL.Password = cfg.Password
		conf.Net.SASL.Mechanism = sarama.SASLTypePlaintext
	}
	return conf
}

// GetDB returns the global database instance.
func GetDB() *gorm.DB { return database.DB }
