// Package business implements tenant group domain logic.
package business

// TenantGroupWithStats is a tenant group view with aggregated counts.
type TenantGroupWithStats struct {
	ID            uint    `json:"id"`
	Name          string  `json:"name"`
	Comment       string  `json:"comment"`
	IsEnabled     bool    `json:"is_enabled"`
	AdminUserID   *uint   `json:"admin_user_id"`
	AdminUsername *string `json:"admin_username"`
	UserCount     int64   `json:"user_count"`
	WafCount      int64   `json:"waf_count"`
	SiteCount     int64   `json:"site_count"`
	CreatedAt     string  `json:"created_at"`
	UpdatedAt     string  `json:"updated_at"`
}
