package business

import (
	"testing"

	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupGroupTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&tgmodel.TenantGroup{}, &usermodel.User{})
	database.DB = db
}

func TestCreateTenantGroup(t *testing.T) {
	setupGroupTestDB(t)
	op := NewTenantGroupOperator()

	group, err := op.Create("测试组", "备注", "admin_a", "pass123")
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if group.ID == 0 {
		t.Error("group ID should be set")
	}
	if group.AdminUserID == nil {
		t.Error("admin_user_id should be set")
	}

	var admin usermodel.User
	database.DB.Where("username = ?", "admin_a").First(&admin)
	if admin.Role != "tenant_admin" {
		t.Errorf("admin role = %s, want tenant_admin", admin.Role)
	}
	if admin.TenantGroupID == nil || *admin.TenantGroupID != group.ID {
		t.Error("admin should belong to the group")
	}
}

func TestCreateDuplicateGroupName(t *testing.T) {
	setupGroupTestDB(t)
	op := NewTenantGroupOperator()

	_, err := op.Create("组A", "", "admin1", "pass")
	if err != nil {
		t.Fatalf("first create: %v", err)
	}
	_, err = op.Create("组A", "", "admin2", "pass")
	if err != ErrGroupExists {
		t.Errorf("err = %v, want ErrGroupExists", err)
	}
}

func TestListTenantGroups(t *testing.T) {
	setupGroupTestDB(t)
	op := NewTenantGroupOperator()

	_, _ = op.Create("组A", "", "a_admin", "pass")
	_, _ = op.Create("组B", "", "b_admin", "pass")

	total, groups, err := op.List(0, 10)
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if total != 2 {
		t.Errorf("total = %d, want 2", total)
	}
	if len(groups) != 2 {
		t.Errorf("len = %d, want 2", len(groups))
	}
}

func TestUpdateTenantGroup(t *testing.T) {
	setupGroupTestDB(t)
	op := NewTenantGroupOperator()

	group, _ := op.Create("旧名", "旧备注", "admin_u", "pass")

	err := op.Update(group.ID, "新名", "新备注", nil)
	if err != nil {
		t.Fatalf("update: %v", err)
	}

	found, _ := op.GetByID(group.ID)
	if found.Name != "新名" {
		t.Errorf("name = %s, want 新名", found.Name)
	}
}

func TestDeleteTenantGroup(t *testing.T) {
	setupGroupTestDB(t)
	op := NewTenantGroupOperator()

	group, _ := op.Create("待删组", "", "del_admin", "pass")

	err := op.Delete([]uint{group.ID})
	if err != nil {
		t.Fatalf("delete: %v", err)
	}

	_, err = op.GetByID(group.ID)
	if err != ErrGroupNotFound {
		t.Errorf("err = %v, want ErrGroupNotFound", err)
	}

	var admin usermodel.User
	database.DB.Unscoped().Where("username = ?", "del_admin").First(&admin)
	if !admin.IsDeleted {
		t.Error("admin user should be soft-deleted with the group")
	}
}

func TestDeleteGroupWithTenantUsers(t *testing.T) {
	setupGroupTestDB(t)
	op := NewTenantGroupOperator()

	group, _ := op.Create("有用户组", "", "g_admin", "pass")

	var admin usermodel.User
	database.DB.Where("username = ?", "g_admin").First(&admin)
	database.DB.Create(&usermodel.User{
		Username:      "tenant1",
		Password:      "hashed",
		Role:          "tenant",
		TenantGroupID: &group.ID,
		IsEnabled:     true,
	})

	err := op.Delete([]uint{group.ID})
	if err != ErrGroupHasUsers {
		t.Errorf("err = %v, want ErrGroupHasUsers", err)
	}
}
