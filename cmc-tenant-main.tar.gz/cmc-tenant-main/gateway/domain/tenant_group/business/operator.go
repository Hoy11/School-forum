package business

import (
	"errors"

	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
)

// ErrGroupExists indicates a tenant group with the same name already exists.
var (
	ErrGroupExists    = errors.New("租户组名称已存在")
	ErrGroupNotFound  = errors.New("租户组不存在")
	ErrGroupHasUsers  = errors.New("租户组内仍有用户，无法删除")
	ErrGroupHasBinds  = errors.New("租户组仍有绑定，无法删除")
)

// TenantGroupOperator handles tenant group CRUD operations.
type TenantGroupOperator struct{}

// NewTenantGroupOperator creates a new TenantGroupOperator.
func NewTenantGroupOperator() *TenantGroupOperator { return &TenantGroupOperator{} }

// Create adds a new tenant group with its admin user.
func (op *TenantGroupOperator) Create(name, comment, adminUsername, adminPassword string) (*tgmodel.TenantGroup, error) {
	var count int64
	database.DB.Model(&tgmodel.TenantGroup{}).Where("name = ? AND is_deleted = false", name).Count(&count)
	if count > 0 {
		return nil, ErrGroupExists
	}

	var userCount int64
	database.DB.Model(&usermodel.User{}).Where("username = ? AND is_deleted = false", adminUsername).Count(&userCount)
	if userCount > 0 {
		return nil, errors.New("管理员用户名已存在")
	}

	hashed, err := bcrypt.GenerateFromPassword([]byte(adminPassword), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	tx := database.DB.Begin()

	group := tgmodel.TenantGroup{
		Name:      name,
		Comment:   comment,
		IsEnabled: true,
	}
	if err := tx.Create(&group).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	admin := usermodel.User{
		Username:      adminUsername,
		Password:      string(hashed),
		Role:          "tenant_admin",
		TenantGroupID: &group.ID,
		IsEnabled:     true,
		PasswordSet:   false,
		Remark:        "租户管理员",
	}
	if err := tx.Create(&admin).Error; err != nil {
		tx.Rollback()
		return nil, err
	}

	group.AdminUserID = &admin.ID
	tx.Model(&group).Update("admin_user_id", admin.ID)

	tx.Commit()
	return &group, nil
}

// List returns a paginated list of tenant groups with user/WAF/site counts.
func (op *TenantGroupOperator) List(offset, count int) (int64, []TenantGroupWithStats, error) {
	q := database.DB.Model(&tgmodel.TenantGroup{}).Where("tenant_groups.is_deleted = false")
	var total int64
	q.Count(&total)

	var results []TenantGroupWithStats
	err := q.Select(
		"tenant_groups.id, tenant_groups.name, tenant_groups.comment, "+
			"tenant_groups.is_enabled, tenant_groups.admin_user_id, "+
			"users.username as admin_username, "+
			"tenant_groups.created_at, tenant_groups.updated_at",
	).
		Joins("LEFT JOIN users ON users.id = tenant_groups.admin_user_id AND users.is_deleted = false").
		Offset(offset).Limit(count).Order("tenant_groups.id ASC").
		Scan(&results).Error
	if err != nil {
		return total, nil, err
	}

	for i := range results {
		database.DB.Model(&usermodel.User{}).
			Where("tenant_group_id = ? AND is_deleted = false", results[i].ID).
			Count(&results[i].UserCount)
		database.DB.Model(&bindingmodel.WafBinding{}).
			Where("tenant_group_id = ?", results[i].ID).
			Count(&results[i].WafCount)
		database.DB.Model(&bindingmodel.SiteBinding{}).
			Where("tenant_group_id = ?", results[i].ID).
			Count(&results[i].SiteCount)
	}

	return total, results, err
}

// Update modifies a tenant group's name, comment, or enabled status.
func (op *TenantGroupOperator) Update(id uint, name, comment string, isEnabled *bool) error {
	updates := map[string]interface{}{}
	if name != "" {
		updates["name"] = name
	}
	if comment != "" {
		updates["comment"] = comment
	}
	if isEnabled != nil {
		updates["is_enabled"] = *isEnabled
	}
	return database.DB.Model(&tgmodel.TenantGroup{}).
		Where("id = ? AND is_deleted = false", id).Updates(updates).Error
}

// Delete soft-deletes tenant groups and their admin users.
func (op *TenantGroupOperator) Delete(ids []uint) error {
	for _, id := range ids {
		var tenantCount int64
		database.DB.Model(&usermodel.User{}).
			Where("tenant_group_id = ? AND is_deleted = false AND role != ?", id, "tenant_admin").
			Count(&tenantCount)
		if tenantCount > 0 {
			return ErrGroupHasUsers
		}

		var wafCount int64
		database.DB.Model(&bindingmodel.WafBinding{}).Where("tenant_group_id = ?", id).Count(&wafCount)
		var siteCount int64
		database.DB.Model(&bindingmodel.SiteBinding{}).Where("tenant_group_id = ?", id).Count(&siteCount)
		if wafCount > 0 || siteCount > 0 {
			return ErrGroupHasBinds
		}
	}

	tx := database.DB.Begin()
	for _, id := range ids {
		tx.Model(&usermodel.User{}).
			Where("tenant_group_id = ? AND role = ? AND is_deleted = false", id, "tenant_admin").
			Update("is_deleted", true)
		tx.Model(&tgmodel.TenantGroup{}).Where("id = ?", id).Update("is_deleted", true)
	}
	tx.Commit()

	return nil
}

// GetByID retrieves a single tenant group by ID.
func (op *TenantGroupOperator) GetByID(id uint) (*tgmodel.TenantGroup, error) {
	var group tgmodel.TenantGroup
	err := database.DB.Where("id = ? AND is_deleted = false", id).First(&group).Error
	if errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, ErrGroupNotFound
	}
	return &group, err
}
