// Package model defines the tenant group data model.
package model

import "time"

// TenantGroup represents a tenant group in the multi-tenant system.
type TenantGroup struct {
	ID          uint      `gorm:"primaryKey" json:"id"`
	Name        string    `gorm:"uniqueIndex;size:128;not null" json:"name"`
	AdminUserID *uint     `json:"admin_user_id"`
	Comment     string    `json:"comment"`
	IsEnabled   bool      `gorm:"not null;default:true" json:"is_enabled"`
	IsDeleted   bool      `gorm:"not null;default:false" json:"-"`
	CreatedAt   time.Time `gorm:"not null" json:"created_at"`
	UpdatedAt   time.Time `gorm:"not null" json:"updated_at"`
}

// TableName returns the database table name for TenantGroup.
func (TenantGroup) TableName() string { return "tenant_groups" }
