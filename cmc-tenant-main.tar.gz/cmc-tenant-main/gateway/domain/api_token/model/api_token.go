// Package model defines the API token data model.
package model

import "time"

// APIToken represents an API access token.
type APIToken struct {
	ID         uint       `gorm:"primaryKey" json:"id"`
	UserID     uint       `gorm:"index;not null" json:"user_id"`
	Name       string     `gorm:"size:128;not null" json:"name"`
	Prefix     string     `gorm:"index;size:8;not null" json:"prefix"`
	Value      string     `gorm:"size:256;not null" json:"-"`
	Remark     string     `json:"remark"`
	ExpireTime *time.Time `json:"expire_time"`
	IsEnabled  bool       `gorm:"not null;default:true" json:"is_enabled"`
	CreatedAt  time.Time  `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for APIToken.
func (APIToken) TableName() string { return "api_tokens" }
