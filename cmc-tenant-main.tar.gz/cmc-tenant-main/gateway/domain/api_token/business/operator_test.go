package business

import (
	"testing"

	tokenmodel "github.com/chaitin/cmc-tenant/domain/api_token/model"
	userbusiness "github.com/chaitin/cmc-tenant/domain/user/business"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupTokenTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&usermodel.User{}, &tokenmodel.APIToken{})
	database.DB = db
}

func TestCreateAndGetToken(t *testing.T) {
	setupTokenTestDB(t)
	op := NewAPITokenOperator()

	userOp := userbusiness.NewUserOperator()
	user, _ := userOp.Create("tokuser", "pass", "admin", nil, "")

	raw, err := op.Create(user.ID, "my-token", "test", "")
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if len(raw) != 64 {
		t.Errorf("token length = %d, want 64", len(raw))
	}

	total, tokens, err := op.List(user.ID, 0, 10)
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if total != 1 {
		t.Errorf("total = %d, want 1", total)
	}
	if tokens[0].Prefix != raw[:6] {
		t.Errorf("prefix mismatch")
	}
}

func TestTokenLimit(t *testing.T) {
	setupTokenTestDB(t)
	op := NewAPITokenOperator()
	userOp := userbusiness.NewUserOperator()
	user, _ := userOp.Create("limiter", "pass", "admin", nil, "")

	for i := 0; i < 10; i++ {
		_, _ = op.Create(user.ID, "token", "", "")
	}
	_, err := op.Create(user.ID, "overflow", "", "")
	if err != ErrTokenLimit {
		t.Errorf("err = %v, want ErrTokenLimit", err)
	}
}

func TestDeleteToken(t *testing.T) {
	setupTokenTestDB(t)
	op := NewAPITokenOperator()
	userOp := userbusiness.NewUserOperator()
	user, _ := userOp.Create("deluser", "pass", "admin", nil, "")

	_, _ = op.Create(user.ID, "t1", "", "")
	_, tokens, _ := op.List(user.ID, 0, 10)

	_ = op.Delete([]uint{tokens[0].ID}, user.ID)

	total, _, _ := op.List(user.ID, 0, 10)
	if total != 0 {
		t.Errorf("total = %d, want 0", total)
	}
}
