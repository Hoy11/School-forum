// Package business provides API token CRUD operations.
package business

import (
	"crypto/rand"
	"encoding/hex"
	"errors"
	"time"

	tokenmodel "github.com/chaitin/cmc-tenant/domain/api_token/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"golang.org/x/crypto/bcrypt"
)

var (
	// ErrTokenLimit indicates the user has reached the token limit.
	ErrTokenLimit  = errors.New("token 数量已达上限")
	// ErrTokenName indicates the token name is empty.
	ErrTokenName   = errors.New("token 名称不能为空")
)

const maxTokensPerUser = 10

// APITokenOperator handles API token CRUD operations.
type APITokenOperator struct{}

// NewAPITokenOperator creates a new APITokenOperator.
func NewAPITokenOperator() *APITokenOperator { return &APITokenOperator{} }

// Create generates a new API token for the given user.
func (op *APITokenOperator) Create(userID uint, name, remark, expireTimeStr string) (string, error) {
	var count int64
	database.DB.Model(&tokenmodel.APIToken{}).Where("user_id = ?", userID).Count(&count)
	if count >= maxTokensPerUser {
		return "", ErrTokenLimit
	}

	raw := generateToken()
	prefix := raw[:6]
	hashed, _ := bcrypt.GenerateFromPassword([]byte(raw), bcrypt.DefaultCost)

	var expireTime *time.Time
	if expireTimeStr != "" {
		t, err := time.Parse(time.RFC3339, expireTimeStr)
		if err != nil {
			return "", errors.New("expire_time 格式错误，需为 RFC3339")
		}
		expireTime = &t
	}

	token := tokenmodel.APIToken{
		UserID:     userID,
		Name:       name,
		Prefix:     prefix,
		Value:      string(hashed),
		Remark:     remark,
		ExpireTime: expireTime,
		IsEnabled:  true,
	}

	if err := database.DB.Create(&token).Error; err != nil {
		return "", err
	}
	return raw, nil
}

// List returns paginated API tokens for the given user.
func (op *APITokenOperator) List(userID uint, offset, count int) (int64, []tokenmodel.APIToken, error) {
	q := database.DB.Model(&tokenmodel.APIToken{}).Where("user_id = ?", userID)
	var total int64
	q.Count(&total)

	var tokens []tokenmodel.APIToken
	err := q.Offset(offset).Limit(count).Order("id DESC").Find(&tokens).Error
	return total, tokens, err
}

// Delete removes API tokens by IDs, scoped to the given user.
func (op *APITokenOperator) Delete(ids []uint, userID uint) error {
	return database.DB.Where("id IN ? AND user_id = ?", ids, userID).
		Delete(&tokenmodel.APIToken{}).Error
}

func generateToken() string {
	b := make([]byte, 32)
	rand.Read(b)
	return hex.EncodeToString(b)
}
