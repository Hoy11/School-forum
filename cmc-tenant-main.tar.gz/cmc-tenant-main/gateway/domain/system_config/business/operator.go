// Package business implements system configuration read/write logic.
package business

import (
	"encoding/json"

	scmodel "github.com/chaitin/cmc-tenant/domain/system_config/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

// SystemConfigOperator handles reading and writing system configuration values.
type SystemConfigOperator struct{}

// NewSystemConfigOperator creates a new SystemConfigOperator.
func NewSystemConfigOperator() *SystemConfigOperator { return &SystemConfigOperator{} }

// Get retrieves a system config value by key into the provided output.
func (o *SystemConfigOperator) Get(key string, out interface{}) error {
	var cfg scmodel.SystemConfig
	err := database.DB.Where("key = ?", key).First(&cfg).Error
	if err != nil {
		return err
	}
	return json.Unmarshal([]byte(cfg.Value), out)
}

// Set writes a system config value by key, creating it if absent.
func (o *SystemConfigOperator) Set(key string, value interface{}) error {
	data, err := json.Marshal(value)
	if err != nil {
		return err
	}

	var cfg scmodel.SystemConfig
	result := database.DB.Where("key = ?", key).First(&cfg)
	if result.Error != nil {
		cfg.Key = key
		cfg.Value = string(data)
		return database.DB.Create(&cfg).Error
	}
	return database.DB.Model(&cfg).Update("value", string(data)).Error
}

// --- Password Config ---

// PasswordConfig defines the password complexity and rotation policy.
type PasswordConfig struct {
	IsForced  bool `json:"is_forced"`
	UpdateDays int `json:"update_days"`
	MinLength  int `json:"min_length"`
	HasUpper   bool `json:"has_upper"`
	HasNum     bool `json:"has_num"`
	HasLower   bool `json:"has_lower"`
	HasSymbol  bool `json:"has_symbol"`
}

// DefaultPasswordConfig returns the default password policy.
func DefaultPasswordConfig() PasswordConfig {
	return PasswordConfig{
		IsForced:   true,
		UpdateDays: 90,
		MinLength:  8,
		HasUpper:   true,
		HasNum:     true,
		HasLower:   true,
		HasSymbol:  false,
	}
}

// GetPasswordConfig retrieves the password policy, falling back to defaults.
func (o *SystemConfigOperator) GetPasswordConfig() (PasswordConfig, error) {
	var cfg PasswordConfig
	err := o.Get("password_config", &cfg)
	if err != nil {
		return DefaultPasswordConfig(), nil
	}
	return cfg, nil
}

// SetPasswordConfig persists the password policy.
func (o *SystemConfigOperator) SetPasswordConfig(cfg PasswordConfig) error {
	return o.Set("password_config", cfg)
}

// --- Login Security ---

// LoginSecurityConfig defines the login retry and lockout policy.
type LoginSecurityConfig struct {
	MaxRetry      int  `json:"max_retry"`
	LockMinutes   int  `json:"lock_minutes"`
	RetryWindowSec int `json:"retry_window"`
	SingleSignOn  bool `json:"single_sign_on"`
}

// DefaultLoginSecurityConfig returns the default login security policy.
func DefaultLoginSecurityConfig() LoginSecurityConfig {
	return LoginSecurityConfig{
		MaxRetry:       5,
		LockMinutes:    30,
		RetryWindowSec: 300,
		SingleSignOn:   false,
	}
}

// GetLoginSecurity retrieves the login security policy, falling back to defaults.
func (o *SystemConfigOperator) GetLoginSecurity() (LoginSecurityConfig, error) {
	var cfg LoginSecurityConfig
	err := o.Get("login_security", &cfg)
	if err != nil {
		return DefaultLoginSecurityConfig(), nil
	}
	return cfg, nil
}

// SetLoginSecurity persists the login security policy.
func (o *SystemConfigOperator) SetLoginSecurity(cfg LoginSecurityConfig) error {
	return o.Set("login_security", cfg)
}

// --- Captain Config ---

// CaptainConfigView is the read-only view of a Captain-2 instance configuration.
type CaptainConfigView struct {
	ID       uint   `json:"id"`
	Host     string `json:"host"`
	APIToken string `json:"api_token"`
}

// GetCaptainConfig retrieves the default Captain-2 instance config with a masked token.
func (o *SystemConfigOperator) GetCaptainConfig() (*CaptainConfigView, error) {
	var cc scmodel.CaptainConfig
	if err := database.DB.Where("is_default = ?", true).First(&cc).Error; err != nil {
		return nil, err
	}
	return &CaptainConfigView{
		ID:       cc.ID,
		Host:     cc.Host,
		APIToken: maskToken(cc.APIToken),
	}, nil
}

// UpdateCaptainConfig upserts the default Captain-2 instance host and API token.
func (o *SystemConfigOperator) UpdateCaptainConfig(host, apiToken string) error {
	var cc scmodel.CaptainConfig
	result := database.DB.Where("is_default = ?", true).First(&cc)
	if result.Error != nil {
		cc = scmodel.CaptainConfig{Host: host, APIToken: apiToken, IsDefault: true}
		return database.DB.Create(&cc).Error
	}
	return database.DB.Model(&cc).Updates(map[string]interface{}{
		"host":      host,
		"api_token": apiToken,
	}).Error
}

func maskToken(token string) string {
	if len(token) <= 6 {
		return "******"
	}
	return token[:3] + "***" + token[len(token)-3:]
}

// --- Highlight Tag Config ---

// GetHighlightTag retrieves the highlight IP tag color-to-label mapping.
func (o *SystemConfigOperator) GetHighlightTag() (map[string]string, error) {
	var cfg scmodel.HighlightTagConfig
	if err := database.DB.First(&cfg).Error; err != nil {
		return map[string]string{"#ff0000": "高危", "#ff8800": "中危", "#00cc00": "正常"}, nil
	}
	var result map[string]string
	if err := json.Unmarshal([]byte(cfg.Value), &result); err != nil {
		return map[string]string{"#ff0000": "高危", "#ff8800": "中危", "#00cc00": "正常"}, nil
	}
	return result, nil
}

// SetHighlightTag persists the highlight IP tag color-to-label mapping.
func (o *SystemConfigOperator) SetHighlightTag(value map[string]string) error {
	data, err := json.Marshal(value)
	if err != nil {
		return err
	}
	var cfg scmodel.HighlightTagConfig
	result := database.DB.First(&cfg)
	if result.Error != nil {
		cfg.Value = string(data)
		return database.DB.Create(&cfg).Error
	}
	return database.DB.Model(&cfg).Update("value", string(data)).Error
}
