package business

import (
	"os"
	"strings"
	"testing"

	scmodel "github.com/chaitin/cmc-tenant/domain/system_config/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupSystemConfigTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&scmodel.SystemConfig{}, &scmodel.CaptainConfig{}, &scmodel.HighlightTagConfig{})
	database.DB = db
}

// TestSystemConfigQueryAvoidsBacktickQuoting 防止 Get/Set 里的 WHERE 子句再写成 MySQL 风格的反引号
// 转义列名（形如 "`key` = ?"）。反引号在 PostgreSQL 下是语法错误，但 sqlite 对反引号是兼容的
// （MySQL 兼容模式），且 sqlite 驱动本身也会给它自动生成的表名/列名加反引号，所以不能靠在 sqlite
// 上跑出来的 SQL 文本去判断"有没有反引号"——必须直接检查源码里我们手写的 Where 条件字符串本身，
// 这是唯一能真正区分"我们手写的字符串里有没有反引号"和"驱动自己加的反引号"的办法。
func TestSystemConfigQueryAvoidsBacktickQuoting(t *testing.T) {
	src, err := os.ReadFile("operator.go")
	if err != nil {
		t.Fatalf("read operator.go: %v", err)
	}
	if strings.Contains(string(src), "`key`") {
		t.Fatalf("operator.go 里的 Where 条件不能用反引号转义列名（MySQL 语法，PostgreSQL 不支持），应该写成 \"key = ?\"")
	}
}

func TestPasswordConfigDefault(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	cfg, err := op.GetPasswordConfig()
	if err != nil {
		t.Fatalf("get default: %v", err)
	}
	if !cfg.IsForced || cfg.MinLength != 8 || cfg.UpdateDays != 90 {
		t.Errorf("default = %+v", cfg)
	}
}

func TestPasswordConfigSetAndGet(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	newCfg := PasswordConfig{IsForced: false, UpdateDays: 30, MinLength: 12, HasUpper: true, HasNum: true, HasLower: true, HasSymbol: true}
	if err := op.SetPasswordConfig(newCfg); err != nil {
		t.Fatalf("set: %v", err)
	}

	got, _ := op.GetPasswordConfig()
	if got.MinLength != 12 || got.UpdateDays != 30 || got.IsForced {
		t.Errorf("got = %+v", got)
	}
}

func TestLoginSecurityDefault(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	cfg, err := op.GetLoginSecurity()
	if err != nil {
		t.Fatalf("get default: %v", err)
	}
	if cfg.MaxRetry != 5 || cfg.LockMinutes != 30 || cfg.RetryWindowSec != 300 {
		t.Errorf("default = %+v", cfg)
	}
}

func TestLoginSecuritySetAndGet(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	newCfg := LoginSecurityConfig{MaxRetry: 10, LockMinutes: 60, RetryWindowSec: 600, SingleSignOn: true}
	if err := op.SetLoginSecurity(newCfg); err != nil {
		t.Fatalf("set: %v", err)
	}

	got, _ := op.GetLoginSecurity()
	if got.MaxRetry != 10 || got.LockMinutes != 60 || !got.SingleSignOn {
		t.Errorf("got = %+v", got)
	}
}

func TestCaptainConfigMasked(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	database.DB.Create(&scmodel.CaptainConfig{Host: "https://captain.test", APIToken: "abc123xyz", IsDefault: true})

	view, err := op.GetCaptainConfig()
	if err != nil {
		t.Fatalf("get: %v", err)
	}
	if view.Host != "https://captain.test" {
		t.Errorf("host = %s", view.Host)
	}
	if view.APIToken == "abc123xyz" {
		t.Error("api_token should be masked")
	}
}

func TestCaptainConfigUpdate(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	database.DB.Create(&scmodel.CaptainConfig{Host: "https://old", APIToken: "oldtoken", IsDefault: true})

	if err := op.UpdateCaptainConfig("https://new", "newtoken"); err != nil {
		t.Fatalf("update: %v", err)
	}

	var cc scmodel.CaptainConfig
	database.DB.Where("is_default = ?", true).First(&cc)
	if cc.Host != "https://new" || cc.APIToken != "newtoken" {
		t.Errorf("host=%s token=%s", cc.Host, cc.APIToken)
	}
}

func TestHighlightTagDefault(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	tags, err := op.GetHighlightTag()
	if err != nil {
		t.Fatalf("get default: %v", err)
	}
	if _, ok := tags["#ff0000"]; !ok {
		t.Errorf("missing default tag: %v", tags)
	}
}

func TestHighlightTagSetAndGet(t *testing.T) {
	setupSystemConfigTestDB(t)
	op := NewSystemConfigOperator()

	newTags := map[string]string{"#aabbcc": "test", "#112233": "other"}
	if err := op.SetHighlightTag(newTags); err != nil {
		t.Fatalf("set: %v", err)
	}

	got, _ := op.GetHighlightTag()
	if got["#aabbcc"] != "test" {
		t.Errorf("got = %v", got)
	}
}
