// Package model defines system configuration data models.
package model

import "time"

// CaptainConfig represents a Captain-2 instance connection stored in the database.
type CaptainConfig struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	Host      string    `gorm:"size:256;not null" json:"host"`
	APIToken  string    `gorm:"size:256;not null" json:"api_token"`
	IsDefault bool      `gorm:"not null;default:true" json:"is_default"`
	CreatedAt time.Time `gorm:"not null" json:"created_at"`
}

// TableName returns the database table name for CaptainConfig.
func (CaptainConfig) TableName() string { return "captain_configs" }

// HighlightTagConfig stores highlight tag color-to-label mappings.
type HighlightTagConfig struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	Value     string    `gorm:"type:jsonb;not null" json:"value"`
	UpdatedAt time.Time `gorm:"not null" json:"updated_at"`
}

// TableName returns the database table name for HighlightTagConfig.
func (HighlightTagConfig) TableName() string { return "highlight_tag_configs" }

// SystemConfig stores arbitrary key-value system settings.
type SystemConfig struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	Key       string    `gorm:"uniqueIndex;size:128;not null" json:"key"`
	Value     string    `gorm:"type:jsonb;not null" json:"value"`
	UpdatedAt time.Time `gorm:"not null" json:"updated_at"`
}

// TableName returns the database table name for SystemConfig.
func (SystemConfig) TableName() string { return "system_configs" }
