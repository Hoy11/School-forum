package business

import (
	"testing"

	hipmodel "github.com/chaitin/cmc-tenant/domain/highlight_ip/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupHIPTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&hipmodel.HighlightIP{})
	database.DB = db
}

func TestCreateHighlightIP(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	record, err := op.Create("192.168.1.0/24", "内网网段", "#FF0000")
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if record.ID == 0 {
		t.Error("ID should be set")
	}
}

func TestCreateHighlightIPSingle(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	_, err := op.Create("10.0.0.1", "单IP", "#00CC00")
	if err != nil {
		t.Fatalf("create single IP: %v", err)
	}
}

func TestCreateHighlightIPInvalid(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	_, err := op.Create("not-an-ip", "invalid", "")
	if err != ErrInvalidCIDR {
		t.Errorf("err = %v, want ErrInvalidCIDR", err)
	}
}

func TestCreateDuplicateHighlightIP(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	_, _ = op.Create("192.168.0.0/16", "", "")
	_, err := op.Create("192.168.0.0/16", "", "")
	if err != ErrHighlightIPExists {
		t.Errorf("err = %v, want ErrHighlightIPExists", err)
	}
}

func TestCreateOverlappingCIDR(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	_, _ = op.Create("192.168.0.0/16", "", "")
	_, err := op.Create("192.168.1.0/24", "", "")
	if err == nil {
		t.Error("expected overlap error, got nil")
	}
}

func TestListHighlightIPs(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	_, _ = op.Create("10.0.0.0/8", "", "")
	_, _ = op.Create("172.16.0.0/12", "", "")

	total, _, err := op.List(0, 10)
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if total != 2 {
		t.Errorf("total = %d, want 2", total)
	}
}

func TestUpdateHighlightIP(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	record, _ := op.Create("192.168.0.0/16", "old", "")
	err := op.Update(record.ID, "10.0.0.0/8", "new", "#0000FF")
	if err != nil {
		t.Fatalf("update: %v", err)
	}

	// Verify color was updated
	var updated hipmodel.HighlightIP
	database.DB.First(&updated, record.ID)
	if updated.Color != "#0000FF" {
		t.Errorf("color = %q, want #0000FF", updated.Color)
	}
	if updated.Comment != "new" {
		t.Errorf("comment = %q, want new", updated.Comment)
	}
}

func TestUpdateHighlightIPSameIP(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	record, _ := op.Create("192.168.0.0/16", "old", "#FF0000")
	// Update color without changing IP — should succeed without overlap check
	err := op.Update(record.ID, "192.168.0.0/16", "updated", "#00FF00")
	if err != nil {
		t.Fatalf("update same IP: %v", err)
	}

	var updated hipmodel.HighlightIP
	database.DB.First(&updated, record.ID)
	if updated.Color != "#00FF00" {
		t.Errorf("color = %q, want #00FF00", updated.Color)
	}
}

func TestUpdateHighlightIPWithOverlap(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	_, _ = op.Create("10.0.0.0/8", "", "")
	record, _ := op.Create("192.168.0.0/16", "", "")
	// Change IP to one that overlaps with existing record
	err := op.Update(record.ID, "10.1.0.0/16", "", "")
	if err == nil {
		t.Error("expected overlap error, got nil")
	}
}

func TestUpdateHighlightIPClearComment(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	record, _ := op.Create("192.168.0.0/16", "has comment", "#FF0000")
	err := op.Update(record.ID, "192.168.0.0/16", "", "#FF0000")
	if err != nil {
		t.Fatalf("update clear comment: %v", err)
	}

	var updated hipmodel.HighlightIP
	database.DB.First(&updated, record.ID)
	if updated.Comment != "" {
		t.Errorf("comment = %q, want empty", updated.Comment)
	}
}

func TestDeleteHighlightIP(t *testing.T) {
	setupHIPTestDB(t)
	op := NewHighlightIPOperator()

	record, _ := op.Create("192.168.0.0/16", "", "")
	_ = op.Delete([]uint{record.ID})

	total, _, _ := op.List(0, 10)
	if total != 0 {
		t.Errorf("total = %d, want 0 after delete", total)
	}
}
