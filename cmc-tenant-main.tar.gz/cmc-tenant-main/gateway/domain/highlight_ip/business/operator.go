// Package business provides highlight IP CRUD operations.
package business

import (
	"errors"
	"fmt"
	"net"

	hipmodel "github.com/chaitin/cmc-tenant/domain/highlight_ip/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

var (
	// ErrHighlightIPExists indicates the IP/CIDR is already registered.
	ErrHighlightIPExists   = errors.New("该 IP/CIDR 已存在")
	// ErrHighlightIPNotFound indicates the highlight IP entry was not found.
	ErrHighlightIPNotFound = errors.New("高亮 IP 不存在")
	// ErrInvalidCIDR indicates the provided CIDR format is invalid.
	ErrInvalidCIDR         = errors.New("无效的 CIDR 格式")
	// ErrCIDROverlap indicates the CIDR overlaps with an existing entry.
	ErrCIDROverlap         = errors.New("该 IP 段与已有高亮 IP 存在重叠")
)

// HighlightIPOperator handles highlight IP CRUD operations.
type HighlightIPOperator struct{}

// NewHighlightIPOperator creates a new HighlightIPOperator.
func NewHighlightIPOperator() *HighlightIPOperator { return &HighlightIPOperator{} }

// Create adds a new highlight IP entry after validating the CIDR.
func (op *HighlightIPOperator) Create(ip, comment, color string) (*hipmodel.HighlightIP, error) {
	if err := validateCIDR(ip); err != nil {
		return nil, err
	}

	var count int64
	database.DB.Model(&hipmodel.HighlightIP{}).Where("ip = ?", ip).Count(&count)
	if count > 0 {
		return nil, ErrHighlightIPExists
	}

	if err := checkCIDROverlap(ip, 0); err != nil {
		return nil, err
	}

	if color == "" {
		color = "#FF0000"
	}
	record := hipmodel.HighlightIP{IP: ip, Color: color, Comment: comment}
	if err := database.DB.Create(&record).Error; err != nil {
		return nil, err
	}
	captain.InvalidateCache()
	return &record, nil
}

// List returns paginated highlight IP entries.
func (op *HighlightIPOperator) List(offset, count int) (int64, []hipmodel.HighlightIP, error) {
	q := database.DB.Model(&hipmodel.HighlightIP{})
	var total int64
	q.Count(&total)

	var records []hipmodel.HighlightIP
	err := q.Offset(offset).Limit(count).Order("id ASC").Find(&records).Error
	return total, records, err
}

// Update modifies a highlight IP entry by ID.
func (op *HighlightIPOperator) Update(id uint, ip, comment, color string) error {
	var current hipmodel.HighlightIP
	if err := database.DB.First(&current, id).Error; err != nil {
		return ErrHighlightIPNotFound
	}

	updates := map[string]interface{}{
		"comment": comment,
		"color":   color,
	}
	if ip != "" && ip != current.IP {
		if err := validateCIDR(ip); err != nil {
			return err
		}
		if err := checkCIDROverlap(ip, id); err != nil {
			return err
		}
		updates["ip"] = ip
	}

	result := database.DB.Model(&hipmodel.HighlightIP{}).Where("id = ?", id).Updates(updates)
	if result.Error != nil {
		return result.Error
	}
	if result.RowsAffected == 0 {
		return ErrHighlightIPNotFound
	}
	captain.InvalidateCache()
	return nil
}

// Delete removes highlight IP entries by IDs; nil ids deletes all.
func (op *HighlightIPOperator) Delete(ids []uint) error {
	var err error
	if ids == nil {
		err = database.DB.Where("1 = 1").Delete(&hipmodel.HighlightIP{}).Error
	} else {
		err = database.DB.Where("id IN ?", ids).Delete(&hipmodel.HighlightIP{}).Error
	}
	if err == nil {
		captain.InvalidateCache()
	}
	return err
}

func validateCIDR(s string) error {
	if _, _, err := net.ParseCIDR(s); err != nil {
		if net.ParseIP(s) == nil {
			return ErrInvalidCIDR
		}
	}
	return nil
}

func checkCIDROverlap(ip string, excludeID uint) error {
	_, newNet, err := net.ParseCIDR(normalizeToCIDR(ip))
	if err != nil {
		return nil
	}

	var records []hipmodel.HighlightIP
	database.DB.Where("id != ?", excludeID).Find(&records)

	for _, r := range records {
		_, existNet, err := net.ParseCIDR(normalizeToCIDR(r.IP))
		if err != nil {
			continue
		}
		if newNet.Contains(existNet.IP) || existNet.Contains(newNet.IP) {
			return fmt.Errorf("%s: %s", ErrCIDROverlap.Error(), r.IP)
		}
	}
	return nil
}

func normalizeToCIDR(ip string) string {
	parsed := net.ParseIP(ip)
	if parsed != nil {
		if parsed.To4() != nil {
			return ip + "/32"
		}
		return ip + "/128"
	}
	return ip
}
