// Package model defines the data model for highlighted IP/CIDR ranges.
package model

import (
	"net"
	"time"
)

// HighlightIP represents a highlighted IP/CIDR range.
type HighlightIP struct {
	ID        uint      `gorm:"primaryKey" json:"id"`
	IP        string    `gorm:"type:cidr;uniqueIndex;not null" json:"ip"`
	Color     string    `gorm:"type:varchar(30);default:'#FF0000';not null" json:"color"`
	Comment   string    `json:"comment"`
	CreatedAt time.Time `gorm:"not null" json:"created_at"`
	UpdatedAt time.Time `gorm:"not null" json:"updated_at"`
}

// TableName returns the database table name for HighlightIP.
func (HighlightIP) TableName() string { return "highlight_ips" }

// Contains checks whether the given IP falls within this HighlightIP's CIDR range.
func (h *HighlightIP) Contains(ip string) bool {
	parsedIP := net.ParseIP(ip)
	if parsedIP == nil {
		return false
	}
	_, ipNet, err := net.ParseCIDR(h.IP)
	if err != nil {
		return false
	}
	return ipNet.Contains(parsedIP)
}
