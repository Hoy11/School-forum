// Package model defines SOC report status persistence models.
package model

import "time"

// SocReportedLog records logs that have already been reported to SOC.
type SocReportedLog struct {
	ID         uint      `gorm:"primaryKey" json:"id"`
	LogID      string    `gorm:"size:128;uniqueIndex;not null" json:"log_id"`
	LogType    string    `gorm:"size:32;not null" json:"log_type"`
	SrcIP      string    `gorm:"size:64" json:"src_ip"`
	ReportedBy string    `gorm:"size:128" json:"reported_by"`
	ReportedAt time.Time `gorm:"not null" json:"reported_at"`
	CreatedAt  time.Time `gorm:"not null" json:"created_at"`
	UpdatedAt  time.Time `gorm:"not null" json:"updated_at"`
}

// TableName returns the database table name for SocReportedLog.
func (SocReportedLog) TableName() string { return "soc_reported_logs" }
