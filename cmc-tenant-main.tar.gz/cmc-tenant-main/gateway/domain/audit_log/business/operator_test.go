package business

import (
	"testing"

	auditmodel "github.com/chaitin/cmc-tenant/domain/audit_log/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupAuditTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&auditmodel.AuditLog{})
	database.DB = db
}

func createAuditLogs(t *testing.T, count int) {
	for i := 0; i < count; i++ {
		log := auditmodel.AuditLog{
			UserID:   1,
			Username: "admin",
			Action:   "CREATE",
			Resource: "user",
			Summary:  "创建用户 admin",
			Result:   "success",
			Detail:   "test",
		}
		if err := database.DB.Create(&log).Error; err != nil {
			t.Fatalf("create audit log: %v", err)
		}
	}
}

func TestAuditLogListPagination(t *testing.T) {
	setupAuditTestDB(t)
	op := NewAuditLogOperator()
	createAuditLogs(t, 25)

	result, err := op.List(AuditLogListRequest{Offset: 0, Limit: 10})
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if result.Total != 25 {
		t.Errorf("total = %d, want 25", result.Total)
	}
	if len(result.Items) != 10 {
		t.Errorf("items = %d, want 10", len(result.Items))
	}
}

func TestAuditLogListFilterByAction(t *testing.T) {
	setupAuditTestDB(t)

	database.DB.Create(&auditmodel.AuditLog{UserID: 1, Username: "admin", Action: "CREATE", Resource: "user", Result: "success"})
	database.DB.Create(&auditmodel.AuditLog{UserID: 1, Username: "admin", Action: "DELETE", Resource: "user", Result: "success"})

	op := NewAuditLogOperator()
	result, err := op.List(AuditLogListRequest{
		Limit: 20,
		Filter: AuditLogFilter{
			Action: []FilterCondition{{Oper: "=", Target: "DELETE"}},
		},
	})
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if result.Total != 1 {
		t.Errorf("total = %d, want 1", result.Total)
	}
	if result.Items[0].Action != "DELETE" {
		t.Errorf("action = %s, want DELETE", result.Items[0].Action)
	}
}

func TestAuditLogListFilterByResource(t *testing.T) {
	setupAuditTestDB(t)

	database.DB.Create(&auditmodel.AuditLog{UserID: 1, Username: "admin", Action: "CREATE", Resource: "user", Result: "success"})
	database.DB.Create(&auditmodel.AuditLog{UserID: 1, Username: "admin", Action: "CREATE", Resource: "tenant_group", Result: "success"})

	op := NewAuditLogOperator()
	result, err := op.List(AuditLogListRequest{
		Limit: 20,
		Filter: AuditLogFilter{
			Resource: []FilterCondition{{Oper: "in", Target: []interface{}{"user"}}},
		},
	})
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if result.Total != 1 {
		t.Errorf("total = %d, want 1", result.Total)
	}
}

func TestAuditLogListDefaultLimit(t *testing.T) {
	setupAuditTestDB(t)
	op := NewAuditLogOperator()

	result, err := op.List(AuditLogListRequest{Offset: 0, Limit: 0})
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if result.Total != 0 {
		t.Errorf("total = %d, want 0", result.Total)
	}
}

func TestAuditLogListFilterByConditions(t *testing.T) {
	setupAuditTestDB(t)

	database.DB.Create(&auditmodel.AuditLog{
		UserID:   1,
		Username: "alice",
		Action:   "CREATE",
		Resource: "user",
		Summary:  "创建用户 alice",
		Result:   "success",
	})
	database.DB.Create(&auditmodel.AuditLog{
		UserID:       2,
		Username:     "bob",
		Action:       "DELETE",
		Resource:     "site",
		Summary:      "删除站点 example.com",
		Result:       "failed",
		ErrorMessage: "权限不足",
	})

	op := NewAuditLogOperator()
	result, err := op.List(AuditLogListRequest{
		Count: 20,
		Conditions: []Condition{
			{Target: "username", Items: []ConditionItem{{Oper: "like", Value: "bob"}}},
			{Target: "result", Items: []ConditionItem{{Oper: "=", Value: "failed"}}},
		},
	})
	if err != nil {
		t.Fatalf("list: %v", err)
	}
	if result.Total != 1 {
		t.Errorf("total = %d, want 1", result.Total)
	}
	if len(result.Items) != 1 {
		t.Fatalf("items = %d, want 1", len(result.Items))
	}
	if result.Items[0].Username != "bob" {
		t.Errorf("username = %s, want bob", result.Items[0].Username)
	}
	if result.Items[0].Result != "failed" {
		t.Errorf("result = %s, want failed", result.Items[0].Result)
	}
}
