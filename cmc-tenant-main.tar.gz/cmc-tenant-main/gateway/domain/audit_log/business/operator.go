// Package business provides audit log query operations.
package business

import (
	"fmt"
	"strconv"
	"strings"

	auditmodel "github.com/chaitin/cmc-tenant/domain/audit_log/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/gorm"
)

// AuditLogOperator handles audit log queries.
type AuditLogOperator struct{}

// NewAuditLogOperator creates a new AuditLogOperator.
func NewAuditLogOperator() *AuditLogOperator { return &AuditLogOperator{} }

// AuditLogFilter defines filter conditions for audit log queries.
type AuditLogFilter struct {
	UserID    []FilterCondition `json:"user_id"`
	Username  []FilterCondition `json:"username"`
	Action    []FilterCondition `json:"action"`
	Resource  []FilterCondition `json:"resource"`
	Result    []FilterCondition `json:"result"`
	CreatedAt []FilterCondition `json:"created_at"`
}

// FilterCondition represents a single filter operation and target value.
type FilterCondition struct {
	Oper   string      `json:"oper"`
	Target interface{} `json:"target"`
}

// ConditionItem describes a single list-condition item.
type ConditionItem struct {
	Oper  string      `json:"oper"`
	Value interface{} `json:"value"`
}

// Condition describes a target field plus its condition items.
type Condition struct {
	Target string          `json:"target"`
	Items  []ConditionItem `json:"items"`
}

// AuditLogListRequest specifies pagination and filter for listing audit logs.
type AuditLogListRequest struct {
	Offset     int            `json:"offset"`
	Count      int            `json:"count"`
	Limit      int            `json:"limit"`
	Filter     AuditLogFilter `json:"filter"`
	Conditions []Condition    `json:"conditions"`
}

// AuditLogListResult contains paginated audit log items.
type AuditLogListResult struct {
	Total int64                 `json:"total"`
	Items []auditmodel.AuditLog `json:"items"`
}

// List returns a paginated list of audit logs matching the request filter.
func (o *AuditLogOperator) List(req AuditLogListRequest) (*AuditLogListResult, error) {
	limit := req.Limit
	if limit <= 0 {
		limit = req.Count
	}
	if limit <= 0 || limit > 100 {
		limit = 20
	}

	q := database.DB.Model(&auditmodel.AuditLog{})
	if len(req.Conditions) > 0 {
		q = applyListConditions(q, req.Conditions)
	} else {
		q = applyAuditFilters(q, req.Filter)
	}

	var total int64
	q.Count(&total)

	var items []auditmodel.AuditLog
	if err := q.Order("id DESC").Offset(req.Offset).Limit(limit).Find(&items).Error; err != nil {
		return nil, err
	}

	return &AuditLogListResult{Total: total, Items: items}, nil
}

func applyAuditFilters(q *gorm.DB, f AuditLogFilter) *gorm.DB {
	if len(f.UserID) > 0 {
		q = applyCondition(q, "user_id", f.UserID)
	}
	if len(f.Username) > 0 {
		q = applyCondition(q, "username", f.Username)
	}
	if len(f.Action) > 0 {
		q = applyCondition(q, "action", f.Action)
	}
	if len(f.Resource) > 0 {
		q = applyCondition(q, "resource", f.Resource)
	}
	if len(f.Result) > 0 {
		q = applyCondition(q, "result", f.Result)
	}
	if len(f.CreatedAt) > 0 {
		q = applyRangeCondition(q, "created_at", f.CreatedAt)
	}
	return q
}

func applyCondition(q *gorm.DB, field string, conds []FilterCondition) *gorm.DB {
	for _, c := range conds {
		switch c.Oper {
		case "=":
			q = q.Where(field+" = ?", c.Target)
		case "like":
			q = q.Where(field+" LIKE ?", "%"+toString(c.Target)+"%")
		case "in":
			targets := interfaceToSlice(c.Target)
			if len(targets) > 0 {
				q = q.Where(field+" IN ?", targets)
			}
		}
	}
	return q
}

func applyRangeCondition(q *gorm.DB, field string, conds []FilterCondition) *gorm.DB {
	for _, c := range conds {
		if c.Oper == "range" {
			start, end, ok := parseRangeValue(c.Target)
			if !ok {
				continue
			}
			q = q.Where(field+" BETWEEN ? AND ?", start, end)
		}
	}
	return q
}

func applyListConditions(q *gorm.DB, conditions []Condition) *gorm.DB {
	for _, cond := range conditions {
		field := auditConditionField(cond.Target)
		if field == "" {
			continue
		}
		for _, item := range cond.Items {
			switch item.Oper {
			case "=", "like", "in":
				q = applyCondition(q, field, []FilterCondition{{Oper: item.Oper, Target: item.Value}})
			case "range":
				q = applyRangeCondition(q, field, []FilterCondition{{Oper: item.Oper, Target: item.Value}})
			}
		}
	}
	return q
}

func auditConditionField(target string) string {
	switch target {
	case "user_id", "username", "action", "resource", "result", "created_at":
		return target
	default:
		return ""
	}
}

func parseRangeValue(v interface{}) (string, string, bool) {
	switch t := v.(type) {
	case string:
		sep := "-"
		if strings.Contains(t, ",") {
			sep = ","
		}
		parts := strings.SplitN(t, sep, 2)
		if len(parts) != 2 || strings.TrimSpace(parts[0]) == "" || strings.TrimSpace(parts[1]) == "" {
			return "", "", false
		}
		return parts[0], parts[1], true
	case []interface{}:
		if len(t) != 2 {
			return "", "", false
		}
		return fmt.Sprint(t[0]), fmt.Sprint(t[1]), true
	default:
		return "", "", false
	}
}

func interfaceToSlice(v interface{}) []string {
	switch t := v.(type) {
	case []interface{}:
		result := make([]string, 0, len(t))
		for _, item := range t {
			result = append(result, toString(item))
		}
		return result
	case []string:
		return t
	default:
		return nil
	}
}

func toString(v interface{}) string {
	switch t := v.(type) {
	case string:
		return t
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	case int:
		return strconv.Itoa(t)
	default:
		return ""
	}
}
