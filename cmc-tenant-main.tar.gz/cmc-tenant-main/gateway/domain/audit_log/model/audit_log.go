// Package model defines the audit log data model.
package model

import "time"

// AuditLog represents an audit log entry.
type AuditLog struct {
	ID           uint      `gorm:"primaryKey" json:"id"`
	UserID       uint      `gorm:"index;not null" json:"user_id"`
	Username     string    `gorm:"size:64;not null" json:"username"`
	Action       string    `gorm:"size:16;not null" json:"action"`
	Resource     string    `gorm:"index;size:64;not null" json:"resource"`
	ResourceID   *uint     `json:"resource_id"`
	RequestURL   string    `gorm:"size:500" json:"request_url"` // 新增：请求路径
	Summary      string    `gorm:"size:255" json:"summary"`
	Result       string    `gorm:"index;size:16;not null;default:success" json:"result"`
	ErrorMessage string    `gorm:"size:255" json:"error_message"`
	Detail       string    `gorm:"type:jsonb" json:"detail"`
	IP           string    `gorm:"size:45" json:"ip"`
	CreatedAt    time.Time `gorm:"index;not null" json:"created_at"`
}

// TableName returns the database table name for AuditLog.
func (AuditLog) TableName() string { return "audit_logs" }
