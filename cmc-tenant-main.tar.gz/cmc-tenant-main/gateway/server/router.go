package server

import (
	"github.com/chaitin/cmc-tenant/config"
	authhandler "github.com/chaitin/cmc-tenant/server/apis/auth/handler"
	userhandler "github.com/chaitin/cmc-tenant/server/apis/user/handler"
	tenanthandler "github.com/chaitin/cmc-tenant/server/apis/tenant_user/handler"
	tokenhandler "github.com/chaitin/cmc-tenant/server/apis/api_token/handler"
	currenthandler "github.com/chaitin/cmc-tenant/server/apis/current_user/handler"
	tgHandler "github.com/chaitin/cmc-tenant/server/apis/tenant_group/handler"
	bindinghandler "github.com/chaitin/cmc-tenant/server/apis/binding/handler"
	hiphandler "github.com/chaitin/cmc-tenant/server/apis/highlight_ip/handler"
	captainhandler "github.com/chaitin/cmc-tenant/server/apis/captain/handler"
	systemhandler "github.com/chaitin/cmc-tenant/server/apis/system/handler"
	sochandler "github.com/chaitin/cmc-tenant/server/apis/soc/handler"
	"github.com/chaitin/cmc-tenant/server/midware"
	"github.com/gin-gonic/gin"
)

// SetupRouter creates and configures the Gin engine with all routes.
func SetupRouter(cfg *config.Config) *gin.Engine {
	systemhandler.InitSystemHandlers(cfg)

	r := gin.New()

	r.Use(midware.Recovery())
	r.Use(midware.Logger())

	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	// Public
	r.POST("/api/auth/login", authhandler.Login(cfg))

	// Auth-protected routes
	auth := r.Group("")
	auth.Use(midware.Auth(cfg.JWT.Secret, cfg.JWT.ExpireHours))
	auth.Use(midware.Permission())
	auth.Use(midware.TenantContext())
	auth.Use(midware.Audit())
	{
		auth.POST("/api/auth/logout", authhandler.Logout())
		auth.GET("/api/auth/current", authhandler.Current())

		// User management (admin)
		user := auth.Group("/api/user")
		{
			user.POST("/list", userhandler.UserList())
			user.POST("/create", userhandler.UserCreate())
			user.PUT("/update", userhandler.UserUpdate())
			user.PUT("/enable", userhandler.UserEnable())
			user.PUT("/credential", userhandler.UserCredential())
			user.PUT("/unlock", userhandler.UserUnlock())
			user.DELETE("/delete", userhandler.UserDelete())
		}

		// Tenant user management (tenant_admin)
		tenant := auth.Group("/api/tenant/user")
		{
			tenant.POST("/list", tenanthandler.TenantUserList())
			tenant.POST("/create", tenanthandler.TenantUserCreate())
			tenant.PUT("/enable", tenanthandler.TenantUserEnable())
			tenant.PUT("/credential", tenanthandler.TenantUserCredential())
			tenant.PUT("/unlock", tenanthandler.TenantUserUnlock())
			tenant.DELETE("/delete", tenanthandler.TenantUserDelete())
		}

		// API Token (self)
		tokens := auth.Group("/api/user/api_token")
		{
			tokens.POST("/create", tokenhandler.APITokenCreate())
			tokens.GET("/list", tokenhandler.APITokenList())
			tokens.DELETE("/delete", tokenhandler.APITokenDelete())
		}

		// Current user settings
		current := auth.Group("/api/user/current")
		{
			current.PUT("/password", currenthandler.ChangePassword())
		}

		// Tenant group management (admin)
		tg := auth.Group("/api/tenant-group")
		{
			tg.GET("/list", tgHandler.TenantGroupList())
			tg.POST("/create", tgHandler.TenantGroupCreate())
			tg.PUT("/update", tgHandler.TenantGroupUpdate())
			tg.DELETE("/delete", tgHandler.TenantGroupDelete())
		}

		// Business bindings (admin)
		binding := auth.Group("/api/binding")
		{
			binding.GET("/waf/list", bindinghandler.WafBindingList())
			binding.POST("/waf/create", bindinghandler.WafBindingCreate())
			binding.DELETE("/waf/delete", bindinghandler.WafBindingDelete())
			binding.GET("/waf/available", bindinghandler.WafBindingAvailable())
			binding.GET("/site/list", bindinghandler.SiteBindingList())
			binding.POST("/site/create", bindinghandler.SiteBindingCreate())
			binding.DELETE("/site/delete", bindinghandler.SiteBindingDelete())
			binding.GET("/site/available", bindinghandler.SiteBindingAvailable())
			binding.POST("/site/resync_one", bindinghandler.SiteBindingResyncOne())
				binding.POST("/site/resync", bindinghandler.ResyncSiteMappings(cfg))
				binding.GET("/site/resync/:task_id", bindinghandler.ResyncTaskStatus(cfg))
		}

		// Highlight IP (all roles view, admin only write)
		hip := auth.Group("/api/highlight-ip")
		{
			hip.GET("/list", hiphandler.HighlightIPList())
			hip.POST("/create", hiphandler.HighlightIPCreate())
			hip.PUT("/update", hiphandler.HighlightIPUpdate())
			hip.DELETE("/delete", hiphandler.HighlightIPDelete())
		}

		// Captain proxy (all roles)
		cp := auth.Group("/api/captain")
		{
			// Site management
			cp.GET("/site/list", captainhandler.SiteList())
			cp.GET("/site/detail", captainhandler.SiteDetail())
			cp.POST("/site", captainhandler.SiteCreate())
			cp.PUT("/site", captainhandler.SiteUpdate())
			cp.DELETE("/site", captainhandler.SiteDelete())

			// Site auxiliary data (for form dropdowns)
			cp.GET("/site/aux/policy-list", captainhandler.SiteAuxPolicyList())
			cp.GET("/site/aux/cert-list", captainhandler.SiteAuxCertList())
			cp.GET("/site/aux/node-list", captainhandler.SiteAuxNodeList())
			cp.GET("/site/aux/asset-group-list", captainhandler.SiteAuxAssetGroupList())
			cp.GET("/site/aux/work-group-list", captainhandler.SiteAuxWorkGroupList())
			cp.GET("/site/aux/work-group-ips", captainhandler.SiteAuxWorkGroupIPList())
			cp.GET("/site/aux/link-ip-list", captainhandler.SiteAuxLinkIPList())
			cp.GET("/site/cookie/generate-key", captainhandler.CookieGenerateKey())

			// Policy rule (custom rule)
			cp.GET("/policy-rule/list", captainhandler.PolicyRuleList())
			cp.POST("/policy-rule/create", captainhandler.PolicyRuleCreate())
			cp.PUT("/policy-rule/update", captainhandler.PolicyRuleUpdate())
			cp.DELETE("/policy-rule/delete", captainhandler.PolicyRuleDelete())
			cp.PUT("/policy-rule/enable", captainhandler.PolicyRuleEnable())
			cp.POST("/policy-rule/module", captainhandler.PolicyRuleModulePost())
			cp.PUT("/policy-rule/module", captainhandler.PolicyRuleModulePut())
				cp.PUT("/policy-rule/skynet-rule", captainhandler.PolicyRuleSkynetRulePut())
				cp.PUT("/policy-rule/priority", captainhandler.PolicyRulePriority())
				cp.PUT("/policy-rule/bind", captainhandler.PolicyRuleBind())
				cp.DELETE("/policy-rule/unbind", captainhandler.PolicyRuleUnbind())
				cp.GET("/policy-rule/detection-modules", captainhandler.DetectionModules())
				cp.GET("/policy-rule/skynet-rules", captainhandler.SkynetRules())

			// Skynet rule (built-in rule)
			cp.GET("/skynet-rule/list", captainhandler.SkynetRuleList())
			cp.PUT("/skynet-rule/update", captainhandler.SkynetRuleUpdate())

			// IP group
			cp.GET("/ip-group/list", captainhandler.IPGroupList())
			cp.POST("/ip-group/create", captainhandler.IPGroupCreate())
			cp.PUT("/ip-group/update", captainhandler.IPGroupUpdate())
			cp.DELETE("/ip-group/delete", captainhandler.IPGroupDelete())
			cp.POST("/ip-group/item/add", captainhandler.IPGroupItemAdd())
			cp.DELETE("/ip-group/item/delete", captainhandler.IPGroupItemDelete())

			// SSL cert
			cp.GET("/cert/list", captainhandler.CertList())
			cp.GET("/cert/detail", captainhandler.CertDetail())
			cp.POST("/cert/upload", captainhandler.CertUpload())
			cp.POST("/cert/edit", captainhandler.CertEdit())
			cp.PUT("/cert/update", captainhandler.CertUpdate())
			cp.DELETE("/cert/delete", captainhandler.CertDelete())

			// Block page (拦截页面)
			cp.GET("/block-page/list", captainhandler.BlockPageList())
			cp.POST("/block-page/upload", captainhandler.BlockPageUpload())
			cp.DELETE("/block-page/delete", captainhandler.BlockPageDelete())
			cp.GET("/block-page/download", captainhandler.BlockPageDownload())

			// Policy
			cp.GET("/policy/list", captainhandler.PolicyList())
			cp.GET("/policy/detail", captainhandler.PolicyDetail())
			cp.POST("/policy/create", captainhandler.PolicyCreate())
			cp.PUT("/policy/update", captainhandler.PolicyUpdate())
			cp.DELETE("/policy/delete", captainhandler.PolicyDelete())
			cp.GET("/policy/global-config", captainhandler.PolicyGlobalConfigGet())
			cp.PUT("/policy/global-config", captainhandler.PolicyGlobalConfigUpdate())

			// Detect log
			cp.POST("/detect-log/list", captainhandler.DetectLogList())
			cp.GET("/detect-log/detail", captainhandler.DetectLogDetail())
			cp.PUT("/detect-log/mark", captainhandler.DetectLogMark())

			// Bot log
			cp.POST("/bot-log/record/list", captainhandler.BotLogRecordList())
			cp.GET("/bot-log/record/detail", captainhandler.BotLogRecordDetail())
			cp.POST("/bot-log/result/list", captainhandler.BotLogResultList())
			cp.GET("/bot-log/result/detail", captainhandler.BotLogResultDetail())

			// ACL log
			cp.POST("/acl-log/list", captainhandler.ACLLogList())
			cp.GET("/acl-log/detail", captainhandler.ACLLogDetail())
			cp.GET("/acl-log/src-ip-detail", captainhandler.ACLSrcIPDetail())

			// Log task
			cp.POST("/log-task/create", captainhandler.LogTaskCreate())
			cp.GET("/log-task/list", captainhandler.LogTaskList())
			cp.PUT("/log-task/:id/cancel", captainhandler.LogTaskCancel())
			cp.DELETE("/log-task/delete", captainhandler.LogTaskDelete())
			cp.POST("/log-task/:id/download", captainhandler.LogTaskDownload())

			// Mark flag
			cp.GET("/mark_flag", captainhandler.MarkFlagGet())
			cp.PUT("/mark_flag", captainhandler.MarkFlagUpdate())

			// Anti-tamper rule
				cp.GET("/anti-tamper/list", captainhandler.AntiTamperRuleList())

				// Filter save
			cp.GET("/filter/list", captainhandler.FilterList())
			cp.POST("/filter/create", captainhandler.FilterCreate())
			cp.PUT("/filter/update", captainhandler.FilterUpdate())
			cp.DELETE("/filter/delete", captainhandler.FilterDelete())
		}

		// System management (admin)
		sys := auth.Group("/api/system")
		{
			// SOC config
			sys.GET("/soc/list", systemhandler.SocList())
			sys.POST("/soc/create", systemhandler.SocCreate())
			sys.PUT("/soc/update", systemhandler.SocUpdate())
			sys.DELETE("/soc/delete", systemhandler.SocDelete())
			sys.POST("/soc/test", systemhandler.SocTest())

			// Captain config (read-only, managed via config/env)
			sys.GET("/captain", systemhandler.CaptainConfigGet())

			// Audit log
			sys.POST("/audit/list", systemhandler.AuditList())

			// Password config
			sys.GET("/password-config", systemhandler.PasswordConfigGet())
			sys.PUT("/password-config", systemhandler.PasswordConfigUpdate())

			// Login security
			sys.GET("/login-security", systemhandler.LoginSecurityGet())
			sys.PUT("/login-security", systemhandler.LoginSecurityUpdate())

			// Highlight tag
			sys.GET("/highlight-tag", systemhandler.HighlightTagGet())
			sys.PUT("/highlight-tag", systemhandler.HighlightTagUpdate())
		}

		// SOC report (all roles)
		auth.POST("/api/soc/report", sochandler.SocReport())
	}

	return r
}
