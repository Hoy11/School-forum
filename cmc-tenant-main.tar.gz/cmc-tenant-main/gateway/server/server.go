package server

import (
	"fmt"
	"log"

	"github.com/chaitin/cmc-tenant/config"
	systemmodel "github.com/chaitin/cmc-tenant/domain/system_config/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	riskguard "github.com/chaitin/cmc-tenant/pkg/risk_guard"
)

// Init initializes database, Redis, Captain client, and default data.
func Init(cfg *config.Config) {
	if err := database.InitPG(&cfg.PG, allModels()...); err != nil {
		log.Fatalf("init postgres: %v", err)
	}
	fmt.Println("postgres connected, migration done")

	if err := database.RunPostMigrations(); err != nil {
		fmt.Printf("warning: post migration failed: %v\n", err)
	}

	if err := database.InitRedis(&cfg.Redis); err != nil {
		log.Fatalf("init redis: %v", err)
	}
	fmt.Println("redis connected")

	initDefaultData(cfg)
	initCaptainClient(cfg)
}

func initCaptainClient(cfg *config.Config) {
	host := cfg.Captain.Host
	apiToken := cfg.Captain.APIToken

	// Fallback to DB if not configured via config/env
	if host == "" || apiToken == "" {
		var cc systemmodel.CaptainConfig
		database.DB.Where("is_default = ?", true).First(&cc)
		if cc.ID != 0 {
			if host == "" {
				host = cc.Host
			}
			if apiToken == "" {
				apiToken = cc.APIToken
			}
		}
	}

	if host == "" || apiToken == "" {
		fmt.Println("no captain config found, captain client not initialized")
		return
	}

	client := captain.NewCaptainClient(
		host, apiToken,
		cfg.Captain.RequestTimeoutSec, cfg.Captain.RetryCount,
	)
	captain.SetDefault(client)

	breaker := captain.NewBreaker(cfg.Captain.BreakerMaxFail, cfg.Captain.BreakerTimeoutSec)
	captain.SetDefaultBreaker(breaker)

	riskguard.Init(client, &cfg.RiskGuard)
	fmt.Println("captain client initialized:", host)
}
