package server

import (
	tokenmodel "github.com/chaitin/cmc-tenant/domain/api_token/model"
	auditmodel "github.com/chaitin/cmc-tenant/domain/audit_log/model"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	hipmodel "github.com/chaitin/cmc-tenant/domain/highlight_ip/model"
	socmodel "github.com/chaitin/cmc-tenant/domain/soc_config/model"
	socreportmodel "github.com/chaitin/cmc-tenant/domain/soc_report/model"
	scmodel "github.com/chaitin/cmc-tenant/domain/system_config/model"
	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
)

func allModels() []interface{} {
	return []interface{}{
		&usermodel.User{},
		&tgmodel.TenantGroup{},
		&tokenmodel.APIToken{},
		&bindingmodel.WafBinding{},
		&bindingmodel.SiteBinding{},
		&bindingmodel.CaptainLogTask{},
		&bindingmodel.CaptainIPGroupBinding{},
		&bindingmodel.CaptainCertBinding{},
		&bindingmodel.CaptainPolicyBinding{},
		&bindingmodel.CaptainPolicyRuleBinding{},
		&bindingmodel.CaptainBlockPageBinding{},
		&hipmodel.HighlightIP{},
		&auditmodel.AuditLog{},
		&socreportmodel.SocReportedLog{},
		&socmodel.SocConfig{},
		&scmodel.CaptainConfig{},
		&scmodel.HighlightTagConfig{},
		&scmodel.SystemConfig{},
	}
}
