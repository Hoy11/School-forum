// Package server initializes and runs the CMC Tenant gateway.
package server

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"log"

	"github.com/chaitin/cmc-tenant/config"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"golang.org/x/crypto/bcrypt"
)

func initDefaultData(_ *config.Config) {
	initAdminUser()
}

func initAdminUser() {
	db := database.DB
	var count int64
	db.Model(&usermodel.User{}).Where("role = ? AND is_deleted = false", "admin").Count(&count)
	if count > 0 {
		return
	}

	rawPwd := generateRandomPassword(16)
	hashed, err := bcrypt.GenerateFromPassword([]byte(rawPwd), bcrypt.DefaultCost)
	if err != nil {
		log.Fatalf("hash admin password: %v", err)
	}

	admin := usermodel.User{
		Username:    "admin",
		Password:    string(hashed),
		Role:        "admin",
		IsEnabled:   true,
		PasswordSet: false,
	}

	if err := db.Create(&admin).Error; err != nil {
		log.Fatalf("create admin user: %v", err)
	}

	fmt.Printf("========================================\n")
	fmt.Printf("  Admin user created\n")
	fmt.Printf("  Username: admin\n")
	fmt.Printf("  Password: %s\n", rawPwd)
	fmt.Printf("  Please change password after first login\n")
	fmt.Printf("========================================\n")
}

func generateRandomPassword(length int) string {
	b := make([]byte, length)
	if _, err := rand.Read(b); err != nil {
		log.Fatalf("generate random password: %v", err)
	}
	return hex.EncodeToString(b)[:length]
}
