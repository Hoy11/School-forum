// Package handler provides HTTP handlers for current user operations.
package handler

import (
	"fmt"
	"strings"
	"unicode"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	"github.com/chaitin/cmc-tenant/domain/user/business"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var currentUserOp = business.NewUserOperator()

// ChangePassword handles the current user's password change request.
func ChangePassword() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*usermodel.User)

		var req struct {
			OldPassword string `json:"old_password" binding:"required"`
			NewPassword string `json:"new_password" binding:"required"`
			DupPassword string `json:"dup_password" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if req.NewPassword != req.DupPassword {
			utils.ErrorBadRequest(c, "两次密码不一致")
			return
		}

		if err := validatePasswordPolicy(req.NewPassword); err != nil {
			utils.ErrorBadRequest(c, err.Error())
			return
		}

		if err := currentUserOp.ChangePassword(u.ID, req.OldPassword, req.NewPassword); err != nil {
			utils.ErrorBadRequest(c, err.Error())
			return
		}
		utils.Success(c, nil)
	}
}

func validatePasswordPolicy(password string) error {
	op := scbusiness.NewSystemConfigOperator()
	cfg, _ := op.GetPasswordConfig()

	if len(password) < cfg.MinLength {
		return newPwdError("密码长度不能小于 %d 位", cfg.MinLength)
	}

	var hasUpper, hasLower, hasNum, hasSymbol bool
	for _, ch := range password {
		switch {
		case unicode.IsUpper(ch):
			hasUpper = true
		case unicode.IsLower(ch):
			hasLower = true
		case unicode.IsDigit(ch):
			hasNum = true
		case unicode.IsPunct(ch) || unicode.IsSymbol(ch):
			hasSymbol = true
		}
	}

	if cfg.HasUpper && !hasUpper {
		return newPwdError("密码必须包含大写字母")
	}
	if cfg.HasLower && !hasLower {
		return newPwdError("密码必须包含小写字母")
	}
	if cfg.HasNum && !hasNum {
		return newPwdError("密码必须包含数字")
	}
	if cfg.HasSymbol && !hasSymbol {
		return newPwdError("密码必须包含特殊字符")
	}
	return nil
}

type pwdError struct{ msg string }

func (e *pwdError) Error() string { return e.msg }

func newPwdError(format string, args ...interface{}) *pwdError {
	return &pwdError{msg: strings.TrimSpace(fmt.Sprintf(format, args...))}
}
