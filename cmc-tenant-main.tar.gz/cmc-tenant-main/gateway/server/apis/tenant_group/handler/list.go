package handler

import (
	"net/http"

	tgbusiness "github.com/chaitin/cmc-tenant/domain/tenant_group/business"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var groupOp = tgbusiness.NewTenantGroupOperator()

// TenantGroupList returns a handler that lists tenant groups with pagination.
func TenantGroupList() gin.HandlerFunc {
	return func(c *gin.Context) {
		offset, count := utils.ParsePagination(c)
		total, groups, err := groupOp.List(offset, count)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"total": total, "items": groups}})
	}
}
