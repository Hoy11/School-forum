package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// TenantGroupDelete returns a handler that soft-deletes tenant groups by IDs.
func TenantGroupDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		if err := groupOp.Delete(req.IDs); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}
