package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// TenantGroupUpdate returns a handler that updates a tenant group's attributes.
func TenantGroupUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID        uint   `json:"id" binding:"required"`
			Name      string `json:"name"`
			Comment   string `json:"comment"`
			IsEnabled *bool  `json:"is_enabled"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		if err := groupOp.Update(req.ID, req.Name, req.Comment, req.IsEnabled); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}
