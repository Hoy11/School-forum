// Package handler implements HTTP handlers for tenant group APIs.
package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// TenantGroupCreate returns a handler that creates a new tenant group with its admin user.
func TenantGroupCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			Name          string `json:"name" binding:"required"`
			Comment       string `json:"comment"`
			AdminUsername string `json:"admin_username" binding:"required"`
			AdminPassword string `json:"admin_password" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		group, err := groupOp.Create(req.Name, req.Comment, req.AdminUsername, req.AdminPassword)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{
			"id": group.ID, "name": group.Name,
			"admin_user_id": group.AdminUserID, "admin_username": req.AdminUsername,
		}})
	}
}
