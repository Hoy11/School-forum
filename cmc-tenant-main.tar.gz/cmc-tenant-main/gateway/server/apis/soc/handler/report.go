// Package handler provides HTTP handlers for SOC reporting.
package handler

import (
	"encoding/json"
	"fmt"
	"net/url"
	"strconv"
	"time"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	socbusiness "github.com/chaitin/cmc-tenant/domain/soc_config/business"
	socreportmodel "github.com/chaitin/cmc-tenant/domain/soc_report/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm/clause"
)

var socReportOp = socbusiness.NewSocConfigOperator()

// SocReport returns a handler that reports logs to configured SOC endpoints.
func SocReport() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			LogID   string   `json:"log_id"`
			LogIDs  []string `json:"log_ids"`
			LogType string   `json:"log_type" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}

		user, _ := c.Get("user")
		u := user.(*usermodel.User)

		logIDs := req.LogIDs
		if req.LogID != "" {
			logIDs = []string{req.LogID}
		}
		if len(logIDs) != 1 {
			utils.ErrorBadRequest(c, "仅支持单条日志上报")
			return
		}

		logData, err := fetchLogData(c, logIDs, req.LogType, u)
		if err != nil {
			utils.ErrorInternal(c, "获取日志失败: "+err.Error())
			return
		}
		if len(logData) != 1 {
			utils.ErrorInternal(c, "未找到指定日志")
			return
		}

		var payloadBytes []byte
		if req.LogType == "detect" {
			client := captain.GetDefault()
			if client == nil {
				utils.ErrorInternal(c, "captain client 未初始化")
				return
			}
			rawLog, rawPayloadBytes, err := fetchRawDetectLogDetailPayload(client, logData[0])
			if err != nil {
				utils.ErrorInternal(c, "获取雷池原始日志失败: "+err.Error())
				return
			}
			logData[0] = rawLog
			payloadBytes = rawPayloadBytes
		} else {
			var err error
			payloadBytes, err = json.Marshal(logData[0])
			if err != nil {
				utils.ErrorInternal(c, "序列化日志失败: "+err.Error())
				return
			}
		}

		socConfigs, err := socReportOp.GetEnabled()
		if err != nil || len(socConfigs) == 0 {
			utils.ErrorBadRequest(c, "无可用 SOC 配置")
			return
		}

		successCount := 0
		failCount := 0
		var lastReportErr error
		for _, sc := range socConfigs {
			if err := socReportOp.ReportLogs(sc, payloadBytes); err != nil {
				failCount++
				lastReportErr = err
			} else {
				successCount++
			}
		}

		if successCount == 0 {
			msg := "上报 SOC 失败"
			if lastReportErr != nil {
				msg += ": " + lastReportErr.Error()
			}
			utils.ErrorInternal(c, msg)
			return
		}

		if successCount > 0 {
			if err := markSocReportedLog(logData[0], req.LogType, logIDs[0], u.Username); err != nil {
				utils.ErrorInternal(c, "记录上报状态失败: "+err.Error())
				return
			}
		}

		utils.Success(c, map[string]int{
			"success_count": successCount,
			"fail_count":    failCount,
		})
	}
}

func fetchLogData(c *gin.Context, logIDs []string, logType string, u *usermodel.User) ([]map[string]interface{}, error) {
	client := captain.GetDefault()
	if client == nil {
		return nil, fmt.Errorf("captain client 未初始化")
	}

	if logType == "detect" && len(logIDs) == 1 {
		return fetchDetectLogDetail(c, client, logIDs[0], u)
	}

	var captainPath string
	switch logType {
	case "detect":
		captainPath = "/api/detect_log/list"
	case "bot":
		captainPath = "/api/bot_log/record/list"
	case "acl":
		captainPath = "/api/acl_log/list"
	default:
		return nil, fmt.Errorf("不支持的日志类型: %s", logType)
	}

	body := map[string]interface{}{}

	// Filter by specific log IDs
	if len(logIDs) > 0 {
		body["id"] = []map[string]interface{}{
			{"oper": "in", "target": logIDs},
		}
	}

	applyLogScope(c, body, logType, u)

	resp, err := client.Do(&captain.CaptainRequest{
		Method: "POST",
		Path:   captainPath,
		Body:   body,
	})
	if err != nil {
		return nil, err
	}

	var result map[string]interface{}
	if err := json.Unmarshal(resp.Body, &result); err != nil {
		return nil, err
	}

	data, ok := result["data"].(map[string]interface{})
	if !ok {
		return nil, fmt.Errorf("响应格式异常")
	}

	items, ok := data["items"].([]interface{})
	if !ok {
		return nil, fmt.Errorf("响应中无日志数据")
	}

	logs := make([]map[string]interface{}, 0, len(items))
	for _, item := range items {
		if m, ok := item.(map[string]interface{}); ok {
			logs = append(logs, m)
		}
	}
	return logs, nil
}

func fetchDetectLogDetail(c *gin.Context, client *captain.CaptainClient, logID string, u *usermodel.User) ([]map[string]interface{}, error) {
	resp, err := client.Do(&captain.CaptainRequest{
		Method: "GET",
		Path:   "/api/detect_log/detail",
		Query:  "id=" + url.QueryEscape(logID),
	})
	if err != nil {
		return nil, err
	}

	var result struct {
		Data map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &result); err != nil {
		return nil, err
	}
	if len(result.Data) == 0 {
		return nil, fmt.Errorf("响应中无日志数据")
	}

	if u.Role != "admin" {
		wafID := interfaceToInt(result.Data["waf_id"])
		if wafID == 0 {
			wafID = interfaceToInt(result.Data["log_id"])
		}
		allowed := false
		if raw, ok := c.Get("allowed_waf_ids"); ok {
			if wafIDs, ok := raw.([]int); ok {
				for _, id := range wafIDs {
					if id == wafID {
						allowed = true
						break
					}
				}
			}
		}
		if !allowed {
			return nil, fmt.Errorf("无权访问该日志")
		}
	}

	return []map[string]interface{}{result.Data}, nil
}

func fetchRawDetectLogDetailPayload(client *captain.CaptainClient, log map[string]interface{}) (map[string]interface{}, []byte, error) {
	eventID, _ := log["event_id"].(string)
	if eventID == "" {
		return nil, nil, fmt.Errorf("日志缺少 event_id")
	}

	instanceID := interfaceToInt(log["waf_id"])
	if instanceID == 0 {
		instanceID = interfaceToInt(log["log_id"])
	}
	if instanceID == 0 {
		return nil, nil, fmt.Errorf("日志缺少 WAF 实例 ID")
	}

	q := url.Values{}
	q.Set("scope", "log:detect_log:detail")
	q.Set("event_id__exact", eventID)
	q.Set("count", "1")

	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/FilterV2API",
		Query:      q.Encode(),
		InstanceID: &idUint,
	})
	if err != nil {
		return nil, nil, err
	}

	return parseRawDetectLogDetailPayload(resp.Body)
}

func parseRawDetectLogDetail(body []byte) (map[string]interface{}, error) {
	item, _, err := parseRawDetectLogDetailPayload(body)
	return item, err
}

func parseRawDetectLogDetailPayload(body []byte) (map[string]interface{}, []byte, error) {
	var result struct {
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(body, &result); err != nil {
		return nil, nil, err
	}

	var items []json.RawMessage
	if err := json.Unmarshal(result.Data, &items); err == nil {
		if len(items) == 0 {
			return nil, nil, fmt.Errorf("响应中无雷池原始日志")
		}
		return rawDetectLogItem(items[0])
	}

	var page struct {
		Items []json.RawMessage `json:"items"`
	}
	if err := json.Unmarshal(result.Data, &page); err == nil && page.Items != nil {
		if len(page.Items) == 0 {
			return nil, nil, fmt.Errorf("响应中无雷池原始日志")
		}
		return rawDetectLogItem(page.Items[0])
	}

	return rawDetectLogItem(result.Data)
}

func rawDetectLogItem(raw json.RawMessage) (map[string]interface{}, []byte, error) {
	var item map[string]interface{}
	if err := json.Unmarshal(raw, &item); err != nil {
		return nil, nil, err
	}
	if len(item) == 0 {
		return nil, nil, fmt.Errorf("响应中无雷池原始日志")
	}
	return item, raw, nil
}

func applyLogScope(c *gin.Context, body map[string]interface{}, logType string, u *usermodel.User) {
	if u.Role == "admin" {
		return
	}
	if raw, ok := c.Get("allowed_waf_ids"); ok {
		if wafIDs, ok := raw.([]int); ok && len(wafIDs) > 0 {
			captain.InjectLogFilter(body, wafIDs)
		}
	}
	if logType == "detect" {
		if raw, ok := c.Get("allowed_sites"); ok {
			if sites, ok := raw.([]bindingmodel.SiteBinding); ok {
				siteIDs := make([]int, 0, len(sites))
				for _, site := range sites {
					siteIDs = append(siteIDs, site.SiteID)
				}
				captain.InjectDetectLogSiteFilter(body, siteIDs)
			}
		}
	}
}

func markSocReportedLog(log map[string]interface{}, logType, logID, username string) error {
	if logID == "" {
		return nil
	}
	srcIP, _ := log["src_ip"].(string)
	now := time.Now()
	record := socreportmodel.SocReportedLog{
		LogID:      logID,
		SrcIP:      srcIP,
		LogType:    logType,
		ReportedBy: username,
		ReportedAt: now,
	}
	return database.DB.Clauses(clause.OnConflict{
		Columns: []clause.Column{{Name: "log_id"}},
		DoUpdates: clause.Assignments(map[string]interface{}{
			"log_type":    logType,
			"src_ip":      srcIP,
			"reported_by": username,
			"reported_at": now,
			"updated_at":  now,
		}),
	}).Create(&record).Error
}

func interfaceToInt(v interface{}) int {
	switch value := v.(type) {
	case int:
		return value
	case int64:
		return int(value)
	case float64:
		return int(value)
	case string:
		n, _ := strconv.Atoi(value)
		return n
	default:
		return 0
	}
}
