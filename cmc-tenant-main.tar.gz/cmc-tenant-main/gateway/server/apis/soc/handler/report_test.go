package handler

import (
	"encoding/json"
	"strings"
	"testing"
)

func TestParseRawDetectLogDetail(t *testing.T) {
	body := []byte(`{
		"err": null,
		"msg": null,
		"data": [{
			"event_id": "evt-1",
			"src_ip": "1.1.1.1",
			"attack_type": "sqli"
		}],
		"total": 1
	}`)

	got, err := parseRawDetectLogDetail(body)
	if err != nil {
		t.Fatalf("parseRawDetectLogDetail() error = %v", err)
	}
	if got["event_id"] != "evt-1" {
		t.Fatalf("event_id = %v, want evt-1", got["event_id"])
	}

	payload, err := json.Marshal(got)
	if err != nil {
		t.Fatalf("Marshal() error = %v", err)
	}
	var sent map[string]interface{}
	if err := json.Unmarshal(payload, &sent); err != nil {
		t.Fatalf("Unmarshal() error = %v", err)
	}
	if _, ok := sent["highlight_note"]; ok {
		t.Fatalf("payload should not contain highlight_note: %v", sent)
	}
	if _, ok := sent["attack_count_last_hour"]; ok {
		t.Fatalf("payload should not contain attack_count_last_hour: %v", sent)
	}
}

func TestParseRawDetectLogDetailPayloadKeepsRawOrder(t *testing.T) {
	body := []byte(`{
		"err": null,
		"msg": null,
		"data": [{
			"event_id": "evt-1",
			"country": "",
			"province": "",
			"src_ip": "1.1.1.1"
		}],
		"total": 1
	}`)

	got, raw, err := parseRawDetectLogDetailPayload(body)
	if err != nil {
		t.Fatalf("parseRawDetectLogDetailPayload() error = %v", err)
	}
	if got["event_id"] != "evt-1" {
		t.Fatalf("event_id = %v, want evt-1", got["event_id"])
	}
	rawText := string(raw)
	eventIDIndex := strings.Index(rawText, `"event_id"`)
	countryIndex := strings.Index(rawText, `"country"`)
	provinceIndex := strings.Index(rawText, `"province"`)
	srcIPIndex := strings.Index(rawText, `"src_ip"`)
	if eventIDIndex >= countryIndex || countryIndex >= provinceIndex || provinceIndex >= srcIPIndex {
		t.Fatalf("raw payload order changed: %s", rawText)
	}
}

func TestParseRawDetectLogDetailEmpty(t *testing.T) {
	if _, err := parseRawDetectLogDetail([]byte(`{"data":[]}`)); err == nil {
		t.Fatal("parseRawDetectLogDetail() error = nil, want error")
	}
}

func TestParseRawDetectLogDetailObject(t *testing.T) {
	got, err := parseRawDetectLogDetail([]byte(`{
		"err": null,
		"msg": null,
		"data": {
			"event_id": "evt-2",
			"src_ip": "2.2.2.2"
		}
	}`))
	if err != nil {
		t.Fatalf("parseRawDetectLogDetail() error = %v", err)
	}
	if got["event_id"] != "evt-2" {
		t.Fatalf("event_id = %v, want evt-2", got["event_id"])
	}
}

func TestParseRawDetectLogDetailPageObject(t *testing.T) {
	got, err := parseRawDetectLogDetail([]byte(`{
		"err": null,
		"msg": null,
		"data": {
			"items": [{
				"event_id": "evt-3",
				"src_ip": "3.3.3.3"
			}],
			"total": 1
		}
	}`))
	if err != nil {
		t.Fatalf("parseRawDetectLogDetail() error = %v", err)
	}
	if got["event_id"] != "evt-3" {
		t.Fatalf("event_id = %v, want evt-3", got["event_id"])
	}
	if _, ok := got["items"]; ok {
		t.Fatalf("payload should be the first item, got wrapper: %v", got)
	}
}
