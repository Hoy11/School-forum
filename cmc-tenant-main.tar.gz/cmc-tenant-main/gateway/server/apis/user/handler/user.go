// Package handler provides HTTP handlers for user management.
package handler

import (
	"net/http"

	"github.com/chaitin/cmc-tenant/domain/user/business"
	"github.com/chaitin/cmc-tenant/server/midware"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var userOp = business.NewUserOperator()

// UserList returns a handler that lists users with filtering and pagination.
func UserList() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			Count          int                      `json:"count"`
			Offset         int                      `json:"offset"`
			Username       []map[string]interface{} `json:"username"`
			Role           []map[string]interface{} `json:"role"`
			TenantGroupID  []map[string]interface{} `json:"tenant_group_id"`
			IsEnabled      []map[string]interface{} `json:"is_enabled"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			req.Count = 20
			req.Offset = 0
		}

		offset := req.Offset
		count := req.Count
		if count <= 0 || count > 100 {
			count = 20
		}

		username := extractLikeValue(req.Username)
		role := extractInValues(req.Role)
		tgID := extractIntValue(req.TenantGroupID)
		isEnabled := extractBoolValue(req.IsEnabled)

		total, users, err := userOp.List(role, tgID, username, isEnabled, offset, count)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		utils.Success(c, gin.H{"total": total, "items": users})
	}
}

// UserCreate returns a handler that creates a new user.
func UserCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			Username      string `json:"username" binding:"required"`
			Password      string `json:"password" binding:"required"`
			Role          string `json:"role" binding:"required"`
			TenantGroupID *uint  `json:"tenant_group_id"`
			Remark        string `json:"remark"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}

		user, err := userOp.Create(req.Username, req.Password, req.Role, req.TenantGroupID, req.Remark)
		if err != nil {
			utils.ErrorBadRequest(c, err.Error())
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"id": user.ID, "username": user.Username}})
	}
}

// UserUpdate returns a handler that updates an existing user.
func UserUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID            uint   `json:"id" binding:"required"`
			Role          string `json:"role"`
			TenantGroupID *uint  `json:"tenant_group_id"`
			Remark        string `json:"remark"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if err := userOp.Update(req.ID, req.Role, req.TenantGroupID, req.Remark); err != nil {
			utils.ErrorBadRequest(c, err.Error())
			return
		}
		utils.Success(c, nil)
	}
}

// UserEnable returns a handler that enables or disables users.
func UserEnable() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs       []uint `json:"ids" binding:"required"`
			IsEnabled bool   `json:"is_enabled"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if err := userOp.Enable(req.IDs, req.IsEnabled); err != nil {
			utils.ErrorInternal(c, err.Error())
			return
		}
		utils.Success(c, nil)
	}
}

// UserCredential returns a handler that resets a user's password.
func UserCredential() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID uint `json:"id" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		pwd, err := userOp.ResetPassword(req.ID)
		if err != nil {
			utils.ErrorBadRequest(c, err.Error())
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"password": pwd}})
	}
}

// UserUnlock returns a handler that unlocks locked users.
func UserUnlock() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		usernames, err := userOp.GetUsernamesByIDs(req.IDs)
		if err != nil {
			utils.ErrorInternal(c, err.Error())
			return
		}
		if err := userOp.Unlock(req.IDs); err != nil {
			utils.ErrorInternal(c, err.Error())
			return
		}
		for _, name := range usernames {
			midware.ClearLoginLock(name)
		}
		utils.Success(c, nil)
	}
}

// UserDelete returns a handler that soft-deletes users.
func UserDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if err := userOp.Delete(req.IDs); err != nil {
			utils.ErrorInternal(c, err.Error())
			return
		}
		utils.Success(c, nil)
	}
}

// extractLikeValue extracts the first "like" target as a string
func extractLikeValue(conds []map[string]interface{}) string {
	for _, c := range conds {
		if oper, _ := c["oper"].(string); oper == "like" {
			if t, ok := c["target"].(string); ok {
				return t
			}
		}
	}
	return ""
}

// extractInValues extracts "in" targets as a string slice
func extractInValues(conds []map[string]interface{}) []string {
	for _, c := range conds {
		if oper, _ := c["oper"].(string); oper == "in" {
			if arr, ok := c["target"].([]interface{}); ok {
				result := make([]string, 0, len(arr))
				for _, v := range arr {
					if s, ok := v.(string); ok {
						result = append(result, s)
					}
				}
				return result
			}
		}
	}
	return nil
}

// extractIntValue extracts a single "=" target as *uint
func extractIntValue(conds []map[string]interface{}) *uint {
	for _, c := range conds {
		if oper, _ := c["oper"].(string); oper == "=" {
			if v, ok := c["target"].(float64); ok {
				id := uint(v)
				return &id
			}
		}
	}
	return nil
}

// extractBoolValue extracts "=" target as *bool
func extractBoolValue(conds []map[string]interface{}) *bool {
	for _, c := range conds {
		if oper, _ := c["oper"].(string); oper == "=" {
			if arr, ok := c["target"].([]interface{}); ok && len(arr) > 0 {
				if s, ok := arr[0].(string); ok {
					b := s == "true"
					return &b
				}
			}
		}
	}
	return nil
}
