package handler

import (
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

type highlightTagItem struct {
	Key     string `json:"key"`
	Color   string `json:"color"`
	Comment string `json:"comment"`
}

// HighlightTagGet returns a handler that retrieves highlight tag configuration.
func HighlightTagGet() gin.HandlerFunc {
	return func(c *gin.Context) {
		cfg, err := scOp.GetHighlightTag()
		if err != nil {
			utils.ErrorInternal(c, "查询失败")
			return
		}
		items := make([]highlightTagItem, 0, len(cfg))
		for color, comment := range cfg {
			items = append(items, highlightTagItem{Key: color, Color: color, Comment: comment})
		}
		utils.Success(c, items)
	}
}

// HighlightTagUpdate returns a handler that updates highlight tag configuration.
func HighlightTagUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			Tags []highlightTagItem `json:"tags"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		value := make(map[string]string, len(req.Tags))
		for _, item := range req.Tags {
			value[item.Color] = item.Comment
		}
		if err := scOp.SetHighlightTag(value); err != nil {
			utils.ErrorInternal(c, "更新失败")
			return
		}
		utils.Success(c, nil)
	}
}
