package handler

import (
	"net/http"

	socbusiness "github.com/chaitin/cmc-tenant/domain/soc_config/business"
	socmodel "github.com/chaitin/cmc-tenant/domain/soc_config/model"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var socOp = socbusiness.NewSocConfigOperator()

// SocList returns a handler that lists all SOC configurations.
func SocList() gin.HandlerFunc {
	return func(c *gin.Context) {
		list, err := socOp.List()
		if err != nil {
			utils.ErrorInternal(c, "查询失败")
			return
		}
		utils.Success(c, gin.H{
			"items": list,
			"total": len(list),
		})
	}
}

// SocCreate returns a handler that creates a new SOC configuration.
func SocCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			Name          string `json:"name" binding:"required"`
			Endpoint      string `json:"endpoint"`
			APIKey        string `json:"api_key"`
			Brokers       string `json:"brokers"`
			Topic         string `json:"topic"`
			Username      string `json:"username"`
			Password      string `json:"password"`
			SASLMechanism string `json:"sasl_mechanism"`
			IsEnabled     *bool  `json:"is_enabled"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if req.Brokers == "" {
			req.Brokers = req.Endpoint
		}
		if req.Topic == "" {
			req.Topic = req.APIKey
		}
		if req.Brokers == "" || req.Topic == "" {
			utils.ErrorBadRequest(c, "Kafka Brokers 和 Topic 必填")
			return
		}
		cfg := socmodel.SocConfig{
			Name:          req.Name,
			Endpoint:      req.Brokers,
			APIKey:        req.Topic,
			Brokers:       req.Brokers,
			Topic:         req.Topic,
			Username:      req.Username,
			Password:      req.Password,
			SASLMechanism: req.SASLMechanism,
		}
		if req.IsEnabled != nil {
			cfg.IsEnabled = *req.IsEnabled
		} else {
			cfg.IsEnabled = true
		}
		if err := socOp.Create(&cfg); err != nil {
			utils.ErrorInternal(c, "创建失败")
			return
		}
		utils.Success(c, cfg)
	}
}

// SocUpdate returns a handler that updates an existing SOC configuration.
func SocUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID            uint   `json:"id" binding:"required"`
			Name          string `json:"name"`
			Endpoint      string `json:"endpoint"`
			APIKey        string `json:"api_key"`
			Brokers       string `json:"brokers"`
			Topic         string `json:"topic"`
			Username      string `json:"username"`
			Password      string `json:"password"`
			SASLMechanism string `json:"sasl_mechanism"`
			IsEnabled     *bool  `json:"is_enabled"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		var cfg socmodel.SocConfig
		if err := socbusiness.GetDB().First(&cfg, req.ID).Error; err != nil {
			utils.ErrorNotFound(c, "配置不存在")
			return
		}
		if req.Name != "" {
			cfg.Name = req.Name
		}
		if req.Brokers == "" {
			req.Brokers = req.Endpoint
		}
		if req.Topic == "" {
			req.Topic = req.APIKey
		}
		if req.Brokers != "" {
			cfg.Brokers = req.Brokers
			cfg.Endpoint = req.Brokers
		}
		if req.Topic != "" {
			cfg.Topic = req.Topic
			cfg.APIKey = req.Topic
		}
		if req.Endpoint != "" {
			cfg.Endpoint = req.Endpoint
		}
		if req.APIKey != "" {
			cfg.APIKey = req.APIKey
		}
		cfg.Username = req.Username
		if req.Username == "" {
			cfg.Password = ""
			cfg.SASLMechanism = ""
		} else if req.Password != "" {
			cfg.Password = req.Password
			cfg.SASLMechanism = req.SASLMechanism
		}
		if req.IsEnabled != nil {
			cfg.IsEnabled = *req.IsEnabled
		}
		if err := socOp.Update(&cfg); err != nil {
			utils.ErrorInternal(c, "更新失败")
			return
		}
		utils.Success(c, nil)
	}
}

// SocDelete returns a handler that deletes a SOC configuration.
func SocDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID uint `json:"id" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if err := socOp.Delete(req.ID); err != nil {
			utils.ErrorInternal(c, "删除失败")
			return
		}
		utils.Success(c, nil)
	}
}

// SocTest returns a handler that tests connectivity to a SOC endpoint.
func SocTest() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID uint `json:"id" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if err := socOp.Test(req.ID); err != nil {
			utils.Error(c, http.StatusOK, "test_failed", err.Error())
			return
		}
		utils.Success(c, nil)
	}
}
