package handler

import (
	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/chaitin/cmc-tenant/config"
	"github.com/gin-gonic/gin"
)

var scOp = scbusiness.NewSystemConfigOperator()
var appCfg *config.Config

// InitSystemHandlers initializes system handlers with the application config.
func InitSystemHandlers(cfg *config.Config) {
	appCfg = cfg
}

// CaptainConfigGet returns a handler that retrieves the Captain-2 configuration.
func CaptainConfigGet() gin.HandlerFunc {
	return func(c *gin.Context) {
		view := gin.H{}

		// Prefer config/env values
		if appCfg.Captain.Host != "" {
			view["host"] = appCfg.Captain.Host
			view["source"] = "config"
		}

		if appCfg.Captain.APIToken != "" {
			view["api_token"] = maskToken(appCfg.Captain.APIToken)
		}

		// Fallback to DB
		if view["host"] == nil {
			dbView, err := scOp.GetCaptainConfig()
			if err == nil {
				view["host"] = dbView.Host
				view["api_token"] = dbView.APIToken
				view["source"] = "database"
			}
		}

		if view["host"] == nil {
			utils.ErrorNotFound(c, "纵横配置不存在")
			return
		}
		utils.Success(c, view)
	}
}

func maskToken(token string) string {
	if len(token) <= 6 {
		return "******"
	}
	return token[:3] + "***" + token[len(token)-3:]
}
