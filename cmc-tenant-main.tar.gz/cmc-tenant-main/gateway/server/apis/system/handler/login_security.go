package handler

import (
	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

// LoginSecurityGet returns a handler that retrieves login security settings.
func LoginSecurityGet() gin.HandlerFunc {
	return func(c *gin.Context) {
		cfg, _ := scOp.GetLoginSecurity()
		utils.Success(c, cfg)
	}
}

// LoginSecurityUpdate returns a handler that updates login security settings.
func LoginSecurityUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var cfg scbusiness.LoginSecurityConfig
		if err := c.ShouldBindJSON(&cfg); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if cfg.MaxRetry < 1 {
			utils.ErrorBadRequest(c, "最大重试次数不能小于1")
			return
		}
		if cfg.LockMinutes < 1 {
			utils.ErrorBadRequest(c, "锁定时长不能小于1分钟")
			return
		}
		if cfg.RetryWindowSec < 60 {
			utils.ErrorBadRequest(c, "重试窗口不能小于60秒")
			return
		}
		if err := scOp.SetLoginSecurity(cfg); err != nil {
			utils.ErrorInternal(c, "更新失败")
			return
		}
		utils.Success(c, nil)
	}
}
