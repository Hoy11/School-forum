package handler

import (
	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

// PasswordConfigGet returns a handler that retrieves password configuration.
func PasswordConfigGet() gin.HandlerFunc {
	return func(c *gin.Context) {
		cfg, _ := scOp.GetPasswordConfig()
		utils.Success(c, cfg)
	}
}

// PasswordConfigUpdate returns a handler that updates password configuration.
func PasswordConfigUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var cfg scbusiness.PasswordConfig
		if err := c.ShouldBindJSON(&cfg); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if cfg.MinLength < 6 {
			utils.ErrorBadRequest(c, "密码最小长度不能小于6")
			return
		}
		if cfg.UpdateDays < 1 {
			utils.ErrorBadRequest(c, "更新周期不能小于1天")
			return
		}
		if err := scOp.SetPasswordConfig(cfg); err != nil {
			utils.ErrorInternal(c, "更新失败")
			return
		}
		utils.Success(c, nil)
	}
}
