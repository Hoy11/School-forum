// Package handler provides HTTP handlers for system administration.
package handler

import (
	auditbusiness "github.com/chaitin/cmc-tenant/domain/audit_log/business"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var auditOp = auditbusiness.NewAuditLogOperator()

// AuditList returns a handler that lists audit log entries.
func AuditList() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req auditbusiness.AuditLogListRequest
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		result, err := auditOp.List(req)
		if err != nil {
			utils.ErrorInternal(c, "查询失败")
			return
		}
		utils.Success(c, result)
	}
}
