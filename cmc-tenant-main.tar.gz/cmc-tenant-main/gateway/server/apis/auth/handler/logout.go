package handler

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

// Logout clears the JWT cookie.
func Logout() gin.HandlerFunc {
	return func(c *gin.Context) {
		c.SetCookie("token", "", -1, "/", "", false, true)
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": ""})
	}
}
