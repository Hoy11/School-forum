package handler

import (
	"crypto/rand"
	"encoding/hex"
	"net/http"
	"strconv"
	"time"

	"github.com/chaitin/cmc-tenant/config"
	"github.com/chaitin/cmc-tenant/domain/audit_log/model"
	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	"github.com/chaitin/cmc-tenant/domain/user/business"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/chaitin/cmc-tenant/pkg/jwt"
	"github.com/chaitin/cmc-tenant/server/midware"
	"github.com/gin-gonic/gin"
)

var timeNow = time.Now

// Login authenticates a user and sets a JWT cookie.
func Login(cfg *config.Config) gin.HandlerFunc {
	userOp := business.NewUserOperator()
	return func(c *gin.Context) {
		var req struct {
			Username string `json:"username" binding:"required"`
			Password string `json:"password" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		loginSec := getLoginSecurity(cfg)

		if midware.IsLoginLocked(req.Username) {
			remaining := midware.GetLockRemaining(req.Username, loginSec.LockMinutes)
			c.JSON(http.StatusForbidden, gin.H{
				"err": "locked", "msg": fmtLockedMsg(remaining), "data": "",
			})
			return
		}

		user, err := userOp.Login(req.Username, req.Password)
		if err != nil {
			if err == business.ErrWrongPassword {
				midware.RecordLoginFail(req.Username, &loginSec)
			}
			status := http.StatusUnauthorized
			if err == business.ErrUserDisabled || err == business.ErrUserLocked {
				status = http.StatusForbidden
			}
			c.JSON(status, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}

		midware.ClearLoginFail(req.Username)

		sessionID := generateSessionID()
		if loginSec.SingleSignOn {
			midware.SetActiveSession(user.ID, sessionID, time.Duration(cfg.JWT.ExpireHours)*time.Hour)
		}
		token, _ := jwt.Sign(cfg.JWT.Secret, user.ID, user.Username, user.Role, user.TenantGroupID, cfg.JWT.ExpireHours, sessionID)
		c.SetCookie("token", token, cfg.JWT.ExpireHours*3600, "/", "", false, true)

		now := timeNow()
		database.DB.Model(user).Updates(map[string]interface{}{
			"last_login":    now,
			"last_login_ip": c.ClientIP(),
		})

		writeLoginAudit(user.ID, user.Username, c.ClientIP())

		resp := gin.H{
			"id":       user.ID,
			"username": user.Username,
			"role":     user.Role,
		}
		if !user.PasswordSet {
			resp["need_change_password"] = true
		} else if isPasswordExpired(user) {
			resp["need_change_password"] = true
		}

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "登录成功", "data": resp})
	}
}

func getLoginSecurity(cfg *config.Config) scbusiness.LoginSecurityConfig {
	if database.DB != nil {
		op := scbusiness.NewSystemConfigOperator()
		if sec, err := op.GetLoginSecurity(); err == nil {
			return sec
		}
	}
	return scbusiness.LoginSecurityConfig{
		MaxRetry:       cfg.LoginSecurity.MaxRetry,
		LockMinutes:    cfg.LoginSecurity.LockMinutes,
		RetryWindowSec: cfg.LoginSecurity.RetryWindowSec,
	}
}

func writeLoginAudit(userID uint, username, ip string) {
	log := model.AuditLog{
		UserID:   userID,
		Username: username,
		Action:   "LOGIN",
		Resource: "auth",
		Summary:  "登录系统",
		Result:   "success",
		IP:       ip,
	}
	go func() { _ = database.DB.Create(&log).Error }()
}

func fmtLockedMsg(remaining int) string {
	return "账户已锁定，请 " + strconv.Itoa(remaining) + " 秒后重试"
}

func generateSessionID() string {
	b := make([]byte, 16)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func isPasswordExpired(user *usermodel.User) bool {
	op := scbusiness.NewSystemConfigOperator()
	cfg, err := op.GetPasswordConfig()
	if err != nil || !cfg.IsForced {
		return false
	}
	if user.PwdChangedAt == nil {
		return true
	}
	return timeNow().Sub(*user.PwdChangedAt) > time.Duration(cfg.UpdateDays)*24*time.Hour
}
