// Package handler provides HTTP handlers for authentication.
package handler

import (
	"net/http"
	"time"

	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

// Current returns the currently authenticated user's info.
func Current() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*usermodel.User)

		resp := gin.H{
			"id":                  u.ID,
			"username":            u.Username,
			"role":                u.Role,
			"tenant_group_id":     u.TenantGroupID,
			"is_enabled":          u.IsEnabled,
			"remark":              u.Remark,
			"last_login":          u.LastLogin,
			"need_change_password": needChangePassword(u),
		}

		if u.TenantGroupID != nil {
			var group tgmodel.TenantGroup
			if err := database.DB.Where("id = ? AND is_deleted = false", *u.TenantGroupID).First(&group).Error; err == nil {
				resp["tenant_group_name"] = group.Name
			}
		}

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": nil, "data": resp})
	}
}

func needChangePassword(u *usermodel.User) bool {
	if !u.PasswordSet {
		return true
	}
	if u.PwdChangedAt == nil {
		return true
	}
	op := scbusiness.NewSystemConfigOperator()
	cfg, err := op.GetPasswordConfig()
	if err != nil || !cfg.IsForced {
		return false
	}
	return time.Since(*u.PwdChangedAt) > time.Duration(cfg.UpdateDays)*24*time.Hour
}
