// Package handler implements HTTP handlers for WAF and site binding APIs.
package handler

import (
	"encoding/json"
	"errors"
	"net/http"

	bindingbusiness "github.com/chaitin/cmc-tenant/domain/binding/business"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	captainhandler "github.com/chaitin/cmc-tenant/server/apis/captain/handler"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var bindingOp = bindingbusiness.NewBindingOperator()

func isAdmin(c *gin.Context) bool {
	u, _ := c.Get("user")
	if u == nil {
		return false
	}
	return u.(*usermodel.User).Role == "admin"
}

func getTenantGroupID(c *gin.Context) *uint {
	id, _ := c.Get("tenant_group_id")
	if id == nil {
		return nil
	}
	switch v := id.(type) {
	case uint:
		return &v
	case *uint:
		return v
	}
	return nil
}

// WafBindingList returns a handler that lists WAF bindings for a tenant group.
func WafBindingList() gin.HandlerFunc {
	return func(c *gin.Context) {
		offset, count := utils.ParsePagination(c)

		type condItem struct {
			Oper  string      `json:"oper"`
			Value interface{} `json:"value"`
		}
		type parsedCond struct {
			Target string     `json:"target"`
			Items  []condItem `json:"items"`
		}
		var parsedConds []parsedCond

		var tgID *uint
		if v := c.Query("tenant_group_id"); v != "" {
			id, err := parsePositiveUintBind(v)
			if err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			tgID = &id
		}
		if condStr := c.Query("conditions"); condStr != "" {
			json.Unmarshal([]byte(condStr), &parsedConds) //nolint:errcheck
		}

		// 从 conditions 中提取 tenant_group_id 和实例级筛选条件
		var instanceFilters []wafCondition
		for _, cond := range parsedConds {
			switch cond.Target {
			case "tenant_group_id":
				if tgID == nil {
					for _, item := range cond.Items {
						if item.Oper == "=" {
							if v, ok := item.Value.(float64); ok {
								if v <= 0 {
									c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
									return
								}
								id := uint(v)
								tgID = &id
							}
						}
					}
				}
			case "instance_name", "instance_status", "version":
				for _, item := range cond.Items {
					val, _ := item.Value.(string)
					if val != "" {
						instanceFilters = append(instanceFilters, wafCondition{
							Target: cond.Target,
							Oper:   item.Oper,
							Value:  val,
						})
					}
				}
			}
		}

		// 非 admin 只能看自己组的绑定
		if !isAdmin(c) {
			tgID = getTenantGroupID(c)
		}

		// 有实例级筛选条件时取全量数据（instance_name/status/version 来自 Captain，不在 DB）
		fetchOffset, fetchCount := offset, count
		if len(instanceFilters) > 0 {
			fetchOffset, fetchCount = 0, -1
		}

		total, bindings, err := bindingOp.ListWafBindings(tgID, fetchOffset, fetchCount)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}

		instanceIDs := make([]int, 0, len(bindings))
		for _, b := range bindings {
			instanceIDs = append(instanceIDs, b.CaptainInstanceID)
		}

		instanceMap, instanceKnown := fetchInstanceMapWithStatus(instanceIDs...)
		items := enrichWafBindingsWithStatus(bindings, instanceMap, instanceKnown)

		// 有实例级筛选条件时内存过滤，并重新计算 total 和分页
		if len(instanceFilters) > 0 {
			items = filterByWafConditions(items, instanceFilters)
			total = int64(len(items))
			items = paginateWafBindingItems(items, offset, count)
		}
		if isAdmin(c) {
			attachBoundTenantGroups(items)
		}

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"total": total, "items": items}})
	}
}

// WafBindingCreate returns a handler that creates WAF bindings for a tenant group.
func WafBindingCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			TenantGroupID      uint  `json:"tenant_group_id" binding:"required"`
			CaptainInstanceIDs []int `json:"captain_instance_ids" binding:"required,min=1,dive,gt=0"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		exists, err := tenantGroupExists(req.TenantGroupID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		if !exists {
			c.JSON(http.StatusNotFound, gin.H{"err": "not_found", "msg": "租户组不存在", "data": ""})
			return
		}

		instances, ok := fetchCaptainWafInstances()
		if !ok {
			c.JSON(http.StatusBadGateway, gin.H{"err": "captain_error", "msg": "获取 WAF 实例列表失败", "data": ""})
			return
		}
		missingIDs := missingCaptainInstanceIDs(req.CaptainInstanceIDs, instances)
		if len(missingIDs) > 0 {
			c.JSON(http.StatusNotFound, gin.H{
				"err":  "not_found",
				"msg":  "WAF 实例不存在: " + joinIntIDs(missingIDs),
				"data": "",
			})
			return
		}

		if err := bindingOp.CreateWafBindings(req.TenantGroupID, req.CaptainInstanceIDs); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

// WafBindingDelete returns a handler that deletes WAF bindings by IDs.
func WafBindingDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}
		if err := bindingOp.DeleteWafBindings(req.IDs); err != nil {
			if errors.Is(err, bindingbusiness.ErrWafHasSiteBindings) {
				c.JSON(http.StatusBadRequest, gin.H{"err": "has_site_bindings", "msg": err.Error(), "data": ""})
			} else {
				c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			}
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

// WafBindingAvailable returns a handler that lists unbound WAF instances for a tenant group.
func WafBindingAvailable() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !isAdmin(c) {
			utils.ErrorForbidden(c, "仅管理员可查看可绑定 WAF 列表")
			return
		}

		tgIDStr := c.Query("tenant_group_id")
		if tgIDStr == "" {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "tenant_group_id 必填", "data": ""})
			return
		}
		tgID, err := parsePositiveUintBind(tgIDStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
			return
		}

		exists, err := tenantGroupExists(tgID)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		if !exists {
			c.JSON(http.StatusNotFound, gin.H{"err": "not_found", "msg": "租户组不存在", "data": ""})
			return
		}

		instances, ok := fetchCaptainWafInstances()
		if !ok {
			c.JSON(http.StatusBadGateway, gin.H{"err": "captain_error", "msg": "获取 WAF 实例列表失败", "data": ""})
			return
		}

		boundIDs := bindingOp.GetBoundInstanceIDs(tgID)
		boundSet := make(map[int]bool, len(boundIDs))
		for _, id := range boundIDs {
			boundSet[id] = true
		}

		available := make([]availableWaf, 0)
		for _, inst := range instances {
			id := getInstanceID(inst)
			if id > 0 && !boundSet[id] {
				available = append(available, availableWaf{
					CaptainInstanceID: id,
					InstanceName:      getFieldString(inst, "name", "Name"),
					InstanceHost:      getFieldString(inst, "host", "Host"),
					InstanceStatus:    getInstanceStatus(inst),
					Version:           getFieldString(inst, "version", "Version"),
				})
			}
		}

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": available})
	}
}

// SiteBindingList returns a handler that lists site bindings for a tenant group.
func SiteBindingList() gin.HandlerFunc {
	return func(c *gin.Context) {
		offset, count := utils.ParsePagination(c)
		var tgID *uint
		if v := c.Query("tenant_group_id"); v != "" {
			id, err := parsePositiveUintBind(v)
			if err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			tgID = &id
		}
		var instanceID *int
		if v := c.Query("captain_instance_id"); v != "" {
			id, err := parsePositiveIntBind(v)
			if err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			instanceID = &id
		}

		// Non-admin users can only see their own group's bindings
		if !isAdmin(c) {
			tgID = getTenantGroupID(c)
		}

		total, bindings, err := bindingOp.ListSiteBindings(tgID, instanceID, offset, count)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}

		siteInstanceIDs := make([]int, 0)
		for _, b := range bindings {
			siteInstanceIDs = append(siteInstanceIDs, b.CaptainInstanceID)
		}
		instanceMap := fetchInstanceMap(siteInstanceIDs...)
		siteNames := fetchSiteNameLookup(instanceID, bindings)
		items := enrichSiteBindingsWithLookup(bindings, instanceMap, siteNames)
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"total": total, "items": items}})
	}
}

// SiteBindingCreate returns a handler that creates site bindings for a tenant group.
func SiteBindingCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			TenantGroupID     uint  `json:"tenant_group_id" binding:"required"`
			CaptainInstanceID int   `json:"captain_instance_id" binding:"required"`
			SiteIDs           []int `json:"site_ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		if err := bindingOp.CreateSiteBindings(req.TenantGroupID, req.CaptainInstanceID, req.SiteIDs); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}

		for _, siteID := range req.SiteIDs {
			captainhandler.SyncSiteResourceMappings(req.CaptainInstanceID, siteID, req.TenantGroupID)
		}

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

// SiteBindingDelete returns a handler that deletes site bindings by IDs.
func SiteBindingDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		if err := bindingOp.DeleteSiteBindings(req.IDs); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

// SiteBindingResyncOne returns a handler that re-syncs resource mappings for a single
// site binding. Unlike ResyncSiteMappings (运维脚本批量同步，需要 X-Resync-Key), this is
// a lightweight, standard JWT-authenticated endpoint for the frontend's per-row "同步" button.
func SiteBindingResyncOne() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID uint `json:"id" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		var binding bindingmodel.SiteBinding
		if err := database.DB.First(&binding, req.ID).Error; err != nil {
			c.JSON(http.StatusNotFound, gin.H{"err": "not_found", "msg": "站点绑定不存在", "data": ""})
			return
		}

		client := captain.GetDefault()
		if client == nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": "captain client not initialized", "data": ""})
			return
		}

		detail, err := captainhandler.FetchSiteDetailForResync(client, binding.CaptainInstanceID, binding.SiteID)
		if err != nil || detail == nil {
			c.JSON(http.StatusOK, gin.H{"err": "invalid", "msg": "site no longer exists, consider manual cleanup", "data": gin.H{"synced": 0}})
			return
		}

		captainhandler.SyncSiteResourceMappings(binding.CaptainInstanceID, binding.SiteID, binding.TenantGroupID)
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"synced": 1}})
	}
}

// SiteBindingAvailable returns a handler that lists unbound sites for a tenant group on a WAF instance.
func SiteBindingAvailable() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceIDStr := c.Query("captain_instance_id")
		if instanceIDStr == "" {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		instanceID, err := parsePositiveIntBind(instanceIDStr)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
			return
		}
		idUint := uint(instanceID)

		client := captain.GetDefault()
		if client == nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "captain_error", "msg": "纵横服务未配置", "data": ""})
			return
		}

		captainPath, err := resolveSitePathForInstance(instanceID)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
			return
		}
		resp, err := client.Do(&captain.CaptainRequest{
			Method: "GET", Path: captainPath, InstanceID: &idUint,
		})
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var captainResp struct {
			Data []map[string]interface{} `json:"data"`
		}
		if err := json.Unmarshal(resp.Body, &captainResp); err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "parse_error", "msg": "解析纵横响应失败", "data": ""})
			return
		}
		allSites := captainResp.Data

		boundIDs := bindingOp.GetAllBoundSiteIDs(instanceID)
		boundSet := make(map[int]bool, len(boundIDs))
		for _, id := range boundIDs {
			boundSet[id] = true
		}

		available := make([]map[string]interface{}, 0)
		for _, site := range allSites {
			id := getIDFromItem(site)
			if !boundSet[id] {
				item := map[string]interface{}{
					"site_id":      id,
					"site_name":    site["name"],
					"server_names": site["server_names"],
				}
				available = append(available, item)
			}
		}

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": available})
	}
}
