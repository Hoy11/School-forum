package handler

import (
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

const siteDetailResp = `{
  "data": {
    "policy_group": 1,
    "ssl_cert": 2,
    "proxy_ip_groups": [],
    "blocking_template": null
  },
  "err": null,
  "msg": ""
}`

func setupSiteBindingResyncTestDB(t *testing.T) *gorm.DB {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(
		&bindingmodel.SiteBinding{},
		&bindingmodel.CaptainPolicyBinding{},
		&bindingmodel.CaptainCertBinding{},
		&bindingmodel.CaptainIPGroupBinding{},
	); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	return db
}

func TestSiteBindingResyncOneRejectsMissingID(t *testing.T) {
	gin.SetMode(gin.TestMode)

	r := gin.New()
	r.POST("/resync_one", SiteBindingResyncOne())

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/resync_one", strings.NewReader(`{}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusBadRequest, w.Body.String())
	}
}

func TestSiteBindingResyncOneRejectsUnknownBinding(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db := setupSiteBindingResyncTestDB(t)
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	r := gin.New()
	r.POST("/resync_one", SiteBindingResyncOne())

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/resync_one", strings.NewReader(`{"id":999}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusNotFound, w.Body.String())
	}
}

func TestSiteBindingResyncOneSyncsExistingSite(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db := setupSiteBindingResyncTestDB(t)
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	if err := db.Create(&bindingmodel.SiteBinding{ID: 1, TenantGroupID: 1, CaptainInstanceID: 1, SiteID: 11}).Error; err != nil {
		t.Fatalf("create binding: %v", err)
	}

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/group/detail" {
			_, _ = w.Write([]byte(groupDetailResp))
			return
		}
		_, _ = w.Write([]byte(siteDetailResp))
	}))
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	r := gin.New()
	r.POST("/resync_one", SiteBindingResyncOne())

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/resync_one", strings.NewReader(`{"id":1}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusOK, w.Body.String())
	}
	if !strings.Contains(w.Body.String(), `"err":null`) {
		t.Fatalf("body = %s, want err:null", w.Body.String())
	}
}

func TestSiteBindingResyncOneReportsInvalidSite(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db := setupSiteBindingResyncTestDB(t)
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	if err := db.Create(&bindingmodel.SiteBinding{ID: 1, TenantGroupID: 1, CaptainInstanceID: 1, SiteID: 11}).Error; err != nil {
		t.Fatalf("create binding: %v", err)
	}

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/api/group/detail" {
			_, _ = w.Write([]byte(groupDetailResp))
			return
		}
		_, _ = w.Write([]byte(`{"err":"object-not-found","msg":"","data":null}`))
	}))
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	r := gin.New()
	r.POST("/resync_one", SiteBindingResyncOne())

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/resync_one", strings.NewReader(`{"id":1}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusOK, w.Body.String())
	}
	if !strings.Contains(w.Body.String(), `"err":"invalid"`) {
		t.Fatalf("body = %s, want err:invalid", w.Body.String())
	}
}
