package handler

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/redis/go-redis/v9"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	captainhandler "github.com/chaitin/cmc-tenant/server/apis/captain/handler"
	"github.com/chaitin/cmc-tenant/config"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

// ResyncSiteMappings re-syncs resource mappings for tenant groups' site bindings.
// Requires dual auth: admin JWT + X-Resync-Key header. Async task with batch processing.
func ResyncSiteMappings(cfg *config.Config) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Dual auth: admin JWT + secret key header
		key := c.GetHeader("X-Resync-Key")
		if key == "" || key != cfg.Resync.SecretKey {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "invalid resync key", "data": ""})
			return
		}

		var req struct {
			TenantGroupIDs    []uint `json:"tenant_group_ids"`
			CaptainInstanceID *int   `json:"captain_instance_id"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "bad request", "data": ""})
			return
		}
		if len(req.TenantGroupIDs) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "tenant_group_ids required", "data": ""})
			return
		}

		// Rate limit: check Redis for each tenant_group_id
		rdb := database.RDB
		for _, tgID := range req.TenantGroupIDs {
			rateKey := fmt.Sprintf("resync:rate:%d", tgID)
			if rdb != nil {
				existing, err := rdb.Get(context.Background(), rateKey).Result()
				if err == nil && existing != "" {
					c.JSON(http.StatusTooManyRequests, gin.H{"err": "rate_limit", "msg": fmt.Sprintf("tenant group %d already synced within rate limit window", tgID), "data": ""})
					return
				}
			}
		}

		// Validate tenant groups exist
		for _, tgID := range req.TenantGroupIDs {
			var count int64
			database.DB.Model(&tgmodel.TenantGroup{}).Where("id = ?", tgID).Count(&count)
			if count == 0 {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": fmt.Sprintf("tenant group %d not found", tgID), "data": ""})
				return
			}
		}

		// Collect all site bindings to sync
		var bindings []bindingmodel.SiteBinding
		q := database.DB
		if req.CaptainInstanceID != nil {
			q = q.Where("tenant_group_id IN ? AND captain_instance_id = ?", req.TenantGroupIDs, *req.CaptainInstanceID)
		} else {
			q = q.Where("tenant_group_id IN ?", req.TenantGroupIDs)
		}
		q.Find(&bindings)

		if len(bindings) == 0 {
			c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"task_id": "", "total_sites": 0}})
			return
		}

		// Set rate limit keys in Redis (configurable TTL)
		rateLimitMinutes := cfg.Resync.RateLimitMinutes
		if rateLimitMinutes <= 0 {
			rateLimitMinutes = 30
		}
		for _, tgID := range req.TenantGroupIDs {
			if rdb != nil {
				rdb.Set(context.Background(), fmt.Sprintf("resync:rate:%d", tgID), "1", time.Duration(rateLimitMinutes)*time.Minute)
			}
		}

		// Generate task ID and start async processing
		taskID := fmt.Sprintf("resync:%d", time.Now().UnixNano())
		taskKey := fmt.Sprintf("resync:task:%s", taskID)

		// Write initial task state to Redis
		taskState := gin.H{
			"task_id":         taskID,
			"status":          "pending",
			"total_sites":     len(bindings),
			"completed_sites": 0,
			"results":         []interface{}{},
		}
		if rdb != nil {
			stateJSON, _ := json.Marshal(taskState)
			rdb.Set(context.Background(), taskKey, stateJSON, 24*time.Hour)
		}

		// Start async goroutine for batch processing
		go processResyncBatch(taskKey, bindings, cfg, rdb)

		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"task_id": taskID, "total_sites": len(bindings)}})
	}
}

// ResyncTaskStatus returns the status of an async resync task.
// Requires X-Resync-Key header for authentication.
func ResyncTaskStatus(cfg *config.Config) gin.HandlerFunc {
	return func(c *gin.Context) {
		key := c.GetHeader("X-Resync-Key")
		if key == "" || key != cfg.Resync.SecretKey {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "invalid resync key", "data": ""})
			return
		}

		taskID := c.Param("task_id")
		taskKey := fmt.Sprintf("resync:task:%s", taskID)
		rdb := database.RDB
		if rdb == nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "redis_error", "msg": "Redis unavailable", "data": ""})
			return
		}

		stateJSON, err := rdb.Get(context.Background(), taskKey).Bytes()
		if err != nil {
			c.JSON(http.StatusNotFound, gin.H{"err": "not_found", "msg": "task not found", "data": ""})
			return
		}

		var state map[string]interface{}
		_ = json.Unmarshal(stateJSON, &state)
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": state})
	}
}

// processResyncBatch processes site bindings in batches with intervals.
func processResyncBatch(taskKey string, bindings []bindingmodel.SiteBinding, cfg *config.Config, rdb *redis.Client) {
	batchSize := cfg.Resync.BatchSize
	if batchSize <= 0 {
		batchSize = 5
	}
	batchInterval := time.Duration(cfg.Resync.BatchInterval) * time.Second
	if batchInterval <= 0 {
		batchInterval = 2 * time.Second
	}

	client := captain.GetDefault()
	results := make([]interface{}, 0, len(bindings))

	// Update status to running
	updateResyncTask(rdb, taskKey, "running", 0, results)

	completed := 0
	for i := 0; i < len(bindings); i += batchSize {
		end := i + batchSize
		if end > len(bindings) {
			end = len(bindings)
		}

		for j := i; j < end; j++ {
			b := bindings[j]
			instanceID := int(b.CaptainInstanceID)
			siteID := b.SiteID

			// Check if site is still valid in Captain
			detail, err := captainhandler.FetchSiteDetailForResync(client, instanceID, siteID)
			if err != nil || detail == nil {
				results = append(results, gin.H{
					"site_id":     siteID,
					"instance_id": instanceID,
					"status":      "invalid",
					"message":     "site no longer exists, consider manual cleanup",
				})
			} else {
				captainhandler.SyncSiteResourceMappings(instanceID, siteID, b.TenantGroupID)
				results = append(results, gin.H{
					"site_id":     siteID,
					"instance_id": instanceID,
					"status":      "success",
				})
			}
			completed++
		}

		// Update progress in Redis
		updateResyncTask(rdb, taskKey, "running", completed, results)

		// Wait between batches (except for the last batch)
		if end < len(bindings) {
			time.Sleep(batchInterval)
		}
	}

	// Final update: done
	updateResyncTask(rdb, taskKey, "done", completed, results)
}

func updateResyncTask(rdb *redis.Client, taskKey, status string, completed int, results []interface{}) {
	if rdb == nil {
		return
	}
	// Merge with existing state to preserve total_sites and task_id
	existingJSON, err := rdb.Get(context.Background(), taskKey).Bytes()
	if err == nil {
		var existing map[string]interface{}
		_ = json.Unmarshal(existingJSON, &existing)
		existing["status"] = status
		existing["completed_sites"] = completed
		existing["results"] = results
		mergedJSON, _ := json.Marshal(existing)
		rdb.Set(context.Background(), taskKey, mergedJSON, 24*time.Hour)
	}
}