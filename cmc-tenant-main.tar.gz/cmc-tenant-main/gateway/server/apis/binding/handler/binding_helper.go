package handler

import (
	"encoding/json"
	"fmt"
	"sort"
	"strconv"
	"strings"

	bindingbusiness "github.com/chaitin/cmc-tenant/domain/binding/business"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

const (
	siteModeSoftwareReverseProxy        = "Software Reverse Proxy"
	siteModeHardwareReverseProxy        = "Hardware Reverse Proxy"
	siteModeHardwareTransparentProxy    = "Hardware Transparent Proxy"
	siteModeHardwareTransparentBridge   = "Hardware Transparent Bridging"
	siteModeHardwarePortMirroring       = "Hardware Port Mirroring"
	siteModeSoftwareClusterReverseProxy = "Software Cluster Reverse Proxy"
	siteModeSoftwarePortMirroring       = "Software Port Mirroring"
	siteModeHardwareRouterProxy         = "Hardware Router Proxy"

	sitePathSoftwareReverseProxy        = "/api/SoftwareReverseProxyWebsiteAPI"
	sitePathHardwareReverseProxy        = "/api/WReverseProxyWebsiteAPI"
	sitePathHardwareTransparentProxy    = "/api/HardwareTransparentProxyWebsiteAPI"
	sitePathHardwareTransparentBridge   = "/api/HardwareTransparentBridgingWebsiteAPI"
	sitePathHardwarePortMirroring       = "/api/HardwarePortMirroringWebsiteAPI"
	sitePathSoftwareClusterReverseProxy = "/api/SoftwareClusterReverseProxyWebsiteAPI"
	sitePathSoftwarePortMirroring       = "/api/SoftwarePortMirroringWebsiteAPI"
)

// availableWaf represents an unbound WAF instance for the frontend dropdown.
type availableWaf struct {
	CaptainInstanceID int    `json:"captain_instance_id"`
	InstanceName      string `json:"instance_name"`
	InstanceHost      string `json:"instance_host"`
	InstanceStatus    string `json:"instance_status"`
	Version           string `json:"version"`
}

type siteNameLookup struct {
	names         map[string]string
	knownInstance map[int]bool
}

func parsePositiveIntBind(s string) (int, error) {
	n, err := strconv.Atoi(s)
	if err != nil || n <= 0 {
		return 0, fmt.Errorf("参数错误")
	}
	return n, nil
}

func parsePositiveUintBind(s string) (uint, error) {
	n, err := parsePositiveIntBind(s)
	if err != nil {
		return 0, err
	}
	return uint(n), nil
}

func tenantGroupExists(id uint) (bool, error) {
	if database.DB == nil {
		return false, fmt.Errorf("数据库未配置")
	}
	var count int64
	err := database.DB.Model(&tgmodel.TenantGroup{}).
		Where("id = ? AND is_deleted = false", id).
		Count(&count).Error
	return count > 0, err
}

func fetchInstanceMap(_ ...int) map[int]map[string]interface{} {
	m, _ := fetchInstanceMapWithStatus()
	return m
}

func fetchInstanceMapWithStatus(_ ...int) (map[int]map[string]interface{}, bool) {
	instances, ok := fetchCaptainWafInstances()
	if !ok {
		return nil, false
	}
	m := make(map[int]map[string]interface{}, len(instances))
	for _, inst := range instances {
		id := getInstanceID(inst)
		if id > 0 {
			m[id] = inst
		}
	}
	return m, true
}

func fetchCaptainWafInstances() ([]map[string]interface{}, bool) {
	client := captain.GetDefault()
	if client == nil {
		return nil, false
	}

	resp, err := client.Do(&captain.CaptainRequest{Method: "GET", Path: "/api/group/detail"})
	if err != nil {
		return nil, false
	}

	instances, ok := parseCaptainGroupDetailWafListOK(resp.Body)
	if !ok {
		return nil, false
	}
	return instances, true
}

func missingCaptainInstanceIDs(requested []int, instances []map[string]interface{}) []int {
	instanceSet := make(map[int]bool, len(instances))
	for _, inst := range instances {
		if id := getInstanceID(inst); id > 0 {
			instanceSet[id] = true
		}
	}

	seen := make(map[int]bool, len(requested))
	missing := make([]int, 0)
	for _, id := range requested {
		if id <= 0 || instanceSet[id] || seen[id] {
			continue
		}
		seen[id] = true
		missing = append(missing, id)
	}
	sort.Ints(missing)
	return missing
}

func joinIntIDs(ids []int) string {
	parts := make([]string, 0, len(ids))
	for _, id := range ids {
		parts = append(parts, strconv.Itoa(id))
	}
	return strings.Join(parts, ",")
}

func parseCaptainGroupDetailWafList(body []byte) []map[string]interface{} {
	items, _ := parseCaptainGroupDetailWafListOK(body)
	return items
}

func parseCaptainGroupDetailWafListOK(body []byte) ([]map[string]interface{}, bool) {
	var wrapper struct {
		Data struct {
			WafList []map[string]interface{} `json:"waf_list"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &wrapper); err != nil {
		return nil, false
	}
	if wrapper.Data.WafList == nil {
		return nil, false
	}
	return wrapper.Data.WafList, true
}

func fetchSiteNameLookup(instanceID *int, bindings []bindingmodel.SiteBinding) *siteNameLookup {
	lookup := &siteNameLookup{
		names:         make(map[string]string),
		knownInstance: make(map[int]bool),
	}
	if instanceID == nil {
		seen := make(map[int]bool)
		for _, b := range bindings {
			if seen[b.CaptainInstanceID] {
				continue
			}
			seen[b.CaptainInstanceID] = true
			addSiteNamesForInstance(lookup, b.CaptainInstanceID)
		}
		return lookup
	}
	addSiteNamesForInstance(lookup, *instanceID)
	return lookup
}

func addSiteNamesForInstance(lookup *siteNameLookup, instanceID int) {
	client := captain.GetDefault()
	if client == nil {
		return
	}
	idUint := uint(instanceID)
	captainPath, err := resolveSitePathForInstance(instanceID)
	if err != nil {
		return
	}
	resp, err := client.Do(&captain.CaptainRequest{
		Method: "GET", Path: captainPath, InstanceID: &idUint,
	})
	if err != nil {
		return
	}
	var captainResp struct {
		Data []map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &captainResp); err != nil {
		return
	}
	lookup.knownInstance[instanceID] = true
	for _, site := range captainResp.Data {
		id := getIDFromItem(site)
		if name, ok := site["name"].(string); ok {
			lookup.names[siteNameKey(instanceID, id)] = name
		}
	}
}

func resolveSitePathForInstance(instanceID int) (string, error) {
	instanceMap := fetchInstanceMap(instanceID)
	if inst, ok := instanceMap[instanceID]; ok {
		switch getFieldString(inst, "mode", "Mode") {
		case siteModeSoftwareReverseProxy:
			return sitePathSoftwareReverseProxy, nil
		case siteModeHardwareReverseProxy, siteModeHardwareRouterProxy:
			return sitePathHardwareReverseProxy, nil
		case siteModeHardwareTransparentProxy:
			return sitePathHardwareTransparentProxy, nil
		case siteModeHardwareTransparentBridge:
			return sitePathHardwareTransparentBridge, nil
		case siteModeHardwarePortMirroring:
			return sitePathHardwarePortMirroring, nil
		case siteModeSoftwareClusterReverseProxy:
			return sitePathSoftwareClusterReverseProxy, nil
		case siteModeSoftwarePortMirroring:
			return sitePathSoftwarePortMirroring, nil
		default:
			return "", fmt.Errorf("WAF 运行模式不支持或未识别: %s", getFieldString(inst, "mode", "Mode"))
		}
	}
	return "", fmt.Errorf("WAF 运行模式不支持或未识别")
}

func siteNameKey(instanceID int, siteID int) string {
	return fmt.Sprintf("%d/%d", instanceID, siteID)
}

func enrichWafBindings(bindings []bindingmodel.WafBinding, instanceMap map[int]map[string]interface{}) []bindingbusiness.WafBindingWithInfo {
	return enrichWafBindingsWithStatus(bindings, instanceMap, instanceMap != nil)
}

func enrichWafBindingsWithStatus(bindings []bindingmodel.WafBinding, instanceMap map[int]map[string]interface{}, instanceKnown bool) []bindingbusiness.WafBindingWithInfo {
	items := make([]bindingbusiness.WafBindingWithInfo, 0, len(bindings))
	for _, b := range bindings {
		item := bindingbusiness.WafBindingWithInfo{
			ID:                b.ID,
			TenantGroupID:     b.TenantGroupID,
			CaptainInstanceID: b.CaptainInstanceID,
			Status:            "unknown",
			CreatedAt:         b.CreatedAt.Format("2006-01-02T15:04:05Z"),
		}
		var group tgmodel.TenantGroup
		if database.DB != nil {
			database.DB.Where("id = ? AND is_deleted = false", b.TenantGroupID).First(&group)
			item.TenantGroupName = group.Name
		}
		if inst, ok := instanceMap[b.CaptainInstanceID]; ok {
			item.InstanceName = getFieldString(inst, "name", "Name")
			item.InstanceHost = getFieldString(inst, "host", "Host")
			item.OperationMode = getFieldString(inst, "mode", "Mode")
			item.InstanceStatus = getInstanceStatus(inst)
			item.IsEnabled = getFieldBoolPtr(inst, "is_enabled", "IsEnabled", "isEnabled")
			item.Version = getFieldString(inst, "version", "Version")
			item.Status = "active"
		} else if instanceKnown {
			item.Status = "invalid"
		}
		items = append(items, item)
	}
	return items
}

func attachBoundTenantGroups(items []bindingbusiness.WafBindingWithInfo) {
	if database.DB == nil || len(items) == 0 {
		return
	}
	instanceIDSet := make(map[int]bool, len(items))
	instanceIDs := make([]int, 0, len(items))
	for _, item := range items {
		if item.CaptainInstanceID <= 0 || instanceIDSet[item.CaptainInstanceID] {
			continue
		}
		instanceIDSet[item.CaptainInstanceID] = true
		instanceIDs = append(instanceIDs, item.CaptainInstanceID)
	}
	if len(instanceIDs) == 0 {
		return
	}

	var rows []struct {
		CaptainInstanceID int
		TenantGroupName   string
	}
	err := database.DB.Table("waf_bindings").
		Select("waf_bindings.captain_instance_id, tenant_groups.name AS tenant_group_name").
		Joins("JOIN tenant_groups ON tenant_groups.id = waf_bindings.tenant_group_id AND tenant_groups.is_deleted = ?", false).
		Where("waf_bindings.captain_instance_id IN ?", instanceIDs).
		Order("waf_bindings.id ASC").
		Scan(&rows).Error
	if err != nil {
		return
	}

	groupMap := make(map[int][]string, len(instanceIDs))
	seen := make(map[int]map[string]bool, len(instanceIDs))
	for _, row := range rows {
		if row.TenantGroupName == "" {
			continue
		}
		if seen[row.CaptainInstanceID] == nil {
			seen[row.CaptainInstanceID] = make(map[string]bool)
		}
		if seen[row.CaptainInstanceID][row.TenantGroupName] {
			continue
		}
		seen[row.CaptainInstanceID][row.TenantGroupName] = true
		groupMap[row.CaptainInstanceID] = append(groupMap[row.CaptainInstanceID], row.TenantGroupName)
	}
	for i := range items {
		items[i].BoundTenantGroups = strings.Join(groupMap[items[i].CaptainInstanceID], "，")
	}
}

func enrichSiteBindingsWithLookup(bindings []bindingmodel.SiteBinding, instanceMap map[int]map[string]interface{}, lookup *siteNameLookup) []bindingbusiness.SiteBindingWithInfo {
	items := make([]bindingbusiness.SiteBindingWithInfo, 0, len(bindings))
	for _, b := range bindings {
		item := bindingbusiness.SiteBindingWithInfo{
			ID:                b.ID,
			TenantGroupID:     b.TenantGroupID,
			CaptainInstanceID: b.CaptainInstanceID,
			SiteID:            b.SiteID,
			Status:            "unknown",
			CreatedAt:         b.CreatedAt.Format("2006-01-02T15:04:05Z"),
		}
		var group tgmodel.TenantGroup
		if database.DB != nil {
			database.DB.Where("id = ? AND is_deleted = false", b.TenantGroupID).First(&group)
			item.TenantGroupName = group.Name
		}
		if inst, ok := instanceMap[b.CaptainInstanceID]; ok {
			item.InstanceName = getFieldString(inst, "name", "Name")
		}
		if lookup != nil && lookup.knownInstance[b.CaptainInstanceID] {
			name, found := lookup.names[siteNameKey(b.CaptainInstanceID, b.SiteID)]
			if found {
				item.SiteName = name
				item.Status = "active"
			} else {
				// Site not found in Captain - may have been deleted
				item.SiteName = ""
				item.Status = "invalid"
			}
		}
		items = append(items, item)
	}
	return items
}

func getInstanceID(inst map[string]interface{}) int {
	if id := valueAsInt(inst["id"]); id > 0 {
		return id
	}
	return valueAsInt(inst["ID"])
}

func getIDFromItem(item map[string]interface{}) int {
	if id := valueAsInt(item["id"]); id > 0 {
		return id
	}
	return valueAsInt(item["ID"])
}

func valueAsInt(v interface{}) int {
	switch n := v.(type) {
	case float64:
		return int(n)
	case json.Number:
		i, _ := n.Int64()
		return int(i)
	case int:
		return n
	case uint:
		return int(n)
	default:
		return 0
	}
}

func getFieldString(inst map[string]interface{}, keys ...string) string {
	for _, key := range keys {
		if v, ok := inst[key].(string); ok {
			return v
		}
	}
	return ""
}

func getFieldBoolPtr(inst map[string]interface{}, keys ...string) *bool {
	for _, key := range keys {
		if v, ok := inst[key].(bool); ok {
			return &v
		}
	}
	return nil
}

func getInstanceStatus(inst map[string]interface{}) string {
	if status := getFieldString(inst, "online_status", "Status", "status", "OnlineStatus"); status != "" {
		return status
	}
	for _, key := range []string{"IsOnline", "is_online", "isOnline"} {
		if isOnline, ok := inst[key].(bool); ok {
			if isOnline {
				return "ONLINE"
			}
			return "OFFLINE"
		}
	}
	return "UNKNOWN"
}

// wafCondition 是 WAF 列表内存过滤的单条条件。
type wafCondition struct {
	Target string
	Oper   string
	Value  string
}

// filterByWafConditions 对 enriched 后的 WAF 列表做内存过滤，所有条件均需满足（AND 语义）。
func filterByWafConditions(items []bindingbusiness.WafBindingWithInfo, conds []wafCondition) []bindingbusiness.WafBindingWithInfo {
	if len(conds) == 0 {
		return items
	}
	result := items[:0]
	for _, item := range items {
		match := true
		for _, cond := range conds {
			var fieldVal string
			switch cond.Target {
			case "instance_name":
				fieldVal = item.InstanceName
			case "instance_status":
				fieldVal = item.InstanceStatus
			case "version":
				fieldVal = item.Version
			default:
				continue
			}
			if !matchWafField(fieldVal, cond.Oper, cond.Value) {
				match = false
				break
			}
		}
		if match {
			result = append(result, item)
		}
	}
	return result
}

// matchWafField 按 oper 对单个字段做匹配：= 精确，其余为大小写不敏感包含。
func matchWafField(fieldVal, oper, filterVal string) bool {
	if filterVal == "" {
		return true
	}
	if oper == "=" {
		return fieldVal == filterVal
	}
	return strings.Contains(strings.ToLower(fieldVal), strings.ToLower(filterVal))
}

func paginateWafBindingItems(items []bindingbusiness.WafBindingWithInfo, offset, count int) []bindingbusiness.WafBindingWithInfo {
	if offset < 0 {
		offset = 0
	}
	if count <= 0 {
		return items
	}
	if offset >= len(items) {
		return []bindingbusiness.WafBindingWithInfo{}
	}
	end := offset + count
	if end > len(items) {
		end = len(items)
	}
	return items[offset:end]
}
