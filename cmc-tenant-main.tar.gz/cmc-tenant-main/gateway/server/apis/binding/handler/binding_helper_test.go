package handler

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	bindingbusiness "github.com/chaitin/cmc-tenant/domain/binding/business"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	tgmodel "github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

const groupDetailResp = `{
  "data": {
    "waf_list": [
      {
        "id": 1,
        "name": "测试-软件反代",
        "host": "https://10.2.101.46:9443/",
        "version": "23.01.014_r6",
        "mode": "Software Reverse Proxy",
        "online_status": "UNHEALTHY"
      },
      {
        "id": 2,
        "name": "透明代理",
        "host": "https://10.2.68.79/",
        "version": "25.03.006",
        "mode": "Hardware Transparent Proxy",
        "online_status": "HEALTHY"
      }
    ]
  },
  "err": null,
  "msg": ""
}`

func TestWafBindingAvailableRejectsNonAdmin(t *testing.T) {
	gin.SetMode(gin.TestMode)

	r := gin.New()
	r.GET("/available", func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant_admin"})
		WafBindingAvailable()(c)
	})

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/available?tenant_group_id=1", nil)
	r.ServeHTTP(w, req)

	if w.Code != http.StatusForbidden {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusForbidden, w.Body.String())
	}
}

func TestWafBindingAvailableRejectsInvalidTenantGroupID(t *testing.T) {
	gin.SetMode(gin.TestMode)

	r := gin.New()
	r.GET("/available", func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		WafBindingAvailable()(c)
	})

	for _, id := range []string{"abc", "0", "-1"} {
		w := httptest.NewRecorder()
		req := httptest.NewRequest(http.MethodGet, "/available?tenant_group_id="+id, nil)
		r.ServeHTTP(w, req)

		if w.Code != http.StatusBadRequest {
			t.Fatalf("tenant_group_id=%s status = %d, want %d, body=%s", id, w.Code, http.StatusBadRequest, w.Body.String())
		}
	}
}

func TestWafBindingAvailableRejectsMissingTenantGroup(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&tgmodel.TenantGroup{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	r := gin.New()
	r.GET("/available", func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		WafBindingAvailable()(c)
	})

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/available?tenant_group_id=999", nil)
	r.ServeHTTP(w, req)

	if w.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusNotFound, w.Body.String())
	}
}

func TestWafBindingAvailableRequiresExistingTenantGroup(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&tgmodel.TenantGroup{}, &bindingmodel.WafBinding{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	if err := db.Create(&tgmodel.TenantGroup{ID: 1, Name: "测试组"}).Error; err != nil {
		t.Fatalf("create group: %v", err)
	}
	if err := db.Create(&bindingmodel.WafBinding{TenantGroupID: 1, CaptainInstanceID: 1}).Error; err != nil {
		t.Fatalf("create binding: %v", err)
	}

	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/group/detail" {
			t.Fatalf("path = %s, want /api/group/detail", r.URL.Path)
		}
		_, _ = w.Write([]byte(groupDetailResp))
	}))
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	r := gin.New()
	r.GET("/available", func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		WafBindingAvailable()(c)
	})

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/available?tenant_group_id=1", nil)
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusOK, w.Body.String())
	}
	var resp struct {
		Data []availableWaf `json:"data"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &resp); err != nil {
		t.Fatalf("decode response: %v", err)
	}
	if len(resp.Data) != 1 {
		t.Fatalf("len(data) = %d, want 1, body=%s", len(resp.Data), w.Body.String())
	}
	if got := resp.Data[0].CaptainInstanceID; got != 2 {
		t.Fatalf("CaptainInstanceID = %d, want 2", got)
	}
}

func TestWafBindingCreateRejectsEmptyInstanceIDs(t *testing.T) {
	gin.SetMode(gin.TestMode)

	r := gin.New()
	r.POST("/create", WafBindingCreate())

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/create", strings.NewReader(`{"tenant_group_id":1,"captain_instance_ids":[]}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusBadRequest {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusBadRequest, w.Body.String())
	}
}

func TestWafBindingCreateRejectsMissingTenantGroup(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&tgmodel.TenantGroup{}, &bindingmodel.WafBinding{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	r := gin.New()
	r.POST("/create", WafBindingCreate())

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/create", strings.NewReader(`{"tenant_group_id":999,"captain_instance_ids":[1]}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusNotFound, w.Body.String())
	}
}

func TestWafBindingCreateRejectsMissingCaptainInstance(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&tgmodel.TenantGroup{}, &bindingmodel.WafBinding{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	if err := db.Create(&tgmodel.TenantGroup{ID: 1, Name: "测试组"}).Error; err != nil {
		t.Fatalf("create group: %v", err)
	}

	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/group/detail" {
			t.Fatalf("path = %s, want /api/group/detail", r.URL.Path)
		}
		_, _ = w.Write([]byte(groupDetailResp))
	}))
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := gin.New()
	router.POST("/create", WafBindingCreate())

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/create", strings.NewReader(`{"tenant_group_id":1,"captain_instance_ids":[999]}`))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(w, req)

	if w.Code != http.StatusNotFound {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusNotFound, w.Body.String())
	}

	var count int64
	if err := db.Model(&bindingmodel.WafBinding{}).Count(&count).Error; err != nil {
		t.Fatalf("count bindings: %v", err)
	}
	if count != 0 {
		t.Fatalf("binding count = %d, want 0", count)
	}
}

func TestParseCaptainGroupDetailWafList(t *testing.T) {
	items := parseCaptainGroupDetailWafList([]byte(groupDetailResp))
	if len(items) != 2 {
		t.Fatalf("len(items) = %d, want 2", len(items))
	}
	if got := getInstanceID(items[1]); got != 2 {
		t.Fatalf("second id = %d, want 2", got)
	}
	if got := getFieldString(items[1], "name", "Name"); got != "透明代理" {
		t.Fatalf("second name = %q", got)
	}
}

func TestFetchInstanceMapUsesGroupDetail(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/group/detail" {
			t.Fatalf("path = %s, want /api/group/detail", r.URL.Path)
		}
		_, _ = w.Write([]byte(groupDetailResp))
	}))
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	m := fetchInstanceMap(2)
	inst, ok := m[2]
	if !ok {
		t.Fatalf("instance 2 not found in map: %#v", m)
	}
	if got := getFieldString(inst, "host", "Host"); got != "https://10.2.68.79/" {
		t.Fatalf("host = %q", got)
	}
	if got := getFieldString(inst, "version", "Version"); got != "25.03.006" {
		t.Fatalf("version = %q", got)
	}
}

func TestInstanceFieldHelpersSupportGroupDetailFields(t *testing.T) {
	inst := map[string]interface{}{
		"id":            float64(2),
		"name":          "透明代理",
		"host":          "https://10.2.68.79/",
		"version":       "25.03.006",
		"mode":          "Hardware Transparent Proxy",
		"online_status": "HEALTHY",
	}
	if got := getInstanceID(inst); got != 2 {
		t.Fatalf("id = %d, want 2", got)
	}
	if got := getFieldString(inst, "name", "Name"); got != "透明代理" {
		t.Fatalf("name = %q", got)
	}
	if got := getInstanceStatus(inst); got != "HEALTHY" {
		t.Fatalf("status = %q", got)
	}
}

func TestEnrichWafBindingsUsesLowercaseGroupDetailFields(t *testing.T) {
	oldDB := database.DB
	database.DB = nil
	defer func() { database.DB = oldDB }()

	bindings := []bindingmodel.WafBinding{{
		ID:                7,
		TenantGroupID:     1,
		CaptainInstanceID: 2,
		CreatedAt:         time.Date(2026, 6, 5, 18, 53, 31, 0, time.UTC),
	}}
	instanceMap := map[int]map[string]interface{}{
		2: {
			"id":            float64(2),
			"name":          "透明代理",
			"host":          "https://10.2.68.79/",
			"version":       "25.03.006",
			"mode":          "Hardware Transparent Proxy",
			"online_status": "HEALTHY",
		},
	}

	items := enrichWafBindings(bindings, instanceMap)
	if len(items) != 1 {
		t.Fatalf("len(items) = %d, want 1", len(items))
	}
	item := items[0]
	if item.InstanceName != "透明代理" {
		t.Fatalf("InstanceName = %q", item.InstanceName)
	}
	if item.InstanceHost != "https://10.2.68.79/" {
		t.Fatalf("InstanceHost = %q", item.InstanceHost)
	}
	if item.OperationMode != "Hardware Transparent Proxy" {
		t.Fatalf("OperationMode = %q", item.OperationMode)
	}
	if item.Version != "25.03.006" {
		t.Fatalf("Version = %q", item.Version)
	}
	if item.InstanceStatus != "HEALTHY" {
		t.Fatalf("InstanceStatus = %q", item.InstanceStatus)
	}
	if item.Status != "active" {
		t.Fatalf("Status = %q, want active", item.Status)
	}
}

func TestEnrichWafBindingsDistinguishesInvalidAndUnknown(t *testing.T) {
	oldDB := database.DB
	database.DB = nil
	defer func() { database.DB = oldDB }()

	bindings := []bindingmodel.WafBinding{{
		ID:                7,
		TenantGroupID:     1,
		CaptainInstanceID: 2,
		CreatedAt:         time.Date(2026, 6, 5, 18, 53, 31, 0, time.UTC),
	}}

	invalidItems := enrichWafBindingsWithStatus(bindings, map[int]map[string]interface{}{}, true)
	if got := invalidItems[0].Status; got != "invalid" {
		t.Fatalf("Status = %q, want invalid", got)
	}

	unknownItems := enrichWafBindingsWithStatus(bindings, nil, false)
	if got := unknownItems[0].Status; got != "unknown" {
		t.Fatalf("Status = %q, want unknown", got)
	}
}

func TestAttachBoundTenantGroupsUsesAllBindingsForPageInstances(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&tgmodel.TenantGroup{}, &bindingmodel.WafBinding{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	groups := []tgmodel.TenantGroup{
		{ID: 1, Name: "测试组"},
		{ID: 2, Name: "开发组"},
		{ID: 3, Name: "已删除组", IsDeleted: true},
	}
	if err := db.Create(&groups).Error; err != nil {
		t.Fatalf("create groups: %v", err)
	}
	bindings := []bindingmodel.WafBinding{
		{TenantGroupID: 1, CaptainInstanceID: 7},
		{TenantGroupID: 2, CaptainInstanceID: 7},
		{TenantGroupID: 3, CaptainInstanceID: 7},
	}
	if err := db.Create(&bindings).Error; err != nil {
		t.Fatalf("create bindings: %v", err)
	}

	items := []bindingbusiness.WafBindingWithInfo{{
		ID:                bindings[0].ID,
		TenantGroupID:     1,
		TenantGroupName:   "测试组",
		CaptainInstanceID: 7,
	}}
	attachBoundTenantGroups(items)

	if got := items[0].BoundTenantGroups; got != "测试组，开发组" {
		t.Fatalf("BoundTenantGroups = %q, want %q", got, "测试组，开发组")
	}
}

func TestEnrichSiteBindingsDistinguishesInvalidAndUnknown(t *testing.T) {
	oldDB := database.DB
	database.DB = nil
	defer func() { database.DB = oldDB }()

	bindings := []bindingmodel.SiteBinding{{
		ID:                9,
		TenantGroupID:     1,
		CaptainInstanceID: 2,
		SiteID:            11,
		CreatedAt:         time.Date(2026, 6, 5, 18, 53, 31, 0, time.UTC),
	}}

	invalidLookup := &siteNameLookup{
		names:         map[string]string{},
		knownInstance: map[int]bool{2: true},
	}
	invalidItems := enrichSiteBindingsWithLookup(bindings, nil, invalidLookup)
	if got := invalidItems[0].Status; got != "invalid" {
		t.Fatalf("Status = %q, want invalid", got)
	}

	unknownLookup := &siteNameLookup{
		names:         map[string]string{},
		knownInstance: map[int]bool{},
	}
	unknownItems := enrichSiteBindingsWithLookup(bindings, nil, unknownLookup)
	if got := unknownItems[0].Status; got != "unknown" {
		t.Fatalf("Status = %q, want unknown", got)
	}
}

func TestPaginateWafBindingItemsHandlesNegativePagination(t *testing.T) {
	items := []bindingbusiness.WafBindingWithInfo{
		{ID: 1},
		{ID: 2},
	}

	got := paginateWafBindingItems(items, 0, -1)
	if len(got) != 2 {
		t.Fatalf("len(got) = %d, want full result", len(got))
	}

	got = paginateWafBindingItems(items, -10, 1)
	if len(got) != 1 || got[0].ID != 1 {
		t.Fatalf("got = %#v, want first item", got)
	}
}

func TestPaginateWafBindingItemsClampsOutOfRange(t *testing.T) {
	items := []bindingbusiness.WafBindingWithInfo{
		{ID: 1},
		{ID: 2},
	}

	got := paginateWafBindingItems(items, 1, 20)
	if len(got) != 1 || got[0].ID != 2 {
		t.Fatalf("got = %#v, want second item", got)
	}

	got = paginateWafBindingItems(items, 20, 1)
	if len(got) != 0 {
		t.Fatalf("len(got) = %d, want empty result", len(got))
	}
}
