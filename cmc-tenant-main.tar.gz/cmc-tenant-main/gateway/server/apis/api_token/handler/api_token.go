// Package handler implements API token HTTP handlers.
package handler

import (
	"net/http"

	"github.com/chaitin/cmc-tenant/domain/api_token/business"
	"github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var tokenOp = business.NewAPITokenOperator()

// APITokenCreate handles API token creation.
func APITokenCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*model.User)

		var req struct {
			Name       string `json:"name" binding:"required"`
			Remark     string `json:"remark"`
			ExpireTime string `json:"expire_time"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		raw, err := tokenOp.Create(u.ID, req.Name, req.Remark, req.ExpireTime)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"token": raw}})
	}
}

// APITokenList handles API token listing.
func APITokenList() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*model.User)
		offset, count := utils.ParsePagination(c)

		total, tokens, err := tokenOp.List(u.ID, offset, count)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"total": total, "items": tokens}})
	}
}

// APITokenDelete handles API token deletion.
func APITokenDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*model.User)

		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}
		if err := tokenOp.Delete(req.IDs, u.ID); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}
