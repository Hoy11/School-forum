// Package handler provides HTTP handlers for highlight IP management.
package handler

import (
	"net/http"

	"github.com/chaitin/cmc-tenant/domain/highlight_ip/business"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/utils"
	"github.com/gin-gonic/gin"
)

var hipOp = business.NewHighlightIPOperator()

func requireAdmin(c *gin.Context) bool {
	user, _ := c.Get("user")
	u := user.(*usermodel.User)
	if u.Role != "admin" {
		utils.ErrorForbidden(c, "仅管理员可执行此操作")
		return false
	}
	return true
}

// HighlightIPList returns a paginated list of highlight IPs.
func HighlightIPList() gin.HandlerFunc {
	return func(c *gin.Context) {
		offset, count := utils.ParsePagination(c)
		total, records, err := hipOp.List(offset, count)
		if err != nil {
			utils.ErrorInternal(c, err.Error())
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"total": total, "items": records}})
	}
}

// HighlightIPCreate adds a new highlight IP entry.
func HighlightIPCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !requireAdmin(c) {
			return
		}
		var req struct {
			IP      string `json:"ip" binding:"required"`
			Color   string `json:"color"`
			Comment string `json:"comment"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		record, err := hipOp.Create(req.IP, req.Comment, req.Color)
		if err != nil {
			utils.ErrorBadRequest(c, err.Error())
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": record})
	}
}

// HighlightIPUpdate modifies an existing highlight IP entry.
func HighlightIPUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !requireAdmin(c) {
			return
		}
		var req struct {
			ID      uint   `json:"id" binding:"required"`
			IP      string `json:"ip"`
			Color   string `json:"color"`
			Comment string `json:"comment"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		if err := hipOp.Update(req.ID, req.IP, req.Comment, req.Color); err != nil {
			utils.ErrorBadRequest(c, err.Error())
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

// HighlightIPDelete removes highlight IP entries by IDs.
func HighlightIPDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !requireAdmin(c) {
			return
		}
		var req struct {
			IDs []uint `json:"ids"`
			All bool   `json:"all"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			utils.ErrorBadRequest(c, "参数错误")
			return
		}
		var ids []uint
		if req.All {
			ids = nil
		} else {
			if len(req.IDs) == 0 {
				utils.ErrorBadRequest(c, "ids 不能为空")
				return
			}
			ids = req.IDs
		}
		if err := hipOp.Delete(ids); err != nil {
			utils.ErrorInternal(c, err.Error())
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}
