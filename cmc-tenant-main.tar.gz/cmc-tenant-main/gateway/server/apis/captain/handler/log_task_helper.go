package handler

import (
	"encoding/json"

	"github.com/chaitin/cmc-tenant/pkg/database"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/gin-gonic/gin"
)

func checkLogTaskOwnership(taskID int, c *gin.Context) bool {
	if isAdmin(c) {
		return true
	}
	tgID := getTenantGroupID(c)
	var count int64
	database.DB.Model(&bindingmodel.CaptainLogTask{}).
		Where("captain_task_id = ? AND tenant_group_id = ?", taskID, tgID).
		Count(&count)
	return count > 0
}

func filterLogTasksByMapping(body []byte, tenantGroupID uint) []byte {
	var tasks []int
	database.DB.Model(&bindingmodel.CaptainLogTask{}).
		Where("tenant_group_id = ?", tenantGroupID).
		Pluck("captain_task_id", &tasks)

	taskMap := make(map[int]bool, len(tasks))
	for _, t := range tasks {
		taskMap[t] = true
	}

	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	// Captain returns {items: [...], total: N} paginated format
	var page struct {
		Items []map[string]interface{} `json:"items"`
		Total int                      `json:"total"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	filtered := make([]map[string]interface{}, 0, len(page.Items))
	for _, item := range page.Items {
		id := getIDFromItem(item)
		if taskMap[id] {
			filtered = append(filtered, item)
		}
	}

	page.Items = filtered
	page.Total = len(tasks)
	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}
