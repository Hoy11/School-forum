package handler

import (
	"net/http"
	"strconv"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	riskguard "github.com/chaitin/cmc-tenant/pkg/risk_guard"
	"github.com/gin-gonic/gin"
)

func getUser(c *gin.Context) *usermodel.User {
	u, _ := c.Get("user")
	return u.(*usermodel.User)
}

func isAdmin(c *gin.Context) bool {
	return getUser(c).Role == "admin"
}

func getAllowedWafIDs(c *gin.Context) []int {
	ids, _ := c.Get("allowed_waf_ids")
	if ids == nil {
		return nil
	}
	return ids.([]int)
}

func getTenantGroupID(c *gin.Context) uint {
	id, _ := c.Get("tenant_group_id")
	if id == nil {
		return 0
	}
	switch v := id.(type) {
	case uint:
		return v
	case *uint:
		if v != nil {
			return *v
		}
	}
	return 0
}

func getInstanceID(c *gin.Context) (int, bool) {
	idStr := c.Query("captain_instance_id")
	if idStr == "" {
		var body map[string]interface{}
		if c.Request.Method != "GET" {
			_ = c.ShouldBindJSON(&body)
		}
		if v, ok := body["captain_instance_id"]; ok {
			switch val := v.(type) {
			case float64:
				return int(val), true
			case string:
				n, _ := strconv.Atoi(val)
				return n, true
			}
		}
		return 0, false
	}
	n, _ := strconv.Atoi(idStr)
	return n, true
}

func checkInstanceAccess(c *gin.Context, instanceID int) bool {
	if isAdmin(c) {
		return true
	}
	for _, id := range getAllowedWafIDs(c) {
		if id == instanceID {
			return true
		}
	}
	return false
}

func proxyRequest(c *gin.Context, req *captain.CaptainRequest) {
	client := captain.GetDefault()
	breaker := captain.GetDefaultBreaker()
	if breaker != nil {
		if err := breaker.Allow(); err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "breaker_open", "msg": "纵横服务暂不可用", "data": ""})
			return
		}
	}

	resp, err := client.Do(req)
	if err != nil {
		if breaker != nil {
			breaker.RecordFailure()
		}
		if _, ok := err.(*captain.ErrCaptainUnauthorized); ok {
			c.JSON(http.StatusBadGateway, gin.H{"err": "captain_auth", "msg": "纵横认证失败", "data": ""})
			return
		}
		c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
		return
	}

	if breaker != nil {
		if resp.StatusCode >= 500 {
			breaker.RecordFailure()
		} else {
			breaker.RecordSuccess()
		}
	}

	if resp.StatusCode == http.StatusUnauthorized {
		c.JSON(http.StatusBadGateway, gin.H{"err": "captain_auth", "msg": "纵横认证失败", "data": ""})
		return
	}

	c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
}

func runRiskGuard(c *gin.Context, instanceID int, body map[string]interface{}) bool {
	if isAdmin(c) {
		return true
	}
	result := riskguard.RunAll(instanceID, getTenantGroupID(c), body)
	if !result.Pass {
		c.JSON(result.Code, gin.H{"err": "risk_check", "msg": result.Message, "data": ""})
		return false
	}
	return true
}
