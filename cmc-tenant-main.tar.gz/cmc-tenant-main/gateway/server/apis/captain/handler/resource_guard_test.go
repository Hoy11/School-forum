package handler

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

func TestRequirePositiveQueryIDRejectsInvalidInput(t *testing.T) {
	gin.SetMode(gin.TestMode)
	cases := []string{"", "?id=0", "?id=-1", "?id=abc"}
	for _, query := range cases {
		c, w := testContext("/cert/detail" + query)
		if id, ok := requirePositiveQueryID(c, "id"); ok || id != 0 {
			t.Fatalf("query %q accepted id=%d", query, id)
		}
		if w.Code != http.StatusBadRequest {
			t.Fatalf("query %q status=%d", query, w.Code)
		}
	}
}

func TestRequirePositiveFormIDRejectsInvalidInput(t *testing.T) {
	gin.SetMode(gin.TestMode)
	cases := []map[string][]string{
		{},
		{"id": []string{"0"}},
		{"id": []string{"-1"}},
		{"id": []string{"abc"}},
	}
	for _, values := range cases {
		c, w := testContext("/cert/edit")
		if id, ok := requirePositiveFormID(c, values, "id"); ok || id != 0 {
			t.Fatalf("form %v accepted id=%d", values, id)
		}
		if w.Code != http.StatusBadRequest {
			t.Fatalf("form %v status=%d", values, w.Code)
		}
	}
}

func TestRequirePositiveResourceIDsSupportsBatchDelete(t *testing.T) {
	gin.SetMode(gin.TestMode)
	body := map[string]interface{}{"ids": []interface{}{float64(1), "2"}}
	c, _ := testContext("/cert/delete")
	ids, ok := requirePositiveResourceIDs(c, body, mappingCert)
	if !ok || len(ids) != 2 || ids[0] != 1 || ids[1] != 2 {
		t.Fatalf("unexpected ids=%v ok=%v", ids, ok)
	}
}

func TestRequirePositiveResourceIDsRejectsMissingID(t *testing.T) {
	gin.SetMode(gin.TestMode)
	c, w := testContext("/cert/delete")
	ids, ok := requirePositiveResourceIDs(c, map[string]interface{}{}, mappingCert)
	if ok || ids != nil {
		t.Fatalf("missing id accepted ids=%v", ids)
	}
	if w.Code != http.StatusBadRequest {
		t.Fatalf("status=%d", w.Code)
	}
}

func TestExtractSiteDeleteIDsSupportsKnownFormats(t *testing.T) {
	body := map[string]interface{}{
		"id__in":   []interface{}{float64(1), "2"},
		"ids":      []interface{}{float64(2), float64(3)},
		"site_ids": []interface{}{"4"},
		"id":       "5",
		"ID":       float64(6),
	}
	ids := extractSiteDeleteIDs(body)
	want := []int{1, 2, 3, 4, 5, 6}
	if len(ids) != len(want) {
		t.Fatalf("len(ids)=%d want=%d ids=%v", len(ids), len(want), ids)
	}
	for i := range want {
		if ids[i] != want[i] {
			t.Fatalf("ids[%d]=%d want=%d ids=%v", i, ids[i], want[i], ids)
		}
	}
}

func TestResolveSiteReadPathRequiresKnownInstanceMode(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/group/detail" {
			t.Fatalf("path=%s want /api/group/detail", r.URL.Path)
		}
		_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":1,"mode":"Hardware Transparent Proxy"},{"id":2,"mode":"Software Reverse Proxy"},{"id":3,"mode":"Unknown Mode"}]}}`))
	}))
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	path, err := resolveSiteReadPath(1)
	if err != nil || path != sitePathHardwareTransparentProxy {
		t.Fatalf("transparent path=%q err=%v", path, err)
	}
	path, err = resolveSiteReadPath(2)
	if err != nil || path != sitePathSoftwareReverseProxy {
		t.Fatalf("reverse path=%q err=%v", path, err)
	}
	if _, err = resolveSiteReadPath(3); err == nil {
		t.Fatal("unknown mode should return error")
	}
}

func TestResolveSiteCreatePathRejectsModeMismatch(t *testing.T) {
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":1,"mode":"Hardware Transparent Proxy"}]}}`))
	}))
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	_, err := resolveSiteCreatePath(1, map[string]interface{}{"operation_mode": "Software Reverse Proxy"})
	if err == nil {
		t.Fatal("mismatched operation_mode should return error")
	}
	path, err := resolveSiteCreatePath(1, map[string]interface{}{"operation_mode": "Hardware Transparent Proxy"})
	if err != nil || path != sitePathHardwareTransparentProxy {
		t.Fatalf("path=%q err=%v", path, err)
	}
}

func testContext(target string) (*gin.Context, *httptest.ResponseRecorder) {
	w := httptest.NewRecorder()
	c, _ := gin.CreateTestContext(w)
	c.Request = httptest.NewRequest(http.MethodGet, target, nil)
	return c, w
}
