package handler

import (
	"fmt"
	"net/http"
	"strconv"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

func requirePositiveQueryID(c *gin.Context, key string) (int, bool) {
	id, ok := extractResourceIDFromQuery(c, key)
	if !ok || id <= 0 {
		rejectInvalidID(c)
		return 0, false
	}
	return id, true
}

func requirePositiveFormID(c *gin.Context, values map[string][]string, key string) (int, bool) {
	ids, ok := values[key]
	if !ok || len(ids) == 0 {
		rejectInvalidID(c)
		return 0, false
	}
	id, err := strconv.Atoi(ids[0])
	if err != nil || id <= 0 {
		rejectInvalidID(c)
		return 0, false
	}
	return id, true
}

func requirePositiveResourceID(c *gin.Context, body map[string]interface{}, table mappingTable) (int, bool) {
	id := extractResourceID(body, table)
	if id <= 0 {
		rejectInvalidID(c)
		return 0, false
	}
	return id, true
}

func requirePositiveResourceIDs(c *gin.Context, body map[string]interface{}, table mappingTable) ([]int, bool) {
	if id := extractResourceID(body, table); id > 0 {
		return []int{id}, true
	}
	ids := extractIDList(body["id__in"])
	if len(ids) == 0 {
		ids = extractIDList(body["ids"])
	}
	if len(ids) == 0 {
		rejectInvalidID(c)
		return nil, false
	}
	for _, id := range ids {
		if id <= 0 {
			rejectInvalidID(c)
			return nil, false
		}
	}
	return ids, true
}

func requireCertOwner(c *gin.Context, instanceID int, certID int, readOnly bool) bool {
	if isAdmin(c) || isMappingOwner(mappingCert, instanceID, certID, getTenantGroupID(c)) {
		return true
	}
	// System certs (is_mgt_api_cert=true) are visible to all tenants in the cert list,
	// so tenants must also be able to read their details.
	if readOnly {
		detail := getCertDetail(captain.GetDefault(), instanceID, certID)
		if detail != nil && detail.isMgtAPICert {
			return true
		}
	}
	msg := "无权操作该资源"
	if readOnly {
		msg = "无权访问该资源"
	}
	c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": msg, "data": ""})
	return false
}

func blockSystemCertEdit(c *gin.Context, instanceID int, certID int) bool {
	if isAdmin(c) {
		return false
	}
	detail := getCertDetail(captain.GetDefault(), instanceID, certID)
	if detail != nil && detail.isMgtAPICert {
		c.JSON(http.StatusForbidden, gin.H{"err": "system_cert", "msg": "该证书为系统管理接口证书，无法编辑", "data": ""})
		return true
	}
	return false
}

func blockSystemCertDelete(c *gin.Context, instanceID int, certID int) bool {
	detail := getCertDetail(captain.GetDefault(), instanceID, certID)
	if detail != nil && detail.isMgtAPICert {
		c.JSON(http.StatusForbidden, gin.H{"err": "system_cert", "msg": "该证书为系统管理接口证书，无法删除", "data": ""})
		return true
	}
	return false
}

func blockProtectedCertEdit(c *gin.Context, instanceID int, certID int) bool {
	if isAdmin(c) {
		return false // admin 编辑由前端确认框代替，后端无需查 Captain API
	}
	detail := getCertDetail(captain.GetDefault(), instanceID, certID)
	if detail != nil && detail.isMgtAPICert {
		c.JSON(http.StatusForbidden, gin.H{"err": "system_cert", "msg": "该证书为系统管理接口证书，无法编辑", "data": ""})
		return true
	}
	if checkCertShared(instanceID, certID) {
		c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，不可编辑", "data": ""})
		return true
	}
	if err := checkCertEditProtection(c, instanceID, certID); err != nil {
		c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
		return true
	}
	return false
}

func blockProtectedCertDelete(c *gin.Context, instanceID int, certID int) bool {
	detail := getCertDetail(captain.GetDefault(), instanceID, certID)
	if detail != nil && detail.isMgtAPICert {
		c.JSON(http.StatusForbidden, gin.H{"err": "system_cert", "msg": "该证书为系统管理接口证书，无法删除", "data": ""})
		return true
	}
	if detail != nil && len(detail.websites) > 0 {
		msg := fmt.Sprintf("该SSL证书正在被 %d 个站点使用，无法删除", len(detail.websites))
		c.JSON(http.StatusForbidden, gin.H{"err": "in_use", "msg": msg, "data": ""})
		return true
	}
	if !isAdmin(c) {
		if checkCertShared(instanceID, certID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，不可删除", "data": ""})
			return true
		}
	}
	return false
}

func extractIDList(raw interface{}) []int {
	arr, ok := raw.([]interface{})
	if !ok {
		return nil
	}
	ids := make([]int, 0, len(arr))
	for _, item := range arr {
		ids = append(ids, extractIntID(item))
	}
	return ids
}

func rejectInvalidID(c *gin.Context) {
	c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "id 参数必填且有效", "data": ""})
}
