package handler

import (
	"strconv"

	"github.com/gin-gonic/gin"
)

func extractResourceIDFromQuery(c *gin.Context, key string) (int, bool) {
	v := c.Query(key)
	if v == "" {
		return 0, false
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return 0, false
	}
	return n, true
}

func extractIDsFromBody(body map[string]interface{}) []int {
	raw, ok := body["ids"]
	if !ok {
		return nil
	}
	arr, ok := raw.([]interface{})
	if !ok {
		return nil
	}
	result := make([]int, 0, len(arr))
	for _, v := range arr {
		if f, ok := v.(float64); ok {
			result = append(result, int(f))
		}
	}
	return result
}
