package handler

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync"
	"testing"

	"github.com/chaitin/cmc-tenant/config"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	riskguard "github.com/chaitin/cmc-tenant/pkg/risk_guard"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

type capturedCaptainRequest struct {
	Method string
	Path   string
	Query  string
}

type fakeCaptainRecorder struct {
	mu       sync.Mutex
	requests []capturedCaptainRequest
}

func (r *fakeCaptainRecorder) append(req capturedCaptainRequest) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.requests = append(r.requests, req)
}

func (r *fakeCaptainRecorder) lastNonGroupDetail() (capturedCaptainRequest, bool) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for i := len(r.requests) - 1; i >= 0; i-- {
		if r.requests[i].Path != "/api/group/detail" {
			return r.requests[i], true
		}
	}
	return capturedCaptainRequest{}, false
}

func (r *fakeCaptainRecorder) hasWritePath(path string) bool {
	r.mu.Lock()
	defer r.mu.Unlock()
	for _, req := range r.requests {
		if req.Path == path && req.Method != http.MethodGet {
			return true
		}
	}
	return false
}

func TestSiteAPIDynamicCaptainPaths(t *testing.T) {
	gin.SetMode(gin.TestMode)
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":1,"mode":"Software Reverse Proxy"},{"id":2,"mode":"Hardware Transparent Proxy"}]}}`))
		case sitePathSoftwareReverseProxy, sitePathHardwareTransparentProxy:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":[{"id":101,"name":"site"}]}`))
		case "/api/WorkGroupAPI":
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":[{"name":"wg"}]}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouter()

	assertSiteAPIPath(t, router, recorder, http.MethodGet, "/api/captain/site/list?captain_instance_id=1", nil, sitePathSoftwareReverseProxy, "")
	assertSiteAPIPath(t, router, recorder, http.MethodGet, "/api/captain/site/list?captain_instance_id=2", nil, sitePathHardwareTransparentProxy, "")
	assertSiteAPIPath(t, router, recorder, http.MethodPost, "/api/captain/site", siteAPIBody(2, siteModeHardwareTransparentProxy), sitePathHardwareTransparentProxy, "")
	assertSiteAPIPath(t, router, recorder, http.MethodPut, "/api/captain/site", siteAPIBody(2, siteModeHardwareTransparentProxy), sitePathHardwareTransparentProxy, "")
	assertSiteAPIPath(t, router, recorder, http.MethodDelete, "/api/captain/site", map[string]interface{}{"captain_instance_id": 2, "id": 101}, sitePathHardwareTransparentProxy, "")
	assertSiteAPIPath(t, router, recorder, http.MethodGet, "/api/captain/site/aux/work-group-list?captain_instance_id=1", nil, "/api/WorkGroupAPI", "from=Website")
	assertSiteAPIPath(t, router, recorder, http.MethodGet, "/api/captain/site/aux/work-group-list?captain_instance_id=2", nil, "/api/WorkGroupAPI", "from=TransparentProxyWebsite")
}

func TestSiteAPIRejectsMismatchedOperationMode(t *testing.T) {
	gin.SetMode(gin.TestMode)
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		if r.URL.Path == "/api/group/detail" {
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Hardware Transparent Proxy"}]}}`))
			return
		}
		http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodPost, "/api/captain/site", siteAPIBody(2, siteModeSoftwareReverseProxy))
	if resp.Code != http.StatusBadRequest {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusBadRequest, resp.Body.String())
	}
	if req, ok := recorder.lastNonGroupDetail(); ok {
		t.Fatalf("mismatched operation_mode should not proxy site request, got %+v", req)
	}
}

func TestSiteAPIRejectsTransparentProxyAddrsIPPortConflict(t *testing.T) {
	gin.SetMode(gin.TestMode)
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case sitePathHardwareTransparentProxy:
			if r.Method == http.MethodGet {
				_, _ = w.Write([]byte(`{"data":[{"id":202,"addrs":[{"ip_port":"10.10.0.10:8080"}]}]}`))
				return
			}
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":303}}`))
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Hardware Transparent Proxy"}]}}`))
		case "/api/SiteAPI":
			_, _ = w.Write([]byte(`{"data":[{"id":202,"ip":"10.10.0.10","port":8080}]}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	client := captain.NewCaptainClient(captainServer.URL, "token", 5, 0)
	captain.SetDefault(client)
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()
	if err := database.DB.Create(&bindingmodel.SiteBinding{
		TenantGroupID:     2,
		CaptainInstanceID: 2,
		SiteID:            202,
	}).Error; err != nil {
		t.Fatalf("seed other tenant site binding: %v", err)
	}
	if err := database.DB.Create(&bindingmodel.SiteBinding{
		TenantGroupID:     1,
		CaptainInstanceID: 2,
		SiteID:            101,
	}).Error; err != nil {
		t.Fatalf("seed own tenant site binding: %v", err)
	}

	riskguard.Init(client, &config.RiskGuardConfig{WAFCooldownSec: 30})
	router := newSiteAPITestRouterWithRole("tenant")

	for _, method := range []string{http.MethodPost, http.MethodPut} {
		resp := performSiteAPIRequest(router, method, "/api/captain/site", siteAPIBody(2, siteModeHardwareTransparentProxy))
		if resp.Code != http.StatusForbidden {
			t.Fatalf("%s status=%d want=%d body=%s", method, resp.Code, http.StatusForbidden, resp.Body.String())
		}
		if !strings.Contains(resp.Body.String(), "该站点已被其他业务占用") {
			t.Fatalf("%s body=%s want occupied-site conflict message", method, resp.Body.String())
		}
	}

	if recorder.hasWritePath(sitePathHardwareTransparentProxy) {
		t.Fatalf("conflicting transparent proxy addrs should be rejected before proxying to %s", sitePathHardwareTransparentProxy)
	}
}

func newSiteAPITestRouter() *gin.Engine {
	return newSiteAPITestRouterWithRole("admin")
}

func newSiteAPITestRouterWithRole(role string) *gin.Engine {
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: role})
		c.Set("tenant_group_id", uint(1))
		c.Set("allowed_waf_ids", []int{1, 2})
		c.Next()
	})
	router.GET("/api/captain/site/list", SiteList())
	router.GET("/api/captain/site/detail", SiteDetail())
	router.GET("/api/captain/site/aux/work-group-list", SiteAuxWorkGroupList())
	router.POST("/api/captain/site", SiteCreate())
	router.PUT("/api/captain/site", SiteUpdate())
	router.DELETE("/api/captain/site", SiteDelete())
	return router
}

func newSiteAPITestDB(t *testing.T) *gorm.DB {
	t.Helper()
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.SiteBinding{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	return db
}

func siteAPIBody(instanceID int, mode string) map[string]interface{} {
	return map[string]interface{}{
		"captain_instance_id": instanceID,
		"id":                  101,
		"name":                "site",
		"operation_mode":      mode,
		"addrs": []map[string]interface{}{
			{"ip_port": "10.10.0.10:8080", "ssl": false, "http2": false, "sni": false, "non_http": false},
		},
	}
}

func assertSiteAPIPath(t *testing.T, router *gin.Engine, recorder *fakeCaptainRecorder, method, target string, body interface{}, wantPath, wantQueryContains string) {
	t.Helper()
	resp := performSiteAPIRequest(router, method, target, body)
	if resp.Code >= http.StatusBadRequest {
		t.Fatalf("%s %s status=%d body=%s", method, target, resp.Code, resp.Body.String())
	}
	req, ok := recorder.lastNonGroupDetail()
	if !ok {
		t.Fatalf("%s %s did not proxy any Captain site request", method, target)
	}
	if req.Path != wantPath {
		t.Fatalf("%s %s proxied path=%s want=%s all=%+v", method, target, req.Path, wantPath, recorder.requests)
	}
	if wantQueryContains != "" && !strings.Contains(req.Query, wantQueryContains) {
		t.Fatalf("%s %s proxied query=%q want contains %q", method, target, req.Query, wantQueryContains)
	}
}

func performSiteAPIRequest(router *gin.Engine, method, target string, body interface{}) *httptest.ResponseRecorder {
	var bodyReader *bytes.Reader
	if body == nil {
		bodyReader = bytes.NewReader(nil)
	} else {
		raw, _ := json.Marshal(body)
		bodyReader = bytes.NewReader(raw)
	}
	req := httptest.NewRequest(method, target, bodyReader)
	if body != nil {
		req.Header.Set("Content-Type", "application/json")
	}
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)
	return resp
}
