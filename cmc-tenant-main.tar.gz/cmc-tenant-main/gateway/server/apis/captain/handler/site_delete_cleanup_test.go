package handler

import (
	"testing"
	"time"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func TestCleanupDeletedSiteBindingsKeepsTenantResourceMappings(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.SiteBinding{}, &bindingmodel.CaptainPolicyBinding{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	now := time.Now()
	if err := db.Create(&bindingmodel.SiteBinding{
		TenantGroupID:     1,
		CaptainInstanceID: 1,
		SiteID:            100,
		CreatedAt:         now,
	}).Error; err != nil {
		t.Fatalf("seed site binding: %v", err)
	}
	if err := db.Create(&bindingmodel.CaptainPolicyBinding{
		CaptainInstanceID: 1,
		PolicyID:          10,
		TenantGroupID:     1,
		Source:            "inherited",
		CreatedAt:         now,
	}).Error; err != nil {
		t.Fatalf("seed policy binding: %v", err)
	}

	cleanupDeletedSiteBindings(1, []int{100})

	var siteBindingCount int64
	if err := db.Model(&bindingmodel.SiteBinding{}).Count(&siteBindingCount).Error; err != nil {
		t.Fatalf("count site bindings: %v", err)
	}
	if siteBindingCount != 0 {
		t.Fatalf("site bindings count=%d want=0", siteBindingCount)
	}

	var policyBindingCount int64
	if err := db.Model(&bindingmodel.CaptainPolicyBinding{}).Count(&policyBindingCount).Error; err != nil {
		t.Fatalf("count policy bindings: %v", err)
	}
	if policyBindingCount != 1 {
		t.Fatalf("policy bindings count=%d want=1", policyBindingCount)
	}
}
