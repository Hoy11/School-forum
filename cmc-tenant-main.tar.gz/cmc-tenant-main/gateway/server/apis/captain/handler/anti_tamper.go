package handler

import (
	"net/http"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

// AntiTamperRuleList proxies anti-tamper rule list queries to Captain.
func AntiTamperRuleList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		query := c.Request.URL.RawQuery
		path := "/api/AntiTamperRuleAPI"
		if query != "" {
			path = path + "?" + query
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       path,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		c.Data(resp.StatusCode, "application/json", wrapListAsPage(resp.Body))
	}
}
