package handler

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

// injectLogTaskSiteFilter 取出 body[filterKey]（不存在则新建空 map），
// 调用 inject 注入站点级过滤，再写回 body。
func injectLogTaskSiteFilter(body map[string]interface{}, filterKey string, allowedSiteIDs []int, inject func(map[string]interface{}, []int)) {
	filter, _ := body[filterKey].(map[string]interface{})
	if filter == nil {
		filter = make(map[string]interface{})
	}
	inject(filter, allowedSiteIDs)
	body[filterKey] = filter
}

// LogTaskCreate proxies log download task creation to Captain.
func LogTaskCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		logType, _ := body["name"].(string)
		if ok := validateLogTaskCreateBody(body); !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		if _, ok := body["conditions"]; ok {
			if logType == "detect_log" {
				if err := rewriteDetectLogWebsiteNameConditions(c, body); err != nil {
					c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
					return
				}
			}
			convertConditionsToBasicFilter(body, logType)
			moveTopLevelFiltersToSubFilter(body, logType)
		}

		if !isAdmin(c) {
			captain.InjectLogTaskFilter(body, getAllowedWafIDs(c), logType)
			switch logType {
			case "detect_log":
				injectLogTaskSiteFilter(body, "detect_log_filter", getAllowedSiteIDs(c), captain.InjectDetectLogSiteFilter)
			case "bot_record_log", "bot_result_log":
				injectLogTaskSiteFilter(body, "bot_log_filter", getAllowedSiteIDs(c), captain.InjectBotLogSiteFilter)
			}
		}

		client := captain.GetDefault()
		var existingTaskIDs map[int]bool
		if !isAdmin(c) {
			existingTaskIDs = fetchLogTaskIDSet(client)
		}

		req := &captain.CaptainRequest{
			Method: "POST",
			Path:   "/api/log/task/create",
			Body:   body,
		}

		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 {
			taskID := extractIDFromResp(resp.Body)
			if taskID == 0 && !isAdmin(c) && isCaptainRespSuccess(resp.Body) {
				taskID = fetchLatestLogTaskID(client, logType, fmt.Sprintf("%v", body["type"]), existingTaskIDs)
			}
			if taskID > 0 {
				record := bindingmodel.CaptainLogTask{CaptainTaskID: taskID}
				if !isAdmin(c) {
					tgID := getTenantGroupID(c)
					record.TenantGroupID = &tgID
				}
				database.DB.Create(&record)
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// LogTaskList proxies log task list queries to Captain.
func LogTaskList() gin.HandlerFunc {
	return func(c *gin.Context) {
		req := &captain.CaptainRequest{
			Method: "GET",
			Path:   "/api/log/task/list",
			Query:  c.Request.URL.RawQuery,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var result []byte
		if isAdmin(c) {
			result = normalizeLogTaskListResp(resp.Body)
		} else {
			filtered := filterLogTasksByMapping(resp.Body, getTenantGroupID(c))
			result = normalizeLogTaskListResp(filtered)
		}
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(result))
	}
}

// LogTaskCancel proxies log task cancellation to Captain.
func LogTaskCancel() gin.HandlerFunc {
	return func(c *gin.Context) {
		taskID, ok := parsePathID(c)
		if !ok {
			return
		}
		if !checkLogTaskOwnership(taskID, c) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该任务", "data": ""})
			return
		}
		req := &captain.CaptainRequest{
			Method: "PUT",
			Path:   "/api/log/task/" + strconv.Itoa(taskID) + "/cancel",
		}
		proxyRequest(c, req)
	}
}

// LogTaskDelete proxies log task deletion to Captain.
func LogTaskDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}
		if !isAdmin(c) {
			if all, _ := body["all"].(bool); all {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "非管理员不支持批量删除全部任务，请指定具体任务 ID", "data": ""})
				return
			}
			ids := extractIDsFromBody(body)
			if len(ids) == 0 {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "ids 参数必填", "data": ""})
				return
			}
			for _, id := range ids {
				if !checkLogTaskOwnership(id, c) {
					c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该任务", "data": ""})
					return
				}
			}
		}
		req := &captain.CaptainRequest{
			Method: "DELETE",
			Path:   "/api/log/task/delete",
			Body:   body,
		}
		proxyRequest(c, req)
	}
}

// LogTaskDownload proxies log task download to Captain.
// Unlike other handlers, this returns binary data (ZIP), so we must NOT use
// proxyRequest which wraps responses as JSON via wrapCaptainResp.
func LogTaskDownload() gin.HandlerFunc {
	return func(c *gin.Context) {
		taskID, ok := parsePathID(c)
		if !ok {
			return
		}
		if !checkLogTaskOwnership(taskID, c) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该任务", "data": ""})
			return
		}
		req := &captain.CaptainRequest{
			Method: "POST",
			Path:   "/api/log/task/" + strconv.Itoa(taskID) + "/download",
		}
		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}
		c.Data(resp.StatusCode, "application/octet-stream", resp.Body)
	}
}

func parsePathID(c *gin.Context) (int, bool) {
	parts := strings.Split(c.Request.URL.Path, "/")
	for i := len(parts) - 1; i >= 0; i-- {
		if n, err := strconv.Atoi(parts[i]); err == nil {
			return n, true
		}
	}
	c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "无效的任务 ID", "data": ""})
	return 0, false
}

var logTaskReservedKeys = map[string]bool{
	"name": true, "type": true, "ids": true, "all": true,
	"detect_log_filter": true, "acl_log_filter": true, "bot_log_filter": true,
}

func validateLogTaskCreateBody(body map[string]interface{}) bool {
	name, _ := body["name"].(string)
	switch name {
	case "detect_log", "acl_log", "bot_record_log", "bot_result_log":
	default:
		return false
	}

	format, _ := body["type"].(string)
	if format != "json" && format != "csv" {
		return false
	}

	all, _ := body["all"].(bool)
	if all {
		return true
	}

	ids, ok := body["ids"].([]interface{})
	return ok && len(ids) > 0
}

func isCaptainRespSuccess(body []byte) bool {
	var resp struct {
		Err json.RawMessage `json:"err"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return false
	}
	return len(resp.Err) == 0 || string(resp.Err) == "null"
}

func fetchLogTaskIDSet(client *captain.CaptainClient) map[int]bool {
	resp, err := client.Do(&captain.CaptainRequest{
		Method: "GET",
		Path:   "/api/log/task/list",
		Query:  "offset=0&count=100",
	})
	if err != nil || resp.StatusCode >= 300 {
		return nil
	}
	return extractLogTaskIDSetFromListResp(resp.Body)
}

func fetchLatestLogTaskID(client *captain.CaptainClient, name, format string, existing map[int]bool) int {
	resp, err := client.Do(&captain.CaptainRequest{
		Method: "GET",
		Path:   "/api/log/task/list",
		Query:  "offset=0&count=10",
	})
	if err != nil || resp.StatusCode >= 300 {
		return 0
	}
	return extractLatestLogTaskIDFromListResp(resp.Body, name, format, existing)
}

func extractLogTaskIDSetFromListResp(body []byte) map[int]bool {
	var resp struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil
	}
	result := make(map[int]bool, len(resp.Data.Items))
	for _, item := range resp.Data.Items {
		if id := getIDFromItem(item); id > 0 {
			result[id] = true
		}
	}
	return result
}

func extractLatestLogTaskIDFromListResp(body []byte, name, format string, existing map[int]bool) int {
	var resp struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return 0
	}
	for _, item := range resp.Data.Items {
		if fmt.Sprintf("%v", item["name"]) != name || fmt.Sprintf("%v", item["type"]) != format {
			continue
		}
		id := getIDFromItem(item)
		if id > 0 && !existing[id] {
			return id
		}
	}
	return 0
}

func moveTopLevelFiltersToSubFilter(body map[string]interface{}, logType string) {
	var filterKey string
	switch logType {
	case "detect_log":
		filterKey = "detect_log_filter"
	case "acl_log":
		filterKey = "acl_log_filter"
	case "bot_record_log", "bot_result_log":
		filterKey = "bot_log_filter"
	default:
		return
	}

	filter, _ := body[filterKey].(map[string]interface{})
	if filter == nil {
		filter = make(map[string]interface{})
	}

	for k, v := range body {
		if !logTaskReservedKeys[k] {
			filter[k] = v
			delete(body, k)
		}
	}

	body[filterKey] = filter
}

func normalizeLogTaskListResp(body []byte) []byte {
	var resp struct {
		Err  json.RawMessage `json:"err"`
		Msg  json.RawMessage `json:"msg"`
		Data struct {
			Items []map[string]interface{} `json:"items"`
			Total int                      `json:"total"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}
	normalizeLogTaskFields(resp.Data.Items)
	out, _ := json.Marshal(resp)
	return out
}

func normalizeLogTaskFields(items []map[string]interface{}) {
	for _, item := range items {
		if state, ok := item["state"]; ok {
			item["status"] = mapTaskState(fmt.Sprintf("%v", state))
			delete(item, "state")
		}
		startStr, _ := item["start_time"].(string)
		endStr, _ := item["end_time"].(string)
		if startStr != "" {
			item["created_at"] = formatUnixTimestamp(startStr)
		}
		if startStr != "" && endStr != "" {
			item["consumed_time"] = computeConsumedTime(startStr, endStr)
		}
	}
}

func mapTaskState(state string) string {
	switch state {
	case "Done":
		return "completed"
	case "Running":
		return "running"
	case "Failed":
		return "failed"
	case "Canceled", "Cancelled":
		return "canceled"
	default:
		return state
	}
}

func formatUnixTimestamp(unixStr string) string {
	n, err := strconv.ParseInt(unixStr, 10, 64)
	if err != nil {
		return unixStr
	}
	return time.Unix(n, 0).Format("2006-01-02 15:04:05")
}

func computeConsumedTime(startStr, endStr string) string {
	s, err1 := strconv.ParseInt(startStr, 10, 64)
	e, err2 := strconv.ParseInt(endStr, 10, 64)
	if err1 != nil || err2 != nil || e < s {
		return ""
	}
	d := time.Duration(e-s) * time.Second
	h := int(d.Hours())
	m := int(d.Minutes()) % 60
	sec := int(d.Seconds()) % 60
	return fmt.Sprintf("%02d:%02d:%02d", h, m, sec)
}
