package handler

import (
	"encoding/json"
	"fmt"
	"log"

	"github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

// --- Protection helpers for policy ---

// captainRespHasError checks if a Captain API response body indicates a failure.
// Captain often returns HTTP 200 with {"err": "error", "msg": "..."} when an operation
// fails (e.g., deleting a policy that's in use). We must not treat this as success.
func captainRespHasError(body []byte) bool {
	var wrapper struct {
		Err interface{} `json:"err"`
	}
	if err := json.Unmarshal(body, &wrapper); err != nil {
		return true // unparseable = treat as error
	}
	if wrapper.Err == nil {
		return false
	}
	// err=null is success; err="error" or err=anything-else is failure
	switch v := wrapper.Err.(type) {
	case nil:
		return false
	case string:
		return v != ""
	case bool:
		return v
	}
	return true
}

// fetchAllSites fetches all sites for a WAF instance from Captain.
func fetchAllSites(instanceID int) []map[string]interface{} {
	captainPath, err := resolveSiteReadPath(instanceID)
	if err != nil {
		log.Printf("[WARN] fetchAllSites: %v", err)
		return nil
	}
	idUint := uint(instanceID)
	req := &captain.CaptainRequest{
		Method:     "GET",
		Path:       captainPath,
		Query:      "count=10000&offset=0",
		InstanceID: &idUint,
	}
	resp, err := captain.GetDefault().Do(req)
	if err != nil {
		log.Printf("[WARN] fetchAllSites: Captain request error: %v", err)
		return nil
	}

	var wrapper struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	// Try paginated format first
	if err := json.Unmarshal(resp.Body, &wrapper); err == nil && len(wrapper.Data.Items) > 0 {
		return wrapper.Data.Items
	}

	// Try bare array format
	var items []map[string]interface{}
	if err := json.Unmarshal(resp.Body, &items); err == nil && len(items) > 0 {
		return items
	}

	// Try wrapper with bare data array
	var bareWrapper struct {
		Data []map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &bareWrapper); err == nil && len(bareWrapper.Data) > 0 {
		return bareWrapper.Data
	}

	return nil
}

// getPolicySiteCount counts how many sites reference the given policy via policy_group field.
func getPolicySiteCount(instanceID int, policyID int) int {
	sites := fetchAllSites(instanceID)
	if sites == nil {
		return 0
	}
	count := 0
	for _, site := range sites {
		if pg, ok := site["policy_group"]; ok {
			if extractIntID(pg) == policyID {
				count++
			}
		}
	}
	return count
}

// checkPolicyExternalRef checks if any site referencing the given policy belongs to an external tenant group.
func checkPolicyExternalRef(instanceID int, policyID int, tenantGroupID uint) bool {
	allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	sites := fetchAllSites(instanceID)
	if sites == nil {
		return false
	}
	for _, site := range sites {
		if pg, ok := site["policy_group"]; ok && extractIntID(pg) == policyID {
			if siteID := extractIntID(site["id"]); siteID > 0 && !allowedSet[siteID] {
				return true
			}
		}
	}
	return false
}

// checkPolicyShared returns true if the policy is bound to more than one tenant group.
func checkPolicyShared(instanceID int, policyID int) bool {
	var count int64
	database.DB.Table("captain_policy_bindings").
		Where("captain_instance_id = ? AND policy_id = ?", instanceID, policyID).
		Count(&count)
	return count > 1
}

// getPolicyIsDefault queries Captain API to check if a policy is the default template.
func getPolicyIsDefault(client *captain.CaptainClient, instanceID int, policyID int) bool {
	if policyID <= 0 {
		return false
	}
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("/api/PolicyGroupAPI?id=%d", policyID),
		InstanceID: &idUint,
	})
	if err != nil {
		log.Printf("[WARN] getPolicyIsDefault: Captain API error for policy %d: %v", policyID, err)
		return false
	}
	if resp.StatusCode >= 300 {
		return false
	}

	var wrapper struct {
		Data map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return false
	}

	if v, ok := wrapper.Data["is_default"]; ok {
		if b, ok := v.(bool); ok {
			return b
		}
	}
	return false
}

// checkPolicyDefault checks if the policy is a default template and returns a protection error.
// This check applies to ALL users (including admin) — is_default deletion is a hard limit.
func checkPolicyDefault(_ *gin.Context, instanceID int, resourceID int) *protectionError {
	if resourceID <= 0 {
		return nil
	}
	client := captain.GetDefault()
	if getPolicyIsDefault(client, instanceID, resourceID) {
		return &protectionError{err: "system_default", msg: "该策略为默认防护策略模板，无法删除"}
	}
	return nil
}

// checkPolicyEditProtection checks edit protection for a policy:
// source=created → allow; otherwise check external reference.
// Only blocks non-admin; admin is handled via frontend confirmation dialogs.
func checkPolicyEditProtection(c *gin.Context, instanceID int, resourceID int) *protectionError {
	if isAdmin(c) || resourceID <= 0 {
		return nil // admin: backend does not block, frontend shows confirmation
	}
	tgID := getTenantGroupID(c)

	source := getMappingSource(mappingPolicy, instanceID, resourceID, tgID)
	if source == "created" {
		return nil // created + binding_count==1 → all referencing sites belong to this tenant
	}

	if checkPolicyExternalRef(instanceID, resourceID, tgID) {
		return &protectionError{err: "has_external_ref", msg: "该策略被其他租户组的站点引用，无法修改"}
	}
	return nil
}

// getReferencedSiteNames returns the names of sites that reference the given policy.
// Used for admin confirmation dialogs.
func getReferencedSiteNames(instanceID int, policyID int) []string {
	sites := fetchAllSites(instanceID)
	if sites == nil {
		return nil
	}
	names := []string{}
	for _, site := range sites {
		if pg, ok := site["policy_group"]; ok && extractIntID(pg) == policyID {
			if name, ok := site["name"].(string); ok && name != "" {
				names = append(names, name)
			}
		}
	}
	return names
}

// getSharedGroupNames returns the names of tenant groups that share the given policy.
// Used for admin confirmation dialogs.
func getSharedGroupNames(instanceID int, policyID int) []string {
	var groupIDs []uint
	database.DB.Table("captain_policy_bindings").
		Where("captain_instance_id = ? AND policy_id = ?", instanceID, policyID).
		Pluck("tenant_group_id", &groupIDs)
	if len(groupIDs) == 0 {
		return nil
	}

	var groups []model.TenantGroup
	database.DB.Where("id IN ? AND is_deleted = false", groupIDs).Find(&groups)

	names := make([]string, 0, len(groups))
	for _, g := range groups {
		names = append(names, g.Name)
	}
	return names
}

// injectPolicyProtectionFields adds site_count, source, has_external_ref, is_default to each policy item.
// Also adds shared_group_names and referenced_site_names for admin users.
// This is called for ALL users (spec24-5 first to inject for admin too).
func injectPolicyProtectionFields(body []byte, instanceID int, tenantGroupID uint, isAdm bool) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	if len(page.Items) == 0 {
		return body
	}

	// Collect policy IDs for batch source lookup
	policyIDs := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			policyIDs = append(policyIDs, id)
		}
	}

	// Batch query source from mapping table (only meaningful for non-admin)
	sourceMap := make(map[int]string)
	if !isAdm {
		sourceMap = getMappingSources(mappingPolicy, instanceID, tenantGroupID, policyIDs)
	}

	// Get allowed site IDs for external ref check (only meaningful for non-admin)
	allowedSet := make(map[int]bool)
	if !isAdm {
		allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
		for _, id := range allowedSites {
			allowedSet[id] = true
		}
	}

	// Fetch all sites once to build siteCountMap and externalRefMap
	siteCountMap := make(map[int]int)
	externalRefMap := make(map[int]bool)
	siteNameMap := make(map[int][]string) // policyID → site names (for admin)

	for _, site := range fetchAllSites(instanceID) {
		pg, ok := site["policy_group"]
		if !ok {
			continue
		}
		policyID := extractIntID(pg)
		if policyID <= 0 {
			continue
		}
		siteCountMap[policyID]++
		siteName, _ := site["name"].(string)

		if isAdm {
			// For admin: collect site names per policy
			siteNameMap[policyID] = append(siteNameMap[policyID], siteName)
		} else {
			// For non-admin: check if site belongs to this tenant
			siteID := extractIntID(site["id"])
			if siteID > 0 && !allowedSet[siteID] {
				externalRefMap[policyID] = true
			}
		}
	}

	// For admin: batch query shared group names for all shared policies
	sharedGroupNamesMap := make(map[int][]string)
	if isAdm {
		for _, id := range policyIDs {
			if checkPolicyShared(instanceID, id) {
				sharedGroupNamesMap[id] = getSharedGroupNames(instanceID, id)
			}
		}
	}

	for _, item := range page.Items {
		id := getIDFromItem(item)
		if id <= 0 {
			continue
		}

		// Inject site_count
		item["site_count"] = siteCountMap[id]

		// Inject is_default (extract from Captain API response directly)
		if v, ok := item["is_default"]; ok {
			// Already present in Captain response, keep it
			_ = v
		} else {
			item["is_default"] = false
		}

		if isAdm {
			// Admin: inject source as empty (admin doesn't have mappings)
			item["source"] = ""
			item["has_external_ref"] = false
			// Inject admin-specific fields
			if names, ok := sharedGroupNamesMap[id]; ok && len(names) > 0 {
				item["shared_group_names"] = names
			}
			if names, ok := siteNameMap[id]; ok && len(names) > 0 {
				item["referenced_site_names"] = names
			}
		} else {
			// Non-admin: inject source and has_external_ref
			if s, ok := sourceMap[id]; ok {
				item["source"] = s
			} else {
				item["source"] = "created"
			}
			item["has_external_ref"] = externalRefMap[id]
		}
	}

	pageData, _ := json.Marshal(page)
	resp["data"] = pageData
	result, _ := json.Marshal(resp)
	return result
}

// injectPolicyDetailProtectionFields injects protection fields into a single policy detail response.
func injectPolicyDetailProtectionFields(body []byte, c *gin.Context, instanceID int, policyID int, _ *captain.CaptainClient) []byte {
	var wrapper struct {
		Err  interface{}            `json:"err"`
		Msg  string                 `json:"msg"`
		Data map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(body, &wrapper); err != nil || wrapper.Data == nil {
		return body
	}

	isAdm := isAdmin(c)
	tgID := getTenantGroupID(c)

	// Inject source
	if isAdm {
		wrapper.Data["source"] = ""
	} else {
		wrapper.Data["source"] = getMappingSource(mappingPolicy, instanceID, policyID, tgID)
	}

	// Inject binding_count
	var bindingCount int64
	database.DB.Table("captain_policy_bindings").
		Where("captain_instance_id = ? AND policy_id = ?", instanceID, policyID).
		Count(&bindingCount)
	wrapper.Data["binding_count"] = bindingCount

	// Inject site_count
	siteCount := getPolicySiteCount(instanceID, policyID)
	wrapper.Data["site_count"] = siteCount

	// Inject is_default (from Captain response or re-fetch)
	if _, ok := wrapper.Data["is_default"]; !ok {
		wrapper.Data["is_default"] = false
	}

	// Inject has_external_ref
	if isAdm {
		wrapper.Data["has_external_ref"] = false
	} else {
		wrapper.Data["has_external_ref"] = checkPolicyExternalRef(instanceID, policyID, tgID)
	}

	// Admin-specific: inject shared_group_names and referenced_site_names
	if isAdm {
		if bindingCount > 1 {
			wrapper.Data["shared_group_names"] = getSharedGroupNames(instanceID, policyID)
		}
		if siteCount > 0 {
			wrapper.Data["referenced_site_names"] = getReferencedSiteNames(instanceID, policyID)
		}
	}

	result, _ := json.Marshal(wrapper)
	return result
}
