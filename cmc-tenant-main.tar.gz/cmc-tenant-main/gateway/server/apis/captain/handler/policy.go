package handler

import (
	"fmt"
	"net/http"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

// PolicyList proxies protection policy list queries to Captain.
func PolicyList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/PolicyGroupAPI",
			InstanceID: &idUint,
		}
		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var body []byte
		if isAdmin(c) {
			body = resp.Body
		} else {
			body = filterResponseByMapping(resp.Body, mappingPolicy, instanceID, getTenantGroupID(c))
		}

		body = wrapListAsPage(body)
		body = injectBindingCounts(body, mappingPolicy, instanceID)
		// spec24-5: inject protection fields for ALL users (including admin)
		body = injectPolicyProtectionFields(body, instanceID, getTenantGroupID(c), isAdmin(c))

		c.Data(resp.StatusCode, "application/json", body)
	}
}

// PolicyDetail proxies protection policy detail queries to Captain.
func PolicyDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		policyID, ok := requirePositiveQueryID(c, "id")
		if !ok {
			return
		}
		if !isAdmin(c) && !isMappingOwner(mappingPolicy, instanceID, policyID, getTenantGroupID(c)) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该资源", "data": ""})
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/PolicyGroupAPI",
			Query:      c.Request.URL.RawQuery,
			InstanceID: &idUint,
		}
		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		// spec24-5: inject protection fields into detail response
		resp.Body = injectPolicyDetailProtectionFields(resp.Body, c, instanceID, policyID, client)

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyCreate proxies protection policy creation to Captain.
func PolicyCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       "/api/PolicyGroupAPI",
			Body:       body,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 && !isAdmin(c) {
			if id := extractIDFromResp(resp.Body); id > 0 {
				writeMapping(mappingPolicy, instanceID, id, getTenantGroupID(c), "created")
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyUpdate proxies protection policy updates to Captain, with shared + edit protection.
func PolicyUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		resourceID := extractResourceID(body, mappingPolicy)

		// Ownership check (skip for admin)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingPolicy, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}

		// spec24-5: shared check (non-admin only)
		if !isAdmin(c) && resourceID > 0 && checkPolicyShared(instanceID, resourceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该策略被多个租户组共享，无法修改", "data": ""})
			return
		}

		// spec24-5: edit protection (non-admin only; admin backend does not block)
		if !isAdmin(c) {
			if err := checkPolicyEditProtection(c, instanceID, resourceID); err != nil {
				c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
				return
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/PolicyGroupAPI",
			Body:       body,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 && !captainRespHasError(resp.Body) && isAdmin(c) && resourceID > 0 {
			go reconcileBlockPageMappings(instanceID, resourceID)
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyDelete proxies protection policy deletion to Captain, with is_default + runtime + shared protection.
func PolicyDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		resourceID := extractResourceID(body, mappingPolicy)

		// spec24-5 step 1: is_default check (hard limit for ALL users, including admin)
		if resourceID > 0 {
			if err := checkPolicyDefault(c, instanceID, resourceID); err != nil {
				c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
				return
			}
		}

		// Ownership check (skip for admin)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingPolicy, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}

		// spec24-5 step 3: runtime protection — site_count > 0 (non-admin only; admin soft limit via frontend)
		if resourceID > 0 {
			siteCount := getPolicySiteCount(instanceID, resourceID)
			if siteCount > 0 && !isAdmin(c) {
				c.JSON(http.StatusForbidden, gin.H{
					"err":  "in_use",
					"msg":  fmt.Sprintf("该策略正在被 %d 个站点引用，无法删除", siteCount),
					"data": "",
				})
				return
			}
		}

		// spec24-5 step 4: shared check (non-admin only; admin soft limit via frontend)
		if resourceID > 0 && checkPolicyShared(instanceID, resourceID) && !isAdmin(c) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该策略被多个租户组共享，无法删除", "data": ""})
			return
		}

		// Build Captain delete request with id__in format
		captainBody := body
		if resourceID > 0 {
			captainBody = map[string]interface{}{
				"id__in": []interface{}{resourceID},
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "DELETE",
			Path:       "/api/PolicyGroupAPI",
			Body:       captainBody,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		// Captain may return HTTP 200 with {"err": "error", ...} when deletion fails
		// (e.g., policy in use by sites). Only clean up mappings when Captain actually
		// succeeded — err is null or absent.
		captainSuccess := resp.StatusCode < 300 && !captainRespHasError(resp.Body)
		if captainSuccess {
			// Clean up mapping for non-admin
			if !isAdmin(c) && resourceID > 0 {
				deleteMapping(mappingPolicy, instanceID, resourceID, getTenantGroupID(c))
			}
			// Clean up all mappings for admin (admin deletes WAF resource entirely)
			if isAdmin(c) && resourceID > 0 {
				database.DB.Table("captain_policy_bindings").
					Where("captain_instance_id = ? AND policy_id = ?", instanceID, resourceID).
					Delete(nil)
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyGlobalConfigGet proxies global policy config queries to Captain.
func PolicyGlobalConfigGet() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !isAdmin(c) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "仅管理员可访问", "data": ""})
			return
		}

		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/GlobalPolicyConfigAPI",
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicyGlobalConfigUpdate proxies global policy config updates to Captain.
func PolicyGlobalConfigUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		if !isAdmin(c) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "仅管理员可访问", "data": ""})
			return
		}

		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/GlobalPolicyConfigAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicySkynetRuleList proxies skynet rule list queries to Captain.
func PolicySkynetRuleList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/FilterV2API",
			Query:      c.Request.URL.RawQuery,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicySkynetRuleUpdate proxies skynet rule updates to Captain.
func PolicySkynetRuleUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/PolicyGroupSkynetRuleBindingAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}
