package handler

import (
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

func TestIsSiteOwner(t *testing.T) {
	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	if err := database.DB.Create(&bindingmodel.SiteBinding{
		TenantGroupID:     1,
		CaptainInstanceID: 2,
		SiteID:            101,
	}).Error; err != nil {
		t.Fatalf("seed site binding: %v", err)
	}

	if !isSiteOwner(2, 101, 1) {
		t.Fatal("isSiteOwner should return true for bound site")
	}
	if isSiteOwner(2, 999, 1) {
		t.Fatal("isSiteOwner should return false for unbound site")
	}
	if isSiteOwner(2, 101, 2) {
		t.Fatal("isSiteOwner should return false for other tenant group")
	}
}

func newSiteDetailCaptainServer(t *testing.T) *httptest.Server {
	t.Helper()
	return httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Software Reverse Proxy"}]}}`))
		case sitePathSoftwareReverseProxy:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101,"name":"site"}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
}

func TestSiteDetailRejectsUnboundSiteForNonAdmin(t *testing.T) {
	server := newSiteDetailCaptainServer(t)
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouterWithRole("tenant")
	resp := performSiteAPIRequest(router, http.MethodGet, "/api/captain/site/detail?captain_instance_id=2&id=101", nil)
	if resp.Code != http.StatusForbidden {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusForbidden, resp.Body.String())
	}
}

func TestSiteDetailAllowsBoundSiteForNonAdmin(t *testing.T) {
	server := newSiteDetailCaptainServer(t)
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()
	if err := database.DB.Create(&bindingmodel.SiteBinding{
		TenantGroupID:     1,
		CaptainInstanceID: 2,
		SiteID:            101,
	}).Error; err != nil {
		t.Fatalf("seed site binding: %v", err)
	}

	router := newSiteAPITestRouterWithRole("tenant")
	resp := performSiteAPIRequest(router, http.MethodGet, "/api/captain/site/detail?captain_instance_id=2&id=101", nil)
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
}

func TestSiteDetailAllowsAdminRegardlessOfBinding(t *testing.T) {
	server := newSiteDetailCaptainServer(t)
	defer server.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(server.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodGet, "/api/captain/site/detail?captain_instance_id=2&id=101", nil)
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
}

func TestSiteDeleteRejectsUnboundSiteForNonAdmin(t *testing.T) {
	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouterWithRole("tenant")
	resp := performSiteAPIRequest(router, http.MethodDelete, "/api/captain/site", map[string]interface{}{
		"captain_instance_id": 2,
		"id":                  101,
	})
	if resp.Code != http.StatusForbidden {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusForbidden, resp.Body.String())
	}
}

func TestSiteUpdateRejectsUnboundSiteForNonAdmin(t *testing.T) {
	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouterWithRole("tenant")
	resp := performSiteAPIRequest(router, http.MethodPut, "/api/captain/site", siteAPIBody(2, siteModeSoftwareReverseProxy))
	if resp.Code != http.StatusForbidden {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusForbidden, resp.Body.String())
	}
}

// 实例 mode 是通用类型，但目标站点真实 operation_mode 是 Hardware Transparent Proxy：
// 第一次按实例 mode 查到的端点缺 ip_port，探测到真实类型后二次查询命中专属端点，响应带 ip_port。
func TestSiteDetailProbesMismatchedSiteType(t *testing.T) {
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Software Reverse Proxy"}]}}`))
		case sitePathSoftwareReverseProxy:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101,"operation_mode":"Hardware Transparent Proxy"}}`))
		case sitePathHardwareTransparentProxy:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101,"operation_mode":"Hardware Transparent Proxy","ip_port":"10.10.0.10:8080"}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodGet, "/api/captain/site/detail?captain_instance_id=2&id=101", nil)
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
	if !strings.Contains(resp.Body.String(), "ip_port") {
		t.Fatalf("body=%s want ip_port from re-queried correct endpoint", resp.Body.String())
	}
}

// 实例 mode 与站点真实类型一致时，不应该发生二次探测请求（零额外开销不退化）。
func TestSiteDetailSkipsProbeWhenModeAlreadyMatches(t *testing.T) {
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Software Reverse Proxy"}]}}`))
		case sitePathSoftwareReverseProxy:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101,"operation_mode":"Software Reverse Proxy"}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodGet, "/api/captain/site/detail?captain_instance_id=2&id=101", nil)
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}

	siteRequests := 0
	for _, req := range recorder.requests {
		if req.Path == sitePathSoftwareReverseProxy {
			siteRequests++
		}
	}
	if siteRequests != 1 {
		t.Fatalf("expected exactly 1 call to %s, got %d", sitePathSoftwareReverseProxy, siteRequests)
	}
}

// 请求体带 operation_mode（跟实例 mode 不一致，但跟探测到的站点真实类型一致）时，
// SiteUpdate 信任 body 并路由到该 operation_mode 对应端点，不会因为跟实例 mode
// 不一致就 400（站点真实类型可能跟实例当前 mode 不一致，这正是该探测逻辑要处理的场景）。
func TestSiteUpdateTrustsBodyOperationModeOverInstanceMode(t *testing.T) {
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		switch {
		case r.URL.Path == "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Software Reverse Proxy"}]}}`))
		case r.URL.Path == sitePathSoftwareReverseProxy && r.Method == http.MethodGet:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101,"operation_mode":"Hardware Transparent Proxy"}}`))
		case r.URL.Path == sitePathHardwareTransparentProxy && r.Method == http.MethodPut:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodPut, "/api/captain/site", siteAPIBody(2, siteModeHardwareTransparentProxy))
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
	req, ok := recorder.lastNonGroupDetail()
	if !ok || req.Path != sitePathHardwareTransparentProxy {
		t.Fatalf("expected proxy to %s, got %+v ok=%v", sitePathHardwareTransparentProxy, req, ok)
	}
}

// 请求体带的 operation_mode 跟探测到的站点真实类型不一致时，必须在代理到纵横之前
// 就拒绝（400 + 含"不匹配"），不能因为"信任 body"而放过真正错误的类型声明。
func TestSiteUpdateRejectsBodyOperationModeMismatchingActualType(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch {
		case r.URL.Path == "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Software Reverse Proxy"}]}}`))
		case r.URL.Path == sitePathSoftwareReverseProxy && r.Method == http.MethodGet:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101,"operation_mode":"Hardware Transparent Proxy"}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodPut, "/api/captain/site", siteAPIBody(2, siteModeSoftwareReverseProxy))
	if resp.Code != http.StatusBadRequest {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusBadRequest, resp.Body.String())
	}
	if !strings.Contains(resp.Body.String(), "不匹配") {
		t.Fatalf("body=%s want mismatch message", resp.Body.String())
	}
}

// 请求体带 operation_mode，但探测站点真实类型失败（如站点不存在）时，
// 保守地跟实例 mode 核对，不一致仍要拒绝——对应真实集成测试里用不存在的
// site id 触发的"代理前拦截"场景。
func TestSiteUpdateRejectsBodyOperationModeWhenProbeFailsAndInstanceModeMismatches(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Hardware Transparent Proxy"}]}}`))
		default:
			http.Error(w, `{"err":"site_not_found"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodPut, "/api/captain/site", siteAPIBody(2, siteModeSoftwareReverseProxy))
	if resp.Code != http.StatusBadRequest {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusBadRequest, resp.Body.String())
	}
	if !strings.Contains(resp.Body.String(), "不匹配") {
		t.Fatalf("body=%s want mismatch message", resp.Body.String())
	}
}

// 请求体不带 operation_mode（模拟启用/禁用最小请求体），站点真实类型与实例 mode 不一致：
// 探测到真实类型后路由到正确端点。
func TestSiteUpdateProbesWhenBodyOmitsOperationMode(t *testing.T) {
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		switch {
		case r.URL.Path == "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Software Reverse Proxy"}]}}`))
		case r.URL.Path == sitePathSoftwareReverseProxy && r.Method == http.MethodGet:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101,"operation_mode":"Hardware Transparent Proxy"}}`))
		case r.URL.Path == sitePathHardwareTransparentProxy && r.Method == http.MethodPut:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodPut, "/api/captain/site", map[string]interface{}{
		"captain_instance_id": 2,
		"id":                  101,
		"is_enabled":          false,
	})
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
	if !recorder.hasWritePath(sitePathHardwareTransparentProxy) {
		t.Fatalf("expected PUT to %s after probing real site type, requests=%+v", sitePathHardwareTransparentProxy, recorder.requests)
	}
}

// 请求体不带 operation_mode 且探测请求失败（Captain 报错）时，回退到实例默认端点，不返回 500/挂死。
func TestSiteUpdateFallsBackToInstanceModeWhenProbeFails(t *testing.T) {
	recorder := &fakeCaptainRecorder{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		recorder.append(capturedCaptainRequest{Method: r.Method, Path: r.URL.Path, Query: r.URL.RawQuery})
		w.Header().Set("Content-Type", "application/json")
		switch {
		case r.URL.Path == "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":2,"mode":"Software Reverse Proxy"}]}}`))
		case r.URL.Path == sitePathSoftwareReverseProxy && r.Method == http.MethodGet:
			http.Error(w, `{"err":"site_not_found"}`, http.StatusNotFound)
		case r.URL.Path == sitePathSoftwareReverseProxy && r.Method == http.MethodPut:
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newSiteAPITestDB(t)
	defer func() { database.DB = oldDB }()

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodPut, "/api/captain/site", map[string]interface{}{
		"captain_instance_id": 2,
		"id":                  101,
		"is_enabled":          false,
	})
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
	if !recorder.hasWritePath(sitePathSoftwareReverseProxy) {
		t.Fatalf("expected fallback PUT to instance default path %s, requests=%+v", sitePathSoftwareReverseProxy, recorder.requests)
	}
}

func TestSiteCreateSanitizesFrontendDetailFields(t *testing.T) {
	var gotBody map[string]interface{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch {
		case r.URL.Path == "/api/group/detail":
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":1,"mode":"Software Reverse Proxy"}]}}`))
		case r.URL.Path == sitePathSoftwareReverseProxy && r.Method == http.MethodPost:
			if err := json.NewDecoder(r.Body).Decode(&gotBody); err != nil {
				t.Fatalf("decode Captain body: %v", err)
			}
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":101}}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newSiteAPITestRouter()
	resp := performSiteAPIRequest(router, http.MethodPost, "/api/captain/site", map[string]interface{}{
		"captain_instance_id":           1,
		"id":                            999,
		"create_time":                   123,
		"last_update_time":              456,
		"health_check_status":           "healthy",
		"name":                          "site",
		"operation_mode":                siteModeSoftwareReverseProxy,
		"session_sticky_cookie_max_age": nil,
		"backend_config": map[string]interface{}{
			"type":                          "proxy",
			"health_check_config":           map[string]interface{}{"is_enabled": false},
			"header_config":                 []interface{}{},
			"session_sticky_cookie_max_age": "",
			"keepalive":                     "",
			"keepalive_timeout":             "",
			"servers": []interface{}{
				map[string]interface{}{"host": "10.0.0.1", "port": 80, "weight": ""},
			},
		},
	})
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
	for _, key := range []string{"captain_instance_id", "id", "create_time", "last_update_time", "health_check_status"} {
		if _, ok := gotBody[key]; ok {
			t.Fatalf("Captain body should not include %q: %#v", key, gotBody)
		}
	}
	backend := gotBody["backend_config"].(map[string]interface{})
	for _, key := range []string{"health_check_config", "header_config", "session_sticky_cookie_max_age"} {
		if _, ok := backend[key]; ok {
			t.Fatalf("backend_config should not include %q: %#v", key, backend)
		}
	}
	if backend["keepalive"] != "0" || backend["keepalive_timeout"] != "0" {
		t.Fatalf("keepalive fields = %#v/%#v, want \"0\"", backend["keepalive"], backend["keepalive_timeout"])
	}
	servers := backend["servers"].([]interface{})
	if servers[0].(map[string]interface{})["weight"] != float64(1) {
		t.Fatalf("server weight = %#v, want 1", servers[0].(map[string]interface{})["weight"])
	}
}
