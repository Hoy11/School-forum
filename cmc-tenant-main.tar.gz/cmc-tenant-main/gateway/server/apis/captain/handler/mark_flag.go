package handler

import (
	"net/http"
	"strconv"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

// MarkFlagGet proxies mark flag queries to Captain.
func MarkFlagGet() gin.HandlerFunc {
	return func(c *gin.Context) {
		req := &captain.CaptainRequest{
			Method: "GET",
			Path:   "/api/mark/flag",
		}
		proxyRequest(c, req)
	}
}

// MarkFlagUpdate proxies mark flag updates to Captain.
func MarkFlagUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		req := &captain.CaptainRequest{
			Method: "PUT",
			Path:   "/api/mark/flag",
			Body:   body,
		}
		proxyRequest(c, req)
	}
}

// FilterList proxies saved filter list queries to Captain.
func FilterList() gin.HandlerFunc {
	return func(c *gin.Context) {
		req := &captain.CaptainRequest{
			Method: "GET",
			Path:   "/api/filter/save/list",
			Query:  c.Request.URL.RawQuery,
		}
		proxyRequest(c, req)
	}
}

// FilterCreate proxies saved filter creation to Captain.
func FilterCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		injectUserContext(c, body)

		req := &captain.CaptainRequest{
			Method: "POST",
			Path:   "/api/filter/save/create",
			Body:   body,
		}
		proxyRequest(c, req)
	}
}

// FilterUpdate proxies saved filter update to Captain.
func FilterUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		injectUserContext(c, body)

		req := &captain.CaptainRequest{
			Method: "PUT",
			Path:   "/api/filter/save/update",
			Body:   body,
		}
		proxyRequest(c, req)
	}
}

// FilterDelete proxies saved filter deletion to Captain.
func FilterDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID uint `json:"id" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		captainReq := &captain.CaptainRequest{
			Method: "DELETE",
			Path:   "/api/filter/save/" + strconv.Itoa(int(req.ID)) + "/delete",
		}
		proxyRequest(c, captainReq)
	}
}

func injectUserContext(c *gin.Context, body map[string]interface{}) {
	user, exists := c.Get("user")
	if !exists {
		return
	}
	u := user.(*usermodel.User)
	if _, ok := body["user_id"]; !ok {
		body["user_id"] = u.ID
	}
}
