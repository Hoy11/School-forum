package handler

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"time"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

type mappingTable string

const (
	mappingIPGroup    mappingTable = "captain_ip_group_bindings"
	mappingCert       mappingTable = "captain_cert_bindings"
	mappingPolicy     mappingTable = "captain_policy_bindings"
	mappingPolicyRule mappingTable = "captain_policy_rule_bindings"
	mappingBlockPage  mappingTable = "captain_block_page_bindings"
)

var errSiteDetailNotFound = errors.New("site detail not found")

func writeMapping(table mappingTable, instanceID int, resourceID int, tenantGroupID uint, source string) {
	col := getIDColumn(table)
	result := database.DB.Exec(
		fmt.Sprintf("INSERT INTO %s (captain_instance_id, %s, tenant_group_id, source, created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT DO NOTHING", string(table), col),
		instanceID, resourceID, tenantGroupID, source, time.Now().UTC(),
	)
	if result.Error != nil {
		log.Printf("[WARN] writeMapping %s (%d, %d, %d): %v", string(table), instanceID, resourceID, tenantGroupID, result.Error)
	}
}

func deleteMapping(table mappingTable, instanceID int, resourceID int, tenantGroupID uint) {
	database.DB.Table(string(table)).
		Where("captain_instance_id = ? AND "+getIDColumn(table)+" = ? AND tenant_group_id = ?",
			instanceID, resourceID, tenantGroupID).
		Delete(nil)
}

// writeMappingIfNotExists writes a mapping record only if it does not already exist.
func writeMappingIfNotExists(table mappingTable, instanceID int, resourceID int, tenantGroupID uint, source string) {
	if resourceID <= 0 {
		return
	}
	if isMappingOwner(table, instanceID, resourceID, tenantGroupID) {
		return
	}
	writeMapping(table, instanceID, resourceID, tenantGroupID, source)
}

// fetchSiteDetail calls Captain API to get a single site's detail.
func fetchSiteDetail(client *captain.CaptainClient, instanceID int, siteID int) (map[string]interface{}, error) {
	idUint := uint(instanceID)
	captainPath, err := resolveSiteReadPath(instanceID)
	if err != nil {
		return nil, err
	}
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("%s?id=%d", captainPath, siteID),
		InstanceID: &idUint,
	})
	if err != nil {
		return nil, fmt.Errorf("fetch site detail: %w", err)
	}

	var wrapper struct {
		Err  string      `json:"err"`
		Msg  string      `json:"msg"`
		Data interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil, fmt.Errorf("parse site detail: %w", err)
	}

	detail, ok := wrapper.Data.(map[string]interface{})
	if !ok {
		if wrapper.Err == "object-not-found" {
			return nil, fmt.Errorf("%w: site %d", errSiteDetailNotFound, siteID)
		}
		log.Printf("[DEBUG] fetchSiteDetail: unexpected data type=%T, body=%s", wrapper.Data, string(resp.Body))
		return nil, fmt.Errorf("site detail unexpected format")
	}
	return detail, nil
}

// FetchSiteDetailForResync is the exported version of fetchSiteDetail for use by the resync handler.
func FetchSiteDetailForResync(client *captain.CaptainClient, instanceID int, siteID int) (map[string]interface{}, error) {
	return fetchSiteDetail(client, instanceID, siteID)
}

// SyncSiteResourceMappings fetches site detail from Captain and writes mapping records
// for the site's associated policy, cert, IP groups, and policy rules.
func SyncSiteResourceMappings(instanceID int, siteID int, tenantGroupID uint) {
	client := captain.GetDefault()
	if client == nil {
		log.Printf("[WARN] SyncSiteResourceMappings: captain client not initialized, skip site %d", siteID)
		return
	}

	detail, err := fetchSiteDetail(client, instanceID, siteID)
	if err != nil {
		if errors.Is(err, errSiteDetailNotFound) {
			return
		}
		log.Printf("[WARN] SyncSiteResourceMappings: %v", err)
		return
	}

	if pgID := extractIntID(detail["policy_group"]); pgID > 0 {
		writeMappingIfNotExists(mappingPolicy, instanceID, pgID, tenantGroupID, "inherited")
	}

	if certID := extractIntID(detail["ssl_cert"]); certID > 0 {
		writeMappingIfNotExists(mappingCert, instanceID, certID, tenantGroupID, "inherited")
	}

	if groups, ok := detail["proxy_ip_groups"].([]interface{}); ok {
		for _, g := range groups {
			if id := extractIntID(g); id > 0 {
				writeMappingIfNotExists(mappingIPGroup, instanceID, id, tenantGroupID, "inherited")
			}
		}
	}

	syncSitePolicyRules(client, instanceID, siteID, tenantGroupID)
	syncSiteBlockPage(client, instanceID, detail, tenantGroupID)
}

// syncSitePolicyRules fetches non-global policy rules from Captain and writes mappings
// for rules whose "website" field matches the given siteID.
func syncSitePolicyRules(client *captain.CaptainClient, instanceID int, siteID int, tenantGroupID uint) {
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/PolicyRuleAPI",
		Query:      "is_global=false",
		InstanceID: &idUint,
	})
	if err != nil {
		log.Printf("[WARN] syncSitePolicyRules: %v", err)
		return
	}

	var items []map[string]interface{}
	var wrapper struct {
		Data []map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err == nil {
		items = wrapper.Data
	} else {
		var paginated struct {
			Data struct {
				Total int                      `json:"total"`
				Items []map[string]interface{} `json:"items"`
			} `json:"data"`
		}
		if err := json.Unmarshal(resp.Body, &paginated); err != nil {
			log.Printf("[WARN] syncSitePolicyRules: parse error: %v", err)
			return
		}
		items = paginated.Data.Items
	}

	for _, rule := range items {
		if matchRuleSite(rule, siteID) {
			if ruleID := extractIntID(rule["id"]); ruleID > 0 {
				writeMappingIfNotExists(mappingPolicyRule, instanceID, ruleID, tenantGroupID, "inherited")
			}
			for _, ipGroupID := range extractInGroupIDs(rule["pattern"]) {
				writeMappingIfNotExists(mappingIPGroup, instanceID, ipGroupID, tenantGroupID, "inherited")
			}
		}
	}
}

// prepareDeletedSiteBindingCleanup returns a callback that removes local site bindings
// after Captain confirms site deletion. Tenant resource mappings are intentionally kept:
// tenants may reuse those assets on new sites and should delete unused assets explicitly.
func prepareDeletedSiteBindingCleanup(instanceID int, siteIDs []int) func() {
	if len(siteIDs) == 0 {
		return nil
	}
	return func() {
		cleanupDeletedSiteBindings(instanceID, siteIDs)
	}
}

func cleanupDeletedSiteBindings(instanceID int, siteIDs []int) {
	if len(siteIDs) == 0 {
		return
	}
	if err := database.DB.
		Where("captain_instance_id = ? AND site_id IN ?", instanceID, siteIDs).
		Delete(&bindingmodel.SiteBinding{}).Error; err != nil {
		log.Printf("[WARN] cleanupDeletedSiteBindings: delete site bindings failed: %v", err)
	}
}

// findBlockPageIDByName queries Captain list API to find a block page id by its name (MD5 hash).
func findBlockPageIDByName(instanceID int, nameHash string) int {
	idUint := uint(instanceID)
	req := &captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/ForbiddenPageAPI",
		Query:      "count=1000&offset=0",
		InstanceID: &idUint,
	}
	resp, err := captain.GetDefault().Do(req)
	if err != nil {
		log.Printf("[DEBUG] findBlockPageIDByName: Captain request error: %v", err)
		return 0
	}

	var wrapper struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		log.Printf("[WARN] findBlockPageIDByName: parse error: %v", err)
		return 0
	}

	for _, item := range wrapper.Data.Items {
		if n, _ := item["name"].(string); n == nameHash {
			return getIDFromItem(item)
		}
	}
	return 0
}

// fetchPolicyDetail calls Captain API to get a single policy's detail.
func fetchPolicyDetail(client *captain.CaptainClient, instanceID int, policyID int) (map[string]interface{}, error) {
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("/api/PolicyGroupAPI?id=%d", policyID),
		InstanceID: &idUint,
	})
	if err != nil {
		return nil, fmt.Errorf("fetch policy detail: %w", err)
	}

	var wrapper struct {
		Data interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil, fmt.Errorf("parse policy detail: %w", err)
	}

	detail, ok := wrapper.Data.(map[string]interface{})
	if !ok {
		return nil, fmt.Errorf("policy detail unexpected format")
	}
	return detail, nil
}

// syncSiteBlockPage fetches the policy referenced by the site, extracts forbidden_page_config.path,
// and writes a block_page mapping if found.
func syncSiteBlockPage(client *captain.CaptainClient, instanceID int, siteDetail map[string]interface{}, tenantGroupID uint) {
	pgID := extractIntID(siteDetail["policy_group"])
	if pgID <= 0 {
		return
	}

	policyDetail, err := fetchPolicyDetail(client, instanceID, pgID)
	if err != nil {
		log.Printf("[WARN] syncSiteBlockPage: %v", err)
		return
	}

	fpc, ok := policyDetail["forbidden_page_config"].(map[string]interface{})
	if !ok {
		return
	}
	path, _ := fpc["path"].(string)
	if path == "" {
		return
	}

	bpID := findBlockPageIDByName(instanceID, path)
	if bpID > 0 {
		writeMappingIfNotExists(mappingBlockPage, instanceID, bpID, tenantGroupID, "inherited")
	}
}
