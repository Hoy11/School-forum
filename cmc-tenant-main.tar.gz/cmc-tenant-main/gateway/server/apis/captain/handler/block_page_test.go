package handler

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestGetBlockPageUsedCountFallsBackToPolicyReferences(t *testing.T) {
	const blockPageName = "fixture-block-page-hash"
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/ForbiddenPageAPI":
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"total":1,"items":[{"id":7,"name":"fixture-block-page-hash","policy_group_used_count":0}]}}`))
		case "/api/PolicyGroupAPI":
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":[{"id":1,"forbidden_page_config":{"path":"fixture-block-page-hash"}},{"id":2,"forbidden_page_config":{"path":"other"}}]}`))
		default:
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()
	withTestCaptainClient(t, captainServer.URL)

	if got := getBlockPageUsedCount(1, blockPageName); got != 1 {
		t.Fatalf("used count = %d, want fallback policy reference count 1", got)
	}
}
