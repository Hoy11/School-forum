package handler

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

// newPolicyRuleWriteTestRouter builds a minimal admin-context router for the
// given handler, mirroring the auth middleware fields other handler tests rely on.
func newPolicyRuleWriteTestRouter(method, path string, handler gin.HandlerFunc) *gin.Engine {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		c.Next()
	})
	router.Handle(method, path, handler)
	return router
}

func captureCaptainRequestBody(t *testing.T) (*httptest.Server, *map[string]interface{}) {
	t.Helper()
	var gotBody map[string]interface{}
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		_ = json.NewDecoder(r.Body).Decode(&gotBody)
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":1}}`))
	}))
	t.Cleanup(server.Close)
	return server, &gotBody
}

func withTestCaptainClient(t *testing.T, serverURL string) {
	t.Helper()
	old := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(serverURL, "token", 5, 0))
	t.Cleanup(func() { captain.SetDefault(old) })
}

func TestPolicyRuleUpdateForcesIsGlobalFalse(t *testing.T) {
	server, gotBody := captureCaptainRequestBody(t)
	withTestCaptainClient(t, server.URL)

	router := newPolicyRuleWriteTestRouter(http.MethodPut, "/api/captain/policy-rule/update", PolicyRuleUpdate())
	body := map[string]interface{}{
		"captain_instance_id": 1,
		"is_global":           true,
		"pattern":             map[string]interface{}{"uri": "/foo"},
	}
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest(http.MethodPut, "/api/captain/policy-rule/update", bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if (*gotBody)["is_global"] != false {
		t.Fatalf("is_global forwarded to Captain = %v, want false", (*gotBody)["is_global"])
	}
}

func TestPolicyRuleModulePostForcesIsGlobalFalse(t *testing.T) {
	server, gotBody := captureCaptainRequestBody(t)
	withTestCaptainClient(t, server.URL)

	router := newPolicyRuleWriteTestRouter(http.MethodPost, "/api/captain/policy-rule/module", PolicyRuleModulePost())
	body := map[string]interface{}{"captain_instance_id": 1, "is_global": true}
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest(http.MethodPost, "/api/captain/policy-rule/module", bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if (*gotBody)["is_global"] != false {
		t.Fatalf("is_global forwarded to Captain = %v, want false", (*gotBody)["is_global"])
	}
}

func TestPolicyRuleModulePutForcesIsGlobalFalse(t *testing.T) {
	server, gotBody := captureCaptainRequestBody(t)
	withTestCaptainClient(t, server.URL)

	router := newPolicyRuleWriteTestRouter(http.MethodPut, "/api/captain/policy-rule/module", PolicyRuleModulePut())
	body := map[string]interface{}{"captain_instance_id": 1, "is_global": true}
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest(http.MethodPut, "/api/captain/policy-rule/module", bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if (*gotBody)["is_global"] != false {
		t.Fatalf("is_global forwarded to Captain = %v, want false", (*gotBody)["is_global"])
	}
}

func TestPolicyRuleSkynetRulePutForcesIsGlobalFalse(t *testing.T) {
	server, gotBody := captureCaptainRequestBody(t)
	withTestCaptainClient(t, server.URL)

	router := newPolicyRuleWriteTestRouter(http.MethodPut, "/api/captain/policy-rule/skynet-rule", PolicyRuleSkynetRulePut())
	body := map[string]interface{}{"captain_instance_id": 1, "is_global": true}
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest(http.MethodPut, "/api/captain/policy-rule/skynet-rule", bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if (*gotBody)["is_global"] != false {
		t.Fatalf("is_global forwarded to Captain = %v, want false", (*gotBody)["is_global"])
	}
}

// TestPolicyRuleUpdateNormalRequestUnaffected is a regression check: a normal
// request without an is_global field still succeeds and forwards as before.
func TestPolicyRuleUpdateNormalRequestUnaffected(t *testing.T) {
	server, gotBody := captureCaptainRequestBody(t)
	withTestCaptainClient(t, server.URL)

	router := newPolicyRuleWriteTestRouter(http.MethodPut, "/api/captain/policy-rule/update", PolicyRuleUpdate())
	body := map[string]interface{}{
		"captain_instance_id": 1,
		"pattern":             map[string]interface{}{"uri": "/foo"},
	}
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest(http.MethodPut, "/api/captain/policy-rule/update", bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if (*gotBody)["pattern"] == nil {
		t.Fatalf("pattern not forwarded: %v", *gotBody)
	}
	if (*gotBody)["is_global"] != false {
		t.Fatalf("is_global forwarded to Captain = %v, want false", (*gotBody)["is_global"])
	}
}
