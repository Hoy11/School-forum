package handler

import (
	"net/http"
	"net/http/httptest"
	"testing"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

func newBotLogTestRouter(role string, wafIDs, siteIDs []int) *gin.Engine {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: role})
		c.Set("allowed_waf_ids", wafIDs)
		bindings := make([]bindingmodel.SiteBinding, 0, len(siteIDs))
		for _, id := range siteIDs {
			bindings = append(bindings, bindingmodel.SiteBinding{SiteID: id})
		}
		c.Set("allowed_sites", bindings)
		c.Next()
	})
	router.GET("/api/captain/bot-log/record/detail", BotLogRecordDetail())
	router.GET("/api/captain/bot-log/result/detail", BotLogResultDetail())
	return router
}

func TestBotLogRecordDetailConvertsIDToChallengeID(t *testing.T) {
	var gotQuery string
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotQuery = r.URL.RawQuery
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":[{"id":"1","waf_id":7,"site_uuid":"101"}]}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newBotLogTestRouter("admin", nil, nil)
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/api/captain/bot-log/record/detail?id=abc123", nil)
	router.ServeHTTP(resp, req)

	if gotQuery != "challenge_id=abc123" {
		t.Fatalf("captain query = %q, want challenge_id=abc123", gotQuery)
	}
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
}

func TestUnwrapBotLogDetailArrayUnwrapsSingleItem(t *testing.T) {
	body := []byte(`{"err":null,"msg":"success","data":[{"id":"1","waf_id":7}]}`)
	out, detail := unwrapBotLogDetailArray(body)
	if detail == nil || detail["id"] != "1" {
		t.Fatalf("detail = %#v, want id=1", detail)
	}
	if string(out) == string(body) {
		t.Fatalf("expected data to be unwrapped from array")
	}
}

func TestUnwrapBotLogDetailArrayHandlesEmptyArray(t *testing.T) {
	body := []byte(`{"err":null,"msg":"success","data":[]}`)
	_, detail := unwrapBotLogDetailArray(body)
	if detail != nil {
		t.Fatalf("detail = %#v, want nil for empty array", detail)
	}
}

func TestUnwrapBotLogDetailArrayHandlesAlreadyObject(t *testing.T) {
	body := []byte(`{"err":null,"msg":"success","data":{"id":"1","waf_id":7}}`)
	_, detail := unwrapBotLogDetailArray(body)
	if detail == nil || detail["id"] != "1" {
		t.Fatalf("detail = %#v, want id=1 from object data", detail)
	}
}

func TestCheckBotLogDetailOwnership(t *testing.T) {
	item := map[string]interface{}{"waf_id": float64(7), "site_uuid": "101"}

	if !checkBotLogDetailOwnership(item, []int{7}, []int{101}) {
		t.Fatal("waf and site both allowed should pass")
	}
	if checkBotLogDetailOwnership(item, []int{8}, []int{101}) {
		t.Fatal("waf not allowed should be rejected")
	}
	if checkBotLogDetailOwnership(item, []int{7}, []int{999}) {
		t.Fatal("site not allowed should be rejected")
	}
}

func TestBotLogRecordDetailRejectsUnboundWafForNonAdmin(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":[{"id":"1","waf_id":99,"site_uuid":"101"}]}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newBotLogTestRouter("tenant", []int{7}, []int{101})
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/api/captain/bot-log/record/detail?id=abc123", nil)
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusForbidden {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusForbidden, resp.Body.String())
	}
}

func TestBotLogResultDetailAllowsBoundSiteForNonAdmin(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":[{"id":"1","waf_id":7,"site_uuid":"101"}]}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newBotLogTestRouter("tenant", []int{7}, []int{101})
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/api/captain/bot-log/result/detail?id=1", nil)
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
}
