package handler

import (
	"encoding/json"
	"fmt"
	"regexp"
	"strings"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

type detectLogFilterSite struct {
	ID   int
	Name string
}

func rewriteDetectLogWebsiteNameConditions(c *gin.Context, body map[string]interface{}) error {
	if !hasConditionTarget(body, "website_name") {
		return nil
	}

	instanceIDs := getAllowedWafIDs(c)
	if isAdmin(c) {
		var err error
		instanceIDs, err = fetchAllCaptainInstanceIDs()
		if err != nil {
			return err
		}
	}

	sites, err := fetchDetectLogFilterSites(instanceIDs)
	if err != nil {
		return err
	}
	rewriteWebsiteNameConditionsWithSites(body, sites)
	return nil
}

func hasConditionTarget(body map[string]interface{}, target string) bool {
	conditions, ok := body["conditions"].([]interface{})
	if !ok {
		return false
	}
	for _, cond := range conditions {
		condMap, ok := cond.(map[string]interface{})
		if !ok {
			continue
		}
		if condMap["target"] == target {
			return true
		}
	}
	return false
}

func rewriteWebsiteNameConditionsWithSites(body map[string]interface{}, sites []detectLogFilterSite) {
	conditions, ok := body["conditions"].([]interface{})
	if !ok {
		return
	}

	rewritten := make([]interface{}, 0, len(conditions))
	for _, cond := range conditions {
		condMap, ok := cond.(map[string]interface{})
		if !ok || condMap["target"] != "website_name" {
			rewritten = append(rewritten, cond)
			continue
		}

		items, _ := condMap["items"].([]interface{})
		siteItems := make([]interface{}, 0, len(items))
		for _, item := range items {
			itemMap, ok := item.(map[string]interface{})
			if !ok {
				continue
			}
			oper := normalizeCaptainFilterOper(fmt.Sprintf("%v", itemMap["oper"]))
			value := fmt.Sprintf("%v", itemMap["value"])
			matchedIDs := matchDetectLogSiteIDsByName(sites, oper, value)

			if isNegativeWebsiteNameOper(oper) {
				for _, id := range matchedIDs {
					siteItems = append(siteItems, map[string]interface{}{"oper": "<>", "value": id})
				}
				continue
			}

			if len(matchedIDs) == 0 {
				matchedIDs = []int{-1}
			}
			for _, id := range matchedIDs {
				siteItems = append(siteItems, map[string]interface{}{"oper": "=", "value": id})
			}
		}

		if len(siteItems) == 0 {
			continue
		}
		condMap["target"] = "site_uuid"
		condMap["items"] = siteItems
		rewritten = append(rewritten, condMap)
	}
	body["conditions"] = rewritten
}

func matchDetectLogSiteIDsByName(sites []detectLogFilterSite, oper, value string) []int {
	result := make([]int, 0)
	seen := make(map[int]struct{})
	values := splitFilterValues(value)
	for _, site := range sites {
		if site.ID == 0 {
			continue
		}
		for _, val := range values {
			if websiteNameMatches(site.Name, oper, val) {
				if _, exists := seen[site.ID]; !exists {
					seen[site.ID] = struct{}{}
					result = append(result, site.ID)
				}
				break
			}
		}
	}
	return result
}

func splitFilterValues(value string) []string {
	parts := strings.Split(value, ",")
	result := make([]string, 0, len(parts))
	for _, part := range parts {
		trimmed := strings.TrimSpace(part)
		if trimmed != "" {
			result = append(result, trimmed)
		}
	}
	if len(result) == 0 {
		return []string{value}
	}
	return result
}

func websiteNameMatches(name, oper, value string) bool {
	switch oper {
	case "=", "<>", "in", "not in":
		return name == value
	case "like", "not like":
		return strings.Contains(name, value)
	case "regexp", "not regexp":
		ok, err := regexp.MatchString(value, name)
		return err == nil && ok
	default:
		return strings.Contains(name, value)
	}
}

func isNegativeWebsiteNameOper(oper string) bool {
	switch oper {
	case "<>", "!=", "not in", "not like", "not regexp":
		return true
	default:
		return false
	}
}

func fetchAllCaptainInstanceIDs() ([]int, error) {
	client := captain.GetDefault()
	if client == nil {
		return nil, fmt.Errorf("captain client is not configured")
	}
	resp, err := client.Do(&captain.CaptainRequest{Method: "GET", Path: "/api/group/detail"})
	if err != nil {
		return nil, fmt.Errorf("fetch Captain WAF list: %w", err)
	}
	if resp.StatusCode >= 300 {
		return nil, fmt.Errorf("fetch Captain WAF list returned %d", resp.StatusCode)
	}

	var wrapper struct {
		Data struct {
			WafList []map[string]interface{} `json:"waf_list"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil, fmt.Errorf("parse Captain WAF list: %w", err)
	}

	ids := make([]int, 0, len(wrapper.Data.WafList))
	seen := make(map[int]struct{}, len(wrapper.Data.WafList))
	for _, item := range wrapper.Data.WafList {
		id := extractIntID(item["id"])
		if id == 0 {
			id = extractIntID(item["ID"])
		}
		if id == 0 {
			continue
		}
		if _, exists := seen[id]; exists {
			continue
		}
		seen[id] = struct{}{}
		ids = append(ids, id)
	}
	return ids, nil
}

func fetchDetectLogFilterSites(instanceIDs []int) ([]detectLogFilterSite, error) {
	client := captain.GetDefault()
	if client == nil {
		return nil, fmt.Errorf("captain client is not configured")
	}

	sites := make([]detectLogFilterSite, 0)
	for _, instanceID := range instanceIDs {
		path, err := resolveSiteReadPath(instanceID)
		if err != nil {
			continue
		}
		idUint := uint(instanceID)
		resp, err := client.Do(&captain.CaptainRequest{
			Method:     "GET",
			Path:       path,
			InstanceID: &idUint,
		})
		if err != nil {
			return nil, fmt.Errorf("fetch Captain sites for instance %d: %w", instanceID, err)
		}
		if resp.StatusCode >= 300 {
			return nil, fmt.Errorf("fetch Captain sites for instance %d returned %d", instanceID, resp.StatusCode)
		}
		sites = append(sites, parseDetectLogFilterSites(resp.Body)...)
	}
	return sites, nil
}

func parseDetectLogFilterSites(body []byte) []detectLogFilterSite {
	var wrapper struct {
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(body, &wrapper); err != nil || len(wrapper.Data) == 0 {
		return nil
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(wrapper.Data, &items); err != nil {
		var page struct {
			Items []map[string]interface{} `json:"items"`
		}
		if err := json.Unmarshal(wrapper.Data, &page); err != nil {
			return nil
		}
		items = page.Items
	}

	sites := make([]detectLogFilterSite, 0, len(items))
	for _, item := range items {
		id := extractIntID(item["id"])
		if id == 0 {
			id = extractIntID(item["ID"])
		}
		name, _ := item["name"].(string)
		if name == "" {
			name, _ = item["Name"].(string)
		}
		if id > 0 && name != "" {
			sites = append(sites, detectLogFilterSite{ID: id, Name: name})
		}
	}
	return sites
}
