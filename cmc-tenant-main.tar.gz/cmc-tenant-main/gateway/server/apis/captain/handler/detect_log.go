package handler

import (
	"encoding/json"
	"net/http"
	"strconv"
	"strings"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

// DetectLogList proxies detect log list queries to Captain.
func DetectLogList() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			body = make(map[string]interface{})
		}

		// Frontend sends {offset, count}; Captain detect_log uses {target_page, count}
		convertOffsetToTargetPage(body)

		if err := rewriteDetectLogWebsiteNameConditions(c, body); err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		// Convert CMC conditions to Captain BasicFilter format
		convertConditionsToBasicFilter(body, "detect_log")

		if !isAdmin(c) {
			wafIDs := getAllowedWafIDs(c)
			captain.InjectLogFilter(body, wafIDs)

			siteIDs := getAllowedSiteIDs(c)
			captain.InjectDetectLogSiteFilter(body, siteIDs)
		}

		req := &captain.CaptainRequest{
			Method: "POST",
			Path:   "/api/detect_log/list",
			Body:   body,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		enhanced := captain.EnhanceLogResponse(resp.Body)
		enhanced = captain.EnhanceSocReportStatus(enhanced)
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(enhanced))
	}
}

// DetectLogDetail proxies detect log detail queries to Captain.
func DetectLogDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		req := &captain.CaptainRequest{
			Method: "GET",
			Path:   "/api/detect_log/detail",
			Query:  c.Request.URL.RawQuery,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if !isAdmin(c) {
			if !checkLogDetailOwnership(resp.Body, getAllowedWafIDs(c), getAllowedSiteIDs(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该日志", "data": ""})
				return
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// DetectLogMark proxies detect log mark/flag updates to Captain.
func DetectLogMark() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		req := &captain.CaptainRequest{
			Method: "PUT",
			Path:   "/api/detect_log/mark/flag",
			Body:   body,
		}
		proxyRequest(c, req)
	}
}

// convertOffsetToTargetPage translates {offset, count} to {target_page, count}
// for Captain APIs that use target_page instead of offset (e.g. detect_log).
func convertOffsetToTargetPage(body map[string]interface{}) {
	offsetVal, hasOffset := body["offset"]
	countVal, hasCount := body["count"]

	if hasOffset && hasCount {
		offset := ifaceToInt(offsetVal)
		count := ifaceToInt(countVal)
		if count > 0 {
			body["target_page"] = offset/count + 1
		}
		delete(body, "offset")
	}
}

// convertConditionsToBasicFilter converts CMC Condition[] to Captain BasicFilter format.
// Each condition {target, items: [{oper, value}]} becomes body[target] = [{oper, target: value}, ...].
// Items within the same condition group are appended to the same field array.
// logType is injected into Captain timestamp filters that require it.
// After conversion, the "conditions" field is removed from the body.
func convertConditionsToBasicFilter(body map[string]interface{}, logType string) {
	conditions, ok := body["conditions"]
	if !ok {
		return
	}

	condSlice, ok := conditions.([]interface{})
	if !ok {
		delete(body, "conditions")
		return
	}

	for _, cond := range condSlice {
		condMap, ok := cond.(map[string]interface{})
		if !ok {
			continue
		}

		target, _ := condMap["target"].(string)
		if target == "" {
			continue
		}

		items, _ := condMap["items"].([]interface{})
		for _, item := range items {
			itemMap, ok := item.(map[string]interface{})
			if !ok {
				continue
			}

			oper, _ := itemMap["oper"].(string)
			value := itemMap["value"]
			target = normalizeCaptainFilterTarget(target, logType)
			oper = normalizeCaptainFilterOperForTarget(target, oper)
			value = normalizeCaptainFilterValue(target, oper, value)

			filterItem := map[string]interface{}{
				"oper":   oper,
				"target": value,
			}

			if isCaptainDetectTimestampFilter(target, logType) {
				filterItem["log_type"] = logType
			}

			// Append to existing array for same field
			existing, exists := body[target]
			if exists {
				if arr, ok := existing.([]interface{}); ok {
					body[target] = append(arr, filterItem)
				} else {
					body[target] = []interface{}{existing, filterItem}
				}
			} else {
				body[target] = []interface{}{filterItem}
			}
		}
	}

	delete(body, "conditions")
}

var captainDetectLogTargetAliases = map[string]string{
	"policy_rule_id": "rule_id",
	"dest_ip":        "dst_ip",
	"dest_port":      "dst_port",
	"timestamp":      "attack_time",
}

var captainFilterOperAliases = map[string]string{
	"eq":                         "=",
	"exact":                      "=",
	"neq":                        "<>",
	"not_exact":                  "<>",
	"contains":                   "like",
	"not_contains":               "not like",
	"in":                         "in",
	"notin":                      "not in",
	"not_in":                     "not in",
	"lt":                         "<",
	"lte":                        "<=",
	"gt":                         ">",
	"gte":                        ">=",
	"regex":                      "regexp",
	"not_regex":                  "not regexp",
	"net_contained_or_equal":     "<<=",
	"not_net_contained_or_equal": "not <<=",
	"incidr":                     "<<",
	"inequalcidr":                "<<=",
	"containscidr":               ">>",
	"containsequalcidr":          ">>=",
}

var captainStringArrayFilterTargets = map[string]bool{
	"log_id":                    true,
	"country":                   true,
	"province":                  true,
	"attack_type":               true,
	"action":                    true,
	"risk_level":                true,
	"method":                    true,
	"req_http_body_is_truncate": true,
	"rsp_http_body_is_truncate": true,
	"http_body_is_abandoned":    true,
	"threat_risk_level":         true,
	"matched_threat_tag":        true,
	"ip_matched_threat_tags":    true,
	"fp_matched_threat_tags":    true,
	"req_payload_explain_ids":   true,
	"rsp_payload_explain_ids":   true,
	"effective":                 true,
}

var captainIntFilterTargets = map[string]bool{
	"site_uuid": true,
}

func normalizeCaptainFilterTarget(target, logType string) string {
	if logType == "detect_log" {
		if alias, ok := captainDetectLogTargetAliases[target]; ok {
			return alias
		}
	}
	return target
}

func normalizeCaptainFilterOper(oper string) string {
	if alias, ok := captainFilterOperAliases[oper]; ok {
		return alias
	}
	return oper
}

func normalizeCaptainFilterOperForTarget(target, oper string) string {
	if target == "attack_time" && oper == "range" {
		return "in"
	}
	return normalizeCaptainFilterOper(oper)
}

func normalizeCaptainFilterValue(target, oper string, value interface{}) interface{} {
	if captainIntFilterTargets[target] {
		return ifaceToInt(value)
	}
	if !captainStringArrayFilterTargets[target] {
		return value
	}
	switch val := value.(type) {
	case []interface{}:
		return val
	case []string:
		result := make([]interface{}, 0, len(val))
		for _, item := range val {
			result = append(result, item)
		}
		return result
	case string:
		if oper == "in" || oper == "not in" {
			parts := strings.Split(val, ",")
			result := make([]interface{}, 0, len(parts))
			for _, part := range parts {
				trimmed := strings.TrimSpace(part)
				if trimmed != "" {
					result = append(result, trimmed)
				}
			}
			if len(result) > 0 {
				return result
			}
		}
		return []interface{}{val}
	default:
		return []interface{}{val}
	}
}

func isCaptainDetectTimestampFilter(target, logType string) bool {
	if logType != "detect_log" {
		return false
	}
	switch target {
	case "req_start_time",
		"req_start_time_tsrange",
		"rsp_start_time",
		"rsp_start_time_tsrange",
		"threat_last_timestamp",
		"threat_last_timestamp_tsrange",
		"threat_ip_last_timestamp",
		"threat_ip_last_timestamp_tsrange",
		"threat_fp_last_timestamp",
		"threat_fp_last_timestamp_tsrange":
		return true
	default:
		return false
	}
}

func ifaceToInt(v interface{}) int {
	switch val := v.(type) {
	case float64:
		return int(val)
	case int:
		return val
	case string:
		n, _ := strconv.Atoi(val)
		return n
	}
	return 0
}

func getAllowedSiteIDs(c *gin.Context) []int {
	sites, _ := c.Get("allowed_sites")
	if sites == nil {
		return nil
	}
	bindings := sites.([]bindingmodel.SiteBinding)
	result := make([]int, 0, len(bindings))
	for _, b := range bindings {
		result = append(result, b.SiteID)
	}
	return result
}

// checkLogDetailOwnership 校验检测日志详情归属：先校验 waf_id，再通过 website_name
// 反查该 WAF 上的站点列表，比对解析出的 site_id 是否在 allowedSiteIDs 内。
// detect_log 详情接口不直接返回 site_uuid（spec/08 第4条），只能按站点名匹配；
// 若同一 WAF 上存在重名站点，名称无法唯一定位真实站点，此时按 fail-closed 处理，
// 不能因为命中其中一个允许的同名站点就放行，避免误放行其他租户的日志。
func checkLogDetailOwnership(body []byte, allowedWafIDs []int, allowedSiteIDs []int) bool {
	var resp struct {
		Data struct {
			WafID       int    `json:"waf_id"`
			WebsiteName string `json:"website_name"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return false
	}

	wafOK := false
	for _, id := range allowedWafIDs {
		if id == resp.Data.WafID {
			wafOK = true
			break
		}
	}
	if !wafOK {
		return false
	}

	if resp.Data.WebsiteName == "" {
		return false
	}

	sites, err := fetchDetectLogFilterSites([]int{resp.Data.WafID})
	if err != nil {
		return false
	}
	allowedSet := make(map[int]bool, len(allowedSiteIDs))
	for _, id := range allowedSiteIDs {
		allowedSet[id] = true
	}

	matched := false
	for _, site := range sites {
		if site.Name != resp.Data.WebsiteName {
			continue
		}
		matched = true
		if !allowedSet[site.ID] {
			// 同名站点里存在不属于当前租户的站点，名称无法唯一确定归属，fail-closed。
			return false
		}
	}
	return matched
}
