package handler

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sync/atomic"
	"testing"
	"time"
)

func TestPolicyUpdateDoesNotReconcileWhenCaptainBodyHasError(t *testing.T) {
	var extraRequests int32
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/PolicyGroupAPI":
			if r.Method != http.MethodPut {
				atomic.AddInt32(&extraRequests, 1)
				http.Error(w, `{"err":"unexpected_method"}`, http.StatusMethodNotAllowed)
				return
			}
			_, _ = w.Write([]byte(`{"err":"object-not-found","msg":"FileStorage：找不到对象","data":""}`))
			return
		case "/api/group/detail":
			atomic.AddInt32(&extraRequests, 1)
			_, _ = w.Write([]byte(`{"data":{"waf_list":[{"id":1,"mode":"Software Reverse Proxy"}]}}`))
		case sitePathSoftwareReverseProxy:
			atomic.AddInt32(&extraRequests, 1)
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":[]}`))
		default:
			atomic.AddInt32(&extraRequests, 1)
			http.Error(w, `{"err":"unexpected_path"}`, http.StatusNotFound)
		}
	}))
	defer captainServer.Close()
	withTestCaptainClient(t, captainServer.URL)

	router := newPolicyRuleWriteTestRouter(http.MethodPut, "/api/captain/policy/update", PolicyUpdate())
	body := map[string]interface{}{
		"captain_instance_id": 1,
		"id":                  101,
		"name":                "policy",
	}
	raw, _ := json.Marshal(body)
	req := httptest.NewRequest(http.MethodPut, "/api/captain/policy/update", bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}

	time.Sleep(100 * time.Millisecond)
	if got := atomic.LoadInt32(&extraRequests); got != 0 {
		t.Fatalf("reconcile should not run after Captain business error; extra Captain requests=%d", got)
	}
}
