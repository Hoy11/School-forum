package handler

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

const (
	ipGroupFilterV2ScopeQuery = "scope=detect%3Aasset%3Aip_group"
	ipGroupFilterV2BatchSize  = 500
)

// IPGroupList proxies IP group list queries to Captain via FilterV2.
// /api/IPGroupAPI only returns a reduced serializer; FilterV2 uses the full
// IPGroupSerializer and includes comment/original/cidrs.
func IPGroupList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		reqOffset := parseQueryInt(c, "offset", 0)
		reqCount := parseQueryInt(c, "count", 20)

		client := captain.GetDefault()
		var resp *captain.CaptainResponse
		var err error
		if isAdmin(c) {
			resp, err = fetchIPGroupFilterV2Page(client, instanceID, reqOffset, reqCount)
		} else {
			if len(getMappedIDs(mappingIPGroup, instanceID, getTenantGroupID(c))) == 0 {
				c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"total": 0, "items": []map[string]interface{}{}}})
				return
			}
			resp, err = fetchAllIPGroups(client, instanceID)
		}
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var body []byte
		if isAdmin(c) {
			body = resp.Body
		} else {
			body = filterResponseByMapping(resp.Body, mappingIPGroup, instanceID, getTenantGroupID(c))
		}

		body = wrapListAsPage(body)
		body = injectBindingCounts(body, mappingIPGroup, instanceID)
		if !isAdmin(c) {
			body = injectIPGroupProtectionFields(body, instanceID, getTenantGroupID(c))
			body = applyLocalPagination(body, reqOffset, reqCount)
		}
		c.Data(resp.StatusCode, "application/json", body)
	}
}

// IPGroupCreate proxies IP group creation to Captain.
func IPGroupCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       "/api/IPGroupAPI",
			Body:       body,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 {
			if !isAdmin(c) {
				if id := extractIDFromResp(resp.Body); id > 0 {
					writeMapping(mappingIPGroup, instanceID, id, getTenantGroupID(c), "created")
				}
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// IPGroupUpdate proxies IP group update to Captain, with shared resource check.
func IPGroupUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		resourceID := extractResourceID(body, mappingIPGroup)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingIPGroup, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if resourceID > 0 && checkIPGroupShared(instanceID, resourceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该IP组被多个租户组共享，无法修改", "data": ""})
			return
		}
		if err := checkIPGroupEditProtection(c, instanceID, resourceID); err != nil {
			c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/IPGroupAPI",
			Body:       body,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// IPGroupDelete proxies IP group deletion to Captain, with shared resource check.
func IPGroupDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		resourceID := extractResourceID(body, mappingIPGroup)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingIPGroup, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if resourceID > 0 {
			usedCount := getIPGroupUsedCount(instanceID, resourceID)
			if usedCount > 0 {
				c.JSON(http.StatusForbidden, gin.H{"err": "in_use", "msg": fmt.Sprintf("该IP组正在被 %d 个防护策略引用，无法删除", usedCount), "data": ""})
				return
			}
		}
		if resourceID > 0 && checkIPGroupShared(instanceID, resourceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该IP组被多个租户组共享，无法删除", "data": ""})
			return
		}

		captainBody := map[string]interface{}{
			"id__in": []interface{}{resourceID},
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "DELETE",
			Path:       "/api/IPGroupAPI",
			Body:       captainBody,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 {
			if resourceID > 0 {
				if !isAdmin(c) {
					deleteMapping(mappingIPGroup, instanceID, resourceID, getTenantGroupID(c))
				} else {
					database.DB.Table("captain_ip_group_bindings").
						Where("captain_instance_id = ? AND ip_group_id = ?", instanceID, resourceID).
						Delete(nil)
				}
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// IPGroupItemAdd proxies IP group item addition to Captain, with shared resource check.
func IPGroupItemAdd() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		delete(body, "captain_instance_id")

		resourceID := extractResourceID(body, mappingIPGroup)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingIPGroup, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if resourceID > 0 && checkIPGroupShared(instanceID, resourceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该IP组被多个租户组共享，无法修改", "data": ""})
			return
		}
		if err := checkIPGroupEditProtection(c, instanceID, resourceID); err != nil {
			c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       "/api/EditIPGroupItem",
			Body:       body,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// IPGroupItemDelete proxies IP group item deletion to Captain, with shared resource check.
func IPGroupItemDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		resourceID := extractResourceID(body, mappingIPGroup)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingIPGroup, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if resourceID > 0 && checkIPGroupShared(instanceID, resourceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该IP组被多个租户组共享，无法修改", "data": ""})
			return
		}
		if err := checkIPGroupEditProtection(c, instanceID, resourceID); err != nil {
			c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "DELETE",
			Path:       "/api/EditIPGroupItem",
			Body:       body,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// checkIPGroupShared returns true if the WAF instance is bound to more than one tenant group,
// meaning any IP group on this instance is a shared resource across tenant groups.
func checkIPGroupShared(instanceID int, resourceID int) bool {
	var count int64
	database.DB.Table("captain_ip_group_bindings").
		Where("captain_instance_id = ? AND ip_group_id = ?", instanceID, resourceID).
		Count(&count)
	return count > 1
}

func fetchIPGroupFilterV2Page(client *captain.CaptainClient, instanceID, offset, count int) (*captain.CaptainResponse, error) {
	idUint := uint(instanceID)
	req := &captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/FilterV2API",
		Query:      fmt.Sprintf("count=%d&offset=%d&%s", count, offset, ipGroupFilterV2ScopeQuery),
		InstanceID: &idUint,
	}
	return client.Do(req)
}

func fetchAllIPGroups(client *captain.CaptainClient, instanceID int) (*captain.CaptainResponse, error) {
	offset := 0
	total := -1
	statusCode := http.StatusOK
	items := make([]map[string]interface{}, 0)
	var envelope map[string]json.RawMessage

	for {
		resp, err := fetchIPGroupFilterV2Page(client, instanceID, offset, ipGroupFilterV2BatchSize)
		if err != nil {
			return nil, err
		}
		statusCode = resp.StatusCode
		if resp.StatusCode >= 300 {
			return resp, nil
		}

		var parsed struct {
			Data struct {
				Total int                      `json:"total"`
				Items []map[string]interface{} `json:"items"`
			} `json:"data"`
		}
		if err := json.Unmarshal(resp.Body, &parsed); err != nil {
			return nil, fmt.Errorf("parse ip group FilterV2 response: %w", err)
		}
		if envelope == nil {
			if err := json.Unmarshal(resp.Body, &envelope); err != nil {
				return nil, fmt.Errorf("parse ip group FilterV2 envelope: %w", err)
			}
		}

		if total < 0 {
			total = parsed.Data.Total
		}
		items = append(items, parsed.Data.Items...)
		if len(items) >= total || len(parsed.Data.Items) == 0 {
			break
		}
		offset += len(parsed.Data.Items)
	}

	if envelope == nil {
		envelope = map[string]json.RawMessage{}
	}
	dataOut, _ := json.Marshal(gin.H{"total": len(items), "items": items})
	envelope["data"] = dataOut
	result, _ := json.Marshal(envelope)
	return &captain.CaptainResponse{StatusCode: statusCode, Body: result}, nil
}

// injectBindingCounts adds a binding_count field to each item in a paginated list response.
func injectBindingCounts(body []byte, table mappingTable, instanceID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	if len(page.Items) == 0 {
		return body
	}

	ids := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			ids = append(ids, id)
		}
	}

	counts := getBindingCounts(table, instanceID, ids)
	for _, item := range page.Items {
		id := getIDFromItem(item)
		if id > 0 {
			item["binding_count"] = counts[id]
		} else {
			item["binding_count"] = 0
		}
	}

	pageData, _ := json.Marshal(page)
	resp["data"] = pageData
	result, _ := json.Marshal(resp)
	return result
}

// --- Protection helpers ---

// fetchAllPolicyRules 分页拉取 WAF 实例上全量非全局自定义规则。
// 返回 (rules, ok)，ok=false 表示中途拉取失败，结果不完整。
func fetchAllPolicyRules(instanceID int) ([]map[string]interface{}, bool) {
	const batchSize = 500
	offset := 0
	total := -1
	items := make([]map[string]interface{}, 0)
	idUint := uint(instanceID)

	for {
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/PolicyRuleAPI",
			Query:      fmt.Sprintf("count=%d&offset=%d&is_global=false", batchSize, offset),
			InstanceID: &idUint,
		}
		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			log.Printf("[WARN] fetchAllPolicyRules: Captain request error: %v", err)
			return items, false
		}

		var wrapper struct {
			Data struct {
				Total int                      `json:"total"`
				Items []map[string]interface{} `json:"items"`
			} `json:"data"`
		}
		if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
			log.Printf("[WARN] fetchAllPolicyRules: parse error: %v", err)
			return items, false
		}

		if total < 0 {
			total = wrapper.Data.Total
		}
		items = append(items, wrapper.Data.Items...)
		if len(items) >= total || len(wrapper.Data.Items) == 0 {
			break
		}
		offset += len(wrapper.Data.Items)
	}
	return items, true
}

// getIPGroupUsedCount counts how many non-global policy rules reference the IP group via ingroup.
func getIPGroupUsedCount(instanceID int, ipGroupID int) int {
	rules, _ := fetchAllPolicyRules(instanceID)
	count := 0
	for _, rule := range rules {
		if pattern, ok := rule["pattern"]; ok {
			for _, id := range extractInGroupIDs(pattern) {
				if id == ipGroupID {
					count++
					break
				}
			}
		}
	}
	return count
}

// checkIPGroupExternalRef checks if the IP group is referenced by rules belonging to external sites.
func checkIPGroupExternalRef(instanceID int, ipGroupID int, tenantGroupID uint) bool {
	allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	rules, ok := fetchAllPolicyRules(instanceID)
	if !ok {
		// 拉取失败，保守返回 true，拒绝删除操作
		return true
	}

	for _, rule := range rules {
		pattern, exists := rule["pattern"]
		if !exists {
			continue
		}
		referenced := false
		for _, id := range extractInGroupIDs(pattern) {
			if id == ipGroupID {
				referenced = true
				break
			}
		}
		if !referenced {
			continue
		}

		var websiteIDs []int
		if websites, ok := extractItemIntArray(rule, "websites"); ok {
			for _, w := range websites {
				if id := extractIntID(w); id > 0 {
					websiteIDs = append(websiteIDs, id)
				}
			}
		}
		if siteID := extractItemIntField(rule, "website"); siteID > 0 {
			websiteIDs = append(websiteIDs, siteID)
		}

		for _, wID := range websiteIDs {
			if !allowedSet[wID] {
				return true
			}
		}
	}
	return false
}

// checkIPGroupEditProtection checks edit protection for an IP group:
// source=created → allow; otherwise check external reference.
func checkIPGroupEditProtection(c *gin.Context, instanceID int, resourceID int) *protectionError {
	if isAdmin(c) || resourceID <= 0 {
		return nil
	}
	tgID := getTenantGroupID(c)

	source := getMappingSource(mappingIPGroup, instanceID, resourceID, tgID)
	if source == "created" {
		return nil
	}

	if checkIPGroupExternalRef(instanceID, resourceID, tgID) {
		return &protectionError{err: "has_external_ref", msg: "该IP组被其他租户组的策略引用，无法修改"}
	}
	return nil
}

// injectIPGroupProtectionFields adds used_count, source, and has_external_ref to each IP group item.
// Fetches all non-global rules once and builds maps for all items to avoid O(N) API calls.
func injectIPGroupProtectionFields(body []byte, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	if len(page.Items) == 0 {
		return body
	}

	ipGroupIDs := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			ipGroupIDs = append(ipGroupIDs, id)
		}
	}

	sourceMap := getMappingSources(mappingIPGroup, instanceID, tenantGroupID, ipGroupIDs)

	allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	usedCountMap := make(map[int]int)
	externalRefMap := make(map[int]bool)

	rules, rulesOK := fetchAllPolicyRules(instanceID)
	for _, rule := range rules {
		pattern, ok := rule["pattern"]
		if !ok {
			continue
		}
		referencedIDs := extractInGroupIDs(pattern)

		var websiteIDs []int
		if websites, ok := extractItemIntArray(rule, "websites"); ok {
			for _, w := range websites {
				if id := extractIntID(w); id > 0 {
					websiteIDs = append(websiteIDs, id)
				}
			}
		}
		if siteID := extractItemIntField(rule, "website"); siteID > 0 {
			websiteIDs = append(websiteIDs, siteID)
		}

		hasExternalWebsite := false
		for _, wID := range websiteIDs {
			if !allowedSet[wID] {
				hasExternalWebsite = true
				break
			}
		}

		for _, refID := range referencedIDs {
			usedCountMap[refID]++
			if hasExternalWebsite {
				externalRefMap[refID] = true
			}
		}
	}
	// 拉取失败时保守处理：当前页所有 IP 组视为有外部引用，阻止删除
	if !rulesOK {
		for _, item := range page.Items {
			if id := getIDFromItem(item); id > 0 {
				externalRefMap[id] = true
			}
		}
	}

	for _, item := range page.Items {
		id := getIDFromItem(item)
		if id <= 0 {
			continue
		}
		item["used_count"] = usedCountMap[id]
		if s, ok := sourceMap[id]; ok {
			item["source"] = s
		} else {
			item["source"] = "created"
		}
		item["has_external_ref"] = externalRefMap[id]
	}

	pageData, _ := json.Marshal(page)
	resp["data"] = pageData
	result, _ := json.Marshal(resp)
	return result
}
