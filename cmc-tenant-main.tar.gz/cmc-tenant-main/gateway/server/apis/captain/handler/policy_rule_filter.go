package handler

import (
	"encoding/json"
	"regexp"
	"strconv"
	"strings"
)

type policyRuleCondition struct {
	Target string                    `json:"target"`
	Items  []policyRuleConditionItem `json:"items"`
}

type policyRuleConditionItem struct {
	Oper  string      `json:"oper"`
	Value interface{} `json:"value"`
}

// policyRuleFilter holds all parsed filter conditions for the custom rule list.
// Captain API does not support conditions on PolicyRuleAPI, so all filtering is
// done locally by the CMC backend after fetching the full rule set.
type policyRuleFilter struct {
	IDs                []int
	IDOper             string // "=", "!=", "<", ">"
	CommentLike        string
	CommentNotLike     string // "not like"
	CommentExact       string
	IsEnabled          *bool
	IsEnabledNegate    bool // when oper is '!='
	Actions            []string
	ActionsNegate      bool // when oper is '!=' or 'not in'
	StatusCodes        []int
	StatusCodeOper     string // "=", "!=", "<", ">", "in", "not in"
	ForwardAddrLike    string
	ForwardAddrNotLike string // "not like"
	ForwardAddrExact   string
	ForwardAddrRegex   string // "regex"
	ForwardAddrNotRe   string // "not regex"
	RiskLevels         []int
	RiskLevelsNegate   bool // when oper is '!=' or 'not in'
	AttackTypes        []int
	AttackNegate       bool   // when oper is '!=' or 'not in'
	CronConfigType     string // "all" / "time_range" / "weekly"
	CreateStart        *int64
	CreateEnd          *int64
	CreateBefore       *int64 // "before"
	CreateAfter        *int64 // "after"
	UpdateStart        *int64
	UpdateEnd          *int64
	UpdateBefore       *int64 // "before"
	UpdateAfter        *int64 // "after"
	ExpireStart        *int64
	ExpireEnd          *int64
	ExpireBefore       *int64 // "before"
	ExpireAfter        *int64 // "after"
	ExpireNever        bool   // "never" — match rules that never expire
	Percentage         *int   // trigger rate (0-100)
	PercentageOper     string // "=", "!=", "<", ">"
	SiteIDs            []int
}

func (f policyRuleFilter) isEmpty() bool {
	return len(f.IDs) == 0 &&
		f.CommentLike == "" &&
		f.CommentNotLike == "" &&
		f.CommentExact == "" &&
		f.IsEnabled == nil &&
		len(f.Actions) == 0 &&
		!f.ActionsNegate &&
		len(f.StatusCodes) == 0 &&
		f.ForwardAddrLike == "" &&
		f.ForwardAddrNotLike == "" &&
		f.ForwardAddrExact == "" &&
		f.ForwardAddrRegex == "" &&
		f.ForwardAddrNotRe == "" &&
		len(f.RiskLevels) == 0 &&
		!f.RiskLevelsNegate &&
		len(f.AttackTypes) == 0 &&
		!f.AttackNegate &&
		f.CronConfigType == "" &&
		f.CreateStart == nil && f.CreateEnd == nil && f.CreateBefore == nil && f.CreateAfter == nil &&
		f.UpdateStart == nil && f.UpdateEnd == nil && f.UpdateBefore == nil && f.UpdateAfter == nil &&
		f.ExpireStart == nil && f.ExpireEnd == nil && f.ExpireBefore == nil && f.ExpireAfter == nil &&
		!f.ExpireNever &&
		f.Percentage == nil &&
		len(f.SiteIDs) == 0
}

// parsePolicyRuleFilter parses all filter conditions from the query parameter.
// It replaces the old parseConditionSiteIDs which only handled site_id.
func parsePolicyRuleFilter(c interface{ Query(string) string }) policyRuleFilter {
	condStr := c.Query("conditions")
	if condStr == "" {
		return policyRuleFilter{}
	}

	var conditions []policyRuleCondition
	if err := json.Unmarshal([]byte(condStr), &conditions); err != nil {
		return policyRuleFilter{}
	}

	var f policyRuleFilter
	for _, cond := range conditions {
		switch cond.Target {
		case "id":
			for _, item := range cond.Items {
				if id := extractIntID(item.Value); id > 0 {
					f.IDs = append(f.IDs, id)
					f.IDOper = item.Oper // store the operator for matching
				}
			}
		case "comment":
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok && s != "" {
					switch item.Oper {
					case "like":
						f.CommentLike = s
					case "not like":
						f.CommentNotLike = s
					default:
						f.CommentExact = s
					}
				}
			}
		case "is_enabled":
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok {
					v := s == "true"
					f.IsEnabled = &v
					if item.Oper == "!=" {
						f.IsEnabledNegate = true
					}
				}
			}
		case "action":
			// Backward compatibility for early MR builds: the filter labeled "拦截码"
			// used to send target=action even though the data lives in status_code.
			for _, item := range cond.Items {
				f.StatusCodes = append(f.StatusCodes, extractPolicyRuleIntValues(item.Value)...)
				f.StatusCodeOper = item.Oper
			}
		case "status_code":
			for _, item := range cond.Items {
				f.StatusCodes = append(f.StatusCodes, extractPolicyRuleIntValues(item.Value)...)
				f.StatusCodeOper = item.Oper
			}
		case "forward_address":
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok && s != "" {
					switch item.Oper {
					case "like":
						f.ForwardAddrLike = s
					case "not like":
						f.ForwardAddrNotLike = s
					case "regex":
						f.ForwardAddrRegex = s
					case "not regex", "not_regex":
						f.ForwardAddrNotRe = s
					default:
						f.ForwardAddrExact = s
					}
				}
			}
		case "risk_level":
			for _, item := range cond.Items {
				if item.Oper == "in" || item.Oper == "=" || item.Oper == "not in" {
					if arr, ok := item.Value.([]interface{}); ok {
						for _, v := range arr {
							if n := extractIntID(v); n >= 0 {
								f.RiskLevels = append(f.RiskLevels, n)
							}
						}
					}
				} else if n := extractIntID(item.Value); n >= 0 {
					f.RiskLevels = append(f.RiskLevels, n)
				}
				if item.Oper == "!=" || item.Oper == "not in" {
					f.RiskLevelsNegate = true
				}
			}
		case "attack_type":
			for _, item := range cond.Items {
				if item.Oper == "in" || item.Oper == "=" || item.Oper == "not in" {
					if arr, ok := item.Value.([]interface{}); ok {
						for _, v := range arr {
							if n := extractIntID(v); n >= 0 {
								f.AttackTypes = append(f.AttackTypes, n)
							}
						}
					}
				} else if n := extractIntID(item.Value); n >= 0 {
					f.AttackTypes = append(f.AttackTypes, n)
				}
				if item.Oper == "!=" || item.Oper == "not in" {
					f.AttackNegate = true
				}
			}
		case "cron_config":
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok && s != "" {
					f.CronConfigType = s
				}
			}
		case "create_time":
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok {
					switch item.Oper {
					case "range":
						f.CreateStart, f.CreateEnd = parseTimeRange(s)
					case "before":
						if ts, err := strconv.ParseInt(s, 10, 64); err == nil && ts > 0 {
							f.CreateBefore = &ts
						}
					case "after":
						if ts, err := strconv.ParseInt(s, 10, 64); err == nil && ts > 0 {
							f.CreateAfter = &ts
						}
					}
				}
			}
		case "last_update_time":
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok {
					switch item.Oper {
					case "range":
						f.UpdateStart, f.UpdateEnd = parseTimeRange(s)
					case "before":
						if ts, err := strconv.ParseInt(s, 10, 64); err == nil && ts > 0 {
							f.UpdateBefore = &ts
						}
					case "after":
						if ts, err := strconv.ParseInt(s, 10, 64); err == nil && ts > 0 {
							f.UpdateAfter = &ts
						}
					}
				}
			}
		case "expire_time":
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok {
					switch item.Oper {
					case "range":
						f.ExpireStart, f.ExpireEnd = parseTimeRange(s)
					case "before":
						if ts, err := strconv.ParseInt(s, 10, 64); err == nil && ts > 0 {
							f.ExpireBefore = &ts
						}
					case "after":
						if ts, err := strconv.ParseInt(s, 10, 64); err == nil && ts > 0 {
							f.ExpireAfter = &ts
						}
					case "=":
						if s == "never" {
							f.ExpireNever = true
						}
					}
				}
			}
		case "expire_time_range":
			// Alias for expire_time range operation
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok && item.Oper == "range" {
					f.ExpireStart, f.ExpireEnd = parseTimeRange(s)
				}
			}
		case "expire_time_never":
			// Explicit never-expire filter
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok && s == "never" {
					f.ExpireNever = true
				}
			}
		case "create_time_range":
			// Alias for create_time range operation
			for _, item := range cond.Items {
				if s, ok := item.Value.(string); ok && item.Oper == "range" {
					f.CreateStart, f.CreateEnd = parseTimeRange(s)
				}
			}
		case "percentage":
			for _, item := range cond.Items {
				if v := extractIntID(item.Value); v >= 0 {
					f.Percentage = &v
					f.PercentageOper = item.Oper
				}
			}
		case "site_id":
			for _, item := range cond.Items {
				f.SiteIDs = append(f.SiteIDs, extractPolicyRuleConditionIDs(item.Value)...)
			}
		}
	}
	return f
}

// parseTimeRange parses a "start-end" string (Unix seconds) into two int64 pointers.
func parseTimeRange(s string) (*int64, *int64) {
	parts := strings.SplitN(s, "-", 2)
	if len(parts) != 2 {
		return nil, nil
	}
	start, err1 := strconv.ParseInt(parts[0], 10, 64)
	end, err2 := strconv.ParseInt(parts[1], 10, 64)
	if err1 != nil || err2 != nil {
		return nil, nil
	}
	return &start, &end
}

// filterByPolicyRuleFilter applies all filter conditions to the rule list.
// It handles both raw array and paginated response formats.
// Returns the body with filtered rules and updated total count.
func filterByPolicyRuleFilter(body []byte, f policyRuleFilter) []byte {
	if f.isEmpty() {
		return body
	}

	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}
	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	// Try raw array first, then paginated format
	var items []map[string]interface{}
	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	isPaginated := false
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		if err := json.Unmarshal(dataRaw, &page); err != nil {
			return body
		}
		items = page.Items
		isPaginated = true
	}

	filtered := make([]map[string]interface{}, 0, len(items))
	for _, item := range items {
		if matchPolicyRuleFilter(item, f) {
			filtered = append(filtered, item)
		}
	}

	var dataOut []byte
	if isPaginated {
		page.Total = len(filtered)
		page.Items = filtered
		dataOut, _ = json.Marshal(page)
	} else {
		dataOut, _ = json.Marshal(filtered)
	}
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// matchPolicyRuleFilter checks if a single rule matches all filter conditions.
func matchPolicyRuleFilter(rule map[string]interface{}, f policyRuleFilter) bool {
	// ID filter
	if len(f.IDs) > 0 {
		id := getIDFromItem(rule)
		matched := false
		switch f.IDOper {
		case "!=":
			for _, fid := range f.IDs {
				if id != fid {
					matched = true
					break
				}
			}
		case "<":
			for _, fid := range f.IDs {
				if id < fid {
					matched = true
					break
				}
			}
		case ">":
			for _, fid := range f.IDs {
				if id > fid {
					matched = true
					break
				}
			}
		default: // "=" or ""
			for _, fid := range f.IDs {
				if id == fid {
					matched = true
					break
				}
			}
		}
		if !matched {
			return false
		}
	}

	// Comment filter — like
	if f.CommentLike != "" {
		comment, _ := rule["comment"].(string)
		if !strings.Contains(comment, f.CommentLike) {
			return false
		}
	}

	// Comment filter — not like
	if f.CommentNotLike != "" {
		comment, _ := rule["comment"].(string)
		if strings.Contains(comment, f.CommentNotLike) {
			return false
		}
	}

	// Comment filter — exact
	if f.CommentExact != "" {
		comment, _ := rule["comment"].(string)
		if comment != f.CommentExact {
			return false
		}
	}

	// IsEnabled filter
	if f.IsEnabled != nil {
		if enabled, ok := rule["is_enabled"].(bool); ok {
			matched := enabled == *f.IsEnabled
			if f.IsEnabledNegate {
				matched = !matched
			}
			if !matched {
				return false
			}
		} else {
			return false
		}
	}

	// Action filter
	if len(f.Actions) > 0 {
		action, _ := rule["action"].(string)
		found := false
		for _, a := range f.Actions {
			if action == a {
				found = true
				break
			}
		}
		if f.ActionsNegate {
			found = !found
		}
		if !found {
			return false
		}
	}

	// Status code filter — stored in forbidden_page_config.status_code.
	if len(f.StatusCodes) > 0 {
		if !matchPolicyRuleStatusCode(extractRuleStatusCode(rule), f.StatusCodes, f.StatusCodeOper) {
			return false
		}
	}

	// Forward address filter — extract from pattern when action=forward
	if f.ForwardAddrLike != "" || f.ForwardAddrNotLike != "" || f.ForwardAddrExact != "" || f.ForwardAddrRegex != "" || f.ForwardAddrNotRe != "" {
		addr := extractForwardAddress(rule)
		if f.ForwardAddrLike != "" && !strings.Contains(addr, f.ForwardAddrLike) {
			return false
		}
		if f.ForwardAddrNotLike != "" && strings.Contains(addr, f.ForwardAddrNotLike) {
			return false
		}
		if f.ForwardAddrExact != "" && addr != f.ForwardAddrExact {
			return false
		}
		if f.ForwardAddrRegex != "" {
			if re, err := regexp.Compile(f.ForwardAddrRegex); err == nil {
				if !re.MatchString(addr) {
					return false
				}
			} else {
				// Invalid regex, treat as no match
				return false
			}
		}
		if f.ForwardAddrNotRe != "" {
			if re, err := regexp.Compile(f.ForwardAddrNotRe); err == nil {
				if re.MatchString(addr) {
					return false
				}
			} else {
				// Invalid regex, treat as no match
				return false
			}
		}
	}

	// Risk level filter
	if len(f.RiskLevels) > 0 {
		level := extractItemIntField(rule, "risk_level")
		found := false
		for _, rl := range f.RiskLevels {
			if level == rl {
				found = true
				break
			}
		}
		if f.RiskLevelsNegate {
			found = !found
		}
		if !found {
			return false
		}
	}

	// Attack type filter
	if len(f.AttackTypes) > 0 {
		at := extractItemIntField(rule, "attack_type")
		found := false
		for _, a := range f.AttackTypes {
			if at == a {
				found = true
				break
			}
		}
		if f.AttackNegate {
			found = !found
		}
		if !found {
			return false
		}
	}

	// Cron config type filter
	if f.CronConfigType != "" {
		cronMap, ok := rule["cron_config"].(map[string]interface{})
		if !ok {
			return false
		}
		typ, _ := cronMap["type"].(string)
		if typ != f.CronConfigType {
			return false
		}
	}

	// Create time filter
	if f.CreateStart != nil || f.CreateEnd != nil || f.CreateBefore != nil || f.CreateAfter != nil {
		ts := int64(extractItemIntField(rule, "create_time"))
		if f.CreateStart != nil && ts < *f.CreateStart {
			return false
		}
		if f.CreateEnd != nil && ts > *f.CreateEnd {
			return false
		}
		if f.CreateBefore != nil && ts >= *f.CreateBefore {
			return false
		}
		if f.CreateAfter != nil && ts <= *f.CreateAfter {
			return false
		}
	}

	// Update time filter
	if f.UpdateStart != nil || f.UpdateEnd != nil || f.UpdateBefore != nil || f.UpdateAfter != nil {
		ts := int64(extractItemIntField(rule, "last_update_time"))
		if f.UpdateStart != nil && ts < *f.UpdateStart {
			return false
		}
		if f.UpdateEnd != nil && ts > *f.UpdateEnd {
			return false
		}
		if f.UpdateBefore != nil && ts >= *f.UpdateBefore {
			return false
		}
		if f.UpdateAfter != nil && ts <= *f.UpdateAfter {
			return false
		}
	}

	// Expire time filter
	if f.ExpireStart != nil || f.ExpireEnd != nil || f.ExpireBefore != nil || f.ExpireAfter != nil {
		ts := extractExpireTime(rule)
		if ts == nil {
			// No expire time = never expires, doesn't match any time filter
			return false
		}
		if f.ExpireStart != nil && *ts < *f.ExpireStart {
			return false
		}
		if f.ExpireEnd != nil && *ts > *f.ExpireEnd {
			return false
		}
		if f.ExpireBefore != nil && *ts >= *f.ExpireBefore {
			return false
		}
		if f.ExpireAfter != nil && *ts <= *f.ExpireAfter {
			return false
		}
	}

	// Expire time — never expires filter
	if f.ExpireNever {
		ts := extractExpireTime(rule)
		if ts != nil {
			return false
		}
	}

	// Percentage (trigger rate) filter
	if f.Percentage != nil {
		pct := extractItemIntField(rule, "percentage")
		matched := false
		switch f.PercentageOper {
		case "!=":
			matched = pct != *f.Percentage
		case "<":
			matched = pct < *f.Percentage
		case ">":
			matched = pct > *f.Percentage
		default: // "=" or ""
			matched = pct == *f.Percentage
		}
		if !matched {
			return false
		}
	}

	// Site ID filter
	if len(f.SiteIDs) > 0 {
		if !policyRuleMatchesAnySite(rule, f.SiteIDs) {
			return false
		}
	}

	return true
}

// extractForwardAddress attempts to extract the forward/redirect target address
// from a rule's pattern field when action is "forward".
// The pattern structure for forward rules contains the target URL in nested conditions.
func extractForwardAddress(rule map[string]interface{}) string {
	action, _ := rule["action"].(string)
	if action != "forward" {
		return ""
	}
	pattern, ok := rule["pattern"].(map[string]interface{})
	if !ok {
		return ""
	}
	// Walk $AND/$OR arrays looking for a condition with a URL-like value
	for _, key := range []string{"$AND", "$OR"} {
		arr, ok := pattern[key].([]interface{})
		if !ok {
			continue
		}
		for _, item := range arr {
			if m, ok := item.(map[string]interface{}); ok {
				// Each condition is {operator: {field: value}}
				for _, v := range m {
					if fieldMap, ok := v.(map[string]interface{}); ok {
						for _, val := range fieldMap {
							if s, ok := val.(string); ok {
								return s
							}
						}
					}
				}
			}
		}
	}
	return ""
}

// extractExpireTime extracts the expire_time as an int64 pointer.
// Returns nil if expire_time is null, 0, or missing (meaning never expires).
func extractExpireTime(rule map[string]interface{}) *int64 {
	val, exists := rule["expire_time"]
	if !exists || val == nil {
		return nil
	}
	switch v := val.(type) {
	case float64:
		if v == 0 {
			return nil
		}
		i := int64(v)
		return &i
	case json.Number:
		if n, err := v.Int64(); err == nil && n != 0 {
			return &n
		}
		return nil
	default:
		return nil
	}
}

func extractPolicyRuleConditionIDs(value interface{}) []int {
	if arr, ok := value.([]interface{}); ok {
		ids := make([]int, 0, len(arr))
		for _, item := range arr {
			if id := extractIntID(item); id > 0 {
				ids = append(ids, id)
			}
		}
		return ids
	}
	if id := extractIntID(value); id > 0 {
		return []int{id}
	}
	return nil
}

func extractPolicyRuleIntValues(value interface{}) []int {
	if arr, ok := value.([]interface{}); ok {
		result := make([]int, 0, len(arr))
		for _, item := range arr {
			result = append(result, extractPolicyRuleIntValues(item)...)
		}
		return result
	}
	if s, ok := value.(string); ok {
		parts := strings.Split(s, ",")
		result := make([]int, 0, len(parts))
		for _, part := range parts {
			if n := extractIntID(strings.TrimSpace(part)); n > 0 {
				result = append(result, n)
			}
		}
		return result
	}
	if n := extractIntID(value); n > 0 {
		return []int{n}
	}
	return nil
}

func matchPolicyRuleStatusCode(statusCode int, filters []int, oper string) bool {
	if statusCode <= 0 || len(filters) == 0 {
		return false
	}
	first := filters[0]
	switch oper {
	case "!=":
		return statusCode != first
	case "<":
		return statusCode < first
	case ">":
		return statusCode > first
	case "not in", "not_in":
		for _, filter := range filters {
			if statusCode == filter {
				return false
			}
		}
		return true
	default:
		for _, filter := range filters {
			if statusCode == filter {
				return true
			}
		}
		return false
	}
}

func extractRuleStatusCode(rule map[string]interface{}) int {
	if n := extractItemIntField(rule, "status_code"); n > 0 {
		return n
	}
	raw, ok := rule["forbidden_page_config"]
	if !ok {
		raw = rule["ForbiddenPageConfig"]
	}
	config, ok := raw.(map[string]interface{})
	if !ok {
		return 0
	}
	if n := extractItemIntField(config, "status_code"); n > 0 {
		return n
	}
	return extractItemIntField(config, "statusCode")
}

func policyRuleMatchesAnySite(rule map[string]interface{}, siteIDs []int) bool {
	for _, siteID := range siteIDs {
		if matchRuleSite(rule, siteID) {
			return true
		}
		if policyRuleMatchesPascalSite(rule, siteID) {
			return true
		}
	}
	return false
}

func policyRuleMatchesPascalSite(rule map[string]interface{}, siteID int) bool {
	if websites, ok := extractItemIntArray(rule, "websites"); ok {
		for _, w := range websites {
			if extractIntID(w) == siteID {
				return true
			}
		}
	}
	return extractItemIntField(rule, "website") == siteID
}
