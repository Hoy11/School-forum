package handler

import (
	"encoding/json"
	"net/http"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

// SkynetRuleList proxies skynet (built-in) rule list queries to Captain.
func SkynetRuleList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		offset := c.DefaultQuery("offset", "0")
		count := c.DefaultQuery("count", "20")
		policyGroupIn := c.Query("policy_group__in")
		query := "offset=" + offset + "&count=" + count + "&scope=detect%3Askynet_rule"
		if policyGroupIn != "" {
			query += "&policy_group__in=" + policyGroupIn
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/FilterV2API",
			Query:      query,
			InstanceID: &idUint,
		}
		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		body := resp.Body
		body = flattenSkynetRuleItems(body)
		body = wrapCaptainResp(body)
		c.Data(resp.StatusCode, "application/json", body)
	}
}

// SkynetRuleUpdate proxies skynet rule binding updates to Captain.
// Uses PolicyGroupSkynetRuleBindingAPI (not ModifySkynetRulePolicyRuleAPI) because
// the latter is for bulk PolicyRule management, not individual rule binding edits.
func SkynetRuleUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		// Ensure enable_log is present (Captain requires it).
		if _, exists := body["enable_log"]; !exists {
			body["enable_log"] = true
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/PolicyGroupSkynetRuleBindingAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// flattenSkynetRuleItems merges the nested skynet_rule object into the top-level item.
// FilterV2API returns items like: {"id": 4064, "skynet_rule": {"id": 626, "ruleid": 65668, ...}, "is_enabled": false, ...}
// After flattening: {"id": 4064, "skynet_rule_id": 626, "ruleid": 65668, ..., "is_enabled": false, ...}
func flattenSkynetRuleItems(body []byte) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	for _, item := range page.Items {
		srRaw, ok := item["skynet_rule"]
		if !ok {
			continue
		}
		srMap, ok := srRaw.(map[string]interface{})
		if !ok {
			continue
		}
		for k, v := range srMap {
			if k == "id" {
				item["skynet_rule_id"] = v
				continue
			}
			if _, exists := item[k]; !exists {
				item[k] = v
			}
		}
		delete(item, "skynet_rule")
	}

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}
