// Package handler provides HTTP handlers for Captain API proxying.
package handler

import (
	"net/http"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

// ACLLogList proxies ACL log list queries to Captain.
func ACLLogList() gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			body = make(map[string]interface{})
		}

		convertConditionsToBasicFilter(body, "")

		if !isAdmin(c) {
			captain.InjectLogFilter(body, getAllowedWafIDs(c))
		}

		req := &captain.CaptainRequest{
			Method: "POST",
			Path:   "/api/acl_log/list",
			Body:   body,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		enhanced := captain.EnhanceLogResponse(resp.Body)
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(enhanced))
	}
}

// ACLLogDetail proxies ACL log detail queries to Captain.
func ACLLogDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}

		// Captain ACLRuleExecutionLogAPI requires 'count' parameter; strip CMC-only params
		q := c.Request.URL.Query()
		q.Del("captain_instance_id")
		if q.Get("count") == "" {
			q.Set("count", "1")
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/ACLRuleExecutionLogAPI",
			Query:      q.Encode(),
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// ACLSrcIPDetail proxies ACL log source IP detail queries to Captain FilterV2API.
// Used by the expand row feature to get IP execution details.
func ACLSrcIPDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}

		q := c.Request.URL.Query()
		q.Del("captain_instance_id")

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/FilterV2API",
			Query:      q.Encode(),
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}
