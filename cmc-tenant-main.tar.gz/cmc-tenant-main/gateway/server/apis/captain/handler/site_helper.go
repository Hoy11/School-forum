package handler

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strconv"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	riskguard "github.com/chaitin/cmc-tenant/pkg/risk_guard"
	"github.com/gin-gonic/gin"
)

const (
	siteModeSoftwareReverseProxy        = "Software Reverse Proxy"
	siteModeHardwareReverseProxy        = "Hardware Reverse Proxy"
	siteModeHardwareTransparentProxy    = "Hardware Transparent Proxy"
	siteModeHardwareTransparentBridge   = "Hardware Transparent Bridging"
	siteModeHardwarePortMirroring       = "Hardware Port Mirroring"
	siteModeSoftwareClusterReverseProxy = "Software Cluster Reverse Proxy"
	siteModeSoftwarePortMirroring       = "Software Port Mirroring"
	siteModeHardwareRouterProxy         = "Hardware Router Proxy"

	sitePathSoftwareReverseProxy        = "/api/SoftwareReverseProxyWebsiteAPI"
	sitePathHardwareReverseProxy        = "/api/WReverseProxyWebsiteAPI"
	sitePathHardwareTransparentProxy    = "/api/HardwareTransparentProxyWebsiteAPI"
	sitePathHardwareTransparentBridge   = "/api/HardwareTransparentBridgingWebsiteAPI"
	sitePathHardwarePortMirroring       = "/api/HardwarePortMirroringWebsiteAPI"
	sitePathSoftwareClusterReverseProxy = "/api/SoftwareClusterReverseProxyWebsiteAPI"
	sitePathSoftwarePortMirroring       = "/api/SoftwarePortMirroringWebsiteAPI"

	siteWorkGroupFromDefault          = "Website"
	siteWorkGroupFromTransparentProxy = "TransparentProxyWebsite"
)

// resolveSiteCreatePath 给 SiteCreate 用：新建站点没有"历史真实类型"可言，
// 要求请求体 operation_mode（如果带了）必须跟实例 mode 一致，不一致就拒绝，
// 防止建出实例部署能力不支持的站点类型。
func resolveSiteCreatePath(instanceID int, body map[string]interface{}) (string, error) {
	instanceMode := fetchSiteInstanceMode(instanceID)
	path, ok := sitePathForMode(instanceMode)
	if !ok {
		return "", fmt.Errorf("WAF 运行模式不支持或未识别: %s", instanceMode)
	}
	if bodyMode, _ := body["operation_mode"].(string); bodyMode != "" && bodyMode != instanceMode {
		return "", fmt.Errorf("站点模式 %s 与 WAF 运行模式 %s 不匹配", bodyMode, instanceMode)
	}
	return path, nil
}

// resolveSiteUpdatePath 给 SiteUpdate 用：请求体没带 operation_mode 时探测该
// 站点的真实类型（典型如启用/禁用的最小化请求体），探测失败则回退到实例默认端点。
// 请求体带 operation_mode 时，跟站点真实类型（探测得到，不该被实例当前 mode
// 否决，因为站点真实类型可能跟实例当前 mode 不一致）核对，不一致则拒绝；探测
// 不到真实类型时，保守地跟实例 mode 核对，不一致同样拒绝。
func resolveSiteUpdatePath(instanceID, siteID int, body map[string]interface{}) (string, error) {
	bodyMode, _ := body["operation_mode"].(string)
	if bodyMode == "" {
		if mode, ok := fetchSiteOperationMode(instanceID, siteID); ok {
			if path, ok := sitePathForMode(mode); ok {
				return path, nil
			}
		}
		return resolveSiteReadPath(instanceID)
	}

	path, ok := sitePathForMode(bodyMode)
	if !ok {
		return "", fmt.Errorf("站点模式不支持或未识别: %s", bodyMode)
	}
	if actualMode, ok := fetchSiteOperationMode(instanceID, siteID); ok {
		if actualMode != bodyMode {
			return "", fmt.Errorf("站点模式 %s 与站点实际类型 %s 不匹配", bodyMode, actualMode)
		}
		return path, nil
	}
	if instanceMode := fetchSiteInstanceMode(instanceID); instanceMode != "" && instanceMode != bodyMode {
		return "", fmt.Errorf("站点模式 %s 与 WAF 运行模式 %s 不匹配", bodyMode, instanceMode)
	}
	return path, nil
}

func resolveSiteReadPath(instanceID int) (string, error) {
	mode := fetchSiteInstanceMode(instanceID)
	path, ok := sitePathForMode(mode)
	if !ok {
		return "", fmt.Errorf("WAF 运行模式不支持或未识别: %s", mode)
	}
	return path, nil
}

// fetchSiteOperationMode 探测某个站点的真实 operation_mode：用默认端点
// （按实例 mode 算出）查询该站点详情，从响应里提取 operation_mode 字段。
// 查询失败或字段缺失时返回 ("", false)。
func fetchSiteOperationMode(instanceID, siteID int) (string, bool) {
	path, err := resolveSiteReadPath(instanceID)
	if err != nil {
		return "", false
	}
	client := captain.GetDefault()
	if client == nil {
		return "", false
	}
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       path + "?id=" + strconv.Itoa(siteID),
		InstanceID: &idUint,
	})
	if err != nil {
		return "", false
	}
	return extractOperationModeFromDetail(resp.Body)
}

// extractOperationModeFromDetail 从站点详情响应 body 中解析 operation_mode 字段。
// 兼容 data 为对象或单元素数组两种 Captain 响应形态。
func extractOperationModeFromDetail(body []byte) (string, bool) {
	var resp struct {
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil || len(resp.Data) == 0 {
		return "", false
	}

	var detail map[string]interface{}
	if err := json.Unmarshal(resp.Data, &detail); err != nil {
		var arr []map[string]interface{}
		if err := json.Unmarshal(resp.Data, &arr); err != nil || len(arr) == 0 {
			return "", false
		}
		detail = arr[0]
	}

	mode, ok := detail["operation_mode"].(string)
	if !ok || mode == "" {
		return "", false
	}
	return mode, true
}

func sitePathForMode(mode string) (string, bool) {
	switch mode {
	case siteModeSoftwareReverseProxy:
		return sitePathSoftwareReverseProxy, true
	case siteModeHardwareReverseProxy:
		return sitePathHardwareReverseProxy, true
	case siteModeHardwareTransparentProxy:
		return sitePathHardwareTransparentProxy, true
	case siteModeHardwareTransparentBridge:
		return sitePathHardwareTransparentBridge, true
	case siteModeHardwarePortMirroring:
		return sitePathHardwarePortMirroring, true
	case siteModeSoftwareClusterReverseProxy:
		return sitePathSoftwareClusterReverseProxy, true
	case siteModeSoftwarePortMirroring:
		return sitePathSoftwarePortMirroring, true
	case siteModeHardwareRouterProxy:
		return sitePathHardwareReverseProxy, true
	}
	return "", false
}

func resolveSiteWorkGroupFrom(instanceID int) (string, error) {
	mode := fetchSiteInstanceMode(instanceID)
	if _, ok := sitePathForMode(mode); !ok {
		return "", fmt.Errorf("WAF 运行模式不支持或未识别: %s", mode)
	}
	if mode == siteModeHardwareTransparentProxy {
		return siteWorkGroupFromTransparentProxy, nil
	}
	return siteWorkGroupFromDefault, nil
}

func fetchSiteInstanceMode(instanceID int) string {
	client := captain.GetDefault()
	if client == nil {
		return ""
	}
	resp, err := client.Do(&captain.CaptainRequest{Method: "GET", Path: "/api/group/detail"})
	if err != nil {
		log.Printf("[WARN] fetchSiteInstanceMode: Captain request error: %v", err)
		return ""
	}
	var wrapper struct {
		Data struct {
			WafList []map[string]interface{} `json:"waf_list"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		log.Printf("[WARN] fetchSiteInstanceMode: parse error: %v", err)
		return ""
	}
	for _, inst := range wrapper.Data.WafList {
		if extractIntID(inst["id"]) != instanceID && extractIntID(inst["ID"]) != instanceID {
			continue
		}
		if mode, ok := inst["mode"].(string); ok {
			return mode
		}
		if mode, ok := inst["Mode"].(string); ok {
			return mode
		}
	}
	return ""
}

// proxyReadAux creates a handler that proxies a read-only Captain API request.
func proxyReadAux(path string) gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       path,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

func filterSitesByBinding(body []byte, instanceID int, tenantGroupID uint) []byte {
	var sites []int
	database.DB.Model(&bindingmodel.SiteBinding{}).
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck("site_id", &sites)

	siteMap := make(map[int]bool, len(sites))
	for _, s := range sites {
		siteMap[s] = true
	}

	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		return body
	}

	filtered := make([]map[string]interface{}, 0, len(items))
	for _, item := range items {
		id := getIDFromItem(item)
		if siteMap[id] {
			filtered = append(filtered, item)
		}
	}

	dataOut, _ := json.Marshal(filtered)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// isSiteOwner 校验目标 site_id 是否属于当前租户组在该 WAF 实例下的站点绑定。
func isSiteOwner(instanceID int, siteID int, tenantGroupID uint) bool {
	var count int64
	database.DB.Model(&bindingmodel.SiteBinding{}).
		Where("captain_instance_id = ? AND site_id = ? AND tenant_group_id = ?", instanceID, siteID, tenantGroupID).
		Count(&count)
	return count > 0
}

func extractSiteIDFromBody(body map[string]interface{}) int {
	if id := extractIntID(body["id"]); id > 0 {
		return id
	}
	return extractIntID(body["ID"])
}

func extractSiteDeleteIDs(body map[string]interface{}) []int {
	seen := make(map[int]bool)
	var ids []int
	appendID := func(id int) {
		if id > 0 && !seen[id] {
			ids = append(ids, id)
			seen[id] = true
		}
	}
	for _, key := range []string{"id__in", "ids", "site_ids"} {
		if arr, ok := body[key].([]interface{}); ok {
			for _, item := range arr {
				appendID(extractIntID(item))
			}
		}
	}
	appendID(extractIntID(body["id"]))
	appendID(extractIntID(body["ID"]))
	return ids
}

func sanitizeSiteCreateBody(body map[string]interface{}) map[string]interface{} {
	out := cloneSiteBody(body)
	sanitizeSiteWriteBody(out)
	for _, key := range []string{"id", "ID", "create_time", "last_update_time", "health_check_status"} {
		delete(out, key)
	}
	if backend, ok := out["backend_config"].(map[string]interface{}); ok {
		if backend["type"] == "proxy" {
			delete(backend, "health_check_config")
			delete(backend, "header_config")
		}
	}
	return out
}

func sanitizeSiteUpdateBody(body map[string]interface{}) map[string]interface{} {
	out := cloneSiteBody(body)
	sanitizeSiteWriteBody(out)
	for _, key := range []string{"create_time", "last_update_time", "health_check_status"} {
		delete(out, key)
	}
	return out
}

func cloneSiteBody(body map[string]interface{}) map[string]interface{} {
	raw, err := json.Marshal(body)
	if err != nil {
		return body
	}
	var out map[string]interface{}
	if err := json.Unmarshal(raw, &out); err != nil {
		return body
	}
	return out
}

func sanitizeSiteWriteBody(body map[string]interface{}) {
	for _, key := range []string{
		"captain_instance_id",
		"binding_count",
		"shared_group_names",
		"site_names",
		"source",
		"has_external_ref",
	} {
		delete(body, key)
	}
	if backend, ok := body["backend_config"].(map[string]interface{}); ok {
		if isEmptyValue(backend["session_sticky_cookie_max_age"]) {
			delete(backend, "session_sticky_cookie_max_age")
		}
		if backend["keepalive"] == "" {
			backend["keepalive"] = "0"
		}
		if backend["keepalive_timeout"] == "" {
			backend["keepalive_timeout"] = "0"
		}
		if servers, ok := backend["servers"].([]interface{}); ok {
			for _, server := range servers {
				if item, ok := server.(map[string]interface{}); ok && isEmptyValue(item["weight"]) {
					item["weight"] = 1
				}
			}
		}
	}
}

func isEmptyValue(v interface{}) bool {
	if v == nil {
		return true
	}
	switch val := v.(type) {
	case string:
		return val == ""
	case float64:
		return val == 0
	case int:
		return val == 0
	}
	return false
}

func syncSiteMappingsForAdmin(c *gin.Context, instanceID int, siteID int) {
	if !isAdmin(c) || siteID <= 0 {
		return
	}
	tenantGroupIDs := getTenantGroupIDsForSites(instanceID, []int{siteID})
	for _, tgID := range tenantGroupIDs {
		SyncSiteResourceMappings(instanceID, siteID, tgID)
	}
}

func proxyAndRecordOp(c *gin.Context, method, path string, body map[string]interface{}, instanceID int, onSuccess ...func()) {
	idUint := uint(instanceID)
	req := &captain.CaptainRequest{
		Method:     method,
		Path:       path,
		Body:       body,
		InstanceID: &idUint,
	}

	client := captain.GetDefault()
	breaker := captain.GetDefaultBreaker()
	if breaker != nil {
		if err := breaker.Allow(); err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "breaker_open", "msg": "纵横服务暂不可用", "data": ""})
			return
		}
	}

	resp, err := client.Do(req)
	if err != nil {
		if breaker != nil {
			breaker.RecordFailure()
		}
		c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
		return
	}

	if breaker != nil {
		if resp.StatusCode >= 500 {
			breaker.RecordFailure()
		} else {
			breaker.RecordSuccess()
		}
	}

	if resp.StatusCode == http.StatusUnauthorized {
		c.JSON(http.StatusBadGateway, gin.H{"err": "captain_auth", "msg": "纵横认证失败", "data": ""})
		return
	}

	if resp.StatusCode < 300 && !captainRespHasError(resp.Body) {
		riskguard.RecordWAFOperation(instanceID)
		for _, fn := range onSuccess {
			if fn != nil {
				fn()
			}
		}
	}
	c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
}
