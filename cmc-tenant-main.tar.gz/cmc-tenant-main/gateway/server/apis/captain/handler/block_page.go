package handler

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"path/filepath"
	"time"

	"github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

const (
	blockPageFileSuffix             = ".html"
	blockPageDefaultMaxSizeKB       = 128
	blockPageTransparentBridgeMaxKB = 10
	blockPageTransparentBridgeMode  = "Hardware Transparent Bridging"
)

// BlockPageList proxies block page list queries to Captain.
func BlockPageList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		idUint := uint(instanceID)
		offset := c.DefaultQuery("offset", "0")
		count := c.DefaultQuery("count", "20")
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/ForbiddenPageAPI",
			Query:      "offset=" + offset + "&count=" + count,
			InstanceID: &idUint,
		}
		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var body []byte
		if isAdmin(c) {
			body = resp.Body
		} else {
			body = filterPaginatedByMapping(resp.Body, mappingBlockPage, instanceID, getTenantGroupID(c))
		}
		body = injectBindingCountsInPaginated(body, mappingBlockPage, instanceID)
		if isAdmin(c) {
			body = injectAdminBlockPageProtectionFields(body, instanceID)
		}
		if !isAdmin(c) {
			body = injectSourceInPaginated(body, mappingBlockPage, instanceID, getTenantGroupID(c))
		}
		body = wrapCaptainResp(body)
		c.Data(resp.StatusCode, "application/json", body)
	}
}

// BlockPageUpload proxies block page upload to Captain.
func BlockPageUpload() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		form, err := c.MultipartForm()
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		maxSizeKB := blockPageUploadMaxSizeKB(instanceID, form.Value)
		for _, files := range form.File {
			for _, f := range files {
				if filepath.Ext(f.Filename) != blockPageFileSuffix {
					c.JSON(http.StatusBadRequest, gin.H{"err": "invalid_format", "msg": "仅支持 .html 格式文件", "data": ""})
					return
				}
				if f.Size > int64(maxSizeKB*1024) {
					c.JSON(http.StatusBadRequest, gin.H{
						"err":  "file_too_large",
						"msg":  fmt.Sprintf("自定义拦截页面最大为 %d KB", maxSizeKB),
						"data": "",
					})
					return
				}
			}
		}

		var formUnits []*captain.FormUnit
		for fieldName, files := range form.File {
			for _, f := range files {
				file, _ := f.Open()
				defer func() { _ = file.Close() }()
				buf := make([]byte, f.Size)
				_, _ = file.Read(buf)
				formUnits = append(formUnits, &captain.FormUnit{
					FieldName: fieldName,
					FileName:  f.Filename,
					Data:      buf,
					IsFile:    true,
				})
			}
		}
		for fieldName, values := range form.Value {
			if fieldName == "captain_instance_id" {
				continue
			}
			for _, v := range values {
				formUnits = append(formUnits, &captain.FormUnit{
					FieldName: fieldName,
					Data:      []byte(v),
					IsFile:    false,
				})
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       "/api/UploadForbiddenPageAPI",
			Form:       formUnits,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		log.Printf("[DEBUG] BlockPageUpload: captain status=%d, isAdmin=%v", resp.StatusCode, isAdmin(c))

		// UploadForbiddenPageAPI returns {data:{path:"md5hash"}} without id.
		// Query the list API to find the new record's id for mapping.
		if resp.StatusCode < 300 && !isAdmin(c) {
			path := extractPathFromUploadResp(resp.Body)
			if path != "" {
				id := findBlockPageIDByName(instanceID, path)
				log.Printf("[DEBUG] BlockPageUpload: path=%q blockPageID=%d", path, id)
				if id > 0 {
					writeMapping(mappingBlockPage, instanceID, id, getTenantGroupID(c), "created")
				}
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// BlockPageDelete proxies block page deletion to Captain with dual protection.
func BlockPageDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		// Extract name hash early for runtime check and resource ID lookup
		nameHash, _ := body["name"].(string)
		if nameHash == "" {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "缺少拦截页面标识", "data": ""})
			return
		}

		resourceID := findBlockPageIDByName(instanceID, nameHash)
		if resourceID <= 0 {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无法确认资源归属，拒绝操作", "data": ""})
			return
		}

		// Ownership check
		if !isAdmin(c) {
			if !isMappingOwner(mappingBlockPage, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}

		// Runtime protection: real-time query to Captain API for policy_group_used_count
		usedCount := getBlockPageUsedCount(instanceID, nameHash)
		if usedCount > 0 {
			c.JSON(http.StatusForbidden, gin.H{"err": "in_use", "msg": fmt.Sprintf("该拦截页面正在被 %d 个防护策略使用，无法删除", usedCount), "data": ""})
			return
		}

		// Shared protection: binding_count > 1 requires a one-time confirm_token for all roles.
		// The token is issued in the err=shared response and must be presented on retry.
		// Non-admin frontend shows a toast and stops; admin frontend shows a confirm dialog and retries.
		if checkBlockPageShared(instanceID, resourceID) {
			confirmToken := c.Query("confirm_token")
			userID := getUser(c).ID
			if confirmToken == "" || !validateAndConsumeBPConfirmToken(userID, nameHash, confirmToken) {
				token, _ := generateBPConfirmToken(userID, nameHash)
				sharedNames := getBlockPageSharedGroupNames(instanceID, resourceID)
				c.JSON(http.StatusForbidden, gin.H{
					"err":                "shared",
					"msg":                "该拦截页面被多个租户组共享，无法删除",
					"data":               "",
					"confirm_token":      token,
					"shared_group_names": sharedNames,
				})
				return
			}
		}

		captainBody := map[string]interface{}{
			"name__in": []interface{}{nameHash},
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "DELETE",
			Path:       "/api/ForbiddenPageAPI",
			Body:       captainBody,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 && resourceID > 0 {
			if !isAdmin(c) {
				deleteMapping(mappingBlockPage, instanceID, resourceID, getTenantGroupID(c))
			} else {
				database.DB.Table("captain_block_page_bindings").
					Where("captain_instance_id = ? AND block_page_id = ?", instanceID, resourceID).
					Delete(nil)
			}

		}
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// BlockPageDownload proxies block page file download from Captain.
func BlockPageDownload() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		nameHash := c.Query("name")
		if nameHash == "" {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "缺少文件标识", "data": ""})
			return
		}

		// Permission check for non-admin: verify the block page belongs to this tenant
		if !isAdmin(c) {
			if !isBlockPageOwnerByName(instanceID, nameHash, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该资源", "data": ""})
				return
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/DownloadFileStorage",
			Query:      "name=" + nameHash,
			InstanceID: &idUint,
		}
		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		contentType := "application/octet-stream"
		c.Data(resp.StatusCode, contentType, resp.Body)
	}
}

// --- Helper functions ---

// filterPaginatedByMapping filters items in a paginated response and updates total.
func filterPaginatedByMapping(body []byte, table mappingTable, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	filtered := filterByMapping(table, instanceID, tenantGroupID, page.Items)
	page.Items = filtered
	page.Total = len(filtered)

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// injectBindingCountsInPaginated adds binding_count to items in a paginated response.
func injectBindingCountsInPaginated(body []byte, table mappingTable, instanceID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	if len(page.Items) == 0 {
		return body
	}

	ids := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			ids = append(ids, id)
		}
	}

	counts := getBindingCounts(table, instanceID, ids)
	for _, item := range page.Items {
		id := getIDFromItem(item)
		if id > 0 {
			item["binding_count"] = counts[id]
		} else {
			item["binding_count"] = 0
		}
	}

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// injectAdminBlockPageProtectionFields adds shared_group_names to each block page
// in the list response for admin users. This mirrors injectAdminRuleProtectionFields
// but simplified — block pages have no websites/external_ref concept.
func injectAdminBlockPageProtectionFields(body []byte, instanceID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}
	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}
	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}
	if len(page.Items) == 0 {
		return body
	}

	bpIDs := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			bpIDs = append(bpIDs, id)
		}
	}

	// Batch query all bindings for these block pages
	type bindingRow struct {
		BlockPageID   int  `gorm:"column:block_page_id"`
		TenantGroupID uint `gorm:"column:tenant_group_id"`
	}
	var bindings []bindingRow
	database.DB.Table("captain_block_page_bindings").
		Select("block_page_id, tenant_group_id").
		Where("captain_instance_id = ? AND block_page_id IN ?", instanceID, bpIDs).
		Find(&bindings)

	bpTGMap := make(map[int][]uint, len(bpIDs))
	allTGIDs := make(map[uint]bool)
	for _, b := range bindings {
		bpTGMap[b.BlockPageID] = append(bpTGMap[b.BlockPageID], b.TenantGroupID)
		allTGIDs[b.TenantGroupID] = true
	}

	// Batch query TG names
	tgIDSlice := make([]uint, 0, len(allTGIDs))
	for id := range allTGIDs {
		tgIDSlice = append(tgIDSlice, id)
	}
	tgNameMap := make(map[uint]string)
	if len(tgIDSlice) > 0 {
		var groups []model.TenantGroup
		database.DB.Where("id IN ? AND is_deleted = false", tgIDSlice).Find(&groups)
		for _, g := range groups {
			tgNameMap[g.ID] = g.Name
		}
	}

	for _, item := range page.Items {
		bpID := getIDFromItem(item)
		if bpID <= 0 {
			continue
		}
		tgIDs := bpTGMap[bpID]
		if len(tgIDs) > 1 {
			const maxSharedNames = 5
			names := make([]string, 0, len(tgIDs))
			for _, tgID := range tgIDs {
				if name, ok := tgNameMap[tgID]; ok {
					names = append(names, name)
				}
				if len(names) >= maxSharedNames {
					break
				}
			}
			item["shared_group_names"] = names
		} else {
			item["shared_group_names"] = []string{}
		}
	}

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// checkBlockPageShared returns true if the block page is bound to more than one tenant group.
func checkBlockPageShared(instanceID int, resourceID int) bool {
	var count int64
	database.DB.Table("captain_block_page_bindings").
		Distinct("tenant_group_id").
		Where("captain_instance_id = ? AND block_page_id = ?", instanceID, resourceID).
		Count(&count)
	return count > 1
}

// extractPathFromUploadResp extracts the "path" field from UploadForbiddenPageAPI response.
func extractPathFromUploadResp(body []byte) string {
	var resp struct {
		Data struct {
			Path string `json:"path"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return ""
	}
	return resp.Data.Path
}

// isBlockPageOwnerByName checks if the block page with the given name hash belongs to the tenant group.
func isBlockPageOwnerByName(instanceID int, nameHash string, tenantGroupID uint) bool {
	id := findBlockPageIDByName(instanceID, nameHash)
	if id <= 0 {
		return false
	}
	return isMappingOwner(mappingBlockPage, instanceID, id, tenantGroupID)
}

// getBlockPageUsedCount queries Captain API to get the real-time policy_group_used_count for a block page.
func getBlockPageUsedCount(instanceID int, nameHash string) int {
	idUint := uint(instanceID)
	req := &captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/ForbiddenPageAPI",
		Query:      "count=1000&offset=0",
		InstanceID: &idUint,
	}
	resp, err := captain.GetDefault().Do(req)
	if err != nil {
		log.Printf("[WARN] getBlockPageUsedCount: Captain request error: %v", err)
		return 0
	}

	var wrapper struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		log.Printf("[WARN] getBlockPageUsedCount: parse error: %v", err)
		return 0
	}

	for _, item := range wrapper.Data.Items {
		if n, _ := item["name"].(string); n == nameHash {
			if v, ok := item["policy_group_used_count"]; ok {
				count := extractIntID(v)
				if count > 0 {
					return count
				}
				return countPolicyForbiddenPageRefs(instanceID, nameHash)
			}
			return countPolicyForbiddenPageRefs(instanceID, nameHash)
		}
	}
	return countPolicyForbiddenPageRefs(instanceID, nameHash)
}

func countPolicyForbiddenPageRefs(instanceID int, nameHash string) int {
	idUint := uint(instanceID)
	resp, err := captain.GetDefault().Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/PolicyGroupAPI",
		InstanceID: &idUint,
	})
	if err != nil || resp.StatusCode >= 300 {
		if err != nil {
			log.Printf("[WARN] countPolicyForbiddenPageRefs: Captain request error: %v", err)
		}
		return 0
	}

	var wrapper struct {
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil || len(wrapper.Data) == 0 {
		return 0
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(wrapper.Data, &items); err != nil {
		var page struct {
			Items []map[string]interface{} `json:"items"`
		}
		if err := json.Unmarshal(wrapper.Data, &page); err != nil {
			return 0
		}
		items = page.Items
	}

	count := 0
	for _, item := range items {
		if fpc, ok := item["forbidden_page_config"].(map[string]interface{}); ok {
			if path, _ := fpc["path"].(string); path == nameHash {
				count++
			}
		}
	}
	return count
}

func blockPageUploadMaxSizeKB(instanceID int, values map[string][]string) int {
	mode := fetchBlockPageInstanceMode(instanceID)
	if mode == "" {
		if modes := values["operation_mode"]; len(modes) > 0 {
			mode = modes[0]
		}
	}
	if mode == blockPageTransparentBridgeMode {
		return blockPageTransparentBridgeMaxKB
	}
	return blockPageDefaultMaxSizeKB
}

func fetchBlockPageInstanceMode(instanceID int) string {
	client := captain.GetDefault()
	if client == nil {
		return ""
	}
	resp, err := client.Do(&captain.CaptainRequest{Method: "GET", Path: "/api/group/detail"})
	if err != nil {
		log.Printf("[WARN] fetchBlockPageInstanceMode: Captain request error: %v", err)
		return ""
	}
	var wrapper struct {
		Data struct {
			WafList []map[string]interface{} `json:"waf_list"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		log.Printf("[WARN] fetchBlockPageInstanceMode: parse error: %v", err)
		return ""
	}
	for _, inst := range wrapper.Data.WafList {
		if blockPageValueAsInt(inst["id"]) != instanceID && blockPageValueAsInt(inst["ID"]) != instanceID {
			continue
		}
		return blockPageFieldString(inst, "mode", "Mode")
	}
	return ""
}

func blockPageValueAsInt(v interface{}) int {
	switch n := v.(type) {
	case float64:
		return int(n)
	case json.Number:
		i, _ := n.Int64()
		return int(i)
	case int:
		return n
	case uint:
		return int(n)
	default:
		return 0
	}
}

func blockPageFieldString(inst map[string]interface{}, keys ...string) string {
	for _, key := range keys {
		if v, ok := inst[key].(string); ok {
			return v
		}
	}
	return ""
}

// generateBPConfirmToken issues a single-use confirm token for shared block page deletion.
// Token is stored in Redis with a 60s TTL, bound to userID and bpName.
func generateBPConfirmToken(userID uint, bpName string) (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	token := hex.EncodeToString(b)
	key := fmt.Sprintf("confirm:bp:%d:%s", userID, bpName)
	return token, database.RDB.Set(context.Background(), key, token, 60*time.Second).Err()
}

// validateAndConsumeBPConfirmToken checks and atomically deletes the confirm token (single-use).
func validateAndConsumeBPConfirmToken(userID uint, bpName string, token string) bool {
	key := fmt.Sprintf("confirm:bp:%d:%s", userID, bpName)
	stored, err := database.RDB.GetDel(context.Background(), key).Result()
	if err != nil {
		return false
	}
	return stored == token
}

// getBlockPageSharedGroupNames returns the tenant group names bound to the given block page (up to 5).
func getBlockPageSharedGroupNames(instanceID int, resourceID int) []string {
	type bindingRow struct {
		TenantGroupID uint `gorm:"column:tenant_group_id"`
	}
	var bindings []bindingRow
	database.DB.Table("captain_block_page_bindings").
		Select("tenant_group_id").
		Where("captain_instance_id = ? AND block_page_id = ?", instanceID, resourceID).
		Find(&bindings)

	const maxSharedNames = 5
	tgIDs := make([]uint, 0, len(bindings))
	for _, b := range bindings {
		tgIDs = append(tgIDs, b.TenantGroupID)
		if len(tgIDs) >= maxSharedNames {
			break
		}
	}
	if len(tgIDs) == 0 {
		return []string{}
	}
	var groups []model.TenantGroup
	database.DB.Where("id IN ? AND is_deleted = false", tgIDs).Find(&groups)
	names := make([]string, 0, len(groups))
	for _, g := range groups {
		names = append(names, g.Name)
	}
	return names
}

// injectSourceInPaginated adds source field to items in a paginated response.
func injectSourceInPaginated(body []byte, table mappingTable, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	if len(page.Items) == 0 {
		return body
	}

	ids := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			ids = append(ids, id)
		}
	}

	sources := getMappingSources(table, instanceID, tenantGroupID, ids)
	for _, item := range page.Items {
		id := getIDFromItem(item)
		if id > 0 {
			if s, ok := sources[id]; ok {
				item["source"] = s
			} else {
				item["source"] = "created"
			}
		}
	}

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}
