package handler

import (
	"encoding/json"
	"net/http"
	"net/url"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/gin-gonic/gin"
)

// BotLogRecordList proxies bot log record list queries to Captain.
func BotLogRecordList() gin.HandlerFunc {
	return botLogProxy("/api/bot_log/record/list")
}

// BotLogRecordDetail proxies bot log record detail queries to Captain.
// 前端传 id，Captain record/detail 实际接收的参数名是 challenge_id。
func BotLogRecordDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		id := c.Query("id")
		req := &captain.CaptainRequest{
			Method: "GET",
			Path:   "/api/bot_log/record/detail",
			Query:  "challenge_id=" + url.QueryEscape(id),
		}
		botLogDetailRequest(c, req)
	}
}

// BotLogResultList proxies bot log result list queries to Captain.
func BotLogResultList() gin.HandlerFunc {
	return botLogProxy("/api/bot_log/result/list")
}

// BotLogResultDetail proxies bot log result detail queries to Captain.
func BotLogResultDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		req := &captain.CaptainRequest{
			Method: "GET",
			Path:   "/api/bot_log/result/detail",
			Query:  c.Request.URL.RawQuery,
		}
		botLogDetailRequest(c, req)
	}
}

// botLogDetailRequest 请求 Captain 后将 data:[]BotLogDetail 解包为单对象，并对非 admin 用户校验归属。
func botLogDetailRequest(c *gin.Context, req *captain.CaptainRequest) {
	resp, err := captain.GetDefault().Do(req)
	if err != nil {
		c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
		return
	}

	body, detail := unwrapBotLogDetailArray(resp.Body)
	if !isAdmin(c) {
		if detail == nil || !checkBotLogDetailOwnership(detail, getAllowedWafIDs(c), getAllowedSiteIDs(c)) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该日志", "data": ""})
			return
		}
	}

	c.Data(resp.StatusCode, "application/json", wrapCaptainResp(body))
}

// unwrapBotLogDetailArray 把 Captain 返回的 data: []BotLogDetail 解包成 data: BotLogDetail（取第一个元素）。
// 返回解包后的响应体，以及解包出的单条记录（供归属校验使用，无记录时为 nil）。
func unwrapBotLogDetailArray(body []byte) ([]byte, map[string]interface{}) {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body, nil
	}
	dataRaw, ok := resp["data"]
	if !ok {
		return body, nil
	}
	var items []map[string]interface{}
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		// data 已经是单对象（非数组），原样返回。
		var detail map[string]interface{}
		_ = json.Unmarshal(dataRaw, &detail)
		return body, detail
	}
	if len(items) == 0 {
		resp["data"] = json.RawMessage("null")
		out, _ := json.Marshal(resp)
		return out, nil
	}
	dataOut, _ := json.Marshal(items[0])
	resp["data"] = dataOut
	out, _ := json.Marshal(resp)
	return out, items[0]
}

// checkBotLogDetailOwnership 校验 Bot 日志详情归属：waf_id 和 site_uuid 都必须在允许范围内。
func checkBotLogDetailOwnership(item map[string]interface{}, allowedWafIDs []int, allowedSiteIDs []int) bool {
	wafID := extractIntID(item["waf_id"])
	wafOK := false
	for _, id := range allowedWafIDs {
		if id == wafID {
			wafOK = true
			break
		}
	}
	if !wafOK {
		return false
	}

	siteID := extractIntID(item["site_uuid"])
	for _, id := range allowedSiteIDs {
		if id == siteID {
			return true
		}
	}
	return false
}

func botLogProxy(path string) gin.HandlerFunc {
	return func(c *gin.Context) {
		var body map[string]interface{}
		if err := c.ShouldBindJSON(&body); err != nil {
			body = make(map[string]interface{})
		}

		convertConditionsToBasicFilter(body, "")

		if !isAdmin(c) {
			captain.InjectLogFilter(body, getAllowedWafIDs(c))
			captain.InjectBotLogSiteFilter(body, getAllowedSiteIDs(c))
		}

		req := &captain.CaptainRequest{
			Method: "POST",
			Path:   path,
			Body:   body,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		enhanced := captain.EnhanceLogResponse(resp.Body)
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(enhanced))
	}
}
