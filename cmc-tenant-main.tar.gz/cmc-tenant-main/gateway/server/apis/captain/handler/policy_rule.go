package handler

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

// PolicyRuleList proxies custom rule list queries to Captain.
// Fetches ALL rules from Captain (no server-side pagination), then applies
// local filtering (tenant mapping + site_id conditions), enrichment, and pagination.
func PolicyRuleList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		// Parse frontend pagination params for local pagination later
		reqOffset := parseQueryInt(c, "offset", 0)
		reqCount := parseQueryInt(c, "count", 20)

		// Parse all filter conditions from frontend for local filtering.
		// Captain API does not support conditions on PolicyRuleAPI, so we filter locally.
		filter := parsePolicyRuleFilter(c)

		// Build a clean Captain query: fetch ALL rules with a large count.
		// Do NOT forward frontend's offset/count — Captain caps results when
		// count is small, and we need all items for correct total + local pagination.
		query := "is_global=false&count=10000&offset=0"
		if ruleType := c.Query("rule_type"); ruleType != "" {
			query += "&rule_type=" + ruleType
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/PolicyRuleAPI",
			Query:      query,
			InstanceID: &idUint,
		}
		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var body []byte
		if isAdmin(c) {
			body = resp.Body
		} else {
			body = filterResponseByMapping(resp.Body, mappingPolicyRule, instanceID, getTenantGroupID(c))
		}

		// Apply all filter conditions (id, comment, is_enabled, action, risk_level,
		// attack_type, cron_config, time ranges, site_id, forward_address, etc.)
		// BEFORE wrapListAsPage so total count is correct.
		body = filterByPolicyRuleFilter(body, filter)

		body = injectSiteNames(body, client, instanceID)
		body = wrapListAsPage(body)
		body = injectBindingCounts(body, mappingPolicyRule, instanceID)

		if !isAdmin(c) {
			body = injectRuleProtectionFields(body, instanceID, getTenantGroupID(c))
			allowedSites := getAllowedSiteIDs(c)
			body = filterRuleWebsites(body, allowedSites)
		} else {
			body = injectAdminRuleProtectionFields(body, instanceID)
		}

		// Apply local pagination: slice the enriched items for the requested page
		body = applyLocalPagination(body, reqOffset, reqCount)

		c.Data(resp.StatusCode, "application/json", body)
	}
}

// PolicyRuleCreate creates a non-global policy rule via Captain.
// Non-admin: restricts websites to tenant-bound sites and validates ingroup IP groups.
func PolicyRuleCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		body["is_global"] = false

		if !isAdmin(c) {
			if err := validateRuleWebsitesScope(body, c); err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			if err := validateRuleInGroupScope(body, instanceID, getTenantGroupID(c)); err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
		}

		// Route to correct Captain API based on action type; convert module/skynet format
		action, _ := body["action"].(string)
		captainPath := "/api/PolicyRuleAPI"
		switch action {
		case "modify_module":
			captainPath = "/api/ModifyModulePolicyRuleAPI"
		case "modify_skynet_rule":
			captainPath = "/api/ModifySkynetRulePolicyRuleAPI"
		}

		// Validate non-empty pattern for all action types
		pattern, hasPattern := body["pattern"]
		if !hasPattern || pattern == nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "匹配条件不能为空", "data": ""})
			return
		}
		patternMap, ok := pattern.(map[string]interface{})
		if !ok || len(patternMap) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "匹配条件不能为空", "data": ""})
			return
		}

		// Convert module_management from [{key, enabled}] to {disabled: [...], enabled: [...]}
		if action == "modify_module" {
			if mmArr, ok := body["module_management"].([]interface{}); ok {
				disabled := []string{}
				enabled := []string{}
				for _, item := range mmArr {
					if m, ok := item.(map[string]interface{}); ok {
						key, _ := m["key"].(string)
						enabledVal, _ := m["enabled"].(bool)
						if enabledVal {
							enabled = append(enabled, key)
						} else {
							disabled = append(disabled, key)
						}
					}
				}
				body["module_management"] = map[string]interface{}{
					"disabled": disabled,
					"enabled":  enabled,
				}
			}
		}

		// Convert skynet_rule_management from [{key, enabled}] to {disabled: [...], enabled: [...]}
		if action == "modify_skynet_rule" {
			if srArr, ok := body["skynet_rule_management"].([]interface{}); ok {
				disabled := []string{}
				enabled := []string{}
				for _, item := range srArr {
					if m, ok := item.(map[string]interface{}); ok {
						key, _ := m["key"].(string)
						enabledVal, _ := m["enabled"].(bool)
						if enabledVal {
							enabled = append(enabled, key)
						} else {
							disabled = append(disabled, key)
						}
					}
				}
				body["skynet_rule_management"] = map[string]interface{}{
					"disabled": disabled,
					"enabled":  enabled,
				}
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       captainPath,
			Body:       body,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 {
			if !isAdmin(c) {
				if id := extractIDFromResp(resp.Body); id > 0 {
					writeMapping(mappingPolicyRule, instanceID, id, getTenantGroupID(c), "created")
				}
				for _, ipGroupID := range extractInGroupIDs(body["pattern"]) {
					writeMappingIfNotExists(mappingIPGroup, instanceID, ipGroupID, getTenantGroupID(c), "inherited")
				}
			} else {
				if id := extractIDFromResp(resp.Body); id > 0 {
					websites := extractWebsitesFromBody(body)
					writeMappingForSiteTenantGroups(mappingPolicyRule, instanceID, id, websites)
					for _, ipGroupID := range extractInGroupIDs(body["pattern"]) {
						writeMappingForSiteTenantGroups(mappingIPGroup, instanceID, ipGroupID, websites)
					}
				}
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyRuleUpdate updates a policy rule via Captain.
// Protection: shared (binding_count > 1) + edit protection (external reference check).
func PolicyRuleUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		body["is_global"] = false

		resourceID := extractResourceID(body, mappingPolicyRule)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingPolicyRule, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if !isAdmin(c) {
			if resourceID > 0 && checkPolicyRuleShared(instanceID, resourceID) {
				c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，不可编辑", "data": ""})
				return
			}
			if err := checkRuleEditProtection(c, instanceID, resourceID); err != nil {
				c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
				return
			}
		}

		if !isAdmin(c) {
			if err := validateRuleWebsitesScope(body, c); err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			if err := validateRuleInGroupScope(body, instanceID, getTenantGroupID(c)); err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
		}

		// Route to correct Captain API based on action type; convert module/skynet format
		action, _ := body["action"].(string)
		captainPath := "/api/PolicyRuleAPI"
		switch action {
		case "modify_module":
			captainPath = "/api/ModifyModulePolicyRuleAPI"
		case "modify_skynet_rule":
			captainPath = "/api/ModifySkynetRulePolicyRuleAPI"
		}

		// Validate non-empty pattern for all action types
		pattern, hasPattern := body["pattern"]
		if !hasPattern || pattern == nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "匹配条件不能为空", "data": ""})
			return
		}
		patternMap, ok := pattern.(map[string]interface{})
		if !ok || len(patternMap) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "匹配条件不能为空", "data": ""})
			return
		}

		// Convert module_management from [{key, enabled}] to {disabled: [...], enabled: [...]}
		if action == "modify_module" {
			if mmArr, ok := body["module_management"].([]interface{}); ok {
				disabled := []string{}
				enabled := []string{}
				for _, item := range mmArr {
					if m, ok := item.(map[string]interface{}); ok {
						key, _ := m["key"].(string)
						enabledVal, _ := m["enabled"].(bool)
						if enabledVal {
							enabled = append(enabled, key)
						} else {
							disabled = append(disabled, key)
						}
					}
				}
				body["module_management"] = map[string]interface{}{
					"disabled": disabled,
					"enabled":  enabled,
				}
			}
		}

		// Convert skynet_rule_management from [{key, enabled}] to {disabled: [...], enabled: [...]}
		if action == "modify_skynet_rule" {
			if srArr, ok := body["skynet_rule_management"].([]interface{}); ok {
				disabled := []string{}
				enabled := []string{}
				for _, item := range srArr {
					if m, ok := item.(map[string]interface{}); ok {
						key, _ := m["key"].(string)
						enabledVal, _ := m["enabled"].(bool)
						if enabledVal {
							enabled = append(enabled, key)
						} else {
							disabled = append(disabled, key)
						}
					}
				}
				body["skynet_rule_management"] = map[string]interface{}{
					"disabled": disabled,
					"enabled":  enabled,
				}
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       captainPath,
			Body:       body,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 {
			if !isAdmin(c) {
				for _, ipGroupID := range extractInGroupIDs(body["pattern"]) {
					writeMappingIfNotExists(mappingIPGroup, instanceID, ipGroupID, getTenantGroupID(c), "inherited")
				}
			} else {
				websites := extractWebsitesFromBody(body)
				resourceID := extractResourceID(body, mappingPolicyRule)
				if resourceID > 0 {
					writeMappingForSiteTenantGroups(mappingPolicyRule, instanceID, resourceID, websites)
				}
				for _, ipGroupID := range extractInGroupIDs(body["pattern"]) {
					writeMappingForSiteTenantGroups(mappingIPGroup, instanceID, ipGroupID, websites)
				}
				// Reconcile IP group mappings (clean up stale ingroup references)
				reconcileIPGroupMappingsForSites(instanceID, websites)
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyRuleDelete deletes a policy rule via Captain.
// Protection: runtime (websites > 0) + shared (binding_count > 1).
func PolicyRuleDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		resourceID := extractResourceID(body, mappingPolicyRule)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingPolicyRule, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}

		// Runtime protection: check if rule is in use by sites
		if resourceID > 0 {
			client := captain.GetDefault()
			websites := getRuleWebsites(client, instanceID, resourceID)
			if len(websites) > 0 {
				c.JSON(http.StatusForbidden, gin.H{"err": "in_use", "msg": fmt.Sprintf("该规则正在被 %d 个站点使用，无法删除", len(websites)), "data": ""})
				return
			}
		}

		if !isAdmin(c) && resourceID > 0 && checkPolicyRuleShared(instanceID, resourceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，无法删除", "data": ""})
			return
		}

		captainBody := map[string]interface{}{
			"id__in": []interface{}{resourceID},
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "DELETE",
			Path:       "/api/PolicyRuleAPI",
			Body:       captainBody,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 && resourceID > 0 {
			if !isAdmin(c) {
				deleteMapping(mappingPolicyRule, instanceID, resourceID, getTenantGroupID(c))
			} else {
				database.DB.Table("captain_policy_rule_bindings").
					Where("captain_instance_id = ? AND rule_id = ?", instanceID, resourceID).
					Delete(nil)
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyRuleEnable toggles a policy rule's enabled status via Captain.
// Protection: shared (binding_count > 1) + edit protection (external reference check).
func PolicyRuleEnable() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		if !isAdmin(c) {
			tgID := getTenantGroupID(c)
			if !checkRuleIDsOwnership(instanceID, body, tgID) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if !isAdmin(c) {
			if checkRuleIDsShared(instanceID, body) {
				c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，不可变更状态", "data": ""})
				return
			}
			if err := checkRuleIDsEditProtection(c, instanceID, body); err != nil {
				c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
				return
			}
		}

		// Construct clean Captain body using id__in (not ids) — WAF API only recognizes id__in
		idsRaw, ok := body["ids"].([]interface{})
		if !ok || len(idsRaw) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "ids 不能为空", "data": ""})
			return
		}
		idIn := make([]interface{}, 0, len(idsRaw))
		for _, id := range idsRaw {
			idIn = append(idIn, int(id.(float64)))
		}

		captainBody := map[string]interface{}{
			"id__in": idIn,
			"action": body["action"],
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/EnableDisablePolicyRuleAPI",
			Body:       captainBody,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicyRuleModulePost creates a policy rule module via Captain.
// Protection: shared (binding_count > 1) + edit protection (external reference check).
func PolicyRuleModulePost() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		body["is_global"] = false

		resourceID := extractResourceID(body, mappingPolicyRule)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingPolicyRule, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if !isAdmin(c) {
			if resourceID > 0 && checkPolicyRuleShared(instanceID, resourceID) {
				c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，不可修改", "data": ""})
				return
			}
			if err := checkRuleEditProtection(c, instanceID, resourceID); err != nil {
				c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
				return
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       "/api/ModifyModulePolicyRuleAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicyRuleModulePut updates a policy rule module via Captain.
// Protection: shared (binding_count > 1) + edit protection (external reference check).
func PolicyRuleModulePut() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		body["is_global"] = false

		resourceID := extractResourceID(body, mappingPolicyRule)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingPolicyRule, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if !isAdmin(c) {
			if resourceID > 0 && checkPolicyRuleShared(instanceID, resourceID) {
				c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，不可修改", "data": ""})
				return
			}
			if err := checkRuleEditProtection(c, instanceID, resourceID); err != nil {
				c.JSON(http.StatusForbidden, gin.H{"err": err.err, "msg": err.msg, "data": ""})
				return
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/ModifyModulePolicyRuleAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicyRuleSkynetRulePut updates a skynet rule policy rule via Captain.
// Shared resource protection: binding_count > 1 rules cannot be modified.
func PolicyRuleSkynetRulePut() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		body["is_global"] = false

		resourceID := extractResourceID(body, mappingPolicyRule)
		if !isAdmin(c) {
			if resourceID > 0 && !isMappingOwner(mappingPolicyRule, instanceID, resourceID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}
		if !isAdmin(c) && resourceID > 0 && checkPolicyRuleShared(instanceID, resourceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "shared", "msg": "该资源被多个租户组绑定，不可修改", "data": ""})
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/ModifySkynetRulePolicyRuleAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicyRulePriority updates rule priority order via Captain.
func PolicyRulePriority() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		if !isAdmin(c) {
			if !checkRuleIDsInBody(instanceID, body, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/PolicyRulePriorityAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// PolicyRuleBind binds existing policy rules to a website via Captain.
func PolicyRuleBind() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		if !isAdmin(c) {
			if !checkRuleIDsInBody(instanceID, body, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/PolicyRuleWebsiteBindingAPI",
			Body:       body,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 && isAdmin(c) {
			websites := extractWebsitesFromBody(body)
			ruleIDs := extractRuleIDsFromBody(body)
			for _, ruleID := range ruleIDs {
				writeMappingForSiteTenantGroups(mappingPolicyRule, instanceID, ruleID, websites)
				ipGroupIDs := fetchRuleInGroupIDs(client, instanceID, ruleID)
				for _, ipGroupID := range ipGroupIDs {
					writeMappingForSiteTenantGroups(mappingIPGroup, instanceID, ipGroupID, websites)
				}
			}
			// Bind does not change existing ingroup references, no IP group reconciliation needed
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// PolicyRuleUnbind unbinds a policy rule from a website via Captain.
func PolicyRuleUnbind() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}

		if !isAdmin(c) {
			if !checkRuleIDsInBody(instanceID, body, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作该资源", "data": ""})
				return
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "DELETE",
			Path:       "/api/PolicyRuleWebsiteBindingAPI",
			Body:       body,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		// After successful unbind, clean up tenant binding if rule no longer belongs to any tenant site.
		if resp.StatusCode < 300 && !isAdmin(c) {
			ruleID := extractPolicyRuleIDFromBody(body)
			if ruleID > 0 {
				cleanupRuleBindingIfOrphaned(c, client, instanceID, ruleID, getTenantGroupID(c))
			}
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

func extractPolicyRuleIDFromBody(body map[string]interface{}) int {
	if arr, ok := body["policy_rule_ids"].([]interface{}); ok && len(arr) > 0 {
		return int(arr[0].(float64))
	}
	if arr, ok := body["ids"].([]interface{}); ok && len(arr) > 0 {
		return int(arr[0].(float64))
	}
	if v, ok := body["policy_rule"].(float64); ok {
		return int(v)
	}
	if v, ok := body["id"].(float64); ok {
		return int(v)
	}
	return 0
}

func cleanupRuleBindingIfOrphaned(c *gin.Context, client *captain.CaptainClient, instanceID int, ruleID int, tenantGroupID uint) {
	tenantSiteIDs := getAllowedSiteIDs(c)
	if len(tenantSiteIDs) == 0 {
		deleteMapping(mappingPolicyRule, instanceID, ruleID, tenantGroupID)
		return
	}
	tenantSiteSet := make(map[int]bool, len(tenantSiteIDs))
	for _, id := range tenantSiteIDs {
		tenantSiteSet[id] = true
	}

	// Fetch rule from Captain to check current websites
	idUint := uint(instanceID)
	ruleReq := &captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("/api/PolicyRuleAPI?offset=0&count=1&is_global=false&id=%d", ruleID),
		InstanceID: &idUint,
	}
	ruleResp, err := client.Do(ruleReq)
	if err != nil || ruleResp.StatusCode >= 300 {
		return // Can't verify, keep binding
	}

	var listResp struct {
		Data []struct {
			Websites []int `json:"websites"`
		} `json:"data"`
	}
	if err := json.Unmarshal(ruleResp.Body, &listResp); err != nil || len(listResp.Data) == 0 {
		// Rule deleted or not found, clean up binding
		deleteMapping(mappingPolicyRule, instanceID, ruleID, tenantGroupID)
		return
	}

	for _, siteID := range listResp.Data[0].Websites {
		if tenantSiteSet[siteID] {
			return // Rule still bound to a tenant site, keep binding
		}
	}

	// Rule no longer bound to any tenant site
	deleteMapping(mappingPolicyRule, instanceID, ruleID, tenantGroupID)
}

// --- Shared resource check ---

// --- Protection checks ---

type protectionError struct {
	err string
	msg string
}

// checkPolicyRuleShared returns true if the policy rule is bound to more than one tenant group.
func checkPolicyRuleShared(instanceID int, ruleID int) bool {
	var count int64
	database.DB.Table("captain_policy_rule_bindings").
		Where("captain_instance_id = ? AND rule_id = ?", instanceID, ruleID).
		Count(&count)
	return count > 1
}

// checkRuleIDsShared checks if any rule ID in the body's "ids" array is shared.
func checkRuleIDsShared(instanceID int, body map[string]interface{}) bool {
	ids, ok := body["ids"].([]interface{})
	if !ok {
		return false
	}
	for _, id := range ids {
		if ruleID := int(id.(float64)); ruleID > 0 {
			if checkPolicyRuleShared(instanceID, ruleID) {
				return true
			}
		}
	}
	return false
}

func checkRuleIDsOwnership(instanceID int, body map[string]interface{}, tenantGroupID uint) bool {
	ids, ok := body["ids"].([]interface{})
	if !ok {
		return false
	}
	for _, id := range ids {
		ruleID := int(id.(float64))
		if !isMappingOwner(mappingPolicyRule, instanceID, ruleID, tenantGroupID) {
			return false
		}
	}
	return true
}

// checkRuleIDsInBody checks ownership for rule IDs in "policy_rule_ids", "ids", or "policy_rule" (singular) fields.
func checkRuleIDsInBody(instanceID int, body map[string]interface{}, tenantGroupID uint) bool {
	var ids []interface{}
	if arr, ok := body["policy_rule_ids"].([]interface{}); ok {
		ids = arr
	} else if arr, ok := body["ids"].([]interface{}); ok {
		ids = arr
	} else if v, ok := body["policy_rule"].(float64); ok {
		ids = []interface{}{v}
	}
	if len(ids) == 0 {
		return false
	}
	for _, id := range ids {
		ruleID := int(id.(float64))
		if !isMappingOwner(mappingPolicyRule, instanceID, ruleID, tenantGroupID) {
			return false
		}
	}
	return true
}

// getRuleWebsites calls Captain API to get the websites list for a policy rule.
func getRuleWebsites(client *captain.CaptainClient, instanceID int, ruleID int) []int {
	if ruleID <= 0 {
		return nil
	}
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("/api/PolicyRuleAPI?id=%d", ruleID),
		InstanceID: &idUint,
	})
	if err != nil {
		log.Printf("[WARN] getRuleWebsites: Captain API error for rule %d: %v", ruleID, err)
		return nil
	}
	if resp.StatusCode >= 300 {
		log.Printf("[WARN] getRuleWebsites: Captain API returned %d for rule %d", resp.StatusCode, ruleID)
		return nil
	}

	var wrapper struct {
		Data map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil
	}

	var websiteIDs []int
	if websites, ok := extractItemIntArray(wrapper.Data, "websites"); ok {
		for _, w := range websites {
			if id := extractIntID(w); id > 0 {
				websiteIDs = append(websiteIDs, id)
			}
		}
	}
	if siteID := extractItemIntField(wrapper.Data, "website"); siteID > 0 {
		websiteIDs = append(websiteIDs, siteID)
	}
	return websiteIDs
}

// checkRuleExternalRef checks if any of the rule's referenced websites belong to a different tenant group.
func checkRuleExternalRef(instanceID int, websites []int, tenantGroupID uint) bool {
	if len(websites) == 0 {
		return false
	}
	allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}
	for _, wID := range websites {
		if !allowedSet[wID] {
			return true
		}
	}
	return false
}

// getAllowedSiteIDsByGroup returns site IDs bound to the given tenant group and WAF instance.
func getAllowedSiteIDsByGroup(instanceID int, tenantGroupID uint) []int {
	var siteIDs []int
	database.DB.Table("site_bindings").
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck("site_id", &siteIDs)
	return siteIDs
}

// checkRuleEditProtection checks edit protection for a single rule:
// binding_count == 1 and source != "created" → check reference site ownership.
func checkRuleEditProtection(c *gin.Context, instanceID int, resourceID int) *protectionError {
	if isAdmin(c) || resourceID <= 0 {
		return nil
	}
	tgID := getTenantGroupID(c)

	// Only check when binding_count == 1 (not shared, already checked)
	source := getMappingSource(mappingPolicyRule, instanceID, resourceID, tgID)
	if source == "created" {
		return nil // created + binding_count==1 → references all from this tenant, safe
	}

	// Non-created: check if referenced websites include external sites
	client := captain.GetDefault()
	websites := getRuleWebsites(client, instanceID, resourceID)
	if checkRuleExternalRef(instanceID, websites, tgID) {
		return &protectionError{err: "in_use", msg: "该规则正在被其他站点引用，无法编辑"}
	}
	return nil
}

// checkRuleIDsEditProtection checks edit protection for multiple rule IDs (batch enable/disable).
func checkRuleIDsEditProtection(c *gin.Context, instanceID int, body map[string]interface{}) *protectionError {
	if isAdmin(c) {
		return nil
	}
	ids, ok := body["ids"].([]interface{})
	if !ok {
		return nil
	}
	for _, id := range ids {
		ruleID := int(id.(float64))
		if err := checkRuleEditProtection(c, instanceID, ruleID); err != nil {
			// Adjust message for enable/disable context
			return &protectionError{err: err.err, msg: "该规则正在被其他站点引用，无法变更状态"}
		}
	}
	return nil
}

// --- List injection ---

// injectRuleProtectionFields adds has_external_ref and source to each rule in the list response.
func injectRuleProtectionFields(body []byte, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var items []map[string]interface{}
	isPaginated := false
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		var page struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		}
		if err := json.Unmarshal(dataRaw, &page); err != nil {
			return body
		}
		items = page.Items
		isPaginated = true
	}

	if len(items) == 0 {
		return body
	}

	// Collect all rule IDs for batch source lookup
	ruleIDs := make([]int, 0, len(items))
	for _, item := range items {
		if id := getIDFromItem(item); id > 0 {
			ruleIDs = append(ruleIDs, id)
		}
	}

	// Batch query source from mapping table
	sourceMap := getMappingSources(mappingPolicyRule, instanceID, tenantGroupID, ruleIDs)

	// Get allowed site IDs for external ref check
	allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	for _, item := range items {
		ruleID := getIDFromItem(item)
		if ruleID <= 0 {
			continue
		}

		// Inject source
		item["source"] = sourceMap[ruleID]

		// Inject has_external_ref
		var websiteIDs []int
		if websites, ok := extractItemIntArray(item, "websites"); ok {
			for _, w := range websites {
				if id := extractIntID(w); id > 0 {
					websiteIDs = append(websiteIDs, id)
				}
			}
		}
		if siteID := extractItemIntField(item, "website"); siteID > 0 {
			websiteIDs = append(websiteIDs, siteID)
		}

		hasExternalRef := false
		for _, wID := range websiteIDs {
			if !allowedSet[wID] {
				hasExternalRef = true
				break
			}
		}
		item["has_external_ref"] = hasExternalRef
	}

	var dataOut []byte
	if isPaginated {
		var page struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		}
		_ = json.Unmarshal(dataRaw, &page)
		page.Items = items
		dataOut, _ = json.Marshal(page)
	} else {
		dataOut, _ = json.Marshal(items)
	}
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// getMappingSources batch-queries the source field for multiple resource IDs.
func getMappingSources(table mappingTable, instanceID int, tenantGroupID uint, resourceIDs []int) map[int]string {
	if len(resourceIDs) == 0 {
		return map[int]string{}
	}
	col := getIDColumn(table)
	type row struct {
		ResourceID int    `gorm:"column:resource_id"`
		Source     string `gorm:"column:source"`
	}
	var results []row
	database.DB.Table(string(table)).
		Select(fmt.Sprintf("%s as resource_id, source", col)).
		Where("captain_instance_id = ? AND tenant_group_id = ? AND "+col+" IN ?", instanceID, tenantGroupID, resourceIDs).
		Find(&results)

	m := make(map[int]string, len(results))
	for _, r := range results {
		m[r.ResourceID] = r.Source
	}
	return m
}

// injectAdminRuleProtectionFields adds shared_group_names and has_external_ref to each rule
// in the list response for admin users. shared_group_names is populated for binding_count > 1 rules;
// has_external_ref distinguishes single-binding rules whose sites span multiple tenant groups.
func injectAdminRuleProtectionFields(body []byte, instanceID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}
	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}
	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}
	if len(page.Items) == 0 {
		return body
	}

	ruleIDs := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			ruleIDs = append(ruleIDs, id)
		}
	}

	// Batch query all bindings for these rules
	type bindingRow struct {
		RuleID        int  `gorm:"column:rule_id"`
		TenantGroupID uint `gorm:"column:tenant_group_id"`
	}
	var bindings []bindingRow
	database.DB.Table("captain_policy_rule_bindings").
		Select("rule_id, tenant_group_id").
		Where("captain_instance_id = ? AND rule_id IN ?", instanceID, ruleIDs).
		Find(&bindings)

	ruleTGMap := make(map[int][]uint, len(ruleIDs))
	allTGIDs := make(map[uint]bool)
	for _, b := range bindings {
		ruleTGMap[b.RuleID] = append(ruleTGMap[b.RuleID], b.TenantGroupID)
		allTGIDs[b.TenantGroupID] = true
	}

	// Batch query site bindings for rule websites so admin external-ref dialogs can
	// show tenant group names instead of falling back to "other tenant groups".
	ruleSiteMap := make(map[int][]int, len(ruleIDs))
	allSiteIDs := make(map[int]bool)
	for _, item := range page.Items {
		ruleID := getIDFromItem(item)
		if ruleID <= 0 {
			continue
		}
		if websites, ok := extractItemIntArray(item, "websites"); ok {
			for _, w := range websites {
				if id := extractIntID(w); id > 0 {
					ruleSiteMap[ruleID] = append(ruleSiteMap[ruleID], id)
					allSiteIDs[id] = true
				}
			}
		}
		if siteID := extractItemIntField(item, "website"); siteID > 0 {
			ruleSiteMap[ruleID] = append(ruleSiteMap[ruleID], siteID)
			allSiteIDs[siteID] = true
		}
	}

	siteIDSlice := make([]int, 0, len(allSiteIDs))
	for id := range allSiteIDs {
		siteIDSlice = append(siteIDSlice, id)
	}
	type siteBindingRow struct {
		SiteID        int  `gorm:"column:site_id"`
		TenantGroupID uint `gorm:"column:tenant_group_id"`
	}
	var siteBindings []siteBindingRow
	if len(siteIDSlice) > 0 {
		database.DB.Table("site_bindings").
			Select("site_id, tenant_group_id").
			Where("captain_instance_id = ? AND site_id IN ?", instanceID, siteIDSlice).
			Find(&siteBindings)
	}
	siteTGMap := make(map[int][]uint, len(siteBindings))
	for _, b := range siteBindings {
		siteTGMap[b.SiteID] = append(siteTGMap[b.SiteID], b.TenantGroupID)
		allTGIDs[b.TenantGroupID] = true
	}

	// Batch query TG names
	tgIDSlice := make([]uint, 0, len(allTGIDs))
	for id := range allTGIDs {
		tgIDSlice = append(tgIDSlice, id)
	}
	tgNameMap := make(map[uint]string)
	if len(tgIDSlice) > 0 {
		var groups []model.TenantGroup
		database.DB.Where("id IN ? AND is_deleted = false", tgIDSlice).Find(&groups)
		for _, g := range groups {
			tgNameMap[g.ID] = g.Name
		}
	}

	// Cache allowed sites per TG for has_external_ref computation
	tgSitesCache := make(map[uint]map[int]bool)
	getAllowedSitesForTG := func(tgID uint) map[int]bool {
		if s, ok := tgSitesCache[tgID]; ok {
			return s
		}
		sites := getAllowedSiteIDsByGroup(instanceID, tgID)
		set := make(map[int]bool, len(sites))
		for _, s := range sites {
			set[s] = true
		}
		tgSitesCache[tgID] = set
		return set
	}

	for _, item := range page.Items {
		ruleID := getIDFromItem(item)
		if ruleID <= 0 {
			continue
		}

		tgIDs := ruleTGMap[ruleID]

		if len(tgIDs) > 1 {
			names := make([]string, 0, len(tgIDs))
			for _, tgID := range tgIDs {
				if name, ok := tgNameMap[tgID]; ok {
					names = append(names, name)
				}
			}
			item["shared_group_names"] = names
			item["has_external_ref"] = false
		} else {
			names := []string{}
			hasExternalRef := false
			if len(tgIDs) == 1 {
				allowedSet := getAllowedSitesForTG(tgIDs[0])
				externalTGIDs := make(map[uint]bool)
				for _, siteID := range ruleSiteMap[ruleID] {
					if !allowedSet[siteID] {
						hasExternalRef = true
						for _, tgID := range siteTGMap[siteID] {
							if tgID != tgIDs[0] {
								externalTGIDs[tgID] = true
							}
						}
					}
				}
				for tgID := range externalTGIDs {
					if name, ok := tgNameMap[tgID]; ok {
						names = append(names, name)
					}
				}
			}
			item["shared_group_names"] = names
			item["has_external_ref"] = hasExternalRef
		}
	}

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// --- Scope validation ---

// validateRuleWebsitesScope ensures non-admin users can only assign websites they are bound to.
// Rejects the request if any website in the list is not in the user's allowed sites.
func validateRuleWebsitesScope(body map[string]interface{}, c *gin.Context) error {
	websitesVal, ok := body["websites"]
	if !ok {
		return nil
	}

	websites, ok := websitesVal.([]interface{})
	if !ok || len(websites) == 0 {
		return nil
	}

	allowedSites := getAllowedSiteIDs(c)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	for _, w := range websites {
		siteID := extractIntID(w)
		if siteID > 0 && !allowedSet[siteID] {
			return fmt.Errorf("站点 %d 不在当前租户的可选范围内", siteID)
		}
	}

	return nil
}

// validateRuleInGroupScope ensures non-admin users can only reference IP groups they are bound to.
func validateRuleInGroupScope(body map[string]interface{}, instanceID int, tenantGroupID uint) error {
	patternVal, ok := body["pattern"]
	if !ok {
		return nil
	}

	ingroupIDs := extractInGroupIDs(patternVal)
	if len(ingroupIDs) == 0 {
		return nil
	}

	boundIDs := getMappedIDs(mappingIPGroup, instanceID, tenantGroupID)
	for _, id := range ingroupIDs {
		if !boundIDs[id] {
			return fmt.Errorf("pattern 中 ingroup 引用了未绑定 IP 组")
		}
	}
	return nil
}

// --- Site name injection ---

// extractItemIntField extracts an integer from a map key, checking both lowercase and uppercase variants.
func extractItemIntField(item map[string]interface{}, key string) int {
	if v, ok := item[key]; ok {
		if id := extractIntID(v); id > 0 {
			return id
		}
	}
	// Try uppercase variant (Captain API may return PascalCase)
	if v, ok := item[capitalize(key)]; ok {
		if id := extractIntID(v); id > 0 {
			return id
		}
	}
	return 0
}

// extractItemIntArray extracts an interface slice from a map key, checking both cases.
func extractItemIntArray(item map[string]interface{}, key string) ([]interface{}, bool) {
	if arr, ok := item[key].([]interface{}); ok {
		return arr, true
	}
	if arr, ok := item[capitalize(key)].([]interface{}); ok {
		return arr, true
	}
	return nil, false
}

func capitalize(s string) string {
	if len(s) == 0 {
		return s
	}
	return string(s[0]-32) + s[1:]
}

// injectSiteNames adds a site_names field (string[]) to each policy rule by resolving
// the website/websites IDs against the Captain site list.
func injectSiteNames(body []byte, client *captain.CaptainClient, instanceID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		var page struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		}
		if err := json.Unmarshal(dataRaw, &page); err != nil {
			return body
		}
		items = page.Items
		dataOut, _ := json.Marshal(items)
		resp["data"] = dataOut
	}

	if len(items) == 0 {
		return body
	}

	siteNameMap := fetchSiteNameMap(client, instanceID)

	for _, item := range items {
		var siteIDs []int
		if websites, ok := extractItemIntArray(item, "websites"); ok {
			for _, w := range websites {
				if id := extractIntID(w); id > 0 {
					siteIDs = append(siteIDs, id)
				}
			}
		}
		if siteID := extractItemIntField(item, "website"); siteID > 0 {
			siteIDs = append(siteIDs, siteID)
		}

		names := make([]string, 0, len(siteIDs))
		seen := make(map[int]bool, len(siteIDs))
		for _, id := range siteIDs {
			if !seen[id] {
				seen[id] = true
				if name, ok := siteNameMap[id]; ok {
					names = append(names, name)
				}
			}
		}
		item["site_names"] = names
	}

	dataOut, _ := json.Marshal(items)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// fetchSiteNameMap returns a map of site ID -> site name for the given WAF instance.
func fetchSiteNameMap(client *captain.CaptainClient, instanceID int) map[int]string {
	captainPath, err := resolveSiteReadPath(instanceID)
	if err != nil {
		log.Printf("[WARN] fetchSiteNameMap: %v", err)
		return map[int]string{}
	}
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       captainPath,
		InstanceID: &idUint,
	})
	if err != nil {
		log.Printf("[WARN] fetchSiteNameMap: Captain API error for instance %d: %v", instanceID, err)
		return map[int]string{}
	}
	if resp.StatusCode >= 300 {
		log.Printf("[WARN] fetchSiteNameMap: Captain API returned status %d for instance %d", resp.StatusCode, instanceID)
		return map[int]string{}
	}

	var wrapper struct {
		Data []map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		log.Printf("[WARN] fetchSiteNameMap: failed to parse site list for instance %d: %v", instanceID, err)
		return map[int]string{}
	}

	m := make(map[int]string, len(wrapper.Data))
	for _, site := range wrapper.Data {
		id := extractIntID(site["id"])
		if id <= 0 {
			// Captain API may return uppercase "ID"
			id = extractIntID(site["ID"])
		}
		name, _ := site["name"].(string)
		if name == "" {
			name, _ = site["Name"].(string)
		}
		if id > 0 {
			m[id] = name
		}
	}

	if len(m) == 0 && len(wrapper.Data) > 0 {
		log.Printf("[WARN] fetchSiteNameMap: %d sites returned but none matched for instance %d, first site keys: %v",
			len(wrapper.Data), instanceID, keysOfMap(wrapper.Data[0]))
	}

	return m
}

func keysOfMap(m map[string]interface{}) []string {
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	return keys
}

// DetectionModules proxies the detection module catalog from Captain.
func DetectionModules() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/ServerControlledConfigAPI?type=detection_config",
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// SkynetRules proxies the built-in (skynet) rule list from Captain.
func SkynetRules() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/FilterV2API?scope=detect:skynet_rule_parttern&count=500",
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// filterRuleWebsites filters websites and site_names in rule list to only include
// sites the current tenant has access to.
func filterRuleWebsites(body []byte, allowedSites []int) []byte {
	if len(allowedSites) == 0 {
		return body
	}

	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	// Handle both paginated and plain array responses
	var items []map[string]interface{}
	isPaginated := false
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		var page struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		}
		if err := json.Unmarshal(dataRaw, &page); err != nil {
			return body
		}
		items = page.Items
		isPaginated = true
	}

	for _, item := range items {
		if websites, ok := item["websites"].([]interface{}); ok {
			filtered := make([]interface{}, 0, len(websites))
			for _, w := range websites {
				if allowedSet[extractIntID(w)] {
					filtered = append(filtered, w)
				}
			}
			item["websites"] = filtered

			// Rebuild site_names by matching filtered website IDs back to original positions
			if siteNames, ok := item["site_names"].([]interface{}); ok {
				filteredNames := make([]interface{}, 0)
				for _, fw := range filtered {
					fid := extractIntID(fw)
					for i, ow := range websites {
						if extractIntID(ow) == fid && i < len(siteNames) {
							if name, ok := siteNames[i].(string); ok {
								filteredNames = append(filteredNames, name)
							}
							break
						}
					}
				}
				item["site_names"] = filteredNames
			}
		}
	}

	var dataOut []byte
	if isPaginated {
		var page struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		}
		_ = json.Unmarshal(dataRaw, &page)
		page.Items = items
		dataOut, _ = json.Marshal(page)
	} else {
		dataOut, _ = json.Marshal(items)
	}
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

