package handler

import (
	"encoding/json"
	"fmt"

	"github.com/chaitin/cmc-tenant/pkg/database"
)

func filterByMapping(table mappingTable, instanceID int, tenantGroupID uint, items []map[string]interface{}) []map[string]interface{} {
	boundIDs := getMappedIDs(table, instanceID, tenantGroupID)
	result := make([]map[string]interface{}, 0, len(items))
	for _, item := range items {
		id := getIDFromItem(item)
		if _, ok := boundIDs[id]; ok {
			result = append(result, item)
		}
	}
	return result
}

func getMappedIDs(table mappingTable, instanceID int, tenantGroupID uint) map[int]bool {
	var ids []int
	database.DB.Table(string(table)).
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck(getIDColumn(table), &ids)

	m := make(map[int]bool, len(ids))
	for _, id := range ids {
		m[id] = true
	}
	return m
}

func isMappingOwner(table mappingTable, instanceID int, resourceID int, tenantGroupID uint) bool {
	var count int64
	database.DB.Table(string(table)).
		Where("captain_instance_id = ? AND "+getIDColumn(table)+" = ? AND tenant_group_id = ?",
			instanceID, resourceID, tenantGroupID).
		Count(&count)
	return count > 0
}

// getMappingSource returns the source field ("created" or "inherited") for a mapping record.
func getMappingSource(table mappingTable, instanceID int, resourceID int, tenantGroupID uint) string {
	var source string
	database.DB.Table(string(table)).
		Select("source").
		Where("captain_instance_id = ? AND "+getIDColumn(table)+" = ? AND tenant_group_id = ?",
			instanceID, resourceID, tenantGroupID).
		Scan(&source)
	if source == "" {
		source = "created"
	}
	return source
}

// getBindingCounts returns a map of resource ID -> number of distinct tenant_group_ids
// that have a binding for the given table, instance, and resource IDs.
func getBindingCounts(table mappingTable, instanceID int, ids []int) map[int]int {
	if len(ids) == 0 {
		return map[int]int{}
	}
	col := getIDColumn(table)
	type row struct {
		ResourceID int `gorm:"column:resource_id"`
		Count      int `gorm:"column:cnt"`
	}
	var results []row
	database.DB.Table(string(table)).
		Select(fmt.Sprintf("%s as resource_id, COUNT(DISTINCT tenant_group_id) as cnt", col)).
		Where("captain_instance_id = ? AND "+col+" IN ?", instanceID, ids).
		Group(col).
		Find(&results)

	m := make(map[int]int, len(results))
	for _, r := range results {
		m[r.ResourceID] = r.Count
	}
	return m
}

func getIDColumn(table mappingTable) string {
	switch table {
	case mappingIPGroup:
		return "ip_group_id"
	case mappingCert:
		return "cert_id"
	case mappingPolicy:
		return "policy_id"
	case mappingPolicyRule:
		return "rule_id"
	case mappingBlockPage:
		return "block_page_id"
	}
	return "id"
}

func getIDFromItem(item map[string]interface{}) int {
	if id, ok := item["id"]; ok {
		switch v := id.(type) {
		case float64:
			return int(v)
		case int:
			return v
		}
	}
	return -1
}

// extractIntID extracts an integer ID from a JSON-decoded value (float64, int, json.Number, or string).
func extractIntID(raw interface{}) int {
	switch v := raw.(type) {
	case float64:
		return int(v)
	case int:
		return v
	case json.Number:
		n, _ := v.Int64()
		return int(n)
	case string:
		var n int
		_, _ = fmt.Sscanf(v, "%d", &n)
		return n
	}
	return 0
}

// extractInGroupIDs recursively walks a policy rule pattern and extracts IP group IDs
// referenced by "ingroup" keys. Captain API pattern example:
//
//	{"$AND": [{"ingroup": {"remote_addr": "1"}, "decode_methods": []}]}
//
// The value of "ingroup" is a map whose values are IP group IDs (string or number).
func extractInGroupIDs(pattern interface{}) []int {
	var ids []int
	walkPattern(pattern, &ids)
	return ids
}

func walkPattern(v interface{}, ids *[]int) {
	switch val := v.(type) {
	case map[string]interface{}:
		if raw, ok := val["ingroup"]; ok {
			if m, ok := raw.(map[string]interface{}); ok {
				for _, idVal := range m {
					if id := extractIntID(idVal); id > 0 {
						*ids = append(*ids, id)
					}
				}
			}
		}
		for _, child := range val {
			walkPattern(child, ids)
		}
	case []interface{}:
		for _, child := range val {
			walkPattern(child, ids)
		}
	}
}

// matchRuleSite checks if a policy rule applies to the given siteID.
// Captain API returns "websites" (array of int) or "website" (single int).
func matchRuleSite(rule map[string]interface{}, siteID int) bool {
	if websites, ok := rule["websites"].([]interface{}); ok {
		for _, w := range websites {
			if extractIntID(w) == siteID {
				return true
			}
		}
	}
	if extractIntID(rule["website"]) == siteID {
		return true
	}
	return false
}

// getMappedResourceIDs returns all resource IDs currently mapped for a tenant group on an instance.
func getMappedResourceIDs(table mappingTable, instanceID int, tenantGroupID uint) []int {
	var ids []int
	database.DB.Table(string(table)).
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck(getIDColumn(table), &ids)
	return ids
}

// extractWebsitesFromBody extracts website IDs from a request body map.
// Handles both "websites"/"Websites" (array) and "website"/"Website" (single value).
func extractWebsitesFromBody(body map[string]interface{}) []int {
	var ids []int
	seen := make(map[int]bool)

	// Array: "websites" or "Websites"
	for _, key := range []string{"websites", "Websites"} {
		if arr, ok := body[key].([]interface{}); ok {
			for _, v := range arr {
				if id := extractIntID(v); id > 0 && !seen[id] {
					ids = append(ids, id)
					seen[id] = true
				}
			}
		}
	}

	// Single: "website" or "Website"
	for _, key := range []string{"website", "Website"} {
		if id := extractIntID(body[key]); id > 0 && !seen[id] {
			ids = append(ids, id)
			seen[id] = true
		}
	}

	return ids
}

// extractRuleIDsFromBody extracts rule IDs from a PolicyRuleBind request body.
// Handles "ids", "policy_rule_ids" and their PascalCase variants.
func extractRuleIDsFromBody(body map[string]interface{}) []int {
	var ids []int
	seen := make(map[int]bool)

	for _, key := range []string{"ids", "Ids", "policy_rule_ids", "PolicyRuleIDs", "PolicyRuleIds"} {
		if arr, ok := body[key].([]interface{}); ok {
			for _, v := range arr {
				if id := extractIntID(v); id > 0 && !seen[id] {
					ids = append(ids, id)
					seen[id] = true
				}
			}
		}
	}

	return ids
}