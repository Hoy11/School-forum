package handler

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func TestValidateLogTaskCreateBodyAcceptsSelectedIDs(t *testing.T) {
	body := map[string]interface{}{
		"name": "detect_log",
		"type": "csv",
		"ids":  []interface{}{"abc"},
		"all":  false,
	}

	if !validateLogTaskCreateBody(body) {
		t.Fatal("valid selected-ID log task was rejected")
	}
}

func TestValidateLogTaskCreateBodyAcceptsAll(t *testing.T) {
	body := map[string]interface{}{
		"name": "detect_log",
		"type": "json",
		"all":  true,
	}

	if !validateLogTaskCreateBody(body) {
		t.Fatal("valid all-log task was rejected")
	}
}

func TestValidateLogTaskCreateBodyRejectsEmptySelectedIDs(t *testing.T) {
	body := map[string]interface{}{
		"name": "detect_log",
		"type": "csv",
		"ids":  []interface{}{},
		"all":  false,
	}

	if validateLogTaskCreateBody(body) {
		t.Fatal("empty selected-ID log task was accepted")
	}
}

func TestValidateLogTaskCreateBodyRejectsInvalidNameOrType(t *testing.T) {
	cases := []map[string]interface{}{
		{"name": "unknown", "type": "csv", "ids": []interface{}{"abc"}, "all": false},
		{"name": "detect_log", "type": "xlsx", "ids": []interface{}{"abc"}, "all": false},
	}

	for _, body := range cases {
		if validateLogTaskCreateBody(body) {
			t.Fatalf("invalid log task body was accepted: %#v", body)
		}
	}
}

func TestIsCaptainRespSuccess(t *testing.T) {
	if !isCaptainRespSuccess([]byte(`{"err":null,"data":null}`)) {
		t.Fatal("err=null response should be successful")
	}
	if isCaptainRespSuccess([]byte(`{"err":"bad_request","data":null}`)) {
		t.Fatal("err response should not be successful")
	}
}

func TestExtractLatestLogTaskIDFromListResp(t *testing.T) {
	body := []byte(`{
		"err": null,
		"data": {
			"items": [
				{"id": 9, "name": "acl_log", "type": "csv"},
				{"id": 8, "name": "detect_log", "type": "csv"},
				{"id": 7, "name": "detect_log", "type": "json"}
			]
		}
	}`)

	id := extractLatestLogTaskIDFromListResp(body, "detect_log", "csv", map[int]bool{9: true})
	if id != 8 {
		t.Fatalf("id = %d, want 8", id)
	}
}

func TestExtractLatestLogTaskIDFromListRespSkipsExisting(t *testing.T) {
	body := []byte(`{
		"err": null,
		"data": {
			"items": [
				{"id": 9, "name": "detect_log", "type": "csv"},
				{"id": 8, "name": "detect_log", "type": "csv"}
			]
		}
	}`)

	id := extractLatestLogTaskIDFromListResp(body, "detect_log", "csv", map[int]bool{9: true})
	if id != 8 {
		t.Fatalf("id = %d, want 8", id)
	}
}

func TestExtractLogTaskIDSetFromListResp(t *testing.T) {
	body := []byte(`{"data":{"items":[{"id":1},{"id":2}]}}`)

	ids := extractLogTaskIDSetFromListResp(body)
	if !ids[1] || !ids[2] || len(ids) != 2 {
		t.Fatalf("ids = %#v, want 1 and 2", ids)
	}
}

func TestLogTaskCreateInjectsTenantDetectLogSiteFilter(t *testing.T) {
	gin.SetMode(gin.TestMode)

	var captured map[string]interface{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/log/task/list":
			_, _ = w.Write([]byte(`{"err":null,"data":{"items":[]}}`))
		case "/api/log/task/create":
			if err := json.NewDecoder(r.Body).Decode(&captured); err != nil {
				t.Fatalf("decode create body: %v", err)
			}
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":77}}`))
		default:
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.CaptainLogTask{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant_admin"})
		c.Set("tenant_group_id", uint(3))
		c.Set("allowed_waf_ids", []int{7})
		c.Set("allowed_sites", []bindingmodel.SiteBinding{
			{TenantGroupID: 3, CaptainInstanceID: 7, SiteID: 101},
			{TenantGroupID: 3, CaptainInstanceID: 7, SiteID: 102},
		})
		c.Next()
	})
	router.POST("/log-task/create", LogTaskCreate())

	body := map[string]interface{}{
		"name": "detect_log",
		"type": "csv",
		"all":  true,
		"detect_log_filter": map[string]interface{}{
			"action": []interface{}{map[string]interface{}{"oper": "=", "target": "1"}},
		},
	}
	reqBody, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("marshal body: %v", err)
	}
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/log-task/create", bytes.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	filter, ok := captured["detect_log_filter"].(map[string]interface{})
	if !ok {
		t.Fatalf("detect_log_filter = %#v, want map", captured["detect_log_filter"])
	}
	siteFilters, ok := filter["site_uuid"].([]interface{})
	if !ok || len(siteFilters) != 2 {
		t.Fatalf("site_uuid = %#v, want two site filters", filter["site_uuid"])
	}
	got := map[int]bool{}
	for _, item := range siteFilters {
		m, ok := item.(map[string]interface{})
		if !ok || m["oper"] != "=" {
			t.Fatalf("site filter item = %#v, want equality map", item)
		}
		if target, ok := m["target"].(float64); ok {
			got[int(target)] = true
		}
	}
	if !got[101] || !got[102] || len(got) != 2 {
		t.Fatalf("site filter targets = %#v, want 101 and 102", got)
	}
	if _, ok := filter["log_id"]; !ok {
		t.Fatalf("log_id tenant filter was not injected: %#v", filter)
	}
}

func TestLogTaskCreateInjectsTenantBotLogSiteFilter(t *testing.T) {
	gin.SetMode(gin.TestMode)

	var captured map[string]interface{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/log/task/list":
			_, _ = w.Write([]byte(`{"err":null,"data":{"items":[]}}`))
		case "/api/log/task/create":
			if err := json.NewDecoder(r.Body).Decode(&captured); err != nil {
				t.Fatalf("decode create body: %v", err)
			}
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":78}}`))
		default:
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.CaptainLogTask{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant_admin"})
		c.Set("tenant_group_id", uint(3))
		c.Set("allowed_waf_ids", []int{7})
		c.Set("allowed_sites", []bindingmodel.SiteBinding{
			{TenantGroupID: 3, CaptainInstanceID: 7, SiteID: 101},
		})
		c.Next()
	})
	router.POST("/log-task/create", LogTaskCreate())

	// 请求体不带 bot_log_filter（典型如前端没传任何筛选条件），验证依然会被注入站点过滤。
	body := map[string]interface{}{
		"name": "bot_record_log",
		"type": "csv",
		"all":  true,
	}
	reqBody, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("marshal body: %v", err)
	}
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/log-task/create", bytes.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	filter, ok := captured["bot_log_filter"].(map[string]interface{})
	if !ok {
		t.Fatalf("bot_log_filter = %#v, want map (was not injected)", captured["bot_log_filter"])
	}
	siteFilters, ok := filter["site_uuid"].([]interface{})
	if !ok || len(siteFilters) != 1 {
		t.Fatalf("site_uuid = %#v, want one site filter", filter["site_uuid"])
	}
	if _, ok := filter["log_id"]; !ok {
		t.Fatalf("log_id tenant filter was not injected: %#v", filter)
	}
}

func TestLogTaskCreateInjectsSiteFilterWhenDetectLogFilterKeyMissing(t *testing.T) {
	gin.SetMode(gin.TestMode)

	var captured map[string]interface{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/log/task/list":
			_, _ = w.Write([]byte(`{"err":null,"data":{"items":[]}}`))
		case "/api/log/task/create":
			if err := json.NewDecoder(r.Body).Decode(&captured); err != nil {
				t.Fatalf("decode create body: %v", err)
			}
			_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":80}}`))
		default:
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.CaptainLogTask{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant_admin"})
		c.Set("tenant_group_id", uint(3))
		c.Set("allowed_waf_ids", []int{7})
		c.Set("allowed_sites", []bindingmodel.SiteBinding{
			{TenantGroupID: 3, CaptainInstanceID: 7, SiteID: 101},
		})
		c.Next()
	})
	router.POST("/log-task/create", LogTaskCreate())

	// 请求体完全不带 detect_log_filter 字段——回归此前 ok 断言失败时整段注入被跳过的缺陷。
	body := map[string]interface{}{"name": "detect_log", "type": "csv", "all": true}
	reqBody, _ := json.Marshal(body)
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/log-task/create", bytes.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	filter, ok := captured["detect_log_filter"].(map[string]interface{})
	if !ok {
		t.Fatalf("detect_log_filter = %#v, want map (injection was skipped)", captured["detect_log_filter"])
	}
	if _, ok := filter["site_uuid"]; !ok {
		t.Fatalf("site_uuid was not injected when detect_log_filter key was missing: %#v", filter)
	}
}

func TestLogTaskCreateAdminBotLogNotSiteFiltered(t *testing.T) {
	gin.SetMode(gin.TestMode)

	var captured map[string]interface{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if err := json.NewDecoder(r.Body).Decode(&captured); err != nil {
			t.Fatalf("decode create body: %v", err)
		}
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":79}}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.CaptainLogTask{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		c.Next()
	})
	router.POST("/log-task/create", LogTaskCreate())

	body := map[string]interface{}{"name": "bot_result_log", "type": "csv", "all": true}
	reqBody, _ := json.Marshal(body)
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/log-task/create", bytes.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if _, ok := captured["bot_log_filter"]; ok {
		t.Fatalf("admin request should not be site-filtered, got bot_log_filter=%#v", captured["bot_log_filter"])
	}
}

func newLogTaskDeleteTestRouter(role string, tenantGroupID uint) *gin.Engine {
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: role})
		c.Set("tenant_group_id", tenantGroupID)
		c.Next()
	})
	router.DELETE("/log-task/delete", LogTaskDelete())
	return router
}

func performLogTaskDeleteRequest(router *gin.Engine, body map[string]interface{}) *httptest.ResponseRecorder {
	raw, _ := json.Marshal(body)
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodDelete, "/log-task/delete", bytes.NewReader(raw))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(resp, req)
	return resp
}

func TestLogTaskDeleteRejectsAllForNonAdmin(t *testing.T) {
	setupLogTaskDB(t, 3, []int{1, 2})
	router := newLogTaskDeleteTestRouter("tenant", 3)

	resp := performLogTaskDeleteRequest(router, map[string]interface{}{"all": true})
	if resp.Code != http.StatusBadRequest {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusBadRequest, resp.Body.String())
	}
}

func TestLogTaskDeleteRejectsEmptyBodyForNonAdmin(t *testing.T) {
	setupLogTaskDB(t, 3, []int{1, 2})
	router := newLogTaskDeleteTestRouter("tenant", 3)

	resp := performLogTaskDeleteRequest(router, map[string]interface{}{})
	if resp.Code != http.StatusBadRequest {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusBadRequest, resp.Body.String())
	}
}

func TestLogTaskDeleteRejectsUnownedIDForNonAdmin(t *testing.T) {
	setupLogTaskDB(t, 3, []int{1, 2})
	router := newLogTaskDeleteTestRouter("tenant", 3)

	resp := performLogTaskDeleteRequest(router, map[string]interface{}{"ids": []interface{}{1, 99}})
	if resp.Code != http.StatusForbidden {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusForbidden, resp.Body.String())
	}
}

func TestLogTaskDeleteAllowsAllForAdmin(t *testing.T) {
	gin.SetMode(gin.TestMode)
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if r.URL.Path != "/api/log/task/delete" {
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":""}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	router := newLogTaskDeleteTestRouter("admin", 0)
	resp := performLogTaskDeleteRequest(router, map[string]interface{}{"all": true})
	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d want=%d body=%s", resp.Code, http.StatusOK, resp.Body.String())
	}
}

func setupLogTaskDB(t *testing.T, tenantGroupID uint, taskIDs []int) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.CaptainLogTask{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	for _, id := range taskIDs {
		db.Create(&bindingmodel.CaptainLogTask{CaptainTaskID: id, TenantGroupID: &tenantGroupID})
	}
	oldDB := database.DB
	database.DB = db
	t.Cleanup(func() { database.DB = oldDB })
}

func TestFilterLogTasksByMappingTotalIgnoresPageHitCount(t *testing.T) {
	setupLogTaskDB(t, 3, []int{1, 2, 3, 4, 5})

	// Captain 返回的这一页里只有 2 条属于该租户，其余 18 条属于别的租户。
	body := []byte(`{"err":null,"data":{"items":[
		{"id":1},{"id":99},{"id":2},{"id":100}
	],"total":20}}`)

	result := filterLogTasksByMapping(body, 3)

	var resp struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
			Total int                       `json:"total"`
		} `json:"data"`
	}
	if err := json.Unmarshal(result, &resp); err != nil {
		t.Fatalf("unmarshal result: %v", err)
	}
	if len(resp.Data.Items) != 2 {
		t.Fatalf("items = %d, want 2 (page hit count)", len(resp.Data.Items))
	}
	if resp.Data.Total != 5 {
		t.Fatalf("total = %d, want 5 (tenant mapping count), not page hit count", resp.Data.Total)
	}
}

func TestFilterLogTasksByMappingTotalNonZeroWhenPageHitsZero(t *testing.T) {
	setupLogTaskDB(t, 3, []int{1, 2, 3})

	// Captain 返回的这一页全部属于别的租户，该租户在这一页里命中 0 条。
	body := []byte(`{"err":null,"data":{"items":[
		{"id":99},{"id":100}
	],"total":20}}`)

	result := filterLogTasksByMapping(body, 3)

	var resp struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
			Total int                       `json:"total"`
		} `json:"data"`
	}
	if err := json.Unmarshal(result, &resp); err != nil {
		t.Fatalf("unmarshal result: %v", err)
	}
	if len(resp.Data.Items) != 0 {
		t.Fatalf("items = %d, want 0", len(resp.Data.Items))
	}
	if resp.Data.Total != 3 {
		t.Fatalf("total = %d, want 3 (tenant mapping count), not 0", resp.Data.Total)
	}
}
