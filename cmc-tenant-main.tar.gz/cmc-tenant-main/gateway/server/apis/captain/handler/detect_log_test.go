package handler

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/chaitin/cmc-tenant/pkg/captain"
)

func TestCheckLogDetailOwnershipRejectsUnboundSite(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"err":null,"data":{"waf_list":[{"id":1,"mode":"Software Reverse Proxy"}]}}`))
		case "/api/SoftwareReverseProxyWebsiteAPI":
			_, _ = w.Write([]byte(`{"err":null,"data":[{"id":10,"name":"other-site"},{"id":20,"name":"own-site"}]}`))
		default:
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	body := []byte(`{"data":{"waf_id":1,"website_name":"other-site"}}`)
	if checkLogDetailOwnership(body, []int{1}, []int{20}) {
		t.Fatal("site not in allowedSiteIDs should be rejected")
	}
}

func TestCheckLogDetailOwnershipAllowsBoundSite(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"err":null,"data":{"waf_list":[{"id":1,"mode":"Software Reverse Proxy"}]}}`))
		case "/api/SoftwareReverseProxyWebsiteAPI":
			_, _ = w.Write([]byte(`{"err":null,"data":[{"id":20,"name":"own-site"}]}`))
		default:
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	body := []byte(`{"data":{"waf_id":1,"website_name":"own-site"}}`)
	if !checkLogDetailOwnership(body, []int{1}, []int{20}) {
		t.Fatal("site in allowedSiteIDs should be allowed")
	}
}

func TestCheckLogDetailOwnershipFailsClosedOnFetchError(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		http.Error(w, `{"err":"unavailable"}`, http.StatusServiceUnavailable)
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	body := []byte(`{"data":{"waf_id":1,"website_name":"own-site"}}`)
	if checkLogDetailOwnership(body, []int{1}, []int{20}) {
		t.Fatal("site list fetch failure must fail closed, not allow access")
	}
}

func TestCheckLogDetailOwnershipRejectsUnboundWaf(t *testing.T) {
	body := []byte(`{"data":{"waf_id":99,"website_name":"own-site"}}`)
	if checkLogDetailOwnership(body, []int{1}, []int{20}) {
		t.Fatal("waf_id not in allowedWafIDs should be rejected before site lookup")
	}
}

func TestCheckLogDetailOwnershipFailsClosedOnDuplicateSiteName(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"err":null,"data":{"waf_list":[{"id":1,"mode":"Software Reverse Proxy"}]}}`))
		case "/api/SoftwareReverseProxyWebsiteAPI":
			// 同一 WAF 上存在两个同名站点：一个属于当前租户(20)，一个属于其他租户(30)。
			_, _ = w.Write([]byte(`{"err":null,"data":[{"id":20,"name":"shared-name"},{"id":30,"name":"shared-name"}]}`))
		default:
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	body := []byte(`{"data":{"waf_id":1,"website_name":"shared-name"}}`)
	if checkLogDetailOwnership(body, []int{1}, []int{20}) {
		t.Fatal("duplicate site name spanning tenants must fail closed, even if one match is allowed")
	}
}

func TestCheckLogDetailOwnershipRejectsEmptyWebsiteName(t *testing.T) {
	body := []byte(`{"data":{"waf_id":1,"website_name":""}}`)
	if checkLogDetailOwnership(body, []int{1}, []int{20}) {
		t.Fatal("empty website_name should be rejected before site lookup")
	}
}
