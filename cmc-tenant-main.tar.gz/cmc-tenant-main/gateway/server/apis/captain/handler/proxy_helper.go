package handler

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func requireInstanceID(c *gin.Context) (int, bool) {
	instanceID, ok := getInstanceID(c)
	if !ok {
		c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
		return 0, false
	}
	if !checkInstanceAccess(c, instanceID) {
		c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
		return 0, false
	}
	return instanceID, true
}

// parseQueryInt parses an integer query parameter, returning defaultValue on missing/invalid input.
func parseQueryInt(c *gin.Context, key string, defaultValue int) int {
	s := c.Query(key)
	if s == "" {
		return defaultValue
	}
	n, err := strconv.Atoi(s)
	if err != nil {
		return defaultValue
	}
	return n
}

func parseInstanceWriteRequest(c *gin.Context) (int, map[string]interface{}, bool) {
	var body map[string]interface{}
	if err := c.ShouldBindJSON(&body); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
		return 0, nil, false
	}

	instanceID, ok := getInstanceIDFromBody(body)
	if !ok {
		c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
		return 0, nil, false
	}
	if !checkInstanceAccess(c, instanceID) {
		c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
		return 0, nil, false
	}
	return instanceID, body, true
}

func getInstanceIDFromBody(body map[string]interface{}) (int, bool) {
	v, ok := body["captain_instance_id"]
	if !ok {
		return 0, false
	}
	switch val := v.(type) {
	case float64:
		return int(val), true
	case string:
		n, _ := strconv.Atoi(val)
		return n, true
	}
	return 0, false
}

func filterResponseByMapping(body []byte, table mappingTable, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var items []map[string]interface{}
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		// Captain may return paginated format: {"items": [...], "total": N}
		var page struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		}
		if err := json.Unmarshal(dataRaw, &page); err != nil {
			return body
		}
		items = page.Items
	}

	filtered := filterByMapping(table, instanceID, tenantGroupID, items)
	dataOut, _ := json.Marshal(filtered)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

func extractIDFromResp(body []byte) int {
	var resp struct {
		Data interface{} `json:"data"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return 0
	}
	switch v := resp.Data.(type) {
	case float64:
		return int(v)
	case map[string]interface{}:
		if id, ok := v["id"]; ok {
			if f, ok := id.(float64); ok {
				return int(f)
			}
		}
	}
	return 0
}

func extractResourceID(body map[string]interface{}, table mappingTable) int {
	col := getIDColumn(table)
	if v, ok := body[col]; ok {
		switch val := v.(type) {
		case float64:
			return int(val)
		case string:
			n, _ := strconv.Atoi(val)
			return n
		}
	}
	if v, ok := body["id"]; ok {
		switch val := v.(type) {
		case float64:
			return int(val)
		case string:
			n, _ := strconv.Atoi(val)
			return n
		}
	}
	// Also check "id__in" (array format used by delete APIs, e.g., {"id__in": [123]})
	if v, ok := body["id__in"]; ok {
		if arr, ok := v.([]interface{}); ok && len(arr) > 0 {
			switch val := arr[0].(type) {
			case float64:
				return int(val)
			case string:
				n, _ := strconv.Atoi(val)
				return n
			}
		}
	}
	return 0
}

// wrapCaptainResp wraps Captain API response into standard {err, msg, data} format.
// Captain returns {"err": null, "msg": null, "data": ...}, frontend expects {"err": null, "msg": "success", "data": ...}.
func wrapCaptainResp(body []byte) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}
	changed := false
	if _, hasErr := resp["err"]; !hasErr {
		resp["err"] = json.RawMessage("null")
		changed = true
	}
	// Captain returns "msg": null or "msg": ""; replace with "success"
	if msgRaw, hasMsg := resp["msg"]; !hasMsg || string(msgRaw) == "null" || string(msgRaw) == `""` {
		resp["msg"] = json.RawMessage(`"success"`)
		changed = true
	}
	if !changed {
		return body
	}
	result, _ := json.Marshal(resp)
	return result
}

func wrapListAsPage(body []byte) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	// If data is already paginated format {total, items}, keep it as-is
	var pageData map[string]json.RawMessage
	if err := json.Unmarshal(dataRaw, &pageData); err == nil {
		if _, hasTotal := pageData["total"]; hasTotal {
			if _, hasItems := pageData["items"]; hasItems {
				// Already paginated, just ensure err/msg are present
				if _, hasErr := resp["err"]; !hasErr {
					resp["err"] = json.RawMessage("null")
				}
				if msgRaw, hasMsg := resp["msg"]; !hasMsg || string(msgRaw) == "null" || string(msgRaw) == `""` {
					resp["msg"] = json.RawMessage(`"success"`)
				}
				result, _ := json.Marshal(resp)
				return result
			}
		}
	}

	// Data is a plain array, wrap it in paginated format
	var items []map[string]interface{}
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		return body
	}

	pageBytes, _ := json.Marshal(gin.H{"total": len(items), "items": items})
	resp["data"] = pageBytes

	// Ensure err/msg are present and msg is not null
	if _, hasErr := resp["err"]; !hasErr {
		resp["err"] = json.RawMessage("null")
	}
	if msgRaw, hasMsg := resp["msg"]; !hasMsg || string(msgRaw) == "null" || string(msgRaw) == `""` {
		resp["msg"] = json.RawMessage(`"success"`)
	}

	result, _ := json.Marshal(resp)
	return result
}

// applyLocalPagination slices a paginated {total, items} response according to
// the frontend's offset/count, preserving the true total while returning only
// the requested page of items.
func applyLocalPagination(body []byte, offset, count int) []byte {
	if count <= 0 {
		return body
	}

	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	// Slice items for the requested page
	total := page.Total
	if total == 0 && len(page.Items) > 0 {
		total = len(page.Items) // fallback if total wasn't set correctly
	}

	if offset >= len(page.Items) {
		page.Items = []map[string]interface{}{}
	} else {
		end := offset + count
		if end > len(page.Items) {
			end = len(page.Items)
		}
		page.Items = page.Items[offset:end]
	}
	page.Total = total

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}
