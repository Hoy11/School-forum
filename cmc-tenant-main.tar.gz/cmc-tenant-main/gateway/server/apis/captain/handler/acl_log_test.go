package handler

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func TestACLLogListTimestampTsRangeConditionUsesCaptainField(t *testing.T) {
	gin.SetMode(gin.TestMode)

	var captured map[string]interface{}
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/api/acl_log/list" {
			t.Fatalf("path=%s want /api/acl_log/list", r.URL.Path)
		}
		if err := json.NewDecoder(r.Body).Decode(&captured); err != nil {
			t.Fatalf("decode Captain request body: %v", err)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"total":0,"items":[]}}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		c.Next()
	})
	router.POST("/acl-log/list", ACLLogList())

	body := map[string]interface{}{
		"offset": 0,
		"count":  20,
		"conditions": []interface{}{
			map[string]interface{}{
				"target": "timestamp_tsrange",
				"items": []interface{}{
					map[string]interface{}{
						"oper":  "range",
						"value": "1781433600-1781520000",
					},
				},
			},
		},
	}
	reqBody, err := json.Marshal(body)
	if err != nil {
		t.Fatalf("marshal request body: %v", err)
	}

	req := httptest.NewRequest(http.MethodPost, "/acl-log/list", bytes.NewReader(reqBody))
	req.Header.Set("Content-Type", "application/json")
	resp := httptest.NewRecorder()
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if _, ok := captured["conditions"]; ok {
		t.Fatal("conditions should be removed after BasicFilter conversion")
	}

	timestampFilters, ok := captured["timestamp_tsrange"].([]interface{})
	if !ok || len(timestampFilters) != 1 {
		t.Fatalf("timestamp_tsrange filter = %#v, want one BasicFilter item", captured["timestamp_tsrange"])
	}

	filterItem, ok := timestampFilters[0].(map[string]interface{})
	if !ok {
		t.Fatalf("timestamp filter item = %#v, want map", timestampFilters[0])
	}
	if filterItem["oper"] != "range" {
		t.Fatalf("oper = %#v, want range", filterItem["oper"])
	}
	if filterItem["target"] != "1781433600-1781520000" {
		t.Fatalf("target = %#v, want selected range", filterItem["target"])
	}
	if _, ok := filterItem["log_type"]; ok {
		t.Fatalf("log_type = %#v, want omitted for ACL timestamp_tsrange", filterItem["log_type"])
	}
}
