package handler

import (
	"net/http"
	"net/http/httptest"
	"reflect"
	"testing"

	"github.com/chaitin/cmc-tenant/pkg/captain"
)

func TestConvertDetectLogConditionsToBasicFilterNormalizesCaptainFields(t *testing.T) {
	body := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"target": "policy_rule_id",
				"items": []interface{}{
					map[string]interface{}{"oper": "exact", "value": "1001"},
				},
			},
			map[string]interface{}{
				"target": "method",
				"items": []interface{}{
					map[string]interface{}{"oper": "in", "value": "GET,POST"},
				},
			},
			map[string]interface{}{
				"target": "url_path",
				"items": []interface{}{
					map[string]interface{}{"oper": "not_regex", "value": "^/private"},
				},
			},
			map[string]interface{}{
				"target": "dest_ip",
				"items": []interface{}{
					map[string]interface{}{"oper": "net_contained_or_equal", "value": "10.0.0.0/8"},
				},
			},
			map[string]interface{}{
				"target": "timestamp",
				"items": []interface{}{
					map[string]interface{}{"oper": "range", "value": "1710000000-1710003600"},
				},
			},
		},
	}

	convertConditionsToBasicFilter(body, "detect_log")

	if _, exists := body["conditions"]; exists {
		t.Fatal("conditions should be removed after conversion")
	}
	assertFilterItems(t, body, "rule_id", []map[string]interface{}{
		{"oper": "=", "target": "1001"},
	})
	assertFilterItems(t, body, "method", []map[string]interface{}{
		{"oper": "in", "target": []interface{}{"GET", "POST"}},
	})
	assertFilterItems(t, body, "url_path", []map[string]interface{}{
		{"oper": "not regexp", "target": "^/private"},
	})
	assertFilterItems(t, body, "dst_ip", []map[string]interface{}{
		{"oper": "<<=", "target": "10.0.0.0/8"},
	})
	assertFilterItems(t, body, "attack_time", []map[string]interface{}{
		{"oper": "in", "target": "1710000000-1710003600"},
	})
}

func TestRewriteWebsiteNameConditionsWithSites(t *testing.T) {
	body := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"target": "website_name",
				"items": []interface{}{
					map[string]interface{}{"oper": "contains", "value": "portal"},
				},
			},
			map[string]interface{}{
				"target": "method",
				"items": []interface{}{
					map[string]interface{}{"oper": "exact", "value": "GET"},
				},
			},
		},
	}

	rewriteWebsiteNameConditionsWithSites(body, []detectLogFilterSite{
		{ID: 10, Name: "portal-web"},
		{ID: 20, Name: "admin"},
		{ID: 30, Name: "portal-api"},
	})
	convertConditionsToBasicFilter(body, "detect_log")

	assertFilterItems(t, body, "site_uuid", []map[string]interface{}{
		{"oper": "=", "target": 10},
		{"oper": "=", "target": 30},
	})
	assertFilterItems(t, body, "method", []map[string]interface{}{
		{"oper": "=", "target": []interface{}{"GET"}},
	})
}

func TestRewriteWebsiteNameConditionsNoMatchUsesImpossibleSite(t *testing.T) {
	body := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"target": "website_name",
				"items": []interface{}{
					map[string]interface{}{"oper": "exact", "value": "missing"},
				},
			},
		},
	}

	rewriteWebsiteNameConditionsWithSites(body, []detectLogFilterSite{{ID: 10, Name: "portal"}})
	convertConditionsToBasicFilter(body, "detect_log")

	assertFilterItems(t, body, "site_uuid", []map[string]interface{}{
		{"oper": "=", "target": -1},
	})
}

func TestFetchDetectLogFilterSitesSkipsUnsupportedInstanceMode(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		switch r.URL.Path {
		case "/api/group/detail":
			_, _ = w.Write([]byte(`{"err":null,"data":{"waf_list":[{"id":1,"mode":"Software Reverse Proxy"},{"id":2}]}}`))
		case "/api/SoftwareReverseProxyWebsiteAPI":
			_, _ = w.Write([]byte(`{"err":null,"data":[{"id":101,"name":"portal"}]}`))
		default:
			t.Fatalf("unexpected Captain path: %s", r.URL.Path)
		}
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	sites, err := fetchDetectLogFilterSites([]int{1, 2})
	if err != nil {
		t.Fatalf("fetchDetectLogFilterSites returned error: %v", err)
	}
	if len(sites) != 1 || sites[0].ID != 101 || sites[0].Name != "portal" {
		t.Fatalf("sites = %#v, want portal site from supported instance only", sites)
	}
}

func TestConvertDetectLogConditionsNormalizesArrayScalarValues(t *testing.T) {
	body := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"target": "effective",
				"items": []interface{}{
					map[string]interface{}{"oper": "exact", "value": "1"},
				},
			},
			map[string]interface{}{
				"target": "risk_level",
				"items": []interface{}{
					map[string]interface{}{"oper": "not_in", "value": []interface{}{"3", "2"}},
				},
			},
		},
	}

	convertConditionsToBasicFilter(body, "detect_log")

	assertFilterItems(t, body, "effective", []map[string]interface{}{
		{"oper": "=", "target": []interface{}{"1"}},
	})
	assertFilterItems(t, body, "risk_level", []map[string]interface{}{
		{"oper": "not in", "target": []interface{}{"3", "2"}},
	})
}

func TestConvertDetectLogConditionsSupportsCaptainThreatFilters(t *testing.T) {
	body := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"target": "country",
				"items": []interface{}{
					map[string]interface{}{"oper": "in", "value": "CN,US"},
				},
			},
			map[string]interface{}{
				"target": "ip_matched_threat_tags",
				"items": []interface{}{
					map[string]interface{}{"oper": "in", "value": "botnet,scanner"},
				},
			},
			map[string]interface{}{
				"target": "threat_ip_last_timestamp_tsrange",
				"items": []interface{}{
					map[string]interface{}{"oper": "range", "value": "1710000000-1710003600"},
				},
			},
			map[string]interface{}{
				"target": "threat_fp_last_timestamp_tsrange",
				"items": []interface{}{
					map[string]interface{}{"oper": "range", "value": "1710000000-1710003600"},
				},
			},
		},
	}

	convertConditionsToBasicFilter(body, "detect_log")

	assertFilterItems(t, body, "country", []map[string]interface{}{
		{"oper": "in", "target": []interface{}{"CN", "US"}},
	})
	assertFilterItems(t, body, "ip_matched_threat_tags", []map[string]interface{}{
		{"oper": "in", "target": []interface{}{"botnet", "scanner"}},
	})
	assertFilterItems(t, body, "threat_ip_last_timestamp_tsrange", []map[string]interface{}{
		{"oper": "range", "target": "1710000000-1710003600", "log_type": "detect_log"},
	})
	assertFilterItems(t, body, "threat_fp_last_timestamp_tsrange", []map[string]interface{}{
		{"oper": "range", "target": "1710000000-1710003600", "log_type": "detect_log"},
	})
}

func TestConvertACLLogConditionsUsesCaptainBasicFilterFields(t *testing.T) {
	body := map[string]interface{}{
		"conditions": []interface{}{
			map[string]interface{}{
				"target": "log_id",
				"items": []interface{}{
					map[string]interface{}{"oper": "in", "value": []interface{}{"1", "2"}},
				},
			},
			map[string]interface{}{
				"target": "target",
				"items": []interface{}{
					map[string]interface{}{"oper": "contains", "value": "1.1.1.1"},
				},
			},
			map[string]interface{}{
				"target": "timestamp_tsrange",
				"items": []interface{}{
					map[string]interface{}{"oper": "range", "value": "1710000000-1710003600"},
				},
			},
		},
	}

	convertConditionsToBasicFilter(body, "")

	assertFilterItems(t, body, "log_id", []map[string]interface{}{
		{"oper": "in", "target": []interface{}{"1", "2"}},
	})
	assertFilterItems(t, body, "target", []map[string]interface{}{
		{"oper": "like", "target": "1.1.1.1"},
	})
	assertFilterItems(t, body, "timestamp_tsrange", []map[string]interface{}{
		{"oper": "range", "target": "1710000000-1710003600"},
	})
}

func assertFilterItems(t *testing.T, body map[string]interface{}, key string, want []map[string]interface{}) {
	t.Helper()
	got, ok := body[key].([]interface{})
	if !ok {
		t.Fatalf("%s = %#v, want []interface{}", key, body[key])
	}
	if len(got) != len(want) {
		t.Fatalf("%s len = %d, want %d (%#v)", key, len(got), len(want), got)
	}
	for i := range want {
		gotMap, ok := got[i].(map[string]interface{})
		if !ok {
			t.Fatalf("%s[%d] = %#v, want map", key, i, got[i])
		}
		if !reflect.DeepEqual(gotMap, want[i]) {
			t.Fatalf("%s[%d] = %#v, want %#v", key, i, gotMap, want[i])
		}
	}
}
