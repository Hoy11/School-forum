package handler

import (
	"crypto/rand"
	"encoding/hex"
	"net/http"
	"strconv"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	riskguard "github.com/chaitin/cmc-tenant/pkg/risk_guard"
	"github.com/gin-gonic/gin"
)

// SiteList proxies site list queries to Captain.
func SiteList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}

		captainPath, err := resolveSiteReadPath(instanceID)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
			return
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       captainPath,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var body []byte
		if isAdmin(c) {
			body = resp.Body
		} else {
			body = filterSitesByBinding(resp.Body, instanceID, getTenantGroupID(c))
		}

		paged := wrapListAsPage(body)
		wrapped := wrapCaptainResp(paged)
		c.Data(resp.StatusCode, "application/json", wrapped)
	}
}

// SiteCreate proxies site creation to Captain with risk guard checks.
func SiteCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}
		riskguard.WithWAFOperationLock(instanceID, func() {
			if !runRiskGuard(c, instanceID, body) {
				return
			}
			captainPath, err := resolveSiteCreatePath(instanceID, body)
			if err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			proxyAndRecordOp(c, "POST", captainPath, sanitizeSiteCreateBody(body), instanceID)
		})
	}
}

// SiteUpdate proxies site update to Captain with risk guard checks.
// Admin path: after successful update, triggers SyncSiteResourceMappings for all bound tenant groups.
func SiteUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}
		riskguard.WithWAFOperationLock(instanceID, func() {
			siteID := extractSiteIDFromBody(body)
			if !isAdmin(c) {
				if !isSiteOwner(instanceID, siteID, getTenantGroupID(c)) {
					c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该站点", "data": ""})
					return
				}
			}
			if !runRiskGuard(c, instanceID, body) {
				return
			}
			captainPath, err := resolveSiteUpdatePath(instanceID, siteID, body)
			if err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			proxyAndRecordOp(c, "PUT", captainPath, sanitizeSiteUpdateBody(body), instanceID, func() {
				syncSiteMappingsForAdmin(c, instanceID, siteID)
			})
		})
	}
}

// SiteDelete proxies site deletion to Captain with risk guard checks.
func SiteDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}
		siteIDs := extractSiteDeleteIDs(body)
		if len(siteIDs) == 0 {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "id 参数必填且有效", "data": ""})
			return
		}
		if !isAdmin(c) {
			tenantGroupID := getTenantGroupID(c)
			for _, siteID := range siteIDs {
				if !isSiteOwner(instanceID, siteID, tenantGroupID) {
					c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该站点", "data": ""})
					return
				}
			}
		}
		cleanupDeletedSites := prepareDeletedSiteBindingCleanup(instanceID, siteIDs)
		captainBody := map[string]interface{}{"id__in": siteIDs}
		riskguard.WithWAFOperationLock(instanceID, func() {
			if !runRiskGuard(c, instanceID, body) {
				return
			}
			captainPath, err := resolveSiteReadPath(instanceID)
			if err != nil {
				c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
				return
			}
			proxyAndRecordOp(c, "DELETE", captainPath, captainBody, instanceID, cleanupDeletedSites)
		})
	}
}

// SiteDetail proxies site detail queries to Captain.
func SiteDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}
		idStr := c.Query("id")
		if idStr == "" {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "id 必填", "data": ""})
			return
		}
		if !isAdmin(c) {
			siteID, _ := strconv.Atoi(idStr)
			if !isSiteOwner(instanceID, siteID, getTenantGroupID(c)) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该站点", "data": ""})
				return
			}
		}

		captainPath, err := resolveSiteReadPath(instanceID)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
			return
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       captainPath + "?id=" + idStr,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		// 实例 mode 不代表该站点真实类型，探测一次：拿到的端点跟刚查的不一样就用真实端点重查
		if mode, ok := extractOperationModeFromDetail(resp.Body); ok {
			if actualPath, pathOK := sitePathForMode(mode); pathOK && actualPath != captainPath {
				if resp2, err2 := client.Do(&captain.CaptainRequest{
					Method:     "GET",
					Path:       actualPath + "?id=" + idStr,
					InstanceID: &idUint,
				}); err2 == nil {
					resp = resp2
				}
			}
		}

		wrapped := wrapCaptainResp(resp.Body)

		c.Data(resp.StatusCode, "application/json", wrapped)
	}
}

// SiteAuxPolicyList returns policy list for site form dropdown.
func SiteAuxPolicyList() gin.HandlerFunc {
	return proxyReadAux("/api/PolicyGroupAPI")
}

// SiteAuxCertList returns SSL cert list for site form dropdown.
// Admin: full list from Captain. Non-admin: system certs + tenant-bound certs only.
func SiteAuxCertList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}
		idUint := uint(instanceID)
		client := captain.GetDefault()
		if isAdmin(c) {
			resp, err := client.Do(&captain.CaptainRequest{Method: "GET", Path: "/api/CertAPI", InstanceID: &idUint})
			if err != nil {
				c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
				return
			}
			c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
			return
		}
		resp, err := fetchAllCerts(client, instanceID)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}
		body := filterCertResponseForTenant(resp.Body, instanceID, getTenantGroupID(c))
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(body))
	}
}

// SiteAuxNodeList returns node list for site form tengine selection.
func SiteAuxNodeList() gin.HandlerFunc {
	return proxyReadAux("/api/NodeInfoAPI")
}

// SiteAuxAssetGroupList returns asset group list for site form.
func SiteAuxAssetGroupList() gin.HandlerFunc {
	return proxyReadAux("/api/waf_assets/v1/Group")
}

// SiteAuxWorkGroupList returns work group list for site form.
func SiteAuxWorkGroupList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}
		from, err := resolveSiteWorkGroupFrom(instanceID)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/WorkGroupAPI?from=" + from,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// SiteAuxLinkIPList returns network interface IP list for site form.
func SiteAuxLinkIPList() gin.HandlerFunc {
	return proxyReadAux("/api/LinkAPI")
}

// SiteAuxWorkGroupIPList returns IP list for a specific work group.
func SiteAuxWorkGroupIPList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}

		name := c.Query("name")
		from, err := resolveSiteWorkGroupFrom(instanceID)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": err.Error(), "data": ""})
			return
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/WorkGroupToIPAPI?name=" + name + "&from=" + from,
			InstanceID: &idUint,
		}

		client := captain.GetDefault()
		resp, err := client.Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// CookieGenerateKey generates a random 32-char hex key for cookie security.
func CookieGenerateKey() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := getInstanceID(c)
		if !ok {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "captain_instance_id 必填", "data": ""})
			return
		}
		if !checkInstanceAccess(c, instanceID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权访问该 WAF", "data": ""})
			return
		}
		b := make([]byte, 16)
		if _, err := rand.Read(b); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "internal", "msg": "密钥生成失败", "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"key": hex.EncodeToString(b)}})
	}
}
