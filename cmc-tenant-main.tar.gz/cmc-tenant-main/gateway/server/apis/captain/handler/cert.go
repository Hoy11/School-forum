package handler

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"

	"github.com/chaitin/cmc-tenant/domain/tenant_group/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

const certListBatchSize = 500

// CertList proxies SSL certificate list queries to Captain.
func CertList() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		reqOffset := parseQueryInt(c, "offset", 0)
		reqCount := parseQueryInt(c, "count", 20)

		idUint := uint(instanceID)
		client := captain.GetDefault()
		var resp *captain.CaptainResponse
		var err error
		if isAdmin(c) {
			resp, err = client.Do(&captain.CaptainRequest{
				Method:     "GET",
				Path:       "/api/CertAPI",
				Query:      fmt.Sprintf("count=%d&offset=%d", reqCount, reqOffset),
				InstanceID: &idUint,
			})
		} else {
			resp, err = fetchAllCerts(client, instanceID)
		}
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		var body []byte
		if isAdmin(c) {
			body = resp.Body
		} else {
			body = filterCertResponseForTenant(resp.Body, instanceID, getTenantGroupID(c))
		}
		body = wrapListAsPage(body)
		body = injectBindingCounts(body, mappingCert, instanceID)
		if isAdmin(c) {
			body = injectAdminCertProtectionFields(body, instanceID)
		} else {
			body = injectCertProtectionFields(body, instanceID, getTenantGroupID(c))
			body = applyLocalPagination(body, reqOffset, reqCount)
		}
		c.Data(resp.StatusCode, "application/json", body)
	}
}

// fetchAllCerts 按批次拉取 /api/CertAPI 的全部证书，合并成 {total, items} 信封返回。
func fetchAllCerts(client *captain.CaptainClient, instanceID int) (*captain.CaptainResponse, error) {
	offset := 0
	total := -1
	statusCode := http.StatusOK
	items := make([]map[string]interface{}, 0)
	var envelope map[string]json.RawMessage

	for {
		idUint := uint(instanceID)
		resp, err := client.Do(&captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/CertAPI",
			Query:      fmt.Sprintf("count=%d&offset=%d", certListBatchSize, offset),
			InstanceID: &idUint,
		})
		if err != nil {
			return nil, err
		}
		statusCode = resp.StatusCode
		if resp.StatusCode >= 300 {
			return resp, nil
		}

		var parsed struct {
			Data struct {
				Total int                      `json:"total"`
				Items []map[string]interface{} `json:"items"`
			} `json:"data"`
		}
		if err := json.Unmarshal(resp.Body, &parsed); err != nil {
			return nil, fmt.Errorf("parse cert list response: %w", err)
		}
		if envelope == nil {
			if err := json.Unmarshal(resp.Body, &envelope); err != nil {
				return nil, fmt.Errorf("parse cert list envelope: %w", err)
			}
		}

		if total < 0 {
			total = parsed.Data.Total
		}
		items = append(items, parsed.Data.Items...)
		if len(items) >= total || len(parsed.Data.Items) == 0 {
			break
		}
		offset += len(parsed.Data.Items)
	}

	if envelope == nil {
		envelope = map[string]json.RawMessage{}
	}
	dataOut, _ := json.Marshal(gin.H{"total": len(items), "items": items})
	envelope["data"] = dataOut
	result, _ := json.Marshal(envelope)
	return &captain.CaptainResponse{StatusCode: statusCode, Body: result}, nil
}

// filterCertResponseForTenant filters a cert list response to items visible to the given
// tenant: certs bound in captain_cert_bindings OR system certs (is_mgt_api_cert=true).
func filterCertResponseForTenant(body []byte, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}
	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}
	var items []map[string]interface{}
	if err := json.Unmarshal(dataRaw, &items); err != nil {
		var page struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		}
		if err := json.Unmarshal(dataRaw, &page); err != nil {
			return body
		}
		items = page.Items
	}
	boundIDs := getMappedIDs(mappingCert, instanceID, tenantGroupID)
	filtered := make([]map[string]interface{}, 0, len(items))
	for _, item := range items {
		id := getIDFromItem(item)
		if _, ok := boundIDs[id]; ok {
			filtered = append(filtered, item)
			continue
		}
		if v, ok := item["is_mgt_api_cert"]; ok {
			if b, ok := v.(bool); ok && b {
				filtered = append(filtered, item)
			}
		}
	}
	dataOut, _ := json.Marshal(filtered)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// CertDetail proxies SSL certificate detail queries to Captain.
func CertDetail() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		certID, ok := requirePositiveQueryID(c, "id")
		if !ok {
			return
		}
		if !requireCertOwner(c, instanceID, certID, true) {
			return
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/CertAPI",
			Query:      c.Request.URL.RawQuery,
			InstanceID: &idUint,
		}
		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		body := resp.Body
		if certID > 0 {
			body = injectDetailBindingCount(body, mappingCert, instanceID, certID)
		}
		if !isAdmin(c) {
			body = injectDetailCertProtectionFields(body, instanceID, getTenantGroupID(c), certID)
		}
		if !isAdmin(c) {
			body = filterCertWebsites(body, instanceID, getTenantGroupID(c))
		}
		c.Data(resp.StatusCode, "application/json", body)
	}
}

// CertUpload proxies SSL certificate upload to Captain.
func CertUpload() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		form, err := c.MultipartForm()
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		var formUnits []*captain.FormUnit
		for fieldName, files := range form.File {
			for _, f := range files {
				file, _ := f.Open()
				defer func() { _ = file.Close() }()
				buf := make([]byte, f.Size)
				_, _ = file.Read(buf)
				formUnits = append(formUnits, &captain.FormUnit{
					FieldName: fieldName,
					FileName:  f.Filename,
					Data:      buf,
					IsFile:    true,
				})
			}
		}
		for fieldName, values := range form.Value {
			if fieldName == "captain_instance_id" {
				continue
			}
			for _, v := range values {
				formUnits = append(formUnits, &captain.FormUnit{
					FieldName: fieldName,
					Data:      []byte(v),
					IsFile:    false,
				})
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       "/api/UploadSSLCertAPI",
			Form:       formUnits,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		if resp.StatusCode < 300 && !isAdmin(c) {
			// Captain occasionally returns 2xx with err != null in the body (e.g. duplicate cert).
			// Only write the binding when Captain explicitly reports success (err is null).
			var captainBody struct {
				Err interface{} `json:"err"`
			}
			captainBodyErr := json.Unmarshal(resp.Body, &captainBody)
			if captainBodyErr == nil && captainBody.Err != nil {
				// Captain error in body — pass through, no binding needed
				c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
				return
			}
			id := extractIDFromResp(resp.Body)
			if id <= 0 {
				c.JSON(http.StatusInternalServerError, gin.H{
					"err":  "binding_failed",
					"msg":  "证书已上传，但无法写入 binding，请联系管理员",
					"data": "",
				})
				return
			}
			writeMapping(mappingCert, instanceID, id, getTenantGroupID(c), "created")
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// CertEdit proxies SSL certificate edit to Captain.
func CertEdit() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, ok := requireInstanceID(c)
		if !ok {
			return
		}

		form, err := c.MultipartForm()
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		resourceID, ok := requirePositiveFormID(c, form.Value, "id")
		if !ok {
			return
		}
		if blockSystemCertEdit(c, instanceID, resourceID) {
			return
		}
		if !requireCertOwner(c, instanceID, resourceID, false) {
			return
		}
		if blockProtectedCertEdit(c, instanceID, resourceID) {
			return
		}

		var formUnits []*captain.FormUnit
		for fieldName, files := range form.File {
			for _, f := range files {
				file, _ := f.Open()
				defer func() { _ = file.Close() }()
				buf := make([]byte, f.Size)
				_, _ = file.Read(buf)
				formUnits = append(formUnits, &captain.FormUnit{
					FieldName: fieldName,
					FileName:  f.Filename,
					Data:      buf,
					IsFile:    true,
				})
			}
		}
		for fieldName, values := range form.Value {
			if fieldName == "captain_instance_id" {
				continue
			}
			for _, v := range values {
				formUnits = append(formUnits, &captain.FormUnit{
					FieldName: fieldName,
					Data:      []byte(v),
					IsFile:    false,
				})
			}
		}

		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "POST",
			Path:       "/api/EditSSLCertAPI",
			Form:       formUnits,
			InstanceID: &idUint,
		}

		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}

		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// CertUpdate proxies SSL certificate update to Captain.
func CertUpdate() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}
		resourceID, ok := requirePositiveResourceID(c, body, mappingCert)
		if !ok {
			return
		}
		if blockSystemCertEdit(c, instanceID, resourceID) {
			return
		}
		if !requireCertOwner(c, instanceID, resourceID, false) {
			return
		}
		if blockProtectedCertEdit(c, instanceID, resourceID) {
			return
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "PUT",
			Path:       "/api/CertAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		proxyRequest(c, req)
	}
}

// CertDelete proxies SSL certificate deletion to Captain.
func CertDelete() gin.HandlerFunc {
	return func(c *gin.Context) {
		instanceID, body, ok := parseInstanceWriteRequest(c)
		if !ok {
			return
		}
		certIDs, ok := requirePositiveResourceIDs(c, body, mappingCert)
		if !ok {
			return
		}
		for _, certID := range certIDs {
			if blockSystemCertDelete(c, instanceID, certID) {
				return
			}
			if !requireCertOwner(c, instanceID, certID, false) {
				return
			}
			if blockProtectedCertDelete(c, instanceID, certID) {
				return
			}
		}
		idUint := uint(instanceID)
		req := &captain.CaptainRequest{
			Method:     "DELETE",
			Path:       "/api/CertAPI",
			Body:       body,
			InstanceID: &idUint,
		}
		resp, err := captain.GetDefault().Do(req)
		if err != nil {
			c.JSON(http.StatusBadGateway, gin.H{"err": "proxy_error", "msg": err.Error(), "data": ""})
			return
		}
		if resp.StatusCode < 300 {
			for _, certID := range certIDs {
				if !isAdmin(c) {
					deleteMapping(mappingCert, instanceID, certID, getTenantGroupID(c))
				} else {
					database.DB.Table("captain_cert_bindings").
						Where("captain_instance_id = ? AND cert_id = ?", instanceID, certID).
						Delete(nil)
				}
			}
		}
		c.Data(resp.StatusCode, "application/json", wrapCaptainResp(resp.Body))
	}
}

// injectDetailBindingCount adds binding_count to a single cert detail response.
func injectDetailBindingCount(body []byte, table mappingTable, instanceID int, resourceID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var detail map[string]interface{}
	if err := json.Unmarshal(dataRaw, &detail); err != nil {
		return body
	}

	counts := getBindingCounts(table, instanceID, []int{resourceID})
	detail["binding_count"] = counts[resourceID]

	dataOut, _ := json.Marshal(detail)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// filterCertWebsites filters the websites array in a cert detail response to only include
// sites that are bound to the given tenant group on the given WAF instance.
func filterCertWebsites(body []byte, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var detail map[string]interface{}
	if err := json.Unmarshal(dataRaw, &detail); err != nil {
		return body
	}

	websitesRaw, ok := detail["websites"]
	if !ok {
		return body
	}

	websites, ok := websitesRaw.([]interface{})
	if !ok || len(websites) == 0 {
		return body
	}

	// Collect site IDs bound to this tenant group on this WAF instance.
	var boundSiteIDs []int
	database.DB.Table("site_bindings").
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck("site_id", &boundSiteIDs)
	boundSet := make(map[int]bool, len(boundSiteIDs))
	for _, id := range boundSiteIDs {
		boundSet[id] = true
	}

	var filtered []interface{}
	for _, w := range websites {
		if m, ok := w.(map[string]interface{}); ok {
			if id := extractIntID(m["id"]); id > 0 && boundSet[id] {
				filtered = append(filtered, w)
			}
		}
	}
	detail["websites"] = filtered

	dataOut, _ := json.Marshal(detail)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// certDetailInfo holds cert detail info used for protection checks.
type certDetailInfo struct {
	websites     []int
	isMgtAPICert bool
}

// getCertDetail calls Captain API to get cert detail for protection checks.
func getCertDetail(client *captain.CaptainClient, instanceID int, certID int) *certDetailInfo {
	if certID <= 0 {
		return nil
	}
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("/api/CertAPI?id=%d", certID),
		InstanceID: &idUint,
	})
	if err != nil {
		log.Printf("[WARN] getCertDetail: Captain API error for cert %d: %v", certID, err)
		return nil
	}
	if resp.StatusCode >= 300 {
		log.Printf("[WARN] getCertDetail: Captain API returned %d for cert %d", resp.StatusCode, certID)
		return nil
	}

	var wrapper struct {
		Data map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil
	}

	info := &certDetailInfo{}

	// Extract is_mgt_api_cert
	if v, ok := wrapper.Data["is_mgt_api_cert"]; ok {
		if b, ok := v.(bool); ok {
			info.isMgtAPICert = b
		}
	}

	// Extract website IDs from websites array [{id, name, server_names}, ...]
	if websitesRaw, ok := wrapper.Data["websites"]; ok {
		if arr, ok := websitesRaw.([]interface{}); ok {
			for _, w := range arr {
				if m, ok := w.(map[string]interface{}); ok {
					if id := extractIntID(m["id"]); id > 0 {
						info.websites = append(info.websites, id)
					}
				}
			}
		}
	}

	return info
}

// checkCertEditProtection checks edit protection for a single cert:
// system_cert → block; source != "created" → check reference site ownership.
func checkCertEditProtection(c *gin.Context, instanceID int, resourceID int) *protectionError {
	if isAdmin(c) || resourceID <= 0 {
		return nil
	}
	tgID := getTenantGroupID(c)

	// Check source: created + binding_count==1 → references all from this tenant, safe
	source := getMappingSource(mappingCert, instanceID, resourceID, tgID)
	if source == "created" {
		return nil
	}

	// Non-created: check if referenced websites include external sites
	client := captain.GetDefault()
	detail := getCertDetail(client, instanceID, resourceID)
	if detail == nil {
		return nil
	}
	if checkRuleExternalRef(instanceID, detail.websites, tgID) {
		return &protectionError{err: "in_use", msg: "该SSL证书正在被其他站点引用，无法编辑"}
	}
	return nil
}

// injectCertProtectionFields adds source, has_external_ref and is_system_cert to each cert in the list response.
func injectCertProtectionFields(body []byte, instanceID int, tenantGroupID uint) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}

	if len(page.Items) == 0 {
		return body
	}

	// Collect all cert IDs for batch source lookup
	certIDs := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			certIDs = append(certIDs, id)
		}
	}

	// Batch query source from mapping table
	sourceMap := getMappingSources(mappingCert, instanceID, tenantGroupID, certIDs)

	// Get allowed site IDs for external ref check
	allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	for _, item := range page.Items {
		certID := getIDFromItem(item)
		if certID <= 0 {
			continue
		}

		// Inject source
		item["source"] = sourceMap[certID]

		// Inject is_system_cert from is_mgt_api_cert field
		item["is_system_cert"] = false
		if v, ok := item["is_mgt_api_cert"]; ok {
			if b, ok := v.(bool); ok {
				item["is_system_cert"] = b
			}
		}

		// Inject has_external_ref — extract website IDs from the websites array
		var hasExternalRef bool
		if websitesRaw, ok := item["websites"]; ok {
			if arr, ok := websitesRaw.([]interface{}); ok {
				for _, w := range arr {
					if m, ok := w.(map[string]interface{}); ok {
						if wID := extractIntID(m["id"]); wID > 0 && !allowedSet[wID] {
							hasExternalRef = true
							break
						}
					}
				}
			}
		}
		item["has_external_ref"] = hasExternalRef
	}

	pageData, _ := json.Marshal(page)
	resp["data"] = pageData
	result, _ := json.Marshal(resp)
	return result
}

// injectAdminCertProtectionFields adds shared_group_names, has_external_ref and is_system_cert
// to each cert in the list response for admin users. shared_group_names is populated for
// binding_count > 1 certs; has_external_ref distinguishes single-binding certs whose sites
// span multiple tenant groups. is_system_cert is extracted from is_mgt_api_cert for all certs.
func injectAdminCertProtectionFields(body []byte, instanceID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}
	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}
	var page struct {
		Total int                      `json:"total"`
		Items []map[string]interface{} `json:"items"`
	}
	if err := json.Unmarshal(dataRaw, &page); err != nil {
		return body
	}
	if len(page.Items) == 0 {
		return body
	}

	certIDs := make([]int, 0, len(page.Items))
	for _, item := range page.Items {
		if id := getIDFromItem(item); id > 0 {
			certIDs = append(certIDs, id)
		}
	}

	// Batch query all bindings for these certs
	type bindingRow struct {
		CertID        int  `gorm:"column:cert_id"`
		TenantGroupID uint `gorm:"column:tenant_group_id"`
	}
	var bindings []bindingRow
	database.DB.Table("captain_cert_bindings").
		Select("cert_id, tenant_group_id").
		Where("captain_instance_id = ? AND cert_id IN ?", instanceID, certIDs).
		Find(&bindings)

	certTGMap := make(map[int][]uint, len(certIDs))
	allTGIDs := make(map[uint]bool)
	for _, b := range bindings {
		certTGMap[b.CertID] = append(certTGMap[b.CertID], b.TenantGroupID)
		allTGIDs[b.TenantGroupID] = true
	}

	// Batch collect website site IDs per cert so external-ref tenant group names can be resolved
	certWebsiteMap := make(map[int][]int, len(certIDs))
	allSiteIDs := make(map[int]bool)
	for _, item := range page.Items {
		cid := getIDFromItem(item)
		if cid <= 0 {
			continue
		}
		if websitesRaw, ok := item["websites"]; ok {
			if arr, ok := websitesRaw.([]interface{}); ok {
				for _, w := range arr {
					if m, ok := w.(map[string]interface{}); ok {
						if wID := extractIntID(m["id"]); wID > 0 {
							certWebsiteMap[cid] = append(certWebsiteMap[cid], wID)
							allSiteIDs[wID] = true
						}
					}
				}
			}
		}
	}
	siteIDSlice := make([]int, 0, len(allSiteIDs))
	for id := range allSiteIDs {
		siteIDSlice = append(siteIDSlice, id)
	}
	type siteBindingRow struct {
		SiteID        int  `gorm:"column:site_id"`
		TenantGroupID uint `gorm:"column:tenant_group_id"`
	}
	var siteBindings []siteBindingRow
	if len(siteIDSlice) > 0 {
		database.DB.Table("site_bindings").
			Select("site_id, tenant_group_id").
			Where("captain_instance_id = ? AND site_id IN ?", instanceID, siteIDSlice).
			Find(&siteBindings)
	}
	siteTGMap := make(map[int][]uint, len(siteBindings))
	for _, b := range siteBindings {
		siteTGMap[b.SiteID] = append(siteTGMap[b.SiteID], b.TenantGroupID)
		allTGIDs[b.TenantGroupID] = true
	}

	// Batch query TG names
	tgIDSlice := make([]uint, 0, len(allTGIDs))
	for id := range allTGIDs {
		tgIDSlice = append(tgIDSlice, id)
	}
	tgNameMap := make(map[uint]string)
	if len(tgIDSlice) > 0 {
		var groups []model.TenantGroup
		database.DB.Where("id IN ? AND is_deleted = false", tgIDSlice).Find(&groups)
		for _, g := range groups {
			tgNameMap[g.ID] = g.Name
		}
	}

	// Cache allowed sites per TG for has_external_ref computation
	tgSitesCache := make(map[uint]map[int]bool)
	getAllowedSitesForTG := func(tgID uint) map[int]bool {
		if s, ok := tgSitesCache[tgID]; ok {
			return s
		}
		sites := getAllowedSiteIDsByGroup(instanceID, tgID)
		set := make(map[int]bool, len(sites))
		for _, s := range sites {
			set[s] = true
		}
		tgSitesCache[tgID] = set
		return set
	}

	for _, item := range page.Items {
		certID := getIDFromItem(item)
		if certID <= 0 {
			continue
		}

		// Inject is_system_cert from is_mgt_api_cert field
		item["is_system_cert"] = false
		if v, ok := item["is_mgt_api_cert"]; ok {
			if b, ok := v.(bool); ok {
				item["is_system_cert"] = b
			}
		}

		tgIDs := certTGMap[certID]

		if len(tgIDs) > 1 {
			names := make([]string, 0, len(tgIDs))
			for _, tgID := range tgIDs {
				if name, ok := tgNameMap[tgID]; ok {
					names = append(names, name)
				}
			}
			item["shared_group_names"] = names
			item["has_external_ref"] = false
		} else {
			names := []string{}
			hasExternalRef := false
			if len(tgIDs) == 1 {
				allowedSet := getAllowedSitesForTG(tgIDs[0])
				externalTGIDs := make(map[uint]bool)
				for _, siteID := range certWebsiteMap[certID] {
					if !allowedSet[siteID] {
						hasExternalRef = true
						for _, tgID := range siteTGMap[siteID] {
							if tgID != tgIDs[0] {
								externalTGIDs[tgID] = true
							}
						}
					}
				}
				for tgID := range externalTGIDs {
					if name, ok := tgNameMap[tgID]; ok {
						names = append(names, name)
					}
				}
			}
			item["shared_group_names"] = names
			item["has_external_ref"] = hasExternalRef
		}
	}

	dataOut, _ := json.Marshal(page)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// injectDetailCertProtectionFields adds source, has_external_ref and is_system_cert to a cert detail response.
// MUST be called before filterCertWebsites, otherwise has_external_ref will always be false.
func injectDetailCertProtectionFields(body []byte, instanceID int, tenantGroupID uint, certID int) []byte {
	var resp map[string]json.RawMessage
	if err := json.Unmarshal(body, &resp); err != nil {
		return body
	}

	dataRaw, ok := resp["data"]
	if !ok {
		return body
	}

	var detail map[string]interface{}
	if err := json.Unmarshal(dataRaw, &detail); err != nil {
		return body
	}

	// Inject source
	source := getMappingSource(mappingCert, instanceID, certID, tenantGroupID)
	detail["source"] = source

	// Inject is_system_cert from is_mgt_api_cert
	detail["is_system_cert"] = false
	if v, ok := detail["is_mgt_api_cert"]; ok {
		if b, ok := v.(bool); ok {
			detail["is_system_cert"] = b
		}
	}

	// Inject has_external_ref — uses original (unfiltered) websites
	allowedSites := getAllowedSiteIDsByGroup(instanceID, tenantGroupID)
	allowedSet := make(map[int]bool, len(allowedSites))
	for _, id := range allowedSites {
		allowedSet[id] = true
	}

	var hasExternalRef bool
	if websitesRaw, ok := detail["websites"]; ok {
		if arr, ok := websitesRaw.([]interface{}); ok {
			for _, w := range arr {
				if m, ok := w.(map[string]interface{}); ok {
					if wID := extractIntID(m["id"]); wID > 0 && !allowedSet[wID] {
						hasExternalRef = true
						break
					}
				}
			}
		}
	}
	detail["has_external_ref"] = hasExternalRef

	dataOut, _ := json.Marshal(detail)
	resp["data"] = dataOut
	result, _ := json.Marshal(resp)
	return result
}

// checkCertShared returns true if the certificate is bound to more than one tenant group.
func checkCertShared(instanceID int, resourceID int) bool {
	var count int64
	database.DB.Table("captain_cert_bindings").
		Where("captain_instance_id = ? AND cert_id = ?", instanceID, resourceID).
		Count(&count)
	return count > 1
}
