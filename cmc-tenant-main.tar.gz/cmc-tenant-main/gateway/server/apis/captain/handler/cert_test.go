package handler

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func newCertListTestRouter(role string) *gin.Engine {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: role})
		c.Set("tenant_group_id", uint(1))
		c.Set("allowed_waf_ids", []int{2})
		c.Next()
	})
	router.GET("/api/captain/cert/list", CertList())
	return router
}

func newCertWriteTestRouter(role string) *gin.Engine {
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: role})
		c.Set("tenant_group_id", uint(1))
		c.Set("allowed_waf_ids", []int{2})
		c.Next()
	})
	router.PUT("/api/captain/cert/update", CertUpdate())
	router.DELETE("/api/captain/cert/delete", CertDelete())
	return router
}

func newCertTestDB(t *testing.T) *gorm.DB {
	t.Helper()
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&bindingmodel.CaptainCertBinding{}, &bindingmodel.SiteBinding{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	return db
}

func TestCertListAdminForwardsOffsetAndCount(t *testing.T) {
	var gotQuery string
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		gotQuery = r.URL.RawQuery
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"total":1,"items":[{"id":1,"name":"cert1"}]}}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newCertTestDB(t)
	defer func() { database.DB = oldDB }()

	router := newCertListTestRouter("admin")
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/api/captain/cert/list?captain_instance_id=2&offset=20&count=20", nil)
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	if gotQuery != "count=20&offset=20" {
		t.Fatalf("captain query = %q, want count=20&offset=20", gotQuery)
	}
}

func TestFetchAllCertsPaginatesAllPages(t *testing.T) {
	gin.SetMode(gin.TestMode)
	const total = 3
	allCerts := make([]map[string]interface{}, 0, total)
	for i := 1; i <= total; i++ {
		allCerts = append(allCerts, map[string]interface{}{"id": i, "name": fmt.Sprintf("cert%d", i)})
	}

	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		query := r.URL.Query()
		offset := 0
		if v := query.Get("offset"); v != "" {
			_, _ = fmt.Sscanf(v, "%d", &offset)
		}
		// 模拟 Captain 每次最多返回 2 条
		end := offset + 2
		if end > total {
			end = total
		}
		page := allCerts[offset:end]
		body := map[string]interface{}{"err": nil, "msg": "success", "data": map[string]interface{}{"total": total, "items": page}}
		raw, _ := json.Marshal(body)
		_, _ = w.Write(raw)
	}))
	defer captainServer.Close()

	client := captain.NewCaptainClient(captainServer.URL, "token", 5, 0)
	resp, err := fetchAllCerts(client, 2)
	if err != nil {
		t.Fatalf("fetchAllCerts error: %v", err)
	}

	var parsed struct {
		Data struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &parsed); err != nil {
		t.Fatalf("unmarshal response: %v", err)
	}
	if len(parsed.Data.Items) != total {
		t.Fatalf("items = %d, want %d", len(parsed.Data.Items), total)
	}
	if parsed.Data.Total != total {
		t.Fatalf("total = %d, want %d", parsed.Data.Total, total)
	}
}

func TestCertListNonAdminFetchesAllAndPaginatesLocally(t *testing.T) {
	const total = 3
	allCerts := make([]map[string]interface{}, 0, total)
	for i := 1; i <= total; i++ {
		allCerts = append(allCerts, map[string]interface{}{"id": i, "name": fmt.Sprintf("cert%d", i)})
	}

	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		query := r.URL.Query()
		offset := 0
		if v := query.Get("offset"); v != "" {
			_, _ = fmt.Sscanf(v, "%d", &offset)
		}
		end := offset + 2
		if end > total {
			end = total
		}
		page := allCerts[offset:end]
		body := map[string]interface{}{"err": nil, "msg": "success", "data": map[string]interface{}{"total": total, "items": page}}
		raw, _ := json.Marshal(body)
		_, _ = w.Write(raw)
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newCertTestDB(t)
	defer func() { database.DB = oldDB }()
	for i := 1; i <= total; i++ {
		if err := database.DB.Create(&bindingmodel.CaptainCertBinding{
			TenantGroupID:     1,
			CaptainInstanceID: 2,
			CertID:            i,
		}).Error; err != nil {
			t.Fatalf("seed cert binding: %v", err)
		}
	}

	router := newCertListTestRouter("tenant")
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodGet, "/api/captain/cert/list?captain_instance_id=2&offset=2&count=2", nil)
	router.ServeHTTP(resp, req)

	if resp.Code != http.StatusOK {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}

	var parsed struct {
		Data struct {
			Total int                      `json:"total"`
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body.Bytes(), &parsed); err != nil {
		t.Fatalf("unmarshal response: %v", err)
	}
	if parsed.Data.Total != total {
		t.Fatalf("total = %d, want %d", parsed.Data.Total, total)
	}
	if len(parsed.Data.Items) != 1 {
		t.Fatalf("items = %d, want 1 (page beyond first 2 certs)", len(parsed.Data.Items))
	}
}

func TestTenantSystemCertUpdateReturnsSystemCertBeforeOwnerCheck(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet || r.URL.Path != "/api/CertAPI" || r.URL.Query().Get("id") != "99" {
			t.Fatalf("unexpected captain request: %s %s?%s", r.Method, r.URL.Path, r.URL.RawQuery)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":99,"is_mgt_api_cert":true,"websites":[]}}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newCertTestDB(t)
	defer func() { database.DB = oldDB }()

	router := newCertWriteTestRouter("tenant")
	body := []byte(`{"id":99,"captain_instance_id":2,"name":"blocked"}`)
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPut, "/api/captain/cert/update", bytes.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(resp, req)

	assertProtectionErr(t, resp, http.StatusForbidden, "system_cert")
}

func TestTenantSystemCertDeleteReturnsSystemCertBeforeOwnerCheck(t *testing.T) {
	captainServer := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet || r.URL.Path != "/api/CertAPI" || r.URL.Query().Get("id") != "99" {
			t.Fatalf("unexpected captain request: %s %s?%s", r.Method, r.URL.Path, r.URL.RawQuery)
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"err":null,"msg":"success","data":{"id":99,"is_mgt_api_cert":true,"websites":[]}}`))
	}))
	defer captainServer.Close()

	oldClient := captain.GetDefault()
	captain.SetDefault(captain.NewCaptainClient(captainServer.URL, "token", 5, 0))
	defer captain.SetDefault(oldClient)

	oldDB := database.DB
	database.DB = newCertTestDB(t)
	defer func() { database.DB = oldDB }()

	router := newCertWriteTestRouter("tenant")
	body := []byte(`{"id":99,"captain_instance_id":2}`)
	resp := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodDelete, "/api/captain/cert/delete", bytes.NewReader(body))
	req.Header.Set("Content-Type", "application/json")
	router.ServeHTTP(resp, req)

	assertProtectionErr(t, resp, http.StatusForbidden, "system_cert")
}

func assertProtectionErr(t *testing.T, resp *httptest.ResponseRecorder, wantStatus int, wantErr string) {
	t.Helper()
	if resp.Code != wantStatus {
		t.Fatalf("status=%d body=%s", resp.Code, resp.Body.String())
	}
	var parsed struct {
		Err string `json:"err"`
	}
	if err := json.Unmarshal(resp.Body.Bytes(), &parsed); err != nil {
		t.Fatalf("unmarshal response: %v", err)
	}
	if parsed.Err != wantErr {
		t.Fatalf("err=%q, want %q; body=%s", parsed.Err, wantErr, resp.Body.String())
	}
}
