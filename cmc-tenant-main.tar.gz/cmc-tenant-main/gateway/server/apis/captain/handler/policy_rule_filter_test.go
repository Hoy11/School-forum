package handler

import (
	"encoding/json"
	"testing"
)

type fakePolicyRuleQuery map[string]string

func (q fakePolicyRuleQuery) Query(key string) string {
	return q[key]
}

func TestPolicyRuleFilterStatusCode(t *testing.T) {
	conditions := []policyRuleCondition{
		{
			Target: "status_code",
			Items: []policyRuleConditionItem{
				{Oper: "in", Value: "403,404"},
			},
		},
	}
	raw, err := json.Marshal(conditions)
	if err != nil {
		t.Fatal(err)
	}

	filter := parsePolicyRuleFilter(fakePolicyRuleQuery{"conditions": string(raw)})
	if len(filter.StatusCodes) != 2 || filter.StatusCodes[0] != 403 || filter.StatusCodes[1] != 404 {
		t.Fatalf("status codes = %#v, want [403 404]", filter.StatusCodes)
	}

	if !matchPolicyRuleFilter(policyRuleWithStatusCode(403), filter) {
		t.Fatal("403 rule should match status_code in 403,404")
	}
	if matchPolicyRuleFilter(policyRuleWithStatusCode(302), filter) {
		t.Fatal("302 rule should not match status_code in 403,404")
	}
}

func TestPolicyRuleFilterStatusCodeBackwardCompatibleActionTarget(t *testing.T) {
	conditions := []policyRuleCondition{
		{
			Target: "action",
			Items: []policyRuleConditionItem{
				{Oper: "!=", Value: "403"},
			},
		},
	}
	raw, err := json.Marshal(conditions)
	if err != nil {
		t.Fatal(err)
	}

	filter := parsePolicyRuleFilter(fakePolicyRuleQuery{"conditions": string(raw)})
	if !matchPolicyRuleFilter(policyRuleWithStatusCode(404), filter) {
		t.Fatal("404 rule should match legacy action target with != 403")
	}
	if matchPolicyRuleFilter(policyRuleWithStatusCode(403), filter) {
		t.Fatal("403 rule should not match legacy action target with != 403")
	}
}

func TestPolicyRuleFilterForwardAddressRegex(t *testing.T) {
	conditions := []policyRuleCondition{
		{
			Target: "forward_address",
			Items: []policyRuleConditionItem{
				{Oper: "regex", Value: `^https://example\.com/`},
			},
		},
	}
	raw, err := json.Marshal(conditions)
	if err != nil {
		t.Fatal(err)
	}

	filter := parsePolicyRuleFilter(fakePolicyRuleQuery{"conditions": string(raw)})
	if filter.ForwardAddrRegex == "" {
		t.Fatal("regex operator should populate ForwardAddrRegex")
	}
	if !matchPolicyRuleFilter(policyRuleWithForwardAddress("https://example.com/login"), filter) {
		t.Fatal("matching forward address should pass regex filter")
	}
	if matchPolicyRuleFilter(policyRuleWithForwardAddress("https://other.example/login"), filter) {
		t.Fatal("non-matching forward address should fail regex filter")
	}
}

func TestPolicyRuleFilterForwardAddressNotRegex(t *testing.T) {
	conditions := []policyRuleCondition{
		{
			Target: "forward_address",
			Items: []policyRuleConditionItem{
				{Oper: "not regex", Value: `^https://blocked\.example/`},
			},
		},
	}
	raw, err := json.Marshal(conditions)
	if err != nil {
		t.Fatal(err)
	}

	filter := parsePolicyRuleFilter(fakePolicyRuleQuery{"conditions": string(raw)})
	if filter.ForwardAddrNotRe == "" {
		t.Fatal("not regex operator should populate ForwardAddrNotRe")
	}
	if !matchPolicyRuleFilter(policyRuleWithForwardAddress("https://allowed.example/login"), filter) {
		t.Fatal("non-matching forward address should pass not regex filter")
	}
	if matchPolicyRuleFilter(policyRuleWithForwardAddress("https://blocked.example/login"), filter) {
		t.Fatal("matching forward address should fail not regex filter")
	}
}

func policyRuleWithStatusCode(code int) map[string]interface{} {
	return map[string]interface{}{
		"forbidden_page_config": map[string]interface{}{
			"status_code": float64(code),
		},
	}
}

func policyRuleWithForwardAddress(address string) map[string]interface{} {
	return map[string]interface{}{
		"action": "forward",
		"pattern": map[string]interface{}{
			"$AND": []interface{}{
				map[string]interface{}{
					"eq": map[string]interface{}{
						"url": address,
					},
				},
			},
		},
	}
}
