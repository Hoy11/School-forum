package handler

import (
	"encoding/json"
	"fmt"
	"log"

	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

// --- Spec23: Admin mapping sync functions ---

// getTenantGroupIDsForSites returns distinct tenant_group_ids that are bound to the given sites
// on the specified WAF instance.
func getTenantGroupIDsForSites(instanceID int, siteIDs []int) []uint {
	if len(siteIDs) == 0 {
		return nil
	}
	var ids []uint
	database.DB.Table("site_bindings").
		Where("captain_instance_id = ? AND site_id IN ?", instanceID, siteIDs).
		Distinct("tenant_group_id").
		Pluck("tenant_group_id", &ids)
	return ids
}

// writeMappingForSiteTenantGroups writes mapping records for all tenant groups that are bound
// to the given sites. Uses writeMappingIfNotExists for idempotency (ON CONFLICT DO NOTHING).
// source is always "inherited" because the resource was not created by the tenant group.
func writeMappingForSiteTenantGroups(table mappingTable, instanceID int, resourceID int, siteIDs []int) {
	if resourceID <= 0 || len(siteIDs) == 0 {
		return
	}
	tenantGroupIDs := getTenantGroupIDsForSites(instanceID, siteIDs)
	for _, tgID := range tenantGroupIDs {
		writeMappingIfNotExists(table, instanceID, resourceID, tgID, "inherited")
	}
}

// fetchRuleInGroupIDs fetches a rule's detail from Captain and extracts ingroup IP group IDs.
// Used by PolicyRuleBind because the bind request body does not contain the pattern field.
func fetchRuleInGroupIDs(client *captain.CaptainClient, instanceID int, ruleID int) []int {
	if ruleID <= 0 || client == nil {
		return nil
	}
	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("/api/PolicyRuleAPI?id=%d", ruleID),
		InstanceID: &idUint,
	})
	if err != nil {
		log.Printf("[WARN] fetchRuleInGroupIDs: Captain API error for rule %d: %v", ruleID, err)
		return nil
	}
	if resp.StatusCode >= 300 {
		log.Printf("[WARN] fetchRuleInGroupIDs: Captain API returned %d for rule %d", resp.StatusCode, ruleID)
		return nil
	}

	var wrapper struct {
		Data map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil
	}

	return extractInGroupIDs(wrapper.Data["pattern"])
}

// --- Spec23: Reconcile functions (Mode B: add missing, delete stale) ---

// reconcileMappings computes the actual set of resources that should be mapped for a tenant group,
// compares it with the current mapped set, and adds missing / deletes stale mappings.
// This is used for indirect association changes (e.g., PolicyUpdate→block page, PolicyRuleUpdate→IP group).
func reconcileMappings(instanceID int, tenantGroupID uint, table mappingTable, actualSet []int) {
	actualMap := make(map[int]bool, len(actualSet))
	for _, id := range actualSet {
		actualMap[id] = true
	}

	// Get currently mapped resource IDs for this tenant group on this instance
	mappedSet := getMappedResourceIDs(table, instanceID, tenantGroupID)

	// Add missing mappings
	for _, id := range actualSet {
		if id > 0 {
			writeMappingIfNotExists(table, instanceID, id, tenantGroupID, "inherited")
		}
	}

	// Delete stale mappings (mapped but not in actualSet)
	for _, id := range mappedSet {
		if id > 0 && !actualMap[id] {
			deleteMapping(table, instanceID, id, tenantGroupID)
		}
	}
}

// buildBlockPageNameMap fetches all block pages from Captain once and returns a name(MD5)→id map.
func buildBlockPageNameMap(instanceID int) map[string]int {
	idUint := uint(instanceID)
	resp, err := captain.GetDefault().Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/ForbiddenPageAPI",
		Query:      "count=1000&offset=0",
		InstanceID: &idUint,
	})
	if err != nil {
		log.Printf("[WARN] buildBlockPageNameMap: Captain request error: %v", err)
		return nil
	}
	var wrapper struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		log.Printf("[WARN] buildBlockPageNameMap: parse error: %v", err)
		return nil
	}
	m := make(map[string]int, len(wrapper.Data.Items))
	for _, item := range wrapper.Data.Items {
		name, _ := item["name"].(string)
		if id := getIDFromItem(item); name != "" && id > 0 {
			m[name] = id
		}
	}
	return m
}

// collectActualBlockPageIDs computes the set of block page IDs that a tenant group actually uses.
// It checks ALL sites bound to this tenant group and extracts block page IDs from their policies.
// bpNameMap (name→id) and policyCache are shared across TG iterations to avoid redundant Captain calls.
func collectActualBlockPageIDs(instanceID int, tenantGroupID uint, bpNameMap map[string]int, policyCache map[int]map[string]interface{}) []int {
	var siteIDs []int
	database.DB.Table("site_bindings").
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck("site_id", &siteIDs)

	if len(siteIDs) == 0 {
		return nil
	}

	client := captain.GetDefault()
	if client == nil {
		return nil
	}

	var bpIDs []int
	seen := make(map[int]bool)

	for _, siteID := range siteIDs {
		detail, err := fetchSiteDetail(client, instanceID, siteID)
		if err != nil {
			log.Printf("[WARN] collectActualBlockPageIDs: site %d: %v", siteID, err)
			continue
		}
		pgID := extractIntID(detail["policy_group"])
		if pgID <= 0 {
			continue
		}
		policyDetail, ok := policyCache[pgID]
		if !ok {
			policyDetail, err = fetchPolicyDetail(client, instanceID, pgID)
			if err != nil {
				log.Printf("[WARN] collectActualBlockPageIDs: policy %d: %v", pgID, err)
				continue
			}
			policyCache[pgID] = policyDetail
		}
		fpc, ok := policyDetail["forbidden_page_config"].(map[string]interface{})
		if !ok {
			continue
		}
		path, _ := fpc["path"].(string)
		if path == "" {
			continue
		}
		bpID := bpNameMap[path]
		if bpID > 0 && !seen[bpID] {
			bpIDs = append(bpIDs, bpID)
			seen[bpID] = true
		}
	}

	return bpIDs
}

// collectActualIPGroupIDs computes the set of IP group IDs that a tenant group actually uses.
// It checks ALL sites for proxy_ip_groups + policy rule ingroup references.
func collectActualIPGroupIDs(instanceID int, tenantGroupID uint) []int {
	var siteIDs []int
	database.DB.Table("site_bindings").
		Where("captain_instance_id = ? AND tenant_group_id = ?", instanceID, tenantGroupID).
		Pluck("site_id", &siteIDs)

	if len(siteIDs) == 0 {
		return nil
	}

	client := captain.GetDefault()
	if client == nil {
		return nil
	}

	var ipGroupIDs []int
	seen := make(map[int]bool)

	for _, siteID := range siteIDs {
		detail, err := fetchSiteDetail(client, instanceID, siteID)
		if err != nil {
			log.Printf("[WARN] collectActualIPGroupIDs: site %d: %v", siteID, err)
			continue
		}

		// Site-level proxy_ip_groups
		if groups, ok := detail["proxy_ip_groups"].([]interface{}); ok {
			for _, g := range groups {
				if id := extractIntID(g); id > 0 && !seen[id] {
					ipGroupIDs = append(ipGroupIDs, id)
					seen[id] = true
				}
			}
		}

		// Policy rule ingroup references
		idUint := uint(instanceID)
		resp, err := client.Do(&captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/PolicyRuleAPI",
			Query:      "is_global=false",
			InstanceID: &idUint,
		})
		if err != nil {
			log.Printf("[WARN] collectActualIPGroupIDs: rules for site %d: %v", siteID, err)
			continue
		}
		var items []map[string]interface{}
		var wrapper struct {
			Data []map[string]interface{} `json:"data"`
		}
		if err := json.Unmarshal(resp.Body, &wrapper); err == nil {
			items = wrapper.Data
		} else {
			var paginated struct {
				Data struct {
					Items []map[string]interface{} `json:"items"`
				} `json:"data"`
			}
			if err := json.Unmarshal(resp.Body, &paginated); err == nil {
				items = paginated.Data.Items
			}
		}
		for _, rule := range items {
			if matchRuleSite(rule, siteID) {
				for _, id := range extractInGroupIDs(rule["pattern"]) {
					if id > 0 && !seen[id] {
						ipGroupIDs = append(ipGroupIDs, id)
						seen[id] = true
					}
				}
			}
		}
	}

	return ipGroupIDs
}

// reconcileBlockPageMappings is a convenience entry point for PolicyUpdate.
// It finds all tenant groups that use sites with the given policy, then for each group
// reconciles block page mappings.
func reconcileBlockPageMappings(instanceID int, policyID int) {
	if policyID <= 0 {
		return
	}
	client := captain.GetDefault()
	if client == nil {
		return
	}

	// Find sites using this policy from Captain site list
	siteItems := fetchAllSites(instanceID)
	var affectedSiteIDs []int
	for _, item := range siteItems {
		if extractIntID(item["policy_group"]) == policyID {
			if id := extractIntID(item["id"]); id > 0 {
				affectedSiteIDs = append(affectedSiteIDs, id)
			} else if id := extractIntID(item["ID"]); id > 0 {
				affectedSiteIDs = append(affectedSiteIDs, id)
			}
		}
	}

	if len(affectedSiteIDs) == 0 {
		return
	}

	// Pre-fetch block page list once and share policy cache across all TG iterations.
	bpNameMap := buildBlockPageNameMap(instanceID)
	policyCache := make(map[int]map[string]interface{})

	// Find tenant groups bound to these sites
	tenantGroupIDs := getTenantGroupIDsForSites(instanceID, affectedSiteIDs)
	for _, tgID := range tenantGroupIDs {
		actualSet := collectActualBlockPageIDs(instanceID, tgID, bpNameMap, policyCache)
		reconcileMappings(instanceID, tgID, mappingBlockPage, actualSet)
	}
}

// reconcileIPGroupMappingsForSites is a convenience entry point for PolicyRuleUpdate.
// It finds tenant groups bound to the given sites and reconciles IP group mappings for each.
func reconcileIPGroupMappingsForSites(instanceID int, siteIDs []int) {
	if len(siteIDs) == 0 {
		return
	}
	tenantGroupIDs := getTenantGroupIDsForSites(instanceID, siteIDs)
	for _, tgID := range tenantGroupIDs {
		actualSet := collectActualIPGroupIDs(instanceID, tgID)
		reconcileMappings(instanceID, tgID, mappingIPGroup, actualSet)
	}
}