// Package handler provides HTTP handlers for tenant user management.
package handler

import (
	"net/http"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/domain/user/business"
	"github.com/chaitin/cmc-tenant/server/midware"
	"github.com/gin-gonic/gin"
)

var tenantUserOp = business.NewUserOperator()

// TenantUserList returns a paginated list of tenant users.
func TenantUserList() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*usermodel.User)

		var req struct {
			Count     int                      `json:"count"`
			Offset    int                      `json:"offset"`
			IsEnabled []map[string]interface{} `json:"is_enabled"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			req.Count = 20
			req.Offset = 0
		}

		offset := req.Offset
		count := req.Count
		if count <= 0 || count > 100 {
			count = 20
		}
		isEnabled := extractBoolValue(req.IsEnabled)

		total, users, err := tenantUserOp.List([]string{"tenant"}, u.TenantGroupID, "", isEnabled, offset, count)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"total": total, "items": users}})
	}
}

// TenantUserCreate adds a new tenant user.
func TenantUserCreate() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*usermodel.User)

		var req struct {
			Username string `json:"username" binding:"required"`
			Password string `json:"password" binding:"required"`
			Remark   string `json:"remark"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}

		created, err := tenantUserOp.Create(req.Username, req.Password, "tenant", u.TenantGroupID, req.Remark)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"id": created.ID, "username": created.Username}})
	}
}

// TenantUserEnable toggles the enabled status of tenant users.
func TenantUserEnable() gin.HandlerFunc {
	return sameGroupOnlyWithEnable(tenantUserOp.Enable)
}

// TenantUserCredential resets a tenant user's password.
func TenantUserCredential() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			ID uint `json:"id" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}
		if !isSameGroup(c, req.ID) {
			c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作", "data": ""})
			return
		}
		pwd, err := tenantUserOp.ResetPassword(req.ID)
		if err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": gin.H{"password": pwd}})
	}
}

// TenantUserUnlock clears the locked status of tenant users and their Redis login lock.
func TenantUserUnlock() gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}
		for _, id := range req.IDs {
			if !isSameGroup(c, id) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作", "data": ""})
				return
			}
		}
		usernames, err := tenantUserOp.GetUsernamesByIDs(req.IDs)
		if err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		if err := tenantUserOp.Unlock(req.IDs); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		for _, name := range usernames {
			midware.ClearLoginLock(name)
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

// TenantUserDelete soft-deletes tenant users.
func TenantUserDelete() gin.HandlerFunc {
	return sameGroupOnlyIDs(tenantUserOp.Delete)
}

func isSameGroup(c *gin.Context, userID uint) bool {
	user, _ := c.Get("user")
	u := user.(*usermodel.User)
	target, err := tenantUserOp.GetByID(userID)
	if err != nil {
		return false
	}
	return target.TenantGroupID != nil && *target.TenantGroupID == *u.TenantGroupID && target.Role == "tenant"
}

func sameGroupOnlyWithEnable(fn func([]uint, bool) error) gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs       []uint `json:"ids" binding:"required"`
			IsEnabled bool   `json:"is_enabled"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}
		for _, id := range req.IDs {
			if !isSameGroup(c, id) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作", "data": ""})
				return
			}
		}
		if err := fn(req.IDs, req.IsEnabled); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

func sameGroupOnlyIDs(fn func([]uint) error) gin.HandlerFunc {
	return func(c *gin.Context) {
		var req struct {
			IDs []uint `json:"ids" binding:"required"`
		}
		if err := c.ShouldBindJSON(&req); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"err": "bad_request", "msg": "参数错误", "data": ""})
			return
		}
		for _, id := range req.IDs {
			if !isSameGroup(c, id) {
				c.JSON(http.StatusForbidden, gin.H{"err": "forbidden", "msg": "无权操作", "data": ""})
				return
			}
		}
		if err := fn(req.IDs); err != nil {
			c.JSON(http.StatusInternalServerError, gin.H{"err": "error", "msg": err.Error(), "data": ""})
			return
		}
		c.JSON(http.StatusOK, gin.H{"err": nil, "msg": "success", "data": nil})
	}
}

func extractBoolValue(conds []map[string]interface{}) *bool {
	for _, c := range conds {
		if oper, _ := c["oper"].(string); oper == "=" {
			if arr, ok := c["target"].([]interface{}); ok && len(arr) > 0 {
				if s, ok := arr[0].(string); ok {
					b := s == "true"
					return &b
				}
			}
		}
	}
	return nil
}
