package handler

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/chaitin/cmc-tenant/server/midware"
	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func connectTestRedis(t *testing.T) *redis.Client {
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "localhost:6379"
	}
	rdb := redis.NewClient(&redis.Options{Addr: addr})
	if err := rdb.Ping(context.Background()).Err(); err != nil {
		t.Skip("redis not available: " + err.Error())
	}
	return rdb
}

func TestTenantUserUnlockClearsRedisLoginLockForSameGroup(t *testing.T) {
	gin.SetMode(gin.TestMode)

	rdb := connectTestRedis(t)
	oldRDB := database.RDB
	database.RDB = rdb
	defer func() { database.RDB = oldRDB }()

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&usermodel.User{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	groupID := uint(1)
	if err := db.Create(&usermodel.User{ID: 2, Username: "tenant_locked_user", Role: "tenant", TenantGroupID: &groupID}).Error; err != nil {
		t.Fatalf("create user: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	ctx := context.Background()
	lockKey := "login_lock:tenant_locked_user"
	failKey := "login_fail:tenant_locked_user"
	defer rdb.Del(ctx, lockKey, failKey)
	rdb.Set(ctx, lockKey, "1", 0)
	rdb.Set(ctx, failKey, "5", 0)

	r := gin.New()
	r.POST("/unlock", func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant_admin", TenantGroupID: &groupID})
		TenantUserUnlock()(c)
	})

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/unlock", strings.NewReader(`{"ids":[2]}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusOK, w.Body.String())
	}
	if midware.IsLoginLocked("tenant_locked_user") {
		t.Error("expected redis login lock to be cleared by TenantUserUnlock")
	}
}

func TestTenantUserUnlockRejectsOtherGroup(t *testing.T) {
	gin.SetMode(gin.TestMode)

	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	if err := db.AutoMigrate(&usermodel.User{}); err != nil {
		t.Fatalf("migrate: %v", err)
	}
	otherGroup := uint(2)
	if err := db.Create(&usermodel.User{ID: 3, Username: "other_group_user", Role: "tenant", TenantGroupID: &otherGroup}).Error; err != nil {
		t.Fatalf("create user: %v", err)
	}
	oldDB := database.DB
	database.DB = db
	defer func() { database.DB = oldDB }()

	myGroup := uint(1)
	r := gin.New()
	r.POST("/unlock", func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant_admin", TenantGroupID: &myGroup})
		TenantUserUnlock()(c)
	})

	w := httptest.NewRecorder()
	req := httptest.NewRequest(http.MethodPost, "/unlock", strings.NewReader(`{"ids":[3]}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusForbidden {
		t.Fatalf("status = %d, want %d, body=%s", w.Code, http.StatusForbidden, w.Body.String())
	}
}
