package midware

import (
	"log"
	"time"

	"github.com/gin-gonic/gin"
)

// Logger logs request method, path, status, duration, and client IP.
func Logger() gin.HandlerFunc {
	return func(c *gin.Context) {
		start := time.Now()
		c.Next()
		cost := time.Since(start)
		log.Printf("[%s] %s %d %v %s",
			c.Request.Method, c.Request.URL.Path,
			c.Writer.Status(), cost, c.ClientIP(),
		)
	}
}
