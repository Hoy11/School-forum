package midware

import (
	"fmt"
	"net/http"
	"runtime"

	"github.com/gin-gonic/gin"
)

// Recovery catches panics and returns a 500 error.
func Recovery() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if err := recover(); err != nil {
				buf := make([]byte, 4096)
				n := runtime.Stack(buf, false)
				_, _ = fmt.Fprintf(gin.DefaultErrorWriter, "[Panic] %v\n%s\n", err, buf[:n])
				c.AbortWithStatusJSON(http.StatusInternalServerError, gin.H{
					"err":  "internal_error",
					"msg":  "服务内部错误",
					"data": "",
				})
			}
		}()
		c.Next()
	}
}
