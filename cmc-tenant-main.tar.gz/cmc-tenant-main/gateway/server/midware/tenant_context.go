package midware

import (
	"github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/gin-gonic/gin"
)

// TenantContext sets data scope and allowed WAF/site IDs based on the user's role.
func TenantContext() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, exists := c.Get("user")
		if !exists {
			c.Next()
			return
		}

		u := user.(*model.User)

		if u.Role == "admin" {
			c.Set("data_scope", "all")
			c.Next()
			return
		}

		c.Set("data_scope", "tenant")
		c.Set("tenant_group_id", u.TenantGroupID)

		var wafIDs []int
		database.DB.Model(&bindingmodel.WafBinding{}).
			Where("tenant_group_id = ?", u.TenantGroupID).
			Pluck("captain_instance_id", &wafIDs)
		c.Set("allowed_waf_ids", wafIDs)

		var sites []bindingmodel.SiteBinding
		database.DB.Where("tenant_group_id = ?", u.TenantGroupID).Find(&sites)
		c.Set("allowed_sites", sites)

		c.Next()
	}
}
