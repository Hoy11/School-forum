// Package midware provides Gin middleware for the CMC Tenant server.
package midware

import (
	"bytes"
	"encoding/json"
	"io"
	"net/http"
	"strconv"
	"strings"

	auditmodel "github.com/chaitin/cmc-tenant/domain/audit_log/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/sanitize"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
)

type auditResponseWriter struct {
	gin.ResponseWriter
	body bytes.Buffer
}

func (w *auditResponseWriter) Write(data []byte) (int, error) {
	w.body.Write(data)
	return w.ResponseWriter.Write(data)
}

// Audit records write operations as audit logs.
func Audit() gin.HandlerFunc {
	return func(c *gin.Context) {
		var bodyBytes []byte
		if isWriteMethod(c.Request.Method) {
			bodyBytes, _ = io.ReadAll(c.Request.Body)
			c.Request.Body = io.NopCloser(bytes.NewBuffer(bodyBytes))
		}
		writer := &auditResponseWriter{ResponseWriter: c.Writer}
		c.Writer = writer
		c.Next()

		if !isWriteMethod(c.Request.Method) || isListEndpoint(c.Request.URL.Path) {
			return
		}
		user, exists := c.Get("user")
		if !exists {
			return
		}

		u := user.(*usermodel.User)
		action := methodToAction(c.Request.Method, c.Request.URL.Path)
		resource := pathToResource(c.Request.URL.Path)

		detail := ""
		if len(bodyBytes) > 0 && len(bodyBytes) < 4096 {
			if strings.HasPrefix(c.GetHeader("Content-Type"), "application/json") {
				detail = sanitize.JSON(string(bodyBytes))
			} else {
				detail = string(bodyBytes)
			}
		}
		result := responseResult(c.Writer.Status())
		errorMessage := extractErrorMessage(writer.body.Bytes(), c.Writer.Status())

		// 构建完整请求路径（包含 Query String）
		requestURL := c.Request.URL.Path
		if c.Request.URL.RawQuery != "" {
			requestURL = requestURL + "?" + c.Request.URL.RawQuery
		}

		log := auditmodel.AuditLog{
			UserID:       u.ID,
			Username:     u.Username,
			Action:       action,
			Resource:     resource,
			RequestURL:   requestURL,
			Summary:      buildAuditSummary(action, resource, detail),
			Result:       result,
			ErrorMessage: errorMessage,
			Detail:       detail,
			IP:           c.ClientIP(),
		}
		go func() { _ = database.DB.Create(&log).Error }()
	}
}

func isListEndpoint(path string) bool {
	return strings.HasSuffix(path, "/list") || strings.HasSuffix(path, "/available")
}

func isWriteMethod(method string) bool {
	return method == "POST" || method == "PUT" || method == "DELETE"
}

func methodToAction(method, path string) string {
	switch method {
	case "POST":
		if strings.HasSuffix(path, "/login") {
			return "LOGIN"
		}
		return "CREATE"
	case "PUT":
		return "UPDATE"
	case "DELETE":
		return "DELETE"
	default:
		return method
	}
}

func pathToResource(path string) string {
	parts := strings.Split(strings.Trim(path, "/"), "/")
	if len(parts) < 2 {
		return path
	}
	if parts[0] != "api" {
		return parts[len(parts)-1]
	}
	if len(parts) == 2 {
		return parts[1]
	}
	switch parts[1] {
	case "auth", "user", "tenant-group", "highlight-ip":
		return parts[1]
	case "tenant", "binding", "captain", "system":
		return parts[2]
	default:
		return parts[1]
	}
}

func responseResult(status int) string {
	if status >= http.StatusBadRequest {
		return "failed"
	}
	return "success"
}

func extractErrorMessage(body []byte, status int) string {
	if status < http.StatusBadRequest || len(body) == 0 {
		return ""
	}
	var payload struct {
		Msg string `json:"msg"`
		Err string `json:"err"`
	}
	if err := json.Unmarshal(body, &payload); err == nil {
		if strings.TrimSpace(payload.Msg) != "" {
			return payload.Msg
		}
		if strings.TrimSpace(payload.Err) != "" {
			return payload.Err
		}
	}
	text := strings.TrimSpace(string(body))
	if len(text) > 255 {
		return text[:255]
	}
	return text
}

func buildAuditSummary(action, resource, detail string) string {
	if action == "LOGIN" {
		return "登录系统"
	}
	resourceLabel := auditResourceLabel(resource)
	objectName := extractAuditObjectName(detail)
	switch action {
	case "CREATE":
		return joinAuditSummary("创建", resourceLabel, objectName)
	case "UPDATE":
		return joinAuditSummary("修改", resourceLabel, objectName)
	case "DELETE":
		return joinAuditSummary("删除", resourceLabel, objectName)
	default:
		return joinAuditSummary(action, resourceLabel, objectName)
	}
}

func joinAuditSummary(action, resourceLabel, objectName string) string {
	if objectName != "" {
		return action + resourceLabel + " " + objectName
	}
	if resourceLabel != "" {
		return action + resourceLabel
	}
	return action
}

func auditResourceLabel(resource string) string {
	labels := map[string]string{
		"auth":            "系统",
		"user":            "用户",
		"tenant-group":    "租户组",
		"tenant_group":    "租户组",
		"site":            "站点",
		"policy":          "防护策略",
		"policy-rule":     "规则",
		"policy_rule":     "规则",
		"ip-group":        "IP组",
		"ip_group":        "IP组",
		"cert":            "证书",
		"anti-tamper":     "防篡改规则",
		"anti_tamper":     "防篡改规则",
		"highlight-ip":    "高亮IP",
		"highlight_ip":    "高亮IP",
		"log-task":        "日志任务",
		"log_task":        "日志任务",
		"soc":             "SOC配置",
		"password-config": "密码策略",
		"password_config": "密码策略",
		"login-security":  "登录安全配置",
		"login_security":  "登录安全配置",
	}
	if label, ok := labels[resource]; ok {
		return label
	}
	normalized := strings.ReplaceAll(resource, "_", " ")
	normalized = strings.ReplaceAll(normalized, "-", " ")
	return strings.TrimSpace(normalized)
}

func extractAuditObjectName(detail string) string {
	if strings.TrimSpace(detail) == "" {
		return ""
	}
	var payload map[string]interface{}
	if err := json.Unmarshal([]byte(detail), &payload); err != nil {
		return ""
	}
	keys := []string{"username", "name", "domain", "title", "key", "resource_name"}
	for _, key := range keys {
		if value := strings.TrimSpace(toAuditString(payload[key])); value != "" {
			return value
		}
	}
	if id := strings.TrimSpace(toAuditString(payload["id"])); id != "" {
		return "#" + id
	}
	return ""
}

func toAuditString(v interface{}) string {
	switch t := v.(type) {
	case string:
		return t
	case float64:
		return strconv.FormatFloat(t, 'f', -1, 64)
	case int:
		return strconv.Itoa(t)
	default:
		return ""
	}
}
