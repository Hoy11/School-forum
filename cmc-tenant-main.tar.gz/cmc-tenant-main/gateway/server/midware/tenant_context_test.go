package midware

import (
	"net/http"
	"net/http/httptest"
	"testing"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupTenantTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&bindingmodel.WafBinding{}, &bindingmodel.SiteBinding{})
	database.DB = db
}

func TestTenantContextAdmin(t *testing.T) {
	setupTenantTestDB(t)
	gin.SetMode(gin.TestMode)

	r := gin.New()
	r.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		c.Next()
	})
	r.Use(TenantContext())
	r.GET("/test", func(c *gin.Context) {
		scope, _ := c.Get("data_scope")
		if scope != "all" {
			c.JSON(500, gin.H{"err": "wrong scope"})
			return
		}
		c.JSON(200, gin.H{"ok": true})
	})

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/test", nil)
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Errorf("admin should get data_scope=all, got %d", w.Code)
	}
}

func TestTenantContextTenant(t *testing.T) {
	setupTenantTestDB(t)
	tgID := uint(1)
	database.DB.Create(&bindingmodel.WafBinding{TenantGroupID: tgID, CaptainInstanceID: 10})
	database.DB.Create(&bindingmodel.SiteBinding{TenantGroupID: tgID, CaptainInstanceID: 10, SiteID: 5})

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant", TenantGroupID: &tgID})
		c.Next()
	})
	r.Use(TenantContext())
	r.GET("/test", func(c *gin.Context) {
		scope, _ := c.Get("data_scope")
		if scope != "tenant" {
			c.JSON(500, gin.H{"err": "wrong scope"})
			return
		}
		wafIDs, _ := c.Get("allowed_waf_ids")
		ids := wafIDs.([]int)
		if len(ids) != 1 || ids[0] != 10 {
			c.JSON(500, gin.H{"err": "wrong waf ids"})
			return
		}
		c.JSON(200, gin.H{"ok": true})
	})

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/test", nil)
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Errorf("tenant should get data_scope=tenant with waf ids, got %d", w.Code)
	}
}
