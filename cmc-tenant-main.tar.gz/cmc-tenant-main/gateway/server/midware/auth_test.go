package midware

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	scmodel "github.com/chaitin/cmc-tenant/domain/system_config/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	tokenmodel "github.com/chaitin/cmc-tenant/domain/api_token/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/chaitin/cmc-tenant/pkg/jwt"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupAuthTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&usermodel.User{}, &tokenmodel.APIToken{}, &scmodel.SystemConfig{})
	database.DB = db
}

func setSingleSignOn(t *testing.T, enabled bool) {
	op := scbusiness.NewSystemConfigOperator()
	cfg, _ := op.GetLoginSecurity()
	cfg.SingleSignOn = enabled
	if err := op.SetLoginSecurity(cfg); err != nil {
		t.Fatalf("set login security: %v", err)
	}
}

func authTestRouter(jwtSecret string) *gin.Engine {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(Auth(jwtSecret, 24))
	r.GET("/protected", func(c *gin.Context) {
		user, _ := c.Get("user")
		u := user.(*usermodel.User)
		c.JSON(200, gin.H{"username": u.Username})
	})
	return r
}

func createTestUser(t *testing.T, username, role string, isEnabled, isLocked bool) *usermodel.User {
	hashed, _ := bcrypt.GenerateFromPassword([]byte("pass"), bcrypt.DefaultCost)
	user := usermodel.User{
		Username:  username,
		Password:  string(hashed),
		Role:      role,
		IsEnabled: true,
		IsDeleted: false,
	}
	if err := database.DB.Create(&user).Error; err != nil {
		t.Fatalf("create test user: %v", err)
	}

	if !isEnabled {
		database.DB.Model(&user).Update("is_enabled", false)
		user.IsEnabled = false
	}
	if isLocked {
		database.DB.Model(&user).Update("is_locked", true)
		user.IsLocked = true
	}
	return &user
}

func TestAuthJWTValid(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "jwtuser", "admin", true, false)

	token, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "test-session")
	r := authTestRouter(secret)

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "token", Value: token})
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Errorf("status = %d, want 200", w.Code)
	}
}

func TestAuthJWTExpired(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "expireduser", "admin", true, false)

	token, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, -1, "test-session")
	r := authTestRouter(secret)

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "token", Value: token})
	r.ServeHTTP(w, req)

	if w.Code != 401 {
		t.Errorf("status = %d, want 401", w.Code)
	}
}

func TestAuthJWTWrongSecret(t *testing.T) {
	setupAuthTestDB(t)
	user := createTestUser(t, "wrongsec", "admin", true, false)

	token, _ := jwt.Sign("wrong-secret", user.ID, user.Username, user.Role, nil, 24, "test-session")
	r := authTestRouter("correct-secret")

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "token", Value: token})
	r.ServeHTTP(w, req)

	if w.Code != 401 {
		t.Errorf("status = %d, want 401", w.Code)
	}
}

func TestAuthAPITokenValid(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "tokenuser", "admin", true, false)

	raw := "abcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
	prefix := raw[:6]
	hashed, _ := bcrypt.GenerateFromPassword([]byte(raw), bcrypt.DefaultCost)
	database.DB.Create(&tokenmodel.APIToken{
		UserID: user.ID, Name: "test", Prefix: prefix, Value: string(hashed), IsEnabled: true,
	})

	r := authTestRouter(secret)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "API-Token", Value: raw})
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Errorf("status = %d, want 200", w.Code)
	}
}

func TestAuthAPITokenInvalid(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	createTestUser(t, "tokenuser2", "admin", true, false)

	r := authTestRouter(secret)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "API-Token", Value: "invalid-token-value-here-padding-to-6-chars"})
	r.ServeHTTP(w, req)

	if w.Code != 401 {
		t.Errorf("status = %d, want 401", w.Code)
	}
}

func TestAuthDisabledUser(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "disableduser", "admin", false, false)

	token, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "test-session")
	r := authTestRouter(secret)

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "token", Value: token})
	r.ServeHTTP(w, req)

	if w.Code != 401 {
		t.Errorf("status = %d, want 401", w.Code)
	}
}

func TestAuthLockedUser(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "lockeduser", "admin", true, true)

	token, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "test-session")
	r := authTestRouter(secret)

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "token", Value: token})
	r.ServeHTTP(w, req)

	if w.Code != 401 {
		t.Errorf("status = %d, want 401", w.Code)
	}
}

func TestAuthTokenPriorityAPITokenOverJWT(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "priorityuser", "admin", true, false)

	raw := "xyzabc1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
	prefix := raw[:6]
	hashed, _ := bcrypt.GenerateFromPassword([]byte(raw), bcrypt.DefaultCost)
	database.DB.Create(&tokenmodel.APIToken{
		UserID: user.ID, Name: "test", Prefix: prefix, Value: string(hashed), IsEnabled: true,
	})

	token, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "test-session")

	r := authTestRouter(secret)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "API-Token", Value: raw})
	req.AddCookie(&http.Cookie{Name: "token", Value: token})
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Errorf("status = %d, want 200", w.Code)
	}
}

func TestAuthExpiredAPIToken(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "expiredtokenuser", "admin", true, false)

	past := time.Now().Add(-1 * time.Hour)
	raw := "expabc1234567890abcdef1234567890abcdef1234567890abcdef1234567890"
	prefix := raw[:6]
	hashed, _ := bcrypt.GenerateFromPassword([]byte(raw), bcrypt.DefaultCost)
	database.DB.Create(&tokenmodel.APIToken{
		UserID: user.ID, Name: "expired", Prefix: prefix, Value: string(hashed),
		IsEnabled: true, ExpireTime: &past,
	})

	r := authTestRouter(secret)
	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "API-Token", Value: raw})
	r.ServeHTTP(w, req)

	if w.Code != 401 {
		t.Errorf("status = %d, want 401 for expired API token", w.Code)
	}
}

func TestAuthNoToken(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	r := authTestRouter(secret)

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	r.ServeHTTP(w, req)

	if w.Code != 401 {
		t.Errorf("status = %d, want 401", w.Code)
	}
}

func TestAuthSSOEnabledRejectsReplacedSession(t *testing.T) {
	setupAuthTestDB(t)
	rdb := connectTestRedis(t)
	oldRDB := database.RDB
	database.RDB = rdb
	defer func() { database.RDB = oldRDB }()

	secret := "test-secret"
	user := createTestUser(t, "ssouser", "admin", true, false)
	setSingleSignOn(t, true)
	defer rdb.Del(context.Background(), activeSessionKeyPrefix+fmt.Sprint(user.ID))

	oldSessionToken, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "session-old")
	newSessionToken, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "session-new")

	// 模拟在另一台设备上重新登录：把当前活跃会话标记为 session-new
	SetActiveSession(user.ID, "session-new", time.Hour)

	r := authTestRouter(secret)

	w1 := httptest.NewRecorder()
	req1, _ := http.NewRequest("GET", "/protected", nil)
	req1.AddCookie(&http.Cookie{Name: "token", Value: newSessionToken})
	r.ServeHTTP(w1, req1)
	if w1.Code != 200 {
		t.Errorf("new session status = %d, want 200", w1.Code)
	}

	w2 := httptest.NewRecorder()
	req2, _ := http.NewRequest("GET", "/protected", nil)
	req2.AddCookie(&http.Cookie{Name: "token", Value: oldSessionToken})
	r.ServeHTTP(w2, req2)
	if w2.Code != 401 {
		t.Errorf("old session status = %d, want 401, body=%s", w2.Code, w2.Body.String())
	}
}

func TestAuthSSODisabledAllowsMultipleSessions(t *testing.T) {
	setupAuthTestDB(t)
	secret := "test-secret"
	user := createTestUser(t, "multisessuser", "admin", true, false)
	setSingleSignOn(t, false)

	tokenA, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "session-a")
	tokenB, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 24, "session-b")

	r := authTestRouter(secret)

	for _, tok := range []string{tokenA, tokenB} {
		w := httptest.NewRecorder()
		req, _ := http.NewRequest("GET", "/protected", nil)
		req.AddCookie(&http.Cookie{Name: "token", Value: tok})
		r.ServeHTTP(w, req)
		if w.Code != 200 {
			t.Errorf("status = %d, want 200 when SSO disabled", w.Code)
		}
	}
}

func TestAuthAutoRefreshPreservesSessionIDAndExtendsActiveSession(t *testing.T) {
	setupAuthTestDB(t)
	rdb := connectTestRedis(t)
	oldRDB := database.RDB
	database.RDB = rdb
	defer func() { database.RDB = oldRDB }()

	secret := "test-secret"
	user := createTestUser(t, "refreshuser", "admin", true, false)
	setSingleSignOn(t, true)

	sessionID := "session-refresh"
	defer rdb.Del(context.Background(), activeSessionKeyPrefix+fmt.Sprint(user.ID))
	SetActiveSession(user.ID, sessionID, time.Minute)

	// 用很短的过期时间签发 token，配合下面 expireHours=24 的中间件，触发自动续期路径
	token, _ := jwt.Sign(secret, user.ID, user.Username, user.Role, nil, 1, sessionID)

	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(Auth(secret, 24))
	r.GET("/protected", func(c *gin.Context) {
		c.JSON(200, gin.H{"ok": true})
	})

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/protected", nil)
	req.AddCookie(&http.Cookie{Name: "token", Value: token})
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Fatalf("status = %d, want 200, body=%s", w.Code, w.Body.String())
	}

	var newToken string
	for _, c := range w.Result().Cookies() {
		if c.Name == "token" {
			newToken = c.Value
		}
	}
	if newToken == "" {
		t.Fatal("expected refreshed token cookie to be set")
	}
	newClaims, err := jwt.Parse(secret, newToken)
	if err != nil {
		t.Fatalf("parse refreshed token: %v", err)
	}
	if newClaims.ID != sessionID {
		t.Errorf("refreshed token sessionID = %q, want %q (must keep same session, not generate a new one)", newClaims.ID, sessionID)
	}

	ttl, err := rdb.TTL(context.Background(), activeSessionKeyPrefix+fmt.Sprint(user.ID)).Result()
	if err != nil {
		t.Fatalf("get ttl: %v", err)
	}
	if ttl < 23*time.Hour {
		t.Errorf("active session TTL = %v, want close to 24h (should be refreshed alongside the token)", ttl)
	}
}
