package midware

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/redis/go-redis/v9"
)

func connectTestRedis(t *testing.T) *redis.Client {
	addr := os.Getenv("REDIS_ADDR")
	if addr == "" {
		addr = "localhost:6379"
	}
	rdb := redis.NewClient(&redis.Options{Addr: addr})
	if err := rdb.Ping(context.Background()).Err(); err != nil {
		t.Skip("redis not available: " + err.Error())
	}
	return rdb
}

func TestClearLoginLockRemovesLockAndFailCounter(t *testing.T) {
	rdb := connectTestRedis(t)
	oldRDB := database.RDB
	database.RDB = rdb
	defer func() { database.RDB = oldRDB }()

	ctx := context.Background()
	username := "test_clear_login_lock_user"
	lockKey := loginLockKeyPrefix + username
	failKey := loginFailKeyPrefix + username
	defer rdb.Del(ctx, lockKey, failKey)

	rdb.Set(ctx, lockKey, "1", 0)
	rdb.Set(ctx, failKey, "5", 0)

	ClearLoginLock(username)

	if IsLoginLocked(username) {
		t.Error("expected login lock to be cleared")
	}
	if val, _ := rdb.Get(ctx, failKey).Result(); val != "" {
		t.Errorf("expected fail counter to be cleared, got %q", val)
	}
}

func TestSetActiveSessionAndIsActiveSession(t *testing.T) {
	rdb := connectTestRedis(t)
	oldRDB := database.RDB
	database.RDB = rdb
	defer func() { database.RDB = oldRDB }()

	const userID = uint(123456)
	defer rdb.Del(context.Background(), activeSessionKeyPrefix+"123456")

	SetActiveSession(userID, "session-a", time.Minute)

	if !IsActiveSession(userID, "session-a") {
		t.Error("expected session-a to be the active session")
	}
	if IsActiveSession(userID, "session-b") {
		t.Error("expected session-b to not be the active session")
	}
}

func TestIsActiveSessionFailsOpenWhenNoRecord(t *testing.T) {
	rdb := connectTestRedis(t)
	oldRDB := database.RDB
	database.RDB = rdb
	defer func() { database.RDB = oldRDB }()

	if !IsActiveSession(uint(999999), "anything") {
		t.Error("expected fail-open (true) when no active session record exists")
	}
}
