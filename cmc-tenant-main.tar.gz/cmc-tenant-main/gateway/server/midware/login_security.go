package midware

import (
	"context"
	"fmt"
	"time"

	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	"github.com/chaitin/cmc-tenant/pkg/database"
)

const loginFailKeyPrefix = "login_fail:"
const loginLockKeyPrefix = "login_lock:"
const activeSessionKeyPrefix = "session:active:"

// RecordLoginFail increments the login failure counter and locks the account if threshold is reached.
func RecordLoginFail(username string, cfg *scbusiness.LoginSecurityConfig) {
	if database.RDB == nil {
		return
	}
	ctx := context.Background()
	failKey := loginFailKeyPrefix + username
	lockKey := loginLockKeyPrefix + username

	count, _ := database.RDB.Incr(ctx, failKey).Result()
	database.RDB.Expire(ctx, failKey, time.Duration(cfg.RetryWindowSec)*time.Second)

	if count >= int64(cfg.MaxRetry) {
		database.RDB.Set(ctx, lockKey, "1", time.Duration(cfg.LockMinutes)*time.Minute)
	}
}

// IsLoginLocked checks if the account is temporarily locked due to too many failed attempts.
func IsLoginLocked(username string) bool {
	if database.RDB == nil {
		return false
	}
	ctx := context.Background()
	lockKey := loginLockKeyPrefix + username
	val, _ := database.RDB.Get(ctx, lockKey).Result()
	return val != ""
}

// ClearLoginFail removes the login failure counter for the given username.
func ClearLoginFail(username string) {
	if database.RDB == nil {
		return
	}
	ctx := context.Background()
	failKey := loginFailKeyPrefix + username
	database.RDB.Del(ctx, failKey)
}

// ClearLoginLock removes the login lock and failure counter for the given username.
// 解锁同时清失败计数器，避免解锁后用户再失败一次就立刻又被锁。
func ClearLoginLock(username string) {
	if database.RDB == nil {
		return
	}
	ctx := context.Background()
	database.RDB.Del(ctx, loginLockKeyPrefix+username)
	database.RDB.Del(ctx, loginFailKeyPrefix+username)
}

// SetActiveSession records the given session ID as the user's currently active session
// for single sign-on enforcement.
func SetActiveSession(userID uint, sessionID string, ttl time.Duration) {
	if database.RDB == nil {
		return
	}
	database.RDB.Set(context.Background(), activeSessionKeyPrefix+fmt.Sprint(userID), sessionID, ttl)
}

// IsActiveSession reports whether sessionID is still the user's currently active session.
// Fail-open (returns true) when Redis is unavailable or no record exists, consistent with
// IsLoginLocked's degrade behavior — SSO is a UX feature, not a security boundary.
func IsActiveSession(userID uint, sessionID string) bool {
	if database.RDB == nil {
		return true
	}
	val, err := database.RDB.Get(context.Background(), activeSessionKeyPrefix+fmt.Sprint(userID)).Result()
	if err != nil {
		return true
	}
	return val == sessionID
}

// GetLockRemaining returns the remaining lock time in seconds for the given username.
func GetLockRemaining(username string, _ int) int {
	if database.RDB == nil {
		return 0
	}
	ctx := context.Background()
	lockKey := loginLockKeyPrefix + username
	ttl, _ := database.RDB.TTL(ctx, lockKey).Result()
	if ttl <= 0 {
		return 0
	}
	return int(ttl.Seconds())
}
