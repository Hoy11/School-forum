package midware

import (
	"net/http"
	"net/http/httptest"
	"testing"

	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/gin-gonic/gin"
)

func TestPermissionAdmin(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "admin"})
		c.Next()
	})
	r.Use(Permission())
	r.POST("/api/tenant-group/create", func(c *gin.Context) {
		c.JSON(200, gin.H{"ok": true})
	})

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("POST", "/api/tenant-group/create", nil)
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Errorf("admin should access tenant-group, got %d", w.Code)
	}
}

func TestPermissionTenantDenied(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant"})
		c.Next()
	})
	r.Use(Permission())
	r.POST("/api/tenant-group/create", func(c *gin.Context) {
		c.JSON(200, gin.H{"ok": true})
	})

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("POST", "/api/tenant-group/create", nil)
	r.ServeHTTP(w, req)

	if w.Code != 403 {
		t.Errorf("tenant should be denied tenant-group, got %d", w.Code)
	}
}

func TestPermissionTenantAdminGroupUser(t *testing.T) {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(func(c *gin.Context) {
		c.Set("user", &usermodel.User{Role: "tenant_admin"})
		c.Next()
	})
	r.Use(Permission())
	r.POST("/api/tenant/user/create", func(c *gin.Context) {
		c.JSON(200, gin.H{"ok": true})
	})

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("POST", "/api/tenant/user/create", nil)
	r.ServeHTTP(w, req)

	if w.Code != 200 {
		t.Errorf("tenant_admin should access tenant/user, got %d", w.Code)
	}
}

func TestPermissionCaptainAllRoles(t *testing.T) {
	roles := []string{"admin", "tenant_admin", "tenant"}
	for _, role := range roles {
		gin.SetMode(gin.TestMode)
		r := gin.New()
		r.Use(func(c *gin.Context) {
			c.Set("user", &usermodel.User{Role: role})
			c.Next()
		})
		r.Use(Permission())
		r.GET("/api/captain/site/list", func(c *gin.Context) {
			c.JSON(200, gin.H{"ok": true})
		})

		w := httptest.NewRecorder()
		req, _ := http.NewRequest("GET", "/api/captain/site/list", nil)
		r.ServeHTTP(w, req)

		if w.Code != 200 {
			t.Errorf("role %s should access captain, got %d", role, w.Code)
		}
	}
}
