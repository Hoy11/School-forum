package midware

import (
	"net/http"
	"sort"
	"strings"

	"github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/gin-gonic/gin"
)

type permRule struct {
	prefix string
	roles  []string
}

var permissionRules = []permRule{
	{"/api/user/api_token/", []string{"admin", "tenant_admin", "tenant"}},
	{"/api/user/current/", []string{"admin", "tenant_admin", "tenant"}},
	{"/api/user/", []string{"admin"}},
	{"/api/tenant/user/", []string{"admin", "tenant_admin"}},
	{"/api/tenant-group/", []string{"admin"}},
	{"/api/binding/waf/list", []string{"admin", "tenant_admin", "tenant"}},
	{"/api/binding/site/list", []string{"admin", "tenant_admin", "tenant"}},
	{"/api/binding/", []string{"admin"}},
	{"/api/system/", []string{"admin"}},
	{"/api/captain/filter/", []string{"admin", "tenant_admin", "tenant"}},
	{"/api/captain/", []string{"admin", "tenant_admin", "tenant"}},
	{"/api/highlight-ip/", []string{"admin", "tenant_admin", "tenant"}},
	{"/api/soc/", []string{"admin", "tenant_admin", "tenant"}},
}

func init() {
	sort.Slice(permissionRules, func(i, j int) bool {
		return len(permissionRules[i].prefix) > len(permissionRules[j].prefix)
	})
}

// Permission checks if the authenticated user's role is allowed for the request path.
func Permission() gin.HandlerFunc {
	return func(c *gin.Context) {
		user, exists := c.Get("user")
		if !exists {
			c.Next()
			return
		}

		u := user.(*model.User)
		path := c.Request.URL.Path

		roles := matchPermission(path)
		if roles == nil {
			c.Next()
			return
		}

		for _, role := range roles {
			if u.Role == role {
				c.Next()
				return
			}
		}

		c.AbortWithStatusJSON(http.StatusForbidden, gin.H{
			"err": "forbidden", "msg": "无权访问", "data": "",
		})
	}
}

func matchPermission(path string) []string {
	for _, rule := range permissionRules {
		if strings.HasPrefix(path, rule.prefix) {
			return rule.roles
		}
	}
	return nil
}
