package midware

import (
	"bytes"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	auditmodel "github.com/chaitin/cmc-tenant/domain/audit_log/model"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/gin-gonic/gin"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

func setupAuditTestDB(t *testing.T) {
	db, err := gorm.Open(sqlite.Open("file::memory:"), &gorm.Config{})
	if err != nil {
		t.Fatalf("open sqlite: %v", err)
	}
	_ = db.AutoMigrate(&auditmodel.AuditLog{})
	database.DB = db
}

func auditTestRouter() *gin.Engine {
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(Audit())

	user := &usermodel.User{ID: 1, Username: "tester", Role: "admin"}

	r.POST("/api/user/create", func(c *gin.Context) {
		c.Set("user", user)
		c.JSON(200, gin.H{})
	})
	r.POST("/api/user/list", func(c *gin.Context) {
		c.Set("user", user)
		c.JSON(200, gin.H{})
	})
	r.GET("/api/user/list", func(c *gin.Context) {
		c.Set("user", user)
		c.JSON(200, gin.H{})
	})
	r.PUT("/api/user/update", func(c *gin.Context) {
		c.Set("user", user)
		c.JSON(200, gin.H{})
	})
	r.DELETE("/api/user/delete", func(c *gin.Context) {
		c.Set("user", user)
		c.JSON(200, gin.H{})
	})
	r.POST("/api/auth/login", func(c *gin.Context) {
		c.Set("user", user)
		c.JSON(200, gin.H{})
	})
	return r
}

func waitForAuditLog() {
	time.Sleep(50 * time.Millisecond)
}

func TestAuditWriteOperation(t *testing.T) {
	setupAuditTestDB(t)
	r := auditTestRouter()

	w := httptest.NewRecorder()
	body := bytes.NewBufferString(`{"username":"test"}`)
	req, _ := http.NewRequest("POST", "/api/user/create", body)
	r.ServeHTTP(w, req)

	waitForAuditLog()

	var count int64
	database.DB.Model(&auditmodel.AuditLog{}).Count(&count)
	if count != 1 {
		t.Errorf("audit log count = %d, want 1", count)
	}

	var log auditmodel.AuditLog
	database.DB.First(&log)
	if log.Action != "CREATE" {
		t.Errorf("action = %s, want CREATE", log.Action)
	}
	if log.Username != "tester" {
		t.Errorf("username = %s, want tester", log.Username)
	}
	if log.Result != "success" {
		t.Errorf("result = %s, want success", log.Result)
	}
	if log.Summary != "创建用户 test" {
		t.Errorf("summary = %s, want 创建用户 test", log.Summary)
	}
}

func TestAuditSkipListEndpoint(t *testing.T) {
	setupAuditTestDB(t)
	r := auditTestRouter()

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("POST", "/api/user/list", bytes.NewBufferString(`{}`))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	waitForAuditLog()

	var count int64
	database.DB.Model(&auditmodel.AuditLog{}).Count(&count)
	if count != 0 {
		t.Errorf("audit log count = %d, want 0 for list endpoint", count)
	}
}

func TestAuditSkipGetRequest(t *testing.T) {
	setupAuditTestDB(t)
	r := auditTestRouter()

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("GET", "/api/user/list", nil)
	r.ServeHTTP(w, req)

	waitForAuditLog()

	var count int64
	database.DB.Model(&auditmodel.AuditLog{}).Count(&count)
	if count != 0 {
		t.Errorf("audit log count = %d, want 0 for GET", count)
	}
}

func TestAuditDeleteAction(t *testing.T) {
	setupAuditTestDB(t)
	r := auditTestRouter()

	w := httptest.NewRecorder()
	body := bytes.NewBufferString(`{"ids":[1]}`)
	req, _ := http.NewRequest("DELETE", "/api/user/delete", body)
	r.ServeHTTP(w, req)

	waitForAuditLog()

	var log auditmodel.AuditLog
	database.DB.First(&log)
	if log.Action != "DELETE" {
		t.Errorf("action = %s, want DELETE", log.Action)
	}
}

func TestAuditUpdateAction(t *testing.T) {
	setupAuditTestDB(t)
	r := auditTestRouter()

	w := httptest.NewRecorder()
	body := bytes.NewBufferString(`{"id":1}`)
	req, _ := http.NewRequest("PUT", "/api/user/update", body)
	r.ServeHTTP(w, req)

	waitForAuditLog()

	var log auditmodel.AuditLog
	database.DB.First(&log)
	if log.Action != "UPDATE" {
		t.Errorf("action = %s, want UPDATE", log.Action)
	}
}

func TestAuditLoginAction(t *testing.T) {
	setupAuditTestDB(t)
	r := auditTestRouter()

	w := httptest.NewRecorder()
	body := bytes.NewBufferString(`{"username":"admin"}`)
	req, _ := http.NewRequest("POST", "/api/auth/login", body)
	r.ServeHTTP(w, req)

	waitForAuditLog()

	var log auditmodel.AuditLog
	database.DB.First(&log)
	if log.Action != "LOGIN" {
		t.Errorf("action = %s, want LOGIN", log.Action)
	}
}

func TestAuditFailedOperation(t *testing.T) {
	setupAuditTestDB(t)
	gin.SetMode(gin.TestMode)
	r := gin.New()
	r.Use(Audit())

	user := &usermodel.User{ID: 1, Username: "tester", Role: "admin"}
	r.PUT("/api/user/update", func(c *gin.Context) {
		c.Set("user", user)
		c.JSON(http.StatusForbidden, gin.H{"err": "error", "msg": "权限不足", "data": ""})
	})

	w := httptest.NewRecorder()
	req, _ := http.NewRequest("PUT", "/api/user/update", bytes.NewBufferString(`{"id":1}`))
	r.ServeHTTP(w, req)

	waitForAuditLog()

	var log auditmodel.AuditLog
	database.DB.First(&log)
	if log.Result != "failed" {
		t.Errorf("result = %s, want failed", log.Result)
	}
	if log.ErrorMessage != "权限不足" {
		t.Errorf("error_message = %s, want 权限不足", log.ErrorMessage)
	}
	if log.Summary != "修改用户 #1" {
		t.Errorf("summary = %s, want 修改用户 #1", log.Summary)
	}
}
