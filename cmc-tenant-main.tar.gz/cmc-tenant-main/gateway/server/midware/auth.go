package midware

import (
	"net/http"
	"time"

	scbusiness "github.com/chaitin/cmc-tenant/domain/system_config/business"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"github.com/chaitin/cmc-tenant/pkg/jwt"
	usermodel "github.com/chaitin/cmc-tenant/domain/user/model"
	tokenmodel "github.com/chaitin/cmc-tenant/domain/api_token/model"
	"github.com/gin-gonic/gin"
	"golang.org/x/crypto/bcrypt"
)

var timeNow = time.Now

var authWhitelist = map[string]bool{
	"/api/auth/login": true,
}

// Auth validates JWT or API-Token cookies and sets the user in context.
func Auth(jwtSecret string, expireHours int) gin.HandlerFunc {
	return func(c *gin.Context) {
		if authWhitelist[c.Request.URL.Path] {
			c.Next()
			return
		}

		var user *usermodel.User

		// Try API Token first (Cookie, same as Captain-2)
		if apiToken, err := c.Cookie("API-Token"); err == nil && apiToken != "" {
			user = authByAPIToken(apiToken)
			if user == nil {
				c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
					"err": "unauthorized", "msg": "API Token 无效或已过期", "data": "",
				})
				return
			}
		} else if tokenStr, err := c.Cookie("token"); err == nil && tokenStr != "" {
			// Try JWT Cookie
			user = authByJWT(jwtSecret, tokenStr)
			if user == nil {
				c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
					"err": "unauthorized", "msg": "登录已过期，请重新登录", "data": "",
				})
				return
			}
			claims, _ := jwt.Parse(jwtSecret, tokenStr)

			loginSec, _ := scbusiness.NewSystemConfigOperator().GetLoginSecurity()
			if claims != nil && loginSec.SingleSignOn && !IsActiveSession(user.ID, claims.ID) {
				c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
					"err": "session_replaced", "msg": "账号已在其他设备登录，请重新登录", "data": "",
				})
				return
			}

			// Auto-refresh if near expiry
			if claims != nil && jwt.ShouldRefresh(claims, expireHours) {
				newToken, _ := jwt.Sign(jwtSecret, claims.UserID, claims.Username, claims.Role, claims.TenantGroupID, expireHours, claims.ID)
				c.SetCookie("token", newToken, expireHours*3600, "/", "", false, true)
				if loginSec.SingleSignOn {
					SetActiveSession(claims.UserID, claims.ID, time.Duration(expireHours)*time.Hour)
				}
			}
		} else {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"err": "unauthorized", "msg": "未登录", "data": "",
			})
			return
		}

		if !user.IsEnabled {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"err": "unauthorized", "msg": "用户已禁用", "data": "",
			})
			return
		}
		if user.IsLocked {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{
				"err": "unauthorized", "msg": "用户已锁定", "data": "",
			})
			return
		}

		c.Set("user", user)
		c.Next()
	}
}

func authByJWT(secret, tokenStr string) *usermodel.User {
	claims, err := jwt.Parse(secret, tokenStr)
	if err != nil {
		return nil
	}
	var user usermodel.User
	if err := database.DB.Where("id = ? AND is_deleted = false", claims.UserID).First(&user).Error; err != nil {
		return nil
	}
	return &user
}

func authByAPIToken(rawToken string) *usermodel.User {
	if len(rawToken) < 6 {
		return nil
	}
	prefix := rawToken[:6]

	var tokens []tokenmodel.APIToken
	database.DB.Where("prefix = ? AND is_enabled = true", prefix).Find(&tokens)

	for _, t := range tokens {
		if t.ExpireTime != nil && t.ExpireTime.Before(timeNow()) {
			continue
		}
		if bcrypt.CompareHashAndPassword([]byte(t.Value), []byte(rawToken)) == nil {
			var user usermodel.User
			if err := database.DB.Where("id = ? AND is_deleted = false", t.UserID).First(&user).Error; err != nil {
				return nil
			}
			return &user
		}
	}
	return nil
}
