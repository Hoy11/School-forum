// Command cleanup-dirty-bindings removes invalid local binding rows left by test data.
package main

import (
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"log"
	"os"
	"sort"
	"strings"

	"github.com/chaitin/cmc-tenant/config"
	bindingmodel "github.com/chaitin/cmc-tenant/domain/binding/model"
	systemmodel "github.com/chaitin/cmc-tenant/domain/system_config/model"
	"github.com/chaitin/cmc-tenant/pkg/captain"
	"github.com/chaitin/cmc-tenant/pkg/database"
	"gorm.io/gorm"
)

type mappingTable struct {
	Name string
	Col  string
}

var mappingTables = []mappingTable{
	{Name: "captain_policy_bindings", Col: "policy_id"},
	{Name: "captain_cert_bindings", Col: "cert_id"},
	{Name: "captain_ip_group_bindings", Col: "ip_group_id"},
	{Name: "captain_policy_rule_bindings", Col: "rule_id"},
	{Name: "captain_block_page_bindings", Col: "block_page_id"},
}

const (
	siteModeSoftwareReverseProxy        = "Software Reverse Proxy"
	siteModeHardwareReverseProxy        = "Hardware Reverse Proxy"
	siteModeHardwareTransparentProxy    = "Hardware Transparent Proxy"
	siteModeHardwareTransparentBridge   = "Hardware Transparent Bridging"
	siteModeHardwarePortMirroring       = "Hardware Port Mirroring"
	siteModeSoftwareClusterReverseProxy = "Software Cluster Reverse Proxy"
	siteModeSoftwarePortMirroring       = "Software Port Mirroring"
	siteModeHardwareRouterProxy         = "Hardware Router Proxy"

	sitePathSoftwareReverseProxy        = "/api/SoftwareReverseProxyWebsiteAPI"
	sitePathHardwareReverseProxy        = "/api/WReverseProxyWebsiteAPI"
	sitePathHardwareTransparentProxy    = "/api/HardwareTransparentProxyWebsiteAPI"
	sitePathHardwareTransparentBridge   = "/api/HardwareTransparentBridgingWebsiteAPI"
	sitePathHardwarePortMirroring       = "/api/HardwarePortMirroringWebsiteAPI"
	sitePathSoftwareClusterReverseProxy = "/api/SoftwareClusterReverseProxyWebsiteAPI"
	sitePathSoftwarePortMirroring       = "/api/SoftwarePortMirroringWebsiteAPI"
)

type dirtySiteBinding struct {
	Binding bindingmodel.SiteBinding
	Reasons []string
}

type pair struct {
	TenantGroupID     uint
	CaptainInstanceID int
}

type resourceSets map[string]map[int]struct{}

func main() {
	envDefault := os.Getenv("APP_ENV")
	if envDefault == "" {
		envDefault = "development"
	}

	env := flag.String("env", envDefault, "config environment name")
	execute := flag.Bool("execute", false, "actually delete dirty rows; default is dry-run")
	instanceID := flag.Int("instance", 0, "only scan one captain_instance_id")
	siteID := flag.Int("site", 0, "only scan one site_id")
	printLimit := flag.Int("print-limit", 100, "maximum dirty site binding rows to print")
	flag.Parse()

	cfg := config.Load(*env)
	if err := database.InitPG(&cfg.PG); err != nil {
		log.Fatalf("init postgres: %v", err)
	}
	if err := ensureSourceColumns(); err != nil {
		log.Fatalf("ensure source columns: %v", err)
	}

	client, host, err := newCaptainClient(cfg)
	if err != nil {
		log.Fatalf("init captain client: %v", err)
	}
	fmt.Printf("captain host: %s\n", host)
	if !*execute {
		fmt.Println("mode: dry-run (no database rows will be deleted)")
	} else {
		fmt.Println("mode: execute (dirty rows will be deleted)")
	}

	bindings, err := loadSiteBindings(*instanceID, *siteID)
	if err != nil {
		log.Fatalf("load site_bindings: %v", err)
	}
	fmt.Printf("site_bindings scanned: %d\n", len(bindings))

	sitePaths := newSitePathCache()
	dirty, affected, scanErrors := findDirtySiteBindings(client, sitePaths, bindings)
	for _, err := range scanErrors {
		fmt.Printf("[SKIP] %v\n", err)
	}

	fmt.Printf("dirty site_bindings found: %d\n", len(dirty))
	for i, row := range dirty {
		if i >= *printLimit {
			fmt.Printf("... %d more dirty rows omitted by --print-limit\n", len(dirty)-*printLimit)
			break
		}
		b := row.Binding
		fmt.Printf(
			"dirty site_binding id=%d tenant_group_id=%d captain_instance_id=%d site_id=%d reason=%s\n",
			b.ID, b.TenantGroupID, b.CaptainInstanceID, b.SiteID, strings.Join(row.Reasons, ","),
		)
	}

	if err := cleanup(dirty, affected, client, sitePaths, *execute); err != nil {
		log.Fatalf("cleanup failed: %v", err)
	}

	if !*execute {
		fmt.Println("dry-run done. Re-run with --execute to apply cleanup.")
		return
	}
	fmt.Println("cleanup done.")
}

func loadSiteBindings(instanceID int, siteID int) ([]bindingmodel.SiteBinding, error) {
	var bindings []bindingmodel.SiteBinding
	q := database.DB.Model(&bindingmodel.SiteBinding{}).Order("captain_instance_id ASC, site_id ASC, tenant_group_id ASC")
	if instanceID > 0 {
		q = q.Where("captain_instance_id = ?", instanceID)
	}
	if siteID > 0 {
		q = q.Where("site_id = ?", siteID)
	}
	return bindings, q.Find(&bindings).Error
}

func newCaptainClient(cfg *config.Config) (*captain.CaptainClient, string, error) {
	host := cfg.Captain.Host
	apiToken := cfg.Captain.APIToken

	if host == "" || apiToken == "" {
		var cc systemmodel.CaptainConfig
		err := database.DB.Where("is_default = ?", true).First(&cc).Error
		if err != nil && !errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, "", err
		}
		if cc.ID != 0 {
			if host == "" {
				host = cc.Host
			}
			if apiToken == "" {
				apiToken = cc.APIToken
			}
		}
	}

	if host == "" || apiToken == "" {
		return nil, "", fmt.Errorf("captain host/api token not found in config/env or captain_configs")
	}

	return captain.NewCaptainClient(host, apiToken, cfg.Captain.RequestTimeoutSec, cfg.Captain.RetryCount), host, nil
}

func findDirtySiteBindings(client *captain.CaptainClient, sitePaths *sitePathCache, bindings []bindingmodel.SiteBinding) ([]dirtySiteBinding, map[pair]struct{}, []error) {
	var dirty []dirtySiteBinding
	var scanErrors []error
	affected := make(map[pair]struct{})
	existenceCache := make(map[string]siteExistence)

	for _, b := range bindings {
		var reasons []string
		if !tenantGroupExists(b.TenantGroupID) {
			reasons = append(reasons, "tenant_group_not_found")
		}
		if !wafBindingExists(b.TenantGroupID, b.CaptainInstanceID) {
			reasons = append(reasons, "waf_binding_not_found")
		}

		if len(reasons) == 0 {
			cacheKey := fmt.Sprintf("%d/%d", b.CaptainInstanceID, b.SiteID)
			existence, ok := existenceCache[cacheKey]
			if !ok {
				existence = checkSiteExists(client, sitePaths, b.CaptainInstanceID, b.SiteID)
				existenceCache[cacheKey] = existence
			}
			if existence.Err != nil {
				if errors.Is(existence.Err, errCaptainInstanceNotFound) {
					reasons = append(reasons, "captain_instance_not_found")
				} else {
					scanErrors = append(scanErrors, fmt.Errorf("site_binding id=%d instance=%d site=%d: %w", b.ID, b.CaptainInstanceID, b.SiteID, existence.Err))
					continue
				}
			}
			if !existence.Exists {
				reasons = append(reasons, "captain_site_not_found")
			}
		}

		if len(reasons) > 0 {
			dirty = append(dirty, dirtySiteBinding{Binding: b, Reasons: reasons})
			affected[pair{TenantGroupID: b.TenantGroupID, CaptainInstanceID: b.CaptainInstanceID}] = struct{}{}
		}
	}

	return dirty, affected, scanErrors
}

type siteExistence struct {
	Exists bool
	Err    error
}

func checkSiteExists(client *captain.CaptainClient, sitePaths *sitePathCache, instanceID int, siteID int) siteExistence {
	detail, err := fetchSiteDetail(client, sitePaths, instanceID, siteID)
	if err != nil {
		if errors.Is(err, errCaptainObjectNotFound) {
			return siteExistence{Exists: false}
		}
		return siteExistence{Err: err}
	}
	return siteExistence{Exists: len(detail) > 0}
}

var (
	errCaptainObjectNotFound   = errors.New("captain object not found")
	errCaptainInstanceNotFound = errors.New("captain instance not found")
)

type sitePathCache struct {
	loaded    bool
	instances map[int]bool
	paths     map[int]string
}

func newSitePathCache() *sitePathCache {
	return &sitePathCache{
		instances: make(map[int]bool),
		paths:     make(map[int]string),
	}
}

func (c *sitePathCache) resolve(client *captain.CaptainClient, instanceID int) (string, error) {
	if !c.loaded {
		if err := c.load(client); err != nil {
			return "", err
		}
	}
	path := c.paths[instanceID]
	if path == "" {
		if !c.instances[instanceID] {
			return "", fmt.Errorf("%w: captain_instance_id=%d", errCaptainInstanceNotFound, instanceID)
		}
		return "", fmt.Errorf("site api path not found for captain_instance_id=%d", instanceID)
	}
	return path, nil
}

func (c *sitePathCache) load(client *captain.CaptainClient) error {
	resp, err := client.Do(&captain.CaptainRequest{Method: "GET", Path: "/api/group/detail"})
	if err != nil {
		return fmt.Errorf("fetch captain group detail: %w", err)
	}

	var wrapper struct {
		Data struct {
			WafList []map[string]interface{} `json:"waf_list"`
		} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return fmt.Errorf("parse captain group detail: %w", err)
	}

	for _, inst := range wrapper.Data.WafList {
		id := getIDFromItem(inst)
		if id <= 0 {
			continue
		}
		c.instances[id] = true
		path, ok := sitePathForMode(getFieldString(inst, "mode", "Mode"))
		if !ok {
			continue
		}
		c.paths[id] = path
	}
	c.loaded = true
	return nil
}

func sitePathForMode(mode string) (string, bool) {
	switch mode {
	case siteModeSoftwareReverseProxy:
		return sitePathSoftwareReverseProxy, true
	case siteModeHardwareReverseProxy, siteModeHardwareRouterProxy:
		return sitePathHardwareReverseProxy, true
	case siteModeHardwareTransparentProxy:
		return sitePathHardwareTransparentProxy, true
	case siteModeHardwareTransparentBridge:
		return sitePathHardwareTransparentBridge, true
	case siteModeHardwarePortMirroring:
		return sitePathHardwarePortMirroring, true
	case siteModeSoftwareClusterReverseProxy:
		return sitePathSoftwareClusterReverseProxy, true
	case siteModeSoftwarePortMirroring:
		return sitePathSoftwarePortMirroring, true
	default:
		return "", false
	}
}

func fetchSiteDetail(client *captain.CaptainClient, sitePaths *sitePathCache, instanceID int, siteID int) (map[string]interface{}, error) {
	sitePath, err := sitePaths.resolve(client, instanceID)
	if err != nil {
		return nil, err
	}

	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("%s?id=%d", sitePath, siteID),
		InstanceID: &idUint,
	})
	if err != nil {
		return nil, err
	}
	if resp.StatusCode == 404 {
		return nil, errCaptainObjectNotFound
	}

	var wrapper struct {
		Err  string          `json:"err"`
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil, fmt.Errorf("parse site detail: %w", err)
	}
	if wrapper.Err == "object-not-found" {
		return nil, errCaptainObjectNotFound
	}
	if len(wrapper.Data) == 0 || string(wrapper.Data) == "null" {
		return nil, fmt.Errorf("site detail empty data, status=%d body=%s", resp.StatusCode, string(resp.Body))
	}

	var detail map[string]interface{}
	if err := json.Unmarshal(wrapper.Data, &detail); err != nil {
		return nil, fmt.Errorf("site detail unexpected format: %w", err)
	}
	return detail, nil
}

func cleanup(dirty []dirtySiteBinding, affected map[pair]struct{}, client *captain.CaptainClient, sitePaths *sitePathCache, execute bool) error {
	tx := database.DB.Begin()
	if tx.Error != nil {
		return tx.Error
	}
	defer func() {
		if r := recover(); r != nil {
			tx.Rollback()
			panic(r)
		}
	}()

	dirtyIDs := dirtySiteBindingIDs(dirty)
	if len(dirtyIDs) > 0 {
		fmt.Printf("site_bindings to delete: %d\n", len(dirtyIDs))
		if execute {
			if err := tx.Where("id IN ?", dirtyIDs).Delete(&bindingmodel.SiteBinding{}).Error; err != nil {
				tx.Rollback()
				return err
			}
		}
	}

	if err := cleanupInvalidMappings(tx, execute); err != nil {
		tx.Rollback()
		return err
	}
	if err := cleanupInvalidLogTasks(tx, execute); err != nil {
		tx.Rollback()
		return err
	}
	if err := reconcileAffectedInheritedMappings(tx, affected, dirtyIDs, client, sitePaths, execute); err != nil {
		tx.Rollback()
		return err
	}

	if !execute {
		return tx.Rollback().Error
	}
	return tx.Commit().Error
}

func dirtySiteBindingIDs(dirty []dirtySiteBinding) []uint {
	ids := make([]uint, 0, len(dirty))
	for _, row := range dirty {
		ids = append(ids, row.Binding.ID)
	}
	return ids
}

func cleanupInvalidMappings(tx *gorm.DB, execute bool) error {
	for _, table := range mappingTables {
		var count int64
		countSQL := fmt.Sprintf(`
			SELECT COUNT(*)
			FROM %s b
			WHERE NOT EXISTS (SELECT 1 FROM tenant_groups tg WHERE tg.id = b.tenant_group_id)
			   OR NOT EXISTS (
				 SELECT 1 FROM waf_bindings wb
				 WHERE wb.tenant_group_id = b.tenant_group_id
				   AND wb.captain_instance_id = b.captain_instance_id
			   )`, table.Name)
		if err := tx.Raw(countSQL).Scan(&count).Error; err != nil {
			return err
		}
		fmt.Printf("%s invalid owner/waf mappings to delete: %d\n", table.Name, count)
		if execute && count > 0 {
			deleteSQL := fmt.Sprintf(`
				DELETE FROM %s b
				WHERE NOT EXISTS (SELECT 1 FROM tenant_groups tg WHERE tg.id = b.tenant_group_id)
				   OR NOT EXISTS (
					 SELECT 1 FROM waf_bindings wb
					 WHERE wb.tenant_group_id = b.tenant_group_id
					   AND wb.captain_instance_id = b.captain_instance_id
				   )`, table.Name)
			if err := tx.Exec(deleteSQL).Error; err != nil {
				return err
			}
		}
	}
	return nil
}

func cleanupInvalidLogTasks(tx *gorm.DB, execute bool) error {
	var count int64
	err := tx.Raw(`
		SELECT COUNT(*)
		FROM captain_log_tasks t
		WHERE t.tenant_group_id IS NOT NULL
		  AND NOT EXISTS (SELECT 1 FROM tenant_groups tg WHERE tg.id = t.tenant_group_id)`,
	).Scan(&count).Error
	if err != nil {
		return err
	}
	fmt.Printf("captain_log_tasks with missing tenant_group to delete: %d\n", count)
	if execute && count > 0 {
		return tx.Exec(`
			DELETE FROM captain_log_tasks t
			WHERE t.tenant_group_id IS NOT NULL
			  AND NOT EXISTS (SELECT 1 FROM tenant_groups tg WHERE tg.id = t.tenant_group_id)`,
		).Error
	}
	return nil
}

func reconcileAffectedInheritedMappings(tx *gorm.DB, affected map[pair]struct{}, excludeSiteBindingIDs []uint, client *captain.CaptainClient, sitePaths *sitePathCache, execute bool) error {
	pairs := sortedPairs(affected)
	if len(pairs) == 0 {
		return nil
	}

	caches := &captainCaches{
		rulesByInstance:      make(map[int][]map[string]interface{}),
		policiesByInstanceID: make(map[string]map[string]interface{}),
		blockPagesByInstance: make(map[int]map[string]int),
		sitePaths:            sitePaths,
	}

	for _, p := range pairs {
		actual, err := collectActualResources(tx, excludeSiteBindingIDs, client, caches, p)
		if err != nil {
			return err
		}
		for _, table := range mappingTables {
			ids := setToSortedSlice(actual[table.Name])
			var count int64
			q := tx.Table(table.Name).
				Where("captain_instance_id = ? AND tenant_group_id = ? AND source = ?", p.CaptainInstanceID, p.TenantGroupID, "inherited")
			if len(ids) > 0 {
				q = q.Where(table.Col+" NOT IN ?", ids)
			}
			if err := q.Count(&count).Error; err != nil {
				return err
			}
			fmt.Printf("%s stale inherited mappings to delete for tenant_group_id=%d captain_instance_id=%d: %d\n",
				table.Name, p.TenantGroupID, p.CaptainInstanceID, count)
			if execute && count > 0 {
				if err := deleteStaleInheritedMappings(tx, table, p, ids); err != nil {
					return err
				}
			}
		}
	}
	return nil
}

func deleteStaleInheritedMappings(tx *gorm.DB, table mappingTable, p pair, keepIDs []int) error {
	if len(keepIDs) == 0 {
		return tx.Exec(
			fmt.Sprintf("DELETE FROM %s WHERE captain_instance_id = ? AND tenant_group_id = ? AND source = ?", table.Name),
			p.CaptainInstanceID, p.TenantGroupID, "inherited",
		).Error
	}
	return tx.Exec(
		fmt.Sprintf("DELETE FROM %s WHERE captain_instance_id = ? AND tenant_group_id = ? AND source = ? AND %s NOT IN ?", table.Name, table.Col),
		p.CaptainInstanceID, p.TenantGroupID, "inherited", keepIDs,
	).Error
}

type captainCaches struct {
	rulesByInstance      map[int][]map[string]interface{}
	policiesByInstanceID map[string]map[string]interface{}
	blockPagesByInstance map[int]map[string]int
	sitePaths            *sitePathCache
}

func collectActualResources(tx *gorm.DB, excludeSiteBindingIDs []uint, client *captain.CaptainClient, caches *captainCaches, p pair) (resourceSets, error) {
	actual := make(resourceSets)
	for _, table := range mappingTables {
		actual[table.Name] = make(map[int]struct{})
	}

	var siteIDs []int
	q := tx.Table("site_bindings").
		Where("tenant_group_id = ? AND captain_instance_id = ?", p.TenantGroupID, p.CaptainInstanceID)
	if len(excludeSiteBindingIDs) > 0 {
		q = q.Where("id NOT IN ?", excludeSiteBindingIDs)
	}
	if err := q.Order("site_id ASC").Pluck("site_id", &siteIDs).Error; err != nil {
		return nil, err
	}

	for _, siteID := range siteIDs {
		detail, err := fetchSiteDetail(client, caches.sitePaths, p.CaptainInstanceID, siteID)
		if err != nil {
			if errors.Is(err, errCaptainObjectNotFound) {
				fmt.Printf("[WARN] remaining site_binding still points to missing site: tenant_group_id=%d captain_instance_id=%d site_id=%d\n",
					p.TenantGroupID, p.CaptainInstanceID, siteID)
				continue
			}
			return nil, fmt.Errorf("fetch remaining site detail tenant_group_id=%d instance=%d site=%d: %w",
				p.TenantGroupID, p.CaptainInstanceID, siteID, err)
		}

		policyID := extractIntID(detail["policy_group"])
		if policyID > 0 {
			actual["captain_policy_bindings"][policyID] = struct{}{}
			policyDetail, err := fetchPolicyDetail(client, caches, p.CaptainInstanceID, policyID)
			if err != nil {
				return nil, err
			}
			if path := extractForbiddenPagePath(policyDetail); path != "" {
				blockPageID, err := findBlockPageIDByName(client, caches, p.CaptainInstanceID, path)
				if err != nil {
					return nil, err
				}
				if blockPageID > 0 {
					actual["captain_block_page_bindings"][blockPageID] = struct{}{}
				}
			}
		}

		if certID := extractIntID(detail["ssl_cert"]); certID > 0 {
			actual["captain_cert_bindings"][certID] = struct{}{}
		}
		if groups, ok := detail["proxy_ip_groups"].([]interface{}); ok {
			for _, group := range groups {
				if id := extractIntID(group); id > 0 {
					actual["captain_ip_group_bindings"][id] = struct{}{}
				}
			}
		}

		rules, err := fetchPolicyRules(client, caches, p.CaptainInstanceID)
		if err != nil {
			return nil, err
		}
		for _, rule := range rules {
			if !matchRuleSite(rule, siteID) {
				continue
			}
			if ruleID := getIDFromItem(rule); ruleID > 0 {
				actual["captain_policy_rule_bindings"][ruleID] = struct{}{}
			}
			for _, ipGroupID := range extractInGroupIDs(rule["pattern"]) {
				if ipGroupID > 0 {
					actual["captain_ip_group_bindings"][ipGroupID] = struct{}{}
				}
			}
		}
	}

	return actual, nil
}

func fetchPolicyRules(client *captain.CaptainClient, caches *captainCaches, instanceID int) ([]map[string]interface{}, error) {
	if rules, ok := caches.rulesByInstance[instanceID]; ok {
		return rules, nil
	}

	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       "/api/PolicyRuleAPI",
		Query:      "is_global=false",
		InstanceID: &idUint,
	})
	if err != nil {
		return nil, fmt.Errorf("fetch policy rules instance=%d: %w", instanceID, err)
	}

	items, err := parseListItems(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("parse policy rules instance=%d: %w", instanceID, err)
	}
	caches.rulesByInstance[instanceID] = items
	return items, nil
}

func fetchPolicyDetail(client *captain.CaptainClient, caches *captainCaches, instanceID int, policyID int) (map[string]interface{}, error) {
	key := fmt.Sprintf("%d/%d", instanceID, policyID)
	if detail, ok := caches.policiesByInstanceID[key]; ok {
		return detail, nil
	}

	idUint := uint(instanceID)
	resp, err := client.Do(&captain.CaptainRequest{
		Method:     "GET",
		Path:       fmt.Sprintf("/api/PolicyGroupAPI?id=%d", policyID),
		InstanceID: &idUint,
	})
	if err != nil {
		return nil, fmt.Errorf("fetch policy detail instance=%d policy=%d: %w", instanceID, policyID, err)
	}

	var wrapper struct {
		Err  string                 `json:"err"`
		Data map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(resp.Body, &wrapper); err != nil {
		return nil, fmt.Errorf("parse policy detail instance=%d policy=%d: %w", instanceID, policyID, err)
	}
	if wrapper.Err == "object-not-found" {
		return nil, fmt.Errorf("policy detail not found instance=%d policy=%d", instanceID, policyID)
	}
	caches.policiesByInstanceID[key] = wrapper.Data
	return wrapper.Data, nil
}

func findBlockPageIDByName(client *captain.CaptainClient, caches *captainCaches, instanceID int, name string) (int, error) {
	blockPages, ok := caches.blockPagesByInstance[instanceID]
	if !ok {
		idUint := uint(instanceID)
		resp, err := client.Do(&captain.CaptainRequest{
			Method:     "GET",
			Path:       "/api/ForbiddenPageAPI",
			Query:      "count=1000&offset=0",
			InstanceID: &idUint,
		})
		if err != nil {
			return 0, fmt.Errorf("fetch block pages instance=%d: %w", instanceID, err)
		}
		items, err := parseListItems(resp.Body)
		if err != nil {
			return 0, fmt.Errorf("parse block pages instance=%d: %w", instanceID, err)
		}
		blockPages = make(map[string]int, len(items))
		for _, item := range items {
			itemName, _ := item["name"].(string)
			if itemName == "" {
				continue
			}
			if id := getIDFromItem(item); id > 0 {
				blockPages[itemName] = id
			}
		}
		caches.blockPagesByInstance[instanceID] = blockPages
	}
	return blockPages[name], nil
}

func parseListItems(body []byte) ([]map[string]interface{}, error) {
	var arrayWrapper struct {
		Data []map[string]interface{} `json:"data"`
	}
	if err := json.Unmarshal(body, &arrayWrapper); err == nil && arrayWrapper.Data != nil {
		return arrayWrapper.Data, nil
	}

	var paginatedWrapper struct {
		Data struct {
			Items []map[string]interface{} `json:"items"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &paginatedWrapper); err != nil {
		return nil, err
	}
	return paginatedWrapper.Data.Items, nil
}

func extractForbiddenPagePath(policyDetail map[string]interface{}) string {
	fpc, ok := policyDetail["forbidden_page_config"].(map[string]interface{})
	if !ok {
		return ""
	}
	path, _ := fpc["path"].(string)
	return path
}

func tenantGroupExists(id uint) bool {
	var count int64
	database.DB.Table("tenant_groups").Where("id = ?", id).Count(&count)
	return count > 0
}

func wafBindingExists(tenantGroupID uint, instanceID int) bool {
	var count int64
	database.DB.Table("waf_bindings").
		Where("tenant_group_id = ? AND captain_instance_id = ?", tenantGroupID, instanceID).
		Count(&count)
	return count > 0
}

func ensureSourceColumns() error {
	for _, table := range mappingTables {
		if err := database.DB.Exec(fmt.Sprintf(
			"ALTER TABLE %s ADD COLUMN IF NOT EXISTS source VARCHAR(16) NOT NULL DEFAULT 'created'", table.Name,
		)).Error; err != nil {
			return err
		}
	}
	return nil
}

func sortedPairs(affected map[pair]struct{}) []pair {
	pairs := make([]pair, 0, len(affected))
	for p := range affected {
		pairs = append(pairs, p)
	}
	sort.Slice(pairs, func(i, j int) bool {
		if pairs[i].CaptainInstanceID == pairs[j].CaptainInstanceID {
			return pairs[i].TenantGroupID < pairs[j].TenantGroupID
		}
		return pairs[i].CaptainInstanceID < pairs[j].CaptainInstanceID
	})
	return pairs
}

func setToSortedSlice(set map[int]struct{}) []int {
	ids := make([]int, 0, len(set))
	for id := range set {
		ids = append(ids, id)
	}
	sort.Ints(ids)
	return ids
}

func getIDFromItem(item map[string]interface{}) int {
	if id := extractIntID(item["id"]); id > 0 {
		return id
	}
	return extractIntID(item["ID"])
}

func getFieldString(item map[string]interface{}, keys ...string) string {
	for _, key := range keys {
		if v, ok := item[key].(string); ok {
			return v
		}
	}
	return ""
}

func extractIntID(raw interface{}) int {
	switch v := raw.(type) {
	case float64:
		return int(v)
	case int:
		return v
	case json.Number:
		n, _ := v.Int64()
		return int(n)
	case string:
		var n int
		_, _ = fmt.Sscanf(v, "%d", &n)
		return n
	case map[string]interface{}:
		if id := extractIntID(v["id"]); id > 0 {
			return id
		}
		return extractIntID(v["ID"])
	}
	return 0
}

func extractInGroupIDs(pattern interface{}) []int {
	var ids []int
	walkPattern(pattern, &ids)
	return ids
}

func walkPattern(v interface{}, ids *[]int) {
	switch val := v.(type) {
	case map[string]interface{}:
		if raw, ok := val["ingroup"]; ok {
			if m, ok := raw.(map[string]interface{}); ok {
				for _, idVal := range m {
					if id := extractIntID(idVal); id > 0 {
						*ids = append(*ids, id)
					}
				}
			}
		}
		for _, child := range val {
			walkPattern(child, ids)
		}
	case []interface{}:
		for _, child := range val {
			walkPattern(child, ids)
		}
	}
}

func matchRuleSite(rule map[string]interface{}, siteID int) bool {
	if websites, ok := rule["websites"].([]interface{}); ok {
		for _, w := range websites {
			if extractIntID(w) == siteID {
				return true
			}
		}
	}
	if extractIntID(rule["website"]) == siteID {
		return true
	}
	return false
}
