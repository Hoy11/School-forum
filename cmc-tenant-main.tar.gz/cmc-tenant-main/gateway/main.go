// Package main is the entry point for the CMC Tenant gateway server.
package main

import (
	"flag"
	"fmt"
	"log"

	"github.com/chaitin/cmc-tenant/config"
	"github.com/chaitin/cmc-tenant/server"
)

func main() {
	env := flag.String("env", "development", "config environment name")
	flag.Parse()

	cfg := config.Load(*env)

	server.Init(cfg)

	r := server.SetupRouter(cfg)

	addr := fmt.Sprintf(":%d", cfg.Server.Port)
	log.Printf("server starting on %s", addr)
	if err := r.Run(addr); err != nil {
		log.Fatalf("server run: %v", err)
	}
}
