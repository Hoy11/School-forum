# CMC Tenant — 多租户管理平台

基于纵横（Captain-2）v24.06.001_r25 的 API 进行二次包装，增加多租户能力。本平台不直接对接 WAF 设备，所有 WAF 操作经纵横中转。认证体系独立，日志查询透传纵横。

## 核心特性

- **三级角色**：admin（全局管理员）> tenant_admin（租户管理员）> tenant（普通租户）
- **独立认证**：自建 JWT + API Token 体系，不依赖纵横；密码策略/登录安全可配置
- **租户隔离**：IP组/SSL证书/防护策略/自定义规则通过映射表隔离，站点/日志通过绑定过滤
- **风险检查**：站点创建/修改时的 IP:Port 冲突检测 + WAF 操作频率限制（30s 冷却）
- **熔断保护**：Captain-2 代理层熔断器（Closed → Open → HalfOpen）
- **纵横代理**：站点管理、日志查询、IP组、SSL证书、防护策略、自定义规则等均代理到纵横 API
- **审计日志**：全量写操作审计，支持条件数组过滤查询
- **SOC 上报**：日志一键上报到已配置的 SOC 接收端

## 技术栈

| 层 | 选型 |
|---|---|
| 后端 | Go 1.21+ / Gin / GORM / PostgreSQL 15 / Redis 7 |
| 前端 | Vue 2.6 + TypeScript / vue-class-component + TSX / @splat/* + @safeline-2/* + Element UI 2.x / Webpack 4 / Vuex 3 |
| 部署 | Docker Compose / Nginx |

> 前端技术栈与纵横保持一致，最大化复用纵横已有业务实现。

## 后端开发进度

| Phase | 内容 | 状态 |
|---|---|:---:|
| 1 | 项目骨架 + 基础设施（Gin/GORM/Viper/JWT/Redis） | ✅ |
| 2 | 数据模型（16张表 AutoMigrate + 默认 admin） | ✅ |
| 3 | 中间件链（Recovery/Logger/Auth/Permission/TenantContext/Audit） | ✅ |
| 4 | 认证与用户 API（登录/登出/用户CRUD/API Token/个人设置） | ✅ |
| 5 | 租户组与业务绑定（租户组CRUD/WAF绑定/站点绑定/高亮IP） | ✅ |
| 6 | CaptainClient + 代理层（HTTP客户端/熔断/租户过滤/风险检查） | ✅ |
| 7 | 纵横代理 API（站点/日志/IP组/SSL/策略/自定义规则/日志下载/标记/筛选） | ✅ |
| 8 | 系统管理与 SOC（SOC配置/纵横配置/审计/密码策略/登录安全/SOC上报） | ✅ |

> 全部 8 个 Phase 开发完成，已通过逐 spec 审计对齐。

## 数据库表（16张）

| 表名 | 用途 |
|---|---|
| users | 用户（含软删除、锁定、密码策略） |
| tenant_groups | 租户组 |
| api_tokens | API Token 管理 |
| waf_bindings | 租户组 ↔ WAF 设备 |
| site_bindings | 租户组 ↔ WAF 站点（UNIQUE instance_id + site_id） |
| captain_ip_group_bindings | 租户组 ↔ IP组 |
| captain_cert_bindings | 租户组 ↔ SSL证书 |
| captain_policy_bindings | 租户组 ↔ 防护策略 |
| captain_policy_rule_bindings | 租户组 ↔ 自定义规则 |
| captain_log_tasks | 租户组 ↔ 日志下载任务 |
| highlight_ips | 高亮 IP（CIDR，GiST 索引） |
| audit_logs | 审计日志（JSONB detail） |
| soc_configs | SOC 配置 |
| system_configs | 通用系统配置（key-value，JSONB value） |
| captain_configs | 纵横连接配置 |
| highlight_tag_configs | 标记颜色配置 |

## API 概览

| 模块 | 路径前缀 | 权限 |
|---|---|---|
| 认证 | `/api/auth` | 全角色 |
| 全局用户管理 | `/api/user` | admin |
| 组内用户管理 | `/api/tenant/user` | tenant_admin |
| API Token | `/api/user/api_token` | 全角色（仅自己的） |
| 个人设置 | `/api/user/current` | 全角色 |
| 租户组管理 | `/api/tenant-group` | admin |
| 业务绑定 | `/api/binding` | admin |
| 高亮 IP | `/api/highlight-ip` | 全角色查看，admin 增删改 |
| 纵横代理 | `/api/captain/*` | 全角色（自动租户过滤） |
| 系统管理 | `/api/system/*` | admin |
| SOC 上报 | `/api/soc/report` | 全角色 |

## 目录说明

```
cmc-tenant/
├── requirements/          # 需求文档
├── spec/                  # 架构设计文档
├── cmc_rpc/               # 纵横 API 接口提取（17个分类文档）
├── frontend/              # 前端代码（Vue 2 + TSX）
├── gateway/               # 后端代码（Go / Gin）
│   ├── main.go            # 入口
│   ├── config/            # Viper 配置加载
│   ├── server/            # HTTP 服务、路由、中间件
│   │   ├── midware/       # Recovery/Logger/Auth/Permission/TenantContext/Audit
│   │   └── apis/          # 各模块 handler
│   ├── domain/            # 业务层（model + business/operator）
│   ├── pkg/               # 基础设施（captain/risk_guard/database/jwt）
│   └── utils/             # 工具函数
└── deploy/                # Docker Compose 部署配置与工具
```

## 依赖服务

- PostgreSQL 15 — 本地业务数据（16张表）
- Redis 7 — 频率限制 / 高亮IP缓存 / 登录锁定
- Captain-2（纵横）— WAF 管理平台，本平台代理其 API
- Nginx — 反向代理 + 静态资源

## 本地开发

```bash
# 启动依赖
docker compose up postgres redis

# 后端开发（需 air）
cd gateway && air

# 前端开发
cd frontend/packages/skyview-web && npm install && npm run dev
```

### 后端测试

```bash
cd gateway && go test ./... -v -count=1
```

### 代码检查（lint → build → e2e）

CI 流水线按 `lint → build → e2e` 顺序执行，lint 不过则不会进入构建阶段。

**前端 lint：**

```bash
cd frontend && pnpm install && pnpm lerna run lint --stream
```

**后端 lint（golangci-lint v2）：**

```bash
cd gateway && go install github.com/golangci/golangci-lint/v2/cmd/golangci-lint@v2.12.2 && golangci-lint run ./...
```

> 配置文件：`.golangci.yml`（v2 格式），启用了 errcheck / govet / staticcheck / unused / ineffassign / gocritic / revive / misspell。

## 开发要求

- SDD 驱动，SPEC 编写遵循 [规范](https://dev.in.chaitin.net/node/019d293d-ed80-7724-a93c-8ba1d5b8f64d)

## npm registry 配置

```ini
# frontend/.npmrc
registry=http://npm.in.chaitin.net
@splat:registry=https://git.in.chaitin.net/api/v4/packages/npm/
@safeline-2:registry=https://git.in.chaitin.net/api/v4/projects/2359/packages/npm/
strict-ssl=false
```
